function [a, v30, err] = priceerror_vvmr(vol,alf,asof,cusips)
cusips = sortrows(cusips,1);

[pr_est, err] = calcprices(vol,alf,asof,cusips);

a = zeros(length(vol),length(alf));
v30 = zeros(length(vol),length(alf));
for i = 1:length(vol)
    for j = 1:length(alf)
        prs = pr_est(abs(pr_est.Vol - vol(i)) < 1e-6 & abs(pr_est.Alpha - alf(j)) < 1e-6,:);
        prs = sortrows(prs,1);
        if size(prs,1) == size(cusips,1) 
            a(i,j) = sum((cusips.Price - prs.Price).^2);
            v30(i,j) = mean(prs.Vol30);
        else
            a(i,j) = 1e6;
            err = 1;
        end
    end
end
