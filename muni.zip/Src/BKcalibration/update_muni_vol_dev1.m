function a = update_muni_vol(asof,varargin)


usecurve = 1;
useterms = 25;

if sum(strcmp('nocurve',varargin)) > 0 
    usecurve = 0;
end

if sum(strcmp('useterms',varargin)) > 0
    useterms = cell2mat(varargin(find(strcmp('useterms',varargin)) + 1));
end

global kalotayDLLPath kalotayDLL kalotayCLS

kalotayDLLPath = 'H:\MATLAB\Kalotay\RAP.KalotayWrapper.dll';
%kalotayDLLPath = 'C:\ABFI_PROD\QuantApps\MATLAB\Kalotay\RAP.KalotayWrapper.dll';
kalotayDLL = NET.addAssembly(kalotayDLLPath);
kalotayCLS = RAP_KalotayWrapper.KalotayWrapper;

%FIQ_USER = 'user_app_Optimizer';
%FIQ_PWD = 'nsv613vj';
%conn = database('fiqdbprod',FIQ_USER, FIQ_PWD);
%conn = database('fiqdbqa','FIQ_USER','FIQ_PWD');

%addpath([ getenv('ABFI_MODEL_HOME') '\Utility\MatLab']);
InitVariables_FULL_QA;


% get calibratioin set
%curs = exec(conn,['exec MUNI..GET_MUNI_VOL_CALIB ''' datestr(asof) '''']);
curs_SQL = sprintf('exec MUNI..GET_MUNI_VOL_CALIB ''%s'' ',asof);
curs=ExecuteSQL(curs_SQL);

%curs = fetch(curs);
alldata = curs.Data';
alldata = cell2table(alldata(:,1:2),'VariableNames',{'Cusip','Price'});
alldata.Cusip = cell2mat(alldata.Cusip);
alldata.Cusip = alldata.Cusip(:,1:8);

curs = ExecuteSQL('select * from MUNI.dbo.LONG_TERM_VOL_CALIB_CUISPS');
ltcusips = curs.Data';

nclcusips = ltcusips(:,1);
clcusips = ltcusips(:,2);

q = ['select EFFECTIVE_DATE date, IDENTIFIER cuisp, PRICE price, convert(date,ISSUE_DATE) idate from Optimizer.dbo.MUNI_ANALYTICS_KALOTAY ' ...
        'where EFFECTIVE_DATE = ''' asof ''' ' ...
        'and SOURCE = ''Index'' ' ...
        'and IDENTIFIER in (''' strjoin([nclcusips;clcusips],''',''') ''') ' ...
        'order by EFFECTIVE_DATE,IDENTIFIER'];
    
curs = ExecuteSQL(q);    
ledata = curs.Data';
ledata = cell2table(ledata,'VariableNames',{'Date','Cusip','Price','IssueDate'});
ledata.Cusip = cell2mat(ledata.Cusip);
ledata.Date = datetime(cell2mat(ledata.Date),'InputFormat','yyyy-MM-dd');
ledata.IssueDate = datetime(cell2mat(ledata.IssueDate),'InputFormat','yyyy-MM-dd');

q = ['select * from MUNI.dbo.LONG_TERM_VOL_CALIB_CUISPS'];

curs = ExecuteSQL(q);    
cusdata = curs.Data';

nclcusips = cusdata(:,1);
clcusips = cusdata(:,2);

q = ['select EFFECTIVE_DATE date, IDENTIFIER cuisp, PRICE price, convert(date,ISSUE_DATE) idate from Optimizer.dbo.MUNI_ANALYTICS_KALOTAY ' ...
        'where EFFECTIVE_DATE = ''' asof ''' ' ...
        'and SOURCE = ''Index'' ' ...
        'and IDENTIFIER in (''' strjoin([nclcusips;clcusips],''',''') ''') ' ...
        'order by EFFECTIVE_DATE,IDENTIFIER'];
    
   % 'and MOODY_RATING = ''AAA'' ' ...
curs = ExecuteSQL(q); 
ledata = curs.Data';
ledata = cell2table(ledata,'VariableNames',{'Date','Cusip','Price','IssueDate'});
ledata.Cusip = cell2mat(ledata.Cusip);
ledata.Date = datetime(cell2mat(ledata.Date),'InputFormat','yyyy-MM-dd');
ledata.IssueDate = datetime(cell2mat(ledata.IssueDate),'InputFormat','yyyy-MM-dd');

flds = join(cellstr([repmat('POINT_',length(useterms),1) num2str(12*reshape(useterms,[length(useterms) 1])) repmat('M',length(useterms),1)]),',');

q = ['select AS_OF_DATE,' char(flds) ' FROM FIQModel.dbo.YIELD_CURVE_TIMESERIES ' ...
  'where YC_NAME = ''MuniMMDCVNONCAL'' ' ...
  'and AS_OF_DATE = ''' asof ''''];

curs = ExecuteSQL(q); 
crv = curs.Data';
crv = cell2table(crv(1,2:end));

volstart = 90;
if datenum(asof) <= datenum('2008-05-31')
    volstart = 45;
end
if datenum(asof) >= datenum('2011-09-30') & datenum(asof) <= datenum('2013-02-28')
    volstart = 70;
end

asofsys = System.DateTime.Parse(datestr(asof));

tic;
[cldata, voltop, sstat, curv] = prep_calib_set(asofsys,alldata,volstart);
toc;

% check if noncallable run thru ok
[tm,ia,ib] = intersect(ledata.Cusip,nclcusips);
nclsecs = ledata(ia,:);
tic;
nclsecs_cl = check_ncl(asofsys,nclsecs(:,2:end),volstart);
toc;
% check if callable run thru ok
[tm,ia,ib] = intersect(ledata.Cusip,clcusips);
clsecs = ledata(ia,:);
tic;
clsecs_cl = check_cl(asofsys,clsecs(:,2:end),volstart);
toc;

volout = 0;
alphaout = 0;
if size(cldata,1) > 0 & size(nclsecs_cl,1) > 0 & size(clsecs_cl,1) > 0
    % set  up ncl/cl pairs
    nclcusipsdata = [];
    clcusipsdata = [];
    for i = 1:size(nclcusips,1)
        if sum(strcmp(nclcusips(i),nclsecs_cl.Cusip)) > 0 & sum(strcmp(clcusips(i),clsecs_cl.Cusip))
            nclcusipsdata = [nclcusipsdata; nclsecs_cl(strcmp(nclcusips(i),nclsecs_cl.Cusip),1:size(nclsecs_cl,2)-2)];
            clcusipsdata = [clcusipsdata; clsecs_cl(strcmp(clcusips(i),clsecs_cl.Cusip),1:size(clsecs_cl,2)-2)];
        end
    end
    
    usesecs = 1:size(nclcusipsdata,1);
    Nd = size(nclcusipsdata,1);
    
    % weit the pairs using average time since issuance
    weit = max([years(asof - nclcusipsdata.IssueDate) years(asof - clcusipsdata.IssueDate)]')';
    weit = interp1([max(weit) 0],[0.2 1],weit);
    weit = weit/sum(weit);
    
    % define a grid of vol/mean reversion (coarse)
    v = 5:5:voltop;
    alf = 0:0.5:6;
    tic;
    [prer, v30, err] = priceerror_vvmr(v,alf,System.DateTime.Parse(datestr(asof)),cldata);
    toc;
    
    % penalty function in vol 30y
    
    use25 = 0;
    lttarg = 15; % target long term volatility
    if sum(v30 - v25 > 0.5) > 0
        disp('Possible issue with v30, switching to v25')
        v30 = v25;
        lttarg = 16;
        use25 = 1;
    end
    
    lttv = v';
    lttv(v < 2*lttarg) = v(v < 2*lttarg)/2;
    lttv(v >= 2*lttarg) = lttarg;
    
    v30 = (v30 - lttv).^2;
    
    if err % remove erroneous points before computing the scalar
        t1 = prer;
        t1(t1 == 1e6) = 0;
        prer(prer == 1e6) = max(max(t1));
    end
    sc = 1.*(max(max(prer)) - min(min(prer)))/(max(max(v30)) - min(min(v30)));
    
    ofunc = prer + sc*v30; % function to minimize
    %ofunc(st0) = prer(st0) + 0.4*sc*v30(st0); %reduced penalty if below target vol
    
    [voli, alfi] = find(ofunc == min(min(ofunc)));
    
    % define a grid of vol/mean reversion (fine)
    v = v(voli)-5:v(voli)+5;
    alf = alf(alfi)-0.4:0.1:alf(alfi)+0.4;
    alf = alf(alf >= 0);
    tic;
    [prer, v30, v25, err] = priceerror_vvmr(v,alf,System.DateTime.Parse(datestr(asof)),cldata);
    toc;
    
    if use25
        v30 = v25;
    end
    % penalty function in vol 30y
    
    lttv = v';
    lttv(v < 2*lttarg) = v(v < 2*lttarg)/2;
    lttv(v >= 2*lttarg) = lttarg;
    
    v30 = (v30 - lttv).^2;
    
    ofunc = prer + sc*v30; % function to minimize
    [voli alfi] = find(ofunc == min(min(ofunc)));
    
    %%%%% second stage: use both ncl mmd curve and ncl/cl pairs to calibrate mean reversion 
    alf = 1:1:20;
    
    tic;
    [oaser, err] = oaserror(v(voli),alf,asof,nclcusipsdata(usesecs,:),clcusipsdata(usesecs,:),weit);
    toc;
    
    volout = v(voli);
    alphaout = alf(alfi);

    display([datestr(asof) ' ' num2str(volout) ' ' num2str(alphaout)]);
    a = cell2table({datestr(asof) volout alphaout},'VariableNames',{'Date','Vol','Alpha'}); 
end

%fastinsert(conn, 'MUNI.dbo.BK_PARAMETERS',{'AS_OF_DATE','MUNI_VOL','MEAN_REV'},[{asof} {volout} {alphaout}])
del_SQL=sprintf('delete MUNI.dbo.BK_PARAMETERS where AS_OF_DATE = ''%s''' ,asof);
ExecuteSQL(del_SQL);

ins_SQL=sprintf('insert into MUNI.dbo.BK_PARAMETERS (AS_OF_DATE, MUNI_VOL, MEAN_REV) values (''%s'',%.20f,%.20f)\n', asof, volout, alphaout);
ExecuteSQL(ins_SQL);


        
        
