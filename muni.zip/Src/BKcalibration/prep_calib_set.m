function [cldata, vupp, stat, curve] = prep_calib_set(asof,data,vols)
global kalotayDLLPath kalotayDLL kalotayCLS

seclist = NET.createGeneric('System.Collections.Generic.List',{'System.String'},1);
vollist = NET.createGeneric('System.Collections.Generic.List',{'System.Double'},1);
mrev = NET.createGeneric('System.Collections.Generic.List',{'System.Double'},1);

vollist.Add(15)
mrev.Add(0)

for i = 1:size(data,1)
    seclist.Add([data{i,1} ',0']);
end

cldata = data;

tic;
output =  kalotayCLS.CalculateByVolatilityAlphaVectors(asof,seclist,'OAS',vollist,mrev);
toc;

curve = parsecurve(char(output.Item(0)));

irem = [];
cldata = [cldata num2cell(ones(size(cldata,1),1))];
is8 = length(cldata{1,1}) == 8;

for i = 1:output.Count
    t = char(output.Item(i-1)); 

    if isempty(regexp(t,'Kalotay Fail','ONCE')) && isempty(regexp(t,'Kalotay API failed','ONCE')) && isempty(regexp(t,'No BBO data','ONCE')) ...
            && isempty(regexp(t,'Unknown Refund','ONCE')) && isempty(regexp(t,'GetMuniSecurity failed','ONCE'))
        t = regexprep(t,' ','');
        tc = regexp(t,'Cusip');
        cusip = t(tc(1)+6:tc(2)-3);
        cusip = cusip(1:8);
        isec = find(strcmp(cellstr(cldata{:,1}),cusip(1:8)));
        cldata{isec,3} = 0;
    end
end
nodata = sum(cldata{:,3});
irem = find(cldata{:,3});
cldata(irem,:) = [];
cldata = cldata(:,1:2);

for i = 1:length(irem)
    seclist.RemoveAt(irem(end-i+1)-1);
end
insens = 0;
tcheap = 0;
trich = 0;
vupp = vols;
if size(cldata,1) > 0
    ex = 0;
    
    while ~ex
        vupp = vupp - 5;
        [prt, err] = calcprices([5 vupp],0,asof,cldata);
        if err
            ex = ~err;
        else
            ex = sum(prt.Price(prt.Vol == vupp) ~= 0) == size(cldata,1) | vupp <20;
        end
    end
    cldata.lvol = zeros(size(cldata,1),1);
    cldata.hvol = zeros(size(cldata,1),1);
    
    if is8
        t = cell2mat(prt.Cusip);
        prt.Cusip = cellstr(t(:,1:8));
    end    
    
    for i = 1:size(cldata)
        cldata.lvol(i) = prt.Price(strcmp(cldata{i,1},prt.Cusip) & prt.Vol == 5);
        cldata.hvol(i) = prt.Price(strcmp(cldata{i,1},prt.Cusip) & prt.Vol == vupp);
    end
    
    sns = 0.5; % threshold to catch securities not sensitive to vol
    irem = find(cldata.lvol - cldata.hvol < sns | cldata.hvol - cldata.Price > 0  | cldata.Price - cldata.lvol > 0);
    insens = sum(cldata.lvol - cldata.hvol < sns);
    tcheap = sum(cldata.hvol - cldata.Price > 0 & cldata.lvol - cldata.hvol > sns);
    trich = sum(cldata.Price - cldata.lvol > 0 & cldata.lvol - cldata.hvol > sns);
    
    cldata(irem,:) = [];

    for i = 1:length(irem)
        seclist.RemoveAt(irem(end-i+1)-1);
    end
end
if size(cldata,1) > 0
    display(cldata);   
end
display(['All: ',num2str(size(data,1)),' NoData: ', num2str(nodata), ' Insensitive: ',num2str(insens),' Too cheap: ',num2str(tcheap), ' Too rich: ', num2str(trich)])

stat = [size(data,1), nodata, insens, tcheap, trich];




