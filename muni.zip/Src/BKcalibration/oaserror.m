function [a, v30, err] = oaserror(vol,alf,asof,ncld,cld,w)
tic;
[oas_ncl, err] = calcoas(vol,alf,asof,[ncld;cld]);
a = zeros(length(vol),length(alf));
v30 = zeros(length(vol),length(alf));
toc;
for i = 1:length(vol)
    for j = 1:length(alf)
        ncl = oas_ncl(abs(oas_ncl.Vol - vol(i)) < 1e-10 & abs(oas_ncl.Alpha - alf(j)) < 1e-10,:);
        %cl = oas_cl(abs(oas_cl.Vol - vol(i)) < 1e-10 & abs(oas_cl.Alpha - alf(j)) < 1e-10,:);
        if size(ncl,1) > 0
            ser = 0;
            for k = 1:size(ncld,1)
                ser = ser + w(k)*(ncl.OAS(strcmp(ncld.Cusip(k,:),ncl.Cusip)) - ncl.OAS(strcmp(cld.Cusip(k,:),ncl.Cusip)))^2;
            end
            a(i,j) = ser;
            v30(i,j) = oas_ncl.Vol30(1);
        else
            a(i,j) = 1e6;
        end
    end
end
