
res = table();
for i = 1:length(dates)
   res = [res; update_muni_vol_dev_prod(dates(i))];
   save res res
end