function a = update_muni_vol_dev1_prod(asof)

global kalotayDLLPath kalotayDLL kalotayCLS

kalotayDLLPath = 'H:\MATLAB\Kalotay\RAP.KalotayWrapper.dll';
%kalotayDLLPath = 'C:\ABFI_PROD\QuantApps\MATLAB\Kalotay\RAP.KalotayWrapper.dll';
kalotayDLL = NET.addAssembly(kalotayDLLPath);
kalotayCLS = RAP_KalotayWrapper.KalotayWrapper;

FIQ_USER = 'user_app_Optimizer';
FIQ_PWD = 'nsv613vj';
conn = database('fiqdbprod',FIQ_USER, FIQ_PWD);
%conn = database('fiqdbqa','FIQ_USER','FIQ_PWD');

%addpath([ getenv('ABFI_MODEL_HOME') '\Utility\MatLab']);
%InitVariables_FULL_QA;

% get calibratioin set

q = ['select IDENTIFIER cuisp, PRICE price, PRICE_FULL pricef from Optimizer.dbo.MUNI_ANALYTICS_KALOTAY ' ...
        'where EFFECTIVE_DATE = ''' datestr(asof) ''' ' ...
        'and SOURCE = ''Index'' ' ...
        'and DATEDIFF(DAY, EFFECTIVE_DATE, MATURITY_DATE)/365.25 < 10.0 ' ...
        'and DATEDIFF(DAY, EFFECTIVE_DATE, NEXT_CALL_DATE)/365.25 > 2.0 ' ...
        'and CALL_TYPE IN (''CALLABLE'', ''CALL/RF'') ' ...      
        'and UPPER(SP_RATING) = ''AAA'' ' ...
        'and UPPER(MOODY_RATING) = ''AAA'' ' ...
        'and COUPON = 5.0 ' ... %and PURPOSE_TYPE = ''Muni GO'' ' ... %'and PURPOSE_CLASS = ''Muni State'' ' ...
        'and DATEDIFF(DAY, NEXT_CALL_DATE, MATURITY_DATE)/365.25 > 2.9 ' ...
        'and STATE in (''MD'', ''VA'',''NC'') ' ...
        'AND PURPOSE_TYPE <> ''Muni PRE'' ' ...
        'AND MUNI_TAXABILITY not in (''FED TAXABLE/ST TAX-EXEMPT'',''FED TAXABLE/ST TAXABLE'', ' ...
        ' ''FED TAXABLE/ST&PR EXMPT'',''FED TAXABLE/CMWLTH EXMPT'',''FED TAXABLE'') ' ...
        'order by EFFECTIVE_DATE,IDENTIFIER'];

q = ['SELECT SP.CUSIP, SP.PRICE ' ...				 
        'FROM MUNI.dbo.SECURITY_PRICE SP ' ...
        'INNER JOIN MUNI.bbo.SECURITY S ' ... 
        'ON ( LEFT(SP.CUSIP, 8) = LEFT(S.CUSIP, 8) ) ' ...
        'WHERE SP.VALUE_DATE = ''' datestr(asof) ''' ' ...
        'AND SP.IS_BENCHMARK = 1 ' ...
        'AND S.CALLABLE = ''Y'' ' ...
        'AND DATEDIFF(DAY, SP.VALUE_DATE, S.MATURITY)/365.25 < 10.0 ' ...
        'AND DATEDIFF(DAY, SP.VALUE_DATE, S.NXT_CALL_DT)/365.25 > 2.0 ' ...
        'AND UPPER(S.RTG_MOODY) = ''AAA'' ' ...
        'AND UPPER(S.RTG_SP) = ''AAA'' ' ...
        'AND S.CPN = 5.0 ' ...
        'AND DATEDIFF(DAY, S.NXT_CALL_DT, S.MATURITY)/365.25 > 2.9 ' ...
        'AND S.STATE_CODE IN (''MD'', ''VA'', ''NC'')  ' ...
        'AND S.MUNI_ADV_RFND_TYP != ''PREREFUNDED'' ' ...
        'ORDER BY 1'];
    
%curs = exec(conn,['exec MUNI..GET_MUNI_VOL_CALIB ''' datestr(asof) '''']);
%curs_SQL = sprintf('exec MUNI..GET_MUNI_VOL_CALIB ''%s'' ',asof);
%curs=ExecuteSQL(curs_SQL);

curs = exec(conn, q);
curs = fetch(curs);
alldata = curs.Data;
alldata = cell2table(alldata(:,1:2),'VariableNames',{'Cusip','Price'});
alldata.Cusip = cell2mat(alldata.Cusip);
alldata.Cusip = alldata.Cusip(:,1:8);

volstart = 90;
if datenum(asof) <= datenum('2008-05-31')
    volstart = 45;
end
if datenum(asof) >= datenum('2011-09-30') & datenum(asof) <= datenum('2013-02-28')
    volstart = 70;
end
    
tic;
[cldata, voltop, sstat, curv] = prep_calib_set(System.DateTime.Parse(datestr(asof)),alldata,volstart);
toc;

volout = 0;
alphaout = 0;
if size(cldata,1) > 0
    % define a grid of vol/mean reversion (coarse)
    v = 5:5:voltop;
    alf = 0:1:10;
    tic;
    [prer, v30, err] = priceerror_vvmr(v,alf,System.DateTime.Parse(datestr(asof)),cldata);
    toc;
    % penalty function in vol 30y
    
    lttarg = 15; % target long term volatility
    
    lttv = v';
    lttv(v < 2*lttarg) = v(v < 2*lttarg)/2;
    lttv(v >= 2*lttarg) = lttarg;
    
    v30 = (v30 - lttv).^2;
    
    if err % remove erroneous points before computing the scalar
        t1 = prer;
        t1(t1 == 1e6) = 0;
        prer(prer == 1e6) = max(max(t1));
    end
    sc = 1.*(max(max(prer)) - min(min(prer)))/(max(max(v30)) - min(min(v30)));
    
    ofunc = prer + sc*v30; % function to minimize
    %ofunc(st0) = prer(st0) + 0.4*sc*v30(st0); %reduced penalty if below target vol
    
    [voli, alfi] = find(ofunc == min(min(ofunc)));
    
    % define a grid of vol/mean reversion (fine)
    v = v(voli)-5:v(voli)+5;
    alf = alf(alfi)-0.9:0.1:alf(alfi)+0.9;
    alf = alf(alf >= 0);
    tic;
    [prer, v30, err] = priceerror_vvmr(v,alf,System.DateTime.Parse(datestr(asof)),cldata);
    toc;
    
    % penalty function in vol 30y
    
    lttv = v';
    lttv(v < 2*lttarg) = v(v < 2*lttarg)/2;
    lttv(v >= 2*lttarg) = lttarg;
    
    v30 = (v30 - lttv).^2;
    
    ofunc = prer + sc*v30; % function to minimize
    %ofunc(st0) = prer(st0) + 0.4*sc*v30(st0); %reduced penalty if below target vol
    [voli alfi] = find(ofunc == min(min(ofunc)));
    
    volout = v(voli);
    alphaout = alf(alfi);

    display([datestr(asof) ' ' num2str(volout) ' ' num2str(alphaout)]);
    a = cell2table({datestr(asof) volout alphaout},'VariableNames',{'Date','Vol','Alpha'}); 
end

%fastinsert(conn, 'MUNI.dbo.BK_PARAMETERS',{'AS_OF_DATE','MUNI_VOL','MEAN_REV'},[{asof} {volout} {alphaout}])
%del_SQL=sprintf('delete MUNI.dbo.BK_PARAMETERS where AS_OF_DATE = ''%s''' ,asof);
%ExecuteSQL(del_SQL);

%ins_SQL=sprintf('insert into MUNI.dbo.BK_PARAMETERS (AS_OF_DATE, MUNI_VOL, MEAN_REV) values (''%s'',%.20f,%.20f)\n', asof, volout, alphaout);
%ExecuteSQL(ins_SQL);


        
        
