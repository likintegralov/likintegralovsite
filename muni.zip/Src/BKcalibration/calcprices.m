function [a, err] = calcprices(vol,mr,asof,data)
global kalotayDLLPath kalotayDLL kalotayCLS 

vollist = NET.createGeneric('System.Collections.Generic.List',{'System.Double'},1);
cusips = NET.createGeneric('System.Collections.Generic.List',{'System.String'},1);
mrlist = NET.createGeneric('System.Collections.Generic.List',{'System.Double'},1);

for i = 1:length(vol)
    for j = 1:length(mr)
        vollist.Add(vol(i))
        mrlist.Add(mr(j))
    end
end
for i = 1:size(data,1)
    cusips.Add([data{i,1} ',0']);
end

output =  kalotayCLS.CalculateByVolatilityAlphaVectors(asof,cusips,'OAS',vollist,mrlist);
display(['Kalotay results in ' num2str(output.Count) ' records']);

if output.Count == 1
    t = char(output.Item(0));
    display(t);
    save kout t
end

a = table();
err = 0;
if output.Count > 0

    for i = 1:output.Count
        
        t = char(output.Item(i-1));
        if isempty(regexp(t,'Kalotay Fail')) && isempty(regexp(t,'Kalotay API failed')) && isempty(regexp(t,'Kalotay API Halt Failure')) && isempty(regexp(t,'Object reference not set'))
            ccurv = parsecurve(t);
            if size(ccurv.curve,1) < size(ccurv.vol,1)
                err = 1;
                return
            end
            tc = regexp(t,'Cusip');
            cusip = t(tc(1)+6:tc(2)-3);
            cusip = cusip(1:8);
            if isempty(regexp(t,'No BBO data'))
                t1 = regexp(t,'Price');
                if ~isempty(t1)
                    
                    tv = regexp(t,'Vol');
                    ta = regexp(t,'Alpha');
                    v = str2double(t(tv(2)+4:ta(1)-2));
                    tat = t(ta(1)+6:ta(1)+10);
                    alpha = str2double(tat(1:regexp(tat,'<')-1));
                    pr = str2double(t(t1(1)+6:t1(1)+16));
                    %long term vol
                    tltv = regexp(t,'Curve_VOL');
                    vcrv = t(tltv(1):tltv(2));
                    t2 = regexp(vcrv,'year="30"');
                    v30 = vcrv(t2:t2+50);
                    t2 = regexp(v30,'rate');
                    v30 = str2double(v30(t2+6:t2+10));
                    if ~isnan(pr)
                        a = [a; table(cellstr(cusip),v,alpha,pr,v30,'VariableNames',{'Cusip','Vol','Alpha','Price','Vol30'})];
                    end
                end
            else
                disp('Error: missing data on consequitive calls'); break;
            end
        end
    end
else
    disp('No output');    err = 1;
end

