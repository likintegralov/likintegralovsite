function a = parsecurve(xmlobj)

t = regexp(xmlobj,'Curve_NCL');
ctext = xmlobj(t(1):t(2));

tinx = regexp(ctext,'year');
tenors = zeros(length(tinx),1);
for i = 1:length(tinx)
   % ctext(tinx(i)+6:tinx(i)+12)
    tenors(i) = str2double(ctext(tinx(i)+6:tinx(i)+12));
end

rinx = regexp(ctext,'rate');
rates = zeros(length(rinx),1);
for i = 1:length(tinx)
    rates(i) = str2double(ctext(rinx(i)+6:rinx(i)+12));
end

a.curve = [tenors rates];

t = regexp(xmlobj,'Curve_VOL');
ctext = xmlobj(t(1):t(2));

tinx = regexp(ctext,'year');
tenors = zeros(length(tinx),1);
for i = 1:length(tinx)
   % ctext(tinx(i)+6:tinx(i)+12)
   tl = ctext(tinx(i)+2:tinx(i)+30);
   tt = regexp(tl,'"');
    tenors(i) = str2double(tl(tt(1)+1:tt(2)-1));
end

rinx = regexp(ctext,'rate');
rates = zeros(length(rinx),1);
for i = 1:length(tinx)
    rates(i) = str2double(ctext(rinx(i)+6:rinx(i)+12));
end

a.vol = [tenors rates];