function [a, err] = curverror(vol,alf,asof,cusip,crv,term)
tic;
[oas_ncl, err] = calccurve(vol,alf,asof,cusip,term);
a = zeros(length(vol),length(alf));
toc;
for i = 1:length(vol)
    for j = 1:length(alf)
        ncl = oas_ncl(abs(oas_ncl.Vol - vol(i)) < 1e-10 & abs(oas_ncl.Alpha - alf(j)) < 1e-10,:);
        
        if size(ncl,1) > 0
            a(i,j) = sum((table2array(ncl(1,4:size(oas_ncl,2))) - table2array(crv)).^2);
        else
            a(i,j) = 1e6;
        end
    end
end
