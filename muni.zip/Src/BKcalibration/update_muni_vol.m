function a = update_muni_vol(asof,varargin)


usecurve = 1; % controls if non-callable MMD curve should be used for long-term vol calibration
useterms = 25; % maturities in years of MMD curve to be used (allowed multiple maturiites) 

if sum(strcmp('nocurve',varargin)) > 0 
    usecurve = 0;
end

if sum(strcmp('useterms',varargin)) > 0
    useterms = cell2mat(varargin(find(strcmp('useterms',varargin)) + 1));
end

% setting up Kalotay interface
global kalotayDLLPath kalotayDLL kalotayCLS

%kalotayDLLPath = 'H:\MATLAB\Kalotay\RAP.KalotayWrapper.dll';
kalotayDLLPath = 'C:\ABFI_PROD\QuantApps\MATLAB\Kalotay\RAP.KalotayWrapper.dll';
kalotayDLL = NET.addAssembly(kalotayDLLPath);
kalotayCLS = RAP_KalotayWrapper.KalotayWrapper;

%addpath([ getenv('ABFI_MODEL_HOME') '\Utility\MatLab']);
%InitVariables_FULL_QA;  % uncomment to run the script as stand along


% get calibratioin set for short term vol
% calibration set consists of MD,VA,NC 5% AAA bonds, maturity < 10y, calls > 2y, call life > 3y   

curs_SQL = sprintf('exec MUNI..GET_MUNI_VOL_CALIB ''%s'' ',asof);
curs=ExecuteSQL(curs_SQL);

alldata = curs.Data';
alldata = cell2table(alldata(:,1:2),'VariableNames',{'Cusip','Price'});
alldata.Cusip = cell2mat(alldata.Cusip);
alldata.Cusip = alldata.Cusip(:,1:8);

% get calibration set for long term vol
% calibration set consists of pairs of non-callable and callable
% securities of similar maturities and of the same issuer with maturities >
% 10y
curs = ExecuteSQL('select * from MUNI.dbo.LONG_TERM_VOL_CALIB_CUISPS');
ltcusips = curs.Data';

nclcusips = ltcusips(:,1); % non-callable cusips
clcusips = ltcusips(:,2);  % callable cusips

% get prices for long-term calibration set
q = ['select p.VALUE_DATE, SUBSTRING(p.CUSIP,1,8) cusip, p.PRICE, s.ISSUE_DT ' ...
    'from MUNI..SECURITY_PRICE p, MUNI.bbo.SECURITY s ' ...
    'where p.VALUE_DATE = ''' asof ''' ' ...
    'and SUBSTRING(p.CUSIP,1,8) = SUBSTRING(s.CUSIP,1,8) ' ...
    'and SUBSTRING(p.CUSIP,1,8) in (''' strjoin([nclcusips;clcusips]',''',''') ''') ' ...
    'order by VALUE_DATE,cusip'];
    
curs = ExecuteSQL(q);    
ledata = curs.Data';
ledata = cell2table(ledata,'VariableNames',{'Date','Cusip','Price','IssueDate'});
ledata.Cusip = cell2mat(ledata.Cusip);
ledata.Date = char(ledata.Date);
ledata.IssueDate = char(ledata.IssueDate);

% get the non-callable MMD AAA curve for selected maturities
flds = strjoin(cellstr([repmat('POINT_',length(useterms),1) num2str(12*reshape(useterms,[length(useterms) 1])) repmat('M',length(useterms),1)]),',');

q = ['select AS_OF_DATE,' flds ' FROM FIQModel.dbo.YIELD_CURVE_TIMESERIES ' ...
  'where YC_NAME = ''MuniMMDCVNONCAL'' ' ...
  'and AS_OF_DATE = ''' asof ''''];

curs = ExecuteSQL(q); 
crv = curs.Data';
crv = cell2table(crv(1,2:end));

% set up initial assumptions for upper limit vol
volstart = 90;
if datenum(asof) <= datenum('2008-05-31')
    volstart = 45;
end
if datenum(asof) >= datenum('2011-09-30') & datenum(asof) <= datenum('2013-02-28')
    volstart = 70;
end

asofsys = System.DateTime.Parse(datestr(asof));

tic;
[cldata, voltop, sstat, curv] = prep_calib_set(asofsys,alldata,volstart);
toc;

% check if noncallable run thru ok
[tm,ia,ib] = intersect(ledata.Cusip,nclcusips);
nclsecs = ledata(ia,:);
tic;
nclsecs_cl = check_ncl(asofsys,nclsecs(:,2:end),volstart);
toc;
% check if callable run thru ok
[tm,ia,ib] = intersect(ledata.Cusip,clcusips);
clsecs = ledata(ia,:);
tic;
clsecs_cl = check_cl(asofsys,clsecs(:,2:end),volstart);
toc;

volout = 0;
alphaout = 0;
if size(cldata,1) > 0 & size(nclsecs_cl,1) > 0 & size(clsecs_cl,1) > 0
    % set up ncl/cl pairs. It is necessary, since
    nclcusipsdata = [];
    clcusipsdata = [];
    for i = 1:size(nclcusips,1)
        if sum(strcmp(nclcusips(i),nclsecs_cl.Cusip)) > 0 & sum(strcmp(clcusips(i),clsecs_cl.Cusip))
            nclcusipsdata = [nclcusipsdata; nclsecs_cl(strcmp(nclcusips(i),nclsecs_cl.Cusip),1:size(nclsecs_cl,2)-2)];
            clcusipsdata = [clcusipsdata; clsecs_cl(strcmp(clcusips(i),clsecs_cl.Cusip),1:size(clsecs_cl,2)-2)];
        end
    end
    
    usesecs = 1:size(nclcusipsdata,1);
    Nd = size(nclcusipsdata,1);
    
    % weit the pairs using average time since issuance
    weit = max([(datenum(asof) - datenum(nclcusipsdata.IssueDate))/365.25 (datenum(asof) - datenum(clcusipsdata.IssueDate))/365.25]')';
    weit = interp1([max(weit) 0],[0.2 1],weit);
    weit = weit/sum(weit);
    
    % define a grid of vol/mean reversion (coarse)
    v = 5:5:voltop;
    alf = 0:1:10;
    tic;
    [prer, v30, err] = priceerror_vvmr(v,alf,System.DateTime.Parse(datestr(asof)),cldata);
    toc;
    
    % penalty function in vol 30y
    
    lttarg = 15; % target long term volatility
    lttv = v';
    lttv(v < 2*lttarg) = v(v < 2*lttarg)/2; %if vol is less than 2*target, set lt vol to 1/2 of target
    lttv(v >= 2*lttarg) = lttarg;
    
    for i = 1:size(v30,2)
        v30(:,i) = v30(:,i) - lttv;
    end
    v30 = v30.^2;
    
    if err % remove erroneous points before computing the scalar
        t1 = prer;
        t1(t1 == 1e6) = 0;
        prer(prer == 1e6) = max(max(t1));
    end
    sc = 1.*(max(max(prer)) - min(min(prer)))/(max(max(v30)) - min(min(v30)));
    
    ofunc = prer + sc*v30; % function to minimize
    
    [voli, alfi] = find(ofunc == min(min(ofunc)));
    
    % define a grid of vol/mean reversion (fine)
    v = v(voli)-5:v(voli)+5;
    alf = alf(alfi)-0.9:0.1:alf(alfi)+0.9;
    alf = alf(alf >= 0);
    tic;
    [prer, v30, err] = priceerror_vvmr(v,alf,System.DateTime.Parse(datestr(asof)),cldata);
    toc;
    
    % penalty function in vol 30y
    
    lttv = v';
    lttv(v < 2*lttarg) = v(v < 2*lttarg)/2;
    lttv(v >= 2*lttarg) = lttarg;
    
    for i = 1:size(v30,2)
        v30(:,i) = v30(:,i) - lttv;
    end
    v30 = v30.^2;
    
    ofunc = prer + sc*v30; % function to minimize
    
    [voli alfi] = find(ofunc == min(min(ofunc)));
    
    %%%%% second stage: use both ncl mmd curve and ncl/cl pairs to calibrate mean reversion
    alf = 1:1:20;
    
    tic;
    [oaser, err] = oaserror(v(voli),alf,asofsys,nclcusipsdata(usesecs,:),clcusipsdata(usesecs,:),weit);
    toc;
    
    crver = zeros(size(oaser));
    sc = 1;
    if usecurve
        tic;
        [crver, err] = curverror(v(voli),alf,asofsys,nclcusipsdata(usesecs(1),:),crv,useterms);
        toc;
        sc = max(oaser)/max(crver)/Nd; %adjust for magnitude and treat as one extra bond (weit 1/Nd)
    end
    
    ofunc = oaser + sc*crver;
    
    alfi = find(ofunc == min(ofunc));
    alf = alf(alfi)-0.9:0.1:alf(alfi)+0.9;
    alf = alf(alf >= 0);
    
    tic;
    [oaser, err] = curverror(v(voli),alf,asofsys,nclcusipsdata(usesecs(1),:),crv,useterms);
    toc;
    
    if usecurve
        tic;
        [crver, err] = curverror(v(voli),alf,asofsys,nclcusipsdata(usesecs(1),:),crv,useterms);
        toc;
    end
    ofunc = oaser + sc*crver;
    
    alfi = find(ofunc == min(ofunc));
    alfi = alfi(1);
    
    volout = v(voli);
    alphaout = alf(alfi);
    
    display([datestr(asof) ' ' num2str(volout) ' ' num2str(alphaout)]);
    a = cell2table({datestr(asof) volout alphaout},'VariableNames',{'Date','Vol','Alpha'});
end

%fastinsert(conn, 'MUNI.dbo.BK_PARAMETERS',{'AS_OF_DATE','MUNI_VOL','MEAN_REV'},[{asof} {volout} {alphaout}])
del_SQL=sprintf('delete MUNI.dbo.BK_PARAMETERS where AS_OF_DATE = ''%s''' ,asof);
ExecuteSQL(del_SQL);

ins_SQL=sprintf('insert into MUNI.dbo.BK_PARAMETERS (AS_OF_DATE, MUNI_VOL, MEAN_REV) values (''%s'',%.20f,%.20f)\n', asof, volout, alphaout);
ExecuteSQL(ins_SQL);




