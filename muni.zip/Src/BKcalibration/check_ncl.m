function cldata = check_ncl(asof,data,vols)
global kalotayDLLPath kalotayDLL kalotayCLS

seclist = NET.createGeneric('System.Collections.Generic.List',{'System.String'},1);
vollist = NET.createGeneric('System.Collections.Generic.List',{'System.Double'},1);
mrev = NET.createGeneric('System.Collections.Generic.List',{'System.Double'},1);

vollist.Add(15)
mrev.Add(0)

for i = 1:size(data,1)
    seclist.Add([data{i,1} ',' num2str(data{i,2})]);
end

cldata = data;


output =  kalotayCLS.CalculateByVolatilityAlphaVectors(asof,seclist,'Price',vollist,mrev);


irem = [];
cldata = [cldata num2cell(ones(size(cldata,1),1))];
is8 = length(cldata{1,1}) == 8;

for i = 1:output.Count
    t = char(output.Item(i-1)); 

    if isempty(regexp(t,'Kalotay Fail','ONCE')) && isempty(regexp(t,'Kalotay API failed','ONCE')) && isempty(regexp(t,'No BBO data','ONCE')) ...
            && isempty(regexp(t,'Unknown Refund','ONCE')) && isempty(regexp(t,'GetMuniSecurity failed','ONCE'))
        t = regexprep(t,' ','');
        tc = regexp(t,'Cusip');
        cusip = t(tc(1)+6:tc(2)-3);
        cusip = cusip(1:8);
        isec = find(strcmp(cellstr(cldata{:,1}),cusip(1:8)));
        cldata{isec,size(cldata,2)} = 0;
    end
end
nodata = sum(cldata{:,size(cldata,2)});
irem = find(cldata{:,size(cldata,2)});
cldata(irem,:) = [];
cldata = cldata(:,1:size(cldata,2)-1);

for i = 1:length(irem)
    seclist.RemoveAt(irem(end-i+1)-1);
end

insens = 0;
vupp = vols;
    
if size(cldata,1) > 0
    ex = 0;
    
    while ~ex
        vupp = vupp - 5;
        [prt, err] = calcoas([5 vupp],0,asof,cldata);
        if err
            ex = ~err;
        else
            ex = sum(prt.OAS(prt.Vol == vupp) ~= 0) == size(cldata,1) | vupp <20;
        end
    end
    cldata.lvol = zeros(size(cldata,1),1);
    cldata.hvol = zeros(size(cldata,1),1);
    
    if is8
        t = cell2mat(prt.Cusip);
        prt.Cusip = cellstr(t(:,1:8));
    end    
    
    for i = 1:size(cldata)
        cldata.lvol(i) = prt.OAS(strcmp(cldata{i,1},prt.Cusip) & prt.Vol == 5);
        cldata.hvol(i) = prt.OAS(strcmp(cldata{i,1},prt.Cusip) & prt.Vol == vupp);
    end
    
    sns = 0.5; % threshold to catch securities not sensitive to vol
    irem = find(cldata.hvol - cldata.lvol < sns);
    insens = sum(cldata.hvol - cldata.lvol < sns);
    
    cldata(irem,:) = [];

    for i = 1:length(irem)
        seclist.RemoveAt(irem(end-i+1)-1);
    end
end
if size(cldata,1) > 0
    display(cldata);   
end
display(['All: ',num2str(size(data,1)),' NoData: ', num2str(nodata), ' Insensitive: ',num2str(insens)])

stat = [size(data,1), nodata, insens];
