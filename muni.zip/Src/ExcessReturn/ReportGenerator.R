#library(ABUtils);
#library(rgl);
#library(directlabels);
library(gplots)
library(RODBC)

source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Utility\\R_Splus\\utility.R',sep='') )

#source('H:/SVN/Muni/v1.0/Src/ExcessReturn/ReportGenerator.R') 
#source('C:/SVN/Quant_Model-SQLServer/Muni/v1.0/Src/ExcessReturn/ReportGenerator.R') 
#read args
args<-commandArgs(TRUE);

#as_of = args[1]
	as_of = as.Date('2018-11-06')

	args = c(format(as_of,format = "%Y-%m-%d"),paste(Sys.getenv('ABFI_DATA_REPOSITORY'),'\\Muni\\v1.0\\Output',sep=''),'QA')
	args = c(format(as_of,format = "%Y-%m-%d"),paste(Sys.getenv('ABFI_DATA_REPOSITORY'),'\\Muni\\v1.0\\Output',sep=''),'PRD')
#print(args[1]);

outputfile = paste(args[2],'\\oasreport_',format(as_of,format = "%Y-%m-%d"),'.pdf',sep='')
#outputfile = paste(args[2],'\\oasreport_',format(as_of,format = "%Y-%m-%d"),'.bval.pdf',sep='')
#    outputfile = paste(args[2],'\\oasreport_',format(as_of,format = "%Y-%m-%d"),'.P.pdf',sep='')
#    outputfile = paste(args[2],'\\oasreport_',format(as_of,format = "%Y-%m-%d"),'.SecCred.pdf',sep='')
#    outputfile = paste(args[2],'\\oasreport_',format(as_of,format = "%Y-%m-%d"),'.Kal.Tax.pdf',sep='')
#    outputfile = paste(args[2],'\\oasreport_',format(as_of,format = "%Y-%m-%d"),'.Kal.NC.pdf',sep='')

#set up db
db_info=get_db_info(args[3]);
#db_info=get_db_info('QA');
db_qa=get_db_info("QA");

channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    
stmt=paste("select * from FIQModel..OAS_ATTRIBUTION_FIT a join  FIQModel..MUNI_DUMMY_VARIABLE_MAP b join FIQModel..MUNI_SECTOR c on b.ORIG_VALUE=c.AB_CODE on a.VALUE1=10*b.MAPPED_VALUE where SECTOR='muni' and AS_OF_DATE='",args[1],"' and a.ATTRIBUTE='ab_code' order by OAS desc",sep="")
df_AB_CODE=sqlQuery(channel,query=stmt)

stmt=paste("select * from FIQModel..OAS_ATTRIBUTION_FIT a join  FIQModel..MUNI_DUMMY_VARIABLE_MAP b on a.VALUE1=10*b.MAPPED_VALUE join (select top 25 STATE,sum(AMT_OUTSTANDING) sum_total from Optimizer..MUNI_ANALYTICS_KALOTAY where convert(date,EFFECTIVE_DATE)='",args[1],"'
           group by STATE order by sum(AMT_OUTSTANDING) desc) c on b.ORIG_VALUE=c.STATE where SECTOR='muni' and  AS_OF_DATE='",args[1],"' and a.ATTRIBUTE='state' order by OAS desc",sep="")
df_STATE=sqlQuery(channel,query=stmt)

stmt=paste("select * from FIQModel..OAS_ATTRIBUTION_FIT a where SECTOR='muni' and AS_OF_DATE='",args[1],"' and a.ATTRIBUTE='deminimis_buffer' order by VALUE2,VALUE1 asc");
df_BUFFER=sqlQuery(channel,query=stmt)

stmt=paste("select * from FIQModel..OAS_ATTRIBUTION_FIT a where SECTOR='muni' and AS_OF_DATE='",args[1],"' and a.ATTRIBUTE='extension_risk' order by VALUE2,VALUE1 asc");
ext_risk=sqlQuery(channel,query=stmt)

stmt=paste("select * from FIQModel..OAS_ATTRIBUTION_FIT a where SECTOR='muni' and AS_OF_DATE='",as_of,"' and a.ATTRIBUTE='muni_taxability'",
			" and VALUE1 >= 20100 and VALUE1 < 20200")
df_TAX=sqlQuery(channel,query=stmt)
df_TAX = df_TAX[df_TAX$VALUE1 %in% c(20100,20140,20180),]

q = paste(" select * from FIQModel..OAS_ATTRIBUTION_FIT where SECTOR='muni' and AS_OF_DATE='",as_of,"' and ATTRIBUTE='index_oas'");
df_index = sqlQuery(channel,query=q)

stmt=paste("select * from FIQModel..OAS_ATTRIBUTION_FIT a join FIQModel..BOND_CREDIT_RATING b on a.VALUE1=b.ID where SECTOR='muni' and AS_OF_DATE='",args[1],"' and a.ATTRIBUTE='credit_oad'");
df_CREDIT_OAD = sqlQuery(channel,query=stmt)

stmt=paste("select * from FIQModel..OAS_ATTRIBUTION_FIT a where SECTOR='muni' and AS_OF_DATE='",args[1],"' and a.ATTRIBUTE='zero_coupon' and VALUE1 >= 40200");
df_zero = sqlQuery(channel,query=stmt)
df_zero = df_zero[df_zero$VALUE1 %in% c(40200,40240,40280),]

stmt=paste("select 
	AB_SECTOR                                                    AS 'Sector',
	round(SUM(COUPON*AMT_OUTSTANDING/SECTOR_SUM),2)             AS 	'Coupon',
	round(AVG(COUPON),2)										  AS 	'Average Coupon',
	round(SUM(EFFECTIVE_MATURITY*AMT_OUTSTANDING/SECTOR_SUM),1) AS 	'Maturity' ,
    round(SUM(MUNI_OAD*AMT_OUTSTANDING/SECTOR_SUM),2) as 'Duration',
	round(AVG(YIELD),2) as 'Yield'
from
(
select a.IDENTIFIER,a.COUPON,a.AMT_OUTSTANDING,d.SECTOR_SUM,AB_SECTOR,a.EFFECTIVE_MATURITY,MUNI_OAD
FROM
	Optimizer..MUNI_ANALYTICS a 
		JOIN FIQModel..MUNI_SECTOR_CODE b 
            ON a.IDENTIFIER=b.IDENTIFIER 
        JOIN FIQModel..MUNI_SECTOR C 
			ON b.AB_CODE=C.AB_CODE 
        JOIN (	SELECT
                    f.AB_CODE,
                    SUM(AMT_OUTSTANDING) AS SECTOR_SUM 
                FROM
                    Optimizer..MUNI_ANALYTICS e 
                    JOIN FIQModel..MUNI_SECTOR_CODE f 
                    ON e.IDENTIFIER=f.IDENTIFIER 
                WHERE
                    CONVERT(DATE,e.EFFECTIVE_DATE)='",args[1],"' 
                GROUP BY
                    f.AB_CODE) d 
            ON b.AB_CODE=d.AB_CODE 
WHERE
	CONVERT(DATE,a.EFFECTIVE_DATE)='",args[1],"') q
	left join (select distinct YIELD,SECURITY_ID from Optimizer..MUNI_POSITION_HISTORY where VALUE_DATE='",args[1],"') i
	on q.IDENTIFIER=i.SECURITY_ID
GROUP BY
	AB_SECTOR"
);
	
df_SECTOR_MAT_CPN=sqlQuery(channel,query=stmt)

stmt=paste("select
STATE AS 'State',
round(SUM(COUPON*AMT_OUTSTANDING/SECTOR_SUM),2) AS 'Coupon',
round(AVG(COUPON),2) AS 'Average Coupon',
round(SUM(EFFECTIVE_MATURITY*AMT_OUTSTANDING/SECTOR_SUM),1) AS 'Maturity' ,
round(SUM(MUNI_OAD*AMT_OUTSTANDING/SECTOR_SUM),2) as 'Duration',
round(AVG(YIELD),2) as 'Yield'
from
(
select a.IDENTIFIER,a.COUPON,a.AMT_OUTSTANDING,d.SECTOR_SUM,a.STATE,a.EFFECTIVE_MATURITY,MUNI_OAD
FROM
Optimizer..MUNI_ANALYTICS a
JOIN ( SELECT
STATE,
SUM(AMT_OUTSTANDING) AS SECTOR_SUM
FROM
Optimizer..MUNI_ANALYTICS e
WHERE
CONVERT(DATE,e.EFFECTIVE_DATE)='",args[1],"'
GROUP BY
STATE) d
ON a.STATE=d.STATE
join (select top 25 STATE,sum(AMT_OUTSTANDING) sum_total from Optimizer..MUNI_ANALYTICS where convert(date,EFFECTIVE_DATE)='",args[1],"' group by STATE) h
on a.STATE=h.STATE
WHERE
CONVERT(DATE,a.EFFECTIVE_DATE)='",args[1],"') q
left join (select distinct YIELD,SECURITY_ID from Optimizer..MUNI_POSITION_HISTORY where VALUE_DATE='",args[1],"') i
on q.IDENTIFIER=i.SECURITY_ID
GROUP BY
STATE",sep="");
df_STATE_MAT_CPN=sqlQuery(channel,query=stmt)

odbcClose(channel)

########################################################################################
#output
pdf(outputfile,width=7,height=7);
#taxability, index ,coupon
#mt<-matrix(c(df_TAX$OAS,df_TAX$MEAN_OAS),nr=nrow(df_TAX));
#mt = matrix(c(c(df_TAX$OAS,df_zero$OAS),c(df_TAX$MEAN_OAS,df_zero$MEAN_OAS)),nrow = 3)

mt = rbind(df_index[,c('OAS','MEAN_OAS')],df_TAX[,c('OAS','MEAN_OAS')],df_zero[,c('OAS','MEAN_OAS')])

mt<-t(mt);
barplot(mt,col=c("darkblue","red"),names.arg=c("Index","AMT <5","AMT 5..15","AMT >15","ZC <5","ZC 5..15","ZC >15"),cex.names = 0.8,
main=paste("OAS ATTRIBUTION ",args[1],sep=" "),cex.main=1.5,legend=c("OAS","HISTORICAL OAS"),beside=T,ylab="OAS (bps)",density=c(10,100),ylim=c(0,max(mt)));


par(mar = c(9,4,4,2) + 0.1)
#AB Code
mt<-matrix(c(df_AB_CODE$OAS,df_AB_CODE$MEAN_OAS),nr=nrow(df_AB_CODE));
mt<-t(mt);
barplot(mt,col=c("darkblue","red"),names.arg=df_AB_CODE$AB_SECTOR,main=paste("OAS ATTRIBUTION (SECTORS)",args[1],sep=" "),las=2,cex.names=.5,cex.main=1,legend=c("OAS","HISTORICAL OAS"),beside=T,ylab="OAS (bps)",density=c(10,100));

#prints the relevant table by sector.

textplot(df_SECTOR_MAT_CPN[,c(1,2,4,5)],show.rownames=FALSE,halign="center",show.colnames=TRUE,mar=c(1,1,4,1),cex=.8);
#textplot(df_SECTOR_MAT_CPN[,c(1,4,5,6)],show.rownames=FALSE,halign="center",show.colnames=TRUE,mar=c(1,1,4,1),cex=.5);

#states
#layout(matrix(c(1,2),2),c(1,1),c(4,1));
par(mfrow=c(1,1));
par(mar = c(9,4,4,2) + 0.1)
mt<-matrix(c(df_STATE$OAS,df_STATE$MEAN_OAS),nr=nrow(df_STATE));
mt<-t(mt);
barplot(mt,col=c("darkblue","red"),names.arg=df_STATE$ORIG_VALUE,main=paste("OAS ATTRIBUTION (STATES)",args[1],sep=" "),
	las=2,cex.names=.5,cex.main=1.5,legend=c("OAS","HISTORICAL OAS"),beside=T,ylab="OAS (bps)",density=c(4,100),ylim = range(mt))#c(-20,100));

#state coupon+maturity
#par(mfrow=c(2,1));
textplot(df_STATE_MAT_CPN[,c(1,2,4,5)],show.rownames=FALSE,halign="center",show.colnames=TRUE,mar=c(1,1,4,1),cex=.8);
#textplot(df_STATE_MAT_CPN[,c(1,4,5,6)],show.rownames=FALSE,halign="center",show.colnames=TRUE,mar=c(1,1,4,1));

#title(paste("Average Coupon, Maturity, Duration and Yield by State--",args[1]),outer=T,line=-1);








par(mfrow=c(2,3));
par(mar = c(4,4,4,1) + 0.1)
indices<-c(1,3,6,9,12,15)

max_oas<-max(c(df_CREDIT_OAD$OAS,df_CREDIT_OAD$MEAN_OAS))+20
min_oas<-min(c(df_CREDIT_OAD$OAS,df_CREDIT_OAD$MEAN_OAS))-20


for(i in 1:6)
{
  rating<-df_CREDIT_OAD[df_CREDIT_OAD$VALUE1==indices[i],11][1];
  if(!is.na(rating))
  {
    df_temp<-df_CREDIT_OAD[df_CREDIT_OAD$VALUE1==indices[i],];
    df_temp<-df_temp[order(df_temp$VALUE2),];
    plot(df_temp$VALUE2,df_temp$OAS,col='red',type='l',ylim=c(min_oas,max_oas),xlab="Duration",ylab="OAS (bps)",main=rating);
    lines(df_temp$VALUE2,df_temp$MEAN_OAS,col='blue',type="o",pch=22,lty=2,cex=0);
    legend('topright',c("OAS","HISTORICAL OAS"),cex=.75,col=c("red","blue"),lty=1:2);
    grid();
  }
}
title(paste("OAS ATTRIBUTION Credit Duration--",args[1],sep=""),outer=T,line=-1);

#deminimis buffer

par(mfrow=c(1,1));
par(mar = c(9,4,4,2) + 0.1)
db_ig = df_BUFFER[df_BUFFER$VALUE2 == 0,]
db_hy = df_BUFFER[df_BUFFER$VALUE2 == 1,]
plot(db_ig$VALUE1,db_ig$OAS,type='l',ylab="OAS (bps)",xlab="Deminimis Buffer",main=paste("OAS ATTRIBUTION",args[1],sep=" "),
	col=c("darkblue"),lty = 1,ylim = range(c(df_BUFFER$OAS,df_BUFFER$MEAN_OAS)))
lines(db_ig$VALUE1,db_ig$MEAN_OAS,type='l',col=c("darkblue"),lty = 2)
lines(db_ig$VALUE1,db_hy$OAS,type='l',col=c("red"),lty = 1)
lines(db_ig$VALUE1,db_hy$MEAN_OAS,type='l',col=c("red"),lty = 2)

legend('top',c("OAS IG","HISTORICAL OAS IG","OAS HY","HISTORICAL OAS HY"),col=c("darkblue","darkblue","red","red"),lty=c(1,2,1,2),cex=1.)

# extension risk
par(mfrow=c(1,1));
par(mar = c(9,4,4,2) + 0.1)
plot(ext_risk$VALUE1,ext_risk$OAS,type='l',ylab="OAS (bps)",xlab="Extension Risk (OAD/Dur2Mat)",
	main=paste("OAS ATTRIBUTION FOR EXTENSION RISK",args[1],sep=" "),col='red',lty = 1,,ylim = range(c(ext_risk$OAS,ext_risk$MEAN_OAS)))
lines(ext_risk$VALUE1,ext_risk$MEAN_OAS,type='l',col=c("blue"),lty = 2)	
legend('top',c("Current","Historical"),col = c('red','blue'),lty = c(1,2))

dev.off();