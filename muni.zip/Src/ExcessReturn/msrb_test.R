#!\\nts0018\bond\ABFI_PROD\QuantApps\R-2.14.2\bin\x64\Rscript

source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.kal.R',sep='') )



calc_security_exposure <- function(data,db_info,gen = F)
{	
	if (gen)
	{	data <- get_factor_exposure_gen(data,db_info)
	}else data <- get_factor_exposure(data,db_info,type='resi',T)
	
	load('../Input/MuniParBondRet.RData')	
	# add return forecat for treasury portfolio to krd_ret_fwd3m_fc
	data = calc_returns(data,dur,yld_fixed)
	names(data)[names(data) == 'krd_ret_fwd3m_fc'] = 'carry'
	data = calc_returns(data,dur,roll)
	names(data)[names(data) == 'krd_ret_fwd3m_fc'] = 'roll'
	data = calc_returns(data,dur,term_tsy_fc)
	names(data)[names(data) == 'krd_ret_fwd3m_fc'] = 'term_tsy'
	data = calc_returns(data,dur,term_sprd_fc)
	names(data)[names(data) == 'krd_ret_fwd3m_fc'] = 'term_sprd'
	data <- calc_returns(data,dur,ret_fc)
	#return only needed fields
	#xvars <- c('index_oas','credit_oad','state','ab_code','muni_taxability','deminimis_buffer','resi_oas')
	if (!gen)
	{
		xvars <- c('credit_oad','resi_oas')
		data <- data[,c('as_of_date','identifier','muni_oad','muni_oas','market_value','total_return_mtd',xvars,
			'krd_ret_fwd3m_fc','carry','roll','term_tsy','term_sprd')]
		ix <- rowSums(is.na(data))==0 | ( rowSums(is.na(data))==1 & is.na(data$total_return_mtd) )
		data[ix,]
	}
	data
}

calc_security_return <- function(data,as_of,db_info,gen=F)
{
	factor_loading <- load_factor_loading(as_of,db_info)
	#use only credit/duration factor and residual
	if (!gen) {
		factor_loading = factor_loading[factor_loading$FACTOR_ID %in% c(1201,1203,1208),]
	}else factor_loading = factor_loading[factor_loading$FACTOR_ID %in% c(1201,1203),]
	
	var_map <- c(
		'Intercept','intercept',
		'index_oas','Index OAS',
		'credit_oad','Credit x OAD',
		'state', 'State',
		'ab_code','Sector',
		'muni_taxability','Taxability',
		'deminimis_buffer','Coupon Effect',
		'resi_oas','Residual OAS')
		
	stmt <- paste("
    	select MODEL_NAME,FACTOR_NAME,FACTOR_ID FROM 
        MODEL_DESCRIPTION a,MODEL_SPECIFICATION b
        WHERE a.MODEL_NAME = 'Muni Excess Return Model'
        AND b.MODEL_ID=a.MODEL_ID
        AND a.VERSION='1.0'
	",sep='')
	
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    id_map <- sqlQuery(channel,query=stmt)
    odbcClose(channel)
    
    idx <- match(id_map$FACTOR_NAME,var_map)
    id_map$xvar <- var_map[idx-1]
    
    factor_loading <- merge(factor_loading,id_map)
    
    data$Intercept <- 0
    #data[,factor_loading$xvar] <- data[,factor_loading$xvar] * data$muni_oad
	
    for( xvar in factor_loading$xvar )
    {
	    #if(xvar=='Intercept') data[,xvar] <- factor_loading$FACTOR_LOADING[factor_loading$xvar==xvar]
	    # excess carry (oas adjusted by reversion of residual oas) instead of intercept
	    if(gen & xvar=='Intercept') { data[,xvar] <- (data$muni_oas)/40000
		}else if(xvar=='Intercept') data[,xvar] <- (data$muni_oas - 0.1*data$resi_oas)/40000
	    
	    else{
		   f <- factor_loading[factor_loading$xvar==xvar,]
		   #remove capping here if necessary
		   # data[,xvar] <- winsorise(data[,xvar],lb.value=f$FACTOR_LB,ub.value=f$FACTOR_UB)
		   data[,xvar] <- f$FACTOR_LOADING*(data$muni_oad*data[,xvar]-f$FACTOR_MEAN)/f$FACTOR_STDEV
	    }
    }
    
    data$excess_ret_fwd3m_fc <- rowSums(data[,factor_loading$xvar])
    data$total_ret_fwd3m_fc <- data$excess_ret_fwd3m_fc + data$krd_ret_fwd3m_fc
    
    data
}

load_reg_data <- function(as_of, from_date)
{
	cat(format(Sys.time()),'loading data as of',format(as_of),'from database...\n')
	stmt <- paste("
		SELECT 
		FWD_DATE,IDENTIFIER,
		EXCESS_RET_FWD3M,KRD_RET_FWD3M_FC,TOTAL_RET_FWD3M,
		INDEX_OAS,CREDIT_OAD,STATE,AB_CODE,MUNI_TAXABILITY,
		DEMINIMIS_BUFFER,RESI_OAS, AMT_OUTSTANDING
		FROM MUNI_MODEL_REGRESSION_DATA
        WHERE FWD_DATE <='", format(as_of,'%d-%b-%Y'),"' and FWD_DATE >= '",format(from_date,'%d-%b-%Y'),"'",sep='')
#        WHERE FWD_DATE <='", format(as_of,'%d-%b-%Y'),"' AND FWD_DATE >= '2010-06-30'",sep='')
	
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    reg_data <- sqlQuery(channel,query=stmt)
    odbcClose(channel)
    names(reg_data) <- casefold(names(reg_data),F)
    reg_data$fwd_date <- as.Date(reg_data$fwd_date)
    cat(format(Sys.time()),'done.\n')
	names(reg_data)[names(reg_data) == 'amt_outstanding'] = 'ex_yield'
	#names(reg_data)[names(reg_data) == 'state'] = 'credit_rating'
	reg_data$ex_yield = reg_data$ex_yield/40000
    reg_data
}

load_reg_data_d <- function(as_of,db_info)
{
	cat(format(Sys.time()),'loading data as of',format(as_of),'from database...\n')
	stmt <- paste("
		SELECT 
		FWD_DATE,IDENTIFIER,
		EXCESS_RET_FWD3M,KRD_RET_FWD3M_FC,TOTAL_RET_FWD3M,
		INDEX_OAS,CREDIT_OAD,STATE,AB_CODE,MUNI_TAXABILITY,
		DEMINIMIS_BUFFER,RESI_OAS, AMT_OUTSTANDING
		FROM MUNI_MODEL_REGRESSION_DATA
        WHERE FWD_DATE ='", format(as_of,'%d-%b-%Y'),"'",sep='')
#        WHERE FWD_DATE <='", format(as_of,'%d-%b-%Y'),"' AND FWD_DATE >= '2010-06-30'",sep='')
	
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    reg_data <- sqlQuery(channel,query=stmt)
    odbcClose(channel)
    names(reg_data) <- casefold(names(reg_data),F)
    reg_data$fwd_date <- as.Date(reg_data$fwd_date)
    cat(format(Sys.time()),'done.\n')
	names(reg_data)[names(reg_data) == 'amt_outstanding'] = 'ex_yield'
	#names(reg_data)[names(reg_data) == 'state'] = 'credit_rating'
	reg_data$ex_yield = reg_data$ex_yield/40000
    reg_data
}

#source("H:\\SVN\\Muni\\v1.0\\Src\\ExcessReturn\\msrb_test.R")

library(RODBC)
setwd(paste(Sys.getenv('ABFI_DATA_REPOSITORY'),'\\Muni\\v1.0\\Output',sep='') )

tdata = read.table(file = "H:\\MATLAB\\msrb\\oasdata.csv",header = T,sep = ",")
names(tdata) = c('as_of_date','identifier','price','muni_oas','muni_oad','muni_6mo_krd','muni_2yr_krd','muni_5yr_krd','muni_10yr_krd','muni_20yr_krd',
				'muni_30yr_krd')
tdata$as_of_date =as.Date(tdata$as_of_date,'%d-%b-%Y')

dates = sort(unique(tdata$as_of_date))

#frdate = add.month(dates[1],3) - 5
#reg_data <- load_reg_data(Sys.Date(), frdate)
#regfdates = sort(unique(reg_data$fwd_date))

wdata = data.frame()

db = get_db_info('QA')
qphist = data.frame()
N = 10
for(i in 1:(length(dates)-3))
{
	andt = dates[i]
	if(dates[i] < as.Date('2013-01-01'))
		andt = month.end(dates[i])
		
	adata = rbind(load_data(andt,db,'Index',ronly = T),load_data(andt,db,'AB',ronly = T))
	
	adata = adata[,c('as_of_date','identifier','deminimis_buffer','state','ab_code','muni_taxability','credit_rating','ce_bucket','extension_risk',
				'total_return_mtd','zero_coupon','hy','cal_impact','market_value','moody_rating', 'sp_rating', 'fitch_rating','credit_enhancement')]
	adata$as_of_date = dates[i]			
	cdata = merge(tdata[tdata$as_of_date == dates[i],],adata)			
	cdata$as_of_date = andt
	
	cdata = calc_security_exposure(cdata,db)
	
	cdata = calc_security_return(cdata,dates[i],db)
#	ix = which(regfdatas == dates[i])
#	rdata = reg_data[reg_data$fwd_date == regfdates[ix+3],]
	if(dates[i+3] < as.Date('2013-01-01'))
		rdata = load_reg_data_d(month.end(dates[i+3]),db)
	else
		rdata = load_reg_data_d(dates[i+3],db)
		
	rdata$fwd_date = andt
	
	cdata = merge(cdata,rdata[,c('fwd_date','identifier','excess_ret_fwd3m','total_ret_fwd3m')],
				by.x = c('as_of_date','identifier'),by.y = c('fwd_date','identifier'))
	
	ql = quantile(cdata$excess_ret_fwd3m_fc,seq(0,1,1/N))
	qperf =vector('numeric',length = length(ql)-1)
	for(j in 2:length(ql))
	{
		qperf[j-1] = mean(cdata$excess_ret_fwd3m[cdata$excess_ret_fwd3m_fc > ql[j-1] & cdata$excess_ret_fwd3m_fc <= ql[j]])/3
	}
	qpdf = data.frame(Date = dates[i],matrix(qperf,nrow = 1))
	names(qpdf)[2:dim(qpdf)[2]] = paste('q',seq(N,1),sep='')

	qphist = rbind(qphist,qpdf)
}


write.csv(qphist,file = 'tmp.csv')