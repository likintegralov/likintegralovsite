#!\\nts0018\bond\ABFI_PROD\QuantApps\R-2.14.2\bin\Rscript

source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.dev25.R',sep='') )

fit_data <- function(as_of,data)
{
	cat('total',nrow(data),'rows of data.\n')
	
	# separate pre-refs
	do_pr = F
	data_pr = get_prerefs(data)
	if( dim(data_pr)[1] >= 700)
	{
		data = data[data$ab_code != 333,]
		do_pr = T
		data_pr = data_pr[data_pr$muni_oas < 150,]
	}
	
	# re-define state to calibrate to high credit only
	
	states_o = sort(unique(data$state))
	data$state_save = data$state
	data$state[data$credit_rating > 5] = 100 # put all low credit in the same bucket
	
	data$n = 1
	bcount = aggregate(data$n,by = list(data$state),FUN = sum)
	sshort = bcount[bcount[,2] < 5,1]
	data$state[data$state %in% sshort] = 100 # put states with too few high credit to the same bucket 
	
	states_m = states_o[which(!(states_o %in% unique(data$state)))] # not calibrated states (replaced by zeros in attribution)
	states_f = sort(unique(data$state))
	
	#winsorise
	data$muni_oad <- winsorise(data$muni_oad,lb=0.00,ub=0.99)
	data$deminimis_buffer <- winsorise(data$deminimis_buffer,lb=0.0,ub=0.99)
	
	# de-mean extension risk
	data$ext_risk_notcentered = data$extension_risk
	data$extension_risk = data$extension_risk - mean(data$extension_risk) 
	
	if(do_pr)
	{
		data_pr$muni_oad = winsorise(data_pr$muni_oad,lb=0.00,ub=0.99)
		data_pr$deminimis_buffer <- winsorise(data_pr$deminimis_buffer,lb=0.0,ub=0.99)
	}
	
	#factorize
	data$state <- as.factor(data$state)
	data$ab_code <- as.factor(data$ab_code)
	data$muni_taxability <- as.factor(data$muni_taxability)
	data$zero_coupon = as.factor(data$zero_coupon)
	data$hy = as.factor(ifelse(data$credit_rating > 10,1,0))
	data$ce_bucket = as.factor(data$ce_bucket)

	if(do_pr)
	{
		data_pr$muni_taxability <- as.factor(data_pr$muni_taxability) 
		data_pr$zero_coupon <- as.factor(data_pr$zero_coupon) 
		data_pr$state <- as.factor(data_pr$state)
	}

	dohy = ifelse(sum(as.integer(data$hy)-1) > 10,1,0)
	
	cat(format(Sys.time()),'running gam...\n')
	fit <- gam( muni_oas ~ te(credit_rating, muni_oad,k=c(3,4)) + s(deminimis_buffer,k=4,by = hy) + poly(extension_risk,3,raw = TRUE) 
							+ s(cal_impact,k=4) + state+ ab_code + muni_taxability + zero_coupon + ce_bucket, data = data) 
	
	do_pr_zero = T						
	if(do_pr)
	{
		if(length(unique(data_pr$zero_coupon)) > 1)
		{
			fit_pr = gam(muni_oas ~ muni_oad + deminimis_buffer + zero_coupon + state,data = data_pr)
 		}else
 		{
	 		do_pr_zero = F
 			fit_pr = gam(muni_oas ~ muni_oad + deminimis_buffer + state,data = data_pr)
 		}
	}
	cat(format(Sys.time()),'done.\n')
	################################################################################
	r_sqr <- (fit$null.deviance-fit$deviance)/fit$null.deviance
	#r_sqr <- (fit_pr$null.deviance-fit_pr$deviance)/fit_pr$null.deviance
	
	cat('r_sqr=',round(r_sqr,3),'\n')
	
	################################################################################
	#plot(fit,rug=F,pers=T,theta=-45,main=format(as_of))
		
	################################################################################
	#first fit credit curve
	x <- sort(unique(data$credit_rating))
	y <- unique( round( c(min(data$muni_oad),quantile(data$muni_oad,1:100/100) ), 4) )
	
	states <- sort(unique(data$state))
	ab_codes <- sort(unique(data$ab_code))
	taxabilities <- sort(unique(data$muni_taxability))
	zero_coupon = sort(unique(data$zero_coupon))
	ce_bucket = sort(unique(data$ce_bucket))
	
	deminimis_buffers <- seq(min(data$deminimis_buffer),max(data$deminimis_buffer),length.out=100)
	extension_risk <- seq(min(data$extension_risk),max(data$extension_risk),length.out=100)
	cal_impact <- seq(min(data$cal_impact),max(data$cal_impact),length.out=100)
	
	n <- length(x)*length(y)
	newdata <- data.frame(credit_rating=rep(x,length(y)),muni_oad=rep(y,rep(length(x),length(y))),
		deminimis_buffer=c(deminimis_buffers,deminimis_buffers,rep(deminimis_buffers[length(deminimis_buffers)],n-2*length(deminimis_buffers))),
		extension_risk = c(extension_risk,rep(extension_risk[1],n-length(extension_risk))),
		cal_impact = c(cal_impact,rep(cal_impact[1],n-length(cal_impact))),
		state=factor(c(levels(states)[states],rep(levels(states)[1],n-length(states)))),
		ab_code=factor(c(levels(ab_codes)[ab_codes],rep(levels(ab_codes)[1],n-length(ab_codes)))),
		muni_taxability=factor(c(levels(taxabilities)[taxabilities],rep(levels(taxabilities)[1],n-length(taxabilities)))),
		zero_coupon=factor(c(levels(zero_coupon)[zero_coupon],rep(levels(zero_coupon)[1],n-length(zero_coupon)))),
		ce_bucket=factor(c(levels(ce_bucket)[ce_bucket],rep(levels(ce_bucket)[1],n-length(ce_bucket)))),
		hy = c(rep(0,length(deminimis_buffers)),rep(1,n-length(deminimis_buffers)))
		)
		
	res <- predict(fit,newdata=newdata,type='terms')
	# pre-refs prediction
	if(do_pr)
	{
		n_pr = 100
	
		muni_oad_pr <- seq(min(data_pr$muni_oad),max(data_pr$muni_oad),length.out=n_pr)		
		deminimis_buffers_pr <- seq(min(data_pr$deminimis_buffer),max(data_pr$deminimis_buffer),length.out=n_pr)
	
		taxabilities_pr <- sort(unique(data_pr$muni_taxability))
		zero_coupon_pr = sort(unique(data_pr$zero_coupon))
		
		states_pr <- sort(unique(data_pr$state))
	
		newdata_pr = data.frame(
				muni_oad = muni_oad_pr,
				deminimis_buffer = deminimis_buffers_pr, 
				zero_coupon = unlist(list(zero_coupon_pr,rep(zero_coupon_pr[1],n_pr-length(zero_coupon_pr)))),
				state=factor(c(levels(states_pr)[states_pr],rep(levels(states_pr)[1],n_pr-length(states_pr))))
				)
				
		res_pr <- predict(fit_pr,newdata=newdata_pr,type='terms')
	}
	#z <- matrix(res[,'te(credit_rating,muni_oad)'],nrow=length(x))
	#persp(x,y,z,theta=-45,xlab='Rating',ylab='muni_oad',zlab='muni_oas')
	
	################################################################################
	cat(format(Sys.time()),'writing results...\n')
	################################################################################
	#credit surface
	oas_attr <- data.frame(ID = 1, SECTOR='muni',AS_OF_DATE=as_of,ATTRIBUTE='credit_oad',VALUE1=newdata$credit_rating,VALUE2=newdata$muni_oad,OAS=res[,'te(credit_rating,muni_oad)'])
	################################################################################	
	# pre-refs duration
	
	if(do_pr)
	{
		oas_attr_pr <- data.frame(ID = 1, SECTOR='muni',AS_OF_DATE=as_of,ATTRIBUTE='credit_oad_pr',VALUE1 = muni_oad_pr,VALUE2 = 0,OAS=res_pr[,'muni_oad'])
	}

	xvars_ex_credit <- c('state','ab_code','extension_risk','ce_bucket','cal_impact')
	xvar_factor_interp = factors_interp_map$fact
	xvar_factor_tags = factors_interp_map$tags # tags for buckets, first 3 digits should be the same as in load_data function
	xvar_pr = c('zero_coupon','state')
	
	index_oas <- attr(res,'constant')
	if(do_pr)
	{
		index_oas_pr <- attr(res_pr,'constant')
	}
	################################################################################
	for(xvar in xvars_ex_credit)
	{
		if(is.numeric(data[,xvar]))
		{
			if(xvar == 'extension_risk')
			{
				x <- seq(min(data[,'ext_risk_notcentered']),max(data[,'ext_risk_notcentered']),length.out=100)
				outdata <- data.frame(x=x,response=res[1:length(x),paste('poly(',xvar,', 3, raw = TRUE)',sep='')])
				colnames(outdata)[1] <- xvar 
				outdata <- data.frame(ID = 1, SECTOR='muni',AS_OF_DATE=as_of,ATTRIBUTE=xvar,VALUE1=outdata[,xvar],VALUE2=0,OAS=outdata$response)
			}else if(xvar == 'cal_impact') #simplify fitted function to be bi-linear
			{
				x <- seq(min(data[,xvar]),max(data[,xvar]),length.out=100)
				outdata <- data.frame(x=x,response=res[1:length(x),paste('s(',xvar,')',sep='')])
				cp = which(abs(x - 0) == min(abs(x - 0)))
				cp = cp[1]
				ynode = outdata[cp + 20,2] - outdata[cp,2]
				yout = approx(c(x[1],0,x[length(x)]),c(0,0,(x[length(x)] - x[cp])/(x[cp + 20] - x[cp])*ynode),x)$y 
				outdata <- data.frame(ID = 1, SECTOR='muni',AS_OF_DATE=as_of,ATTRIBUTE=xvar,VALUE1=x,VALUE2=0,OAS=yout)
			}else
			{
				x <- seq(min(data[,xvar]),max(data[,xvar]),length.out=100)
				outdata <- data.frame(x=x,response=res[1:length(x),paste('s(',xvar,')',sep='')])
				colnames(outdata)[1] <- xvar 
				outdata <- data.frame(ID = 1, SECTOR='muni',AS_OF_DATE=as_of,ATTRIBUTE=xvar,VALUE1=outdata[,xvar],VALUE2=0,OAS=outdata$response)
			}
			# pre-refs
			if(xvar %in% xvar_pr & do_pr)
			{
				x_pr = seq(min(data_pr[,xvar]),max(data_pr[,xvar]),length.out=n_pr)
				outdata_pr <- data.frame(x=x_pr,response=res_pr[1:length(x_pr),xvar])
				colnames(outdata_pr)[1] <- xvar 
				outdata_pr <- data.frame(ID = 1, SECTOR='muni',AS_OF_DATE=as_of,ATTRIBUTE=paste(xvar,'_pr',sep=''),VALUE1=outdata_pr[,xvar],VALUE2=0,OAS=outdata_pr$response)
			}
		}else #is.factor
		{
			if(xvar == 'state')
			{
				outdata = data.frame(x=states_f[2:length(states_f)],response=res[2:length(states_f),xvar]) # ignore first bucket with low credit securities
				colnames(outdata)[1] <- xvar
				data$state = data$state_save # restore original states
				datat = data; datat = datat[!(datat$state %in% states_m),] # remove missing states 
				wgts <- aggregate(fit$weights[1:dim(datat)[1]],by=list(datat[,xvar]),FUN=sum)
				names(wgts) <- c(xvar,'wgt')
				outdata <- merge(outdata,wgts)
				shift <- sum(outdata$response*outdata$wgt)/sum(outdata$wgt)
				
				outdata$response <- outdata$response - shift
				outdata = rbind(outdata,data.frame(state = states_m,response = 0,wgt = 1)) # use 0 attribution for 100 bucket
				index_oas <- index_oas + shift
				
				outdata <- data.frame(ID = 1, SECTOR='muni',AS_OF_DATE=as_of,ATTRIBUTE=xvar,VALUE1=outdata[,xvar],VALUE2=0,OAS=outdata$response)
			}else
			{
				x <- sort(unique(data[,xvar]))
				outdata <- data.frame(x=x,response=res[1:length(x),xvar])
				colnames(outdata)[1] <- xvar 
				wgts <- aggregate(fit$weights,by=list(data[,xvar]),FUN=sum)
				names(wgts) <- c(xvar,'wgt')
				outdata <- merge(outdata,wgts)
				shift <- sum(outdata$response*outdata$wgt)/sum(outdata$wgt)
				
				outdata$response <- outdata$response - shift
				index_oas <- index_oas + shift
				
				outdata <- data.frame(ID = 1, SECTOR='muni',AS_OF_DATE=as_of,ATTRIBUTE=xvar,VALUE1=outdata[,xvar],VALUE2=0,OAS=outdata$response)
			}
			if(xvar == 'ce_bucket')
			{		# force non-positive credit enhancement attribution
				outdata$OAS[outdata$OAS > 0 & outdata$VALUE1 != 500] = 0
			}
			#pre-refs
			if(xvar %in% xvar_pr & do_pr)
			{
				x <- sort(unique(data_pr[,xvar]))
				if(xvar != 'zero_coupon' | do_pr_zero)
				{
					outdata_pr <- data.frame(x=x,response=res_pr[1:length(x),xvar])
					colnames(outdata_pr)[1] <- xvar 
					wgts <- aggregate(fit_pr$weights,by=list(data_pr[,xvar]),FUN=sum)
					names(wgts) <- c(xvar,'wgt')
					outdata_pr <- merge(outdata_pr,wgts,by = xvar)
					shift <- sum(outdata_pr$response*outdata_pr$wgt)/sum(outdata_pr$wgt)
					
					outdata_pr$response <- outdata_pr$response - shift
					index_oas_pr <- index_oas_pr + shift
					
					outdata_pr <- data.frame(ID = 1, SECTOR='muni',AS_OF_DATE=as_of,ATTRIBUTE=paste(xvar,'_pr',sep=''),VALUE1=outdata_pr[,xvar],VALUE2=0,OAS=outdata_pr$response)
				}
			}
		}
		oas_attr <- rbind(oas_attr,outdata)
		if(xvar %in% xvar_pr & do_pr)
			oas_attr_pr <- rbind(oas_attr_pr,outdata_pr)
	}
	
	for(i in 1:length(xvar_factor_interp))
	{
		xvar = xvar_factor_interp[i]
		
		x <- sort(unique(data[,xvar]))
		outdata <- data.frame(x=x,response=res[1:length(x),xvar])
		colnames(outdata)[1] <- xvar 
		wgts <- aggregate(fit$weights,by=list(data[,xvar]),FUN=sum)
		names(wgts) <- c(xvar,'wgt')
		outdata <- merge(outdata,wgts)
		shift <- sum(outdata$response*outdata$wgt)/sum(outdata$wgt)
		
		outdata$response <- outdata$response - shift
		index_oas <- index_oas + shift
		
		matb = term_interpolation_buckets # buckets for interpolation and saving
		inx = substring(as.character(outdata[,xvar]),1,3) %in% substring(as.character(xvar_factor_tags[i]),1,3) # pick factors of term structure
		x = term_calibration_buckets # calibration buckets (matches zero_coupon and taxability buckets in load_data function)
		term_calib = outdata[inx,]
		term_calib = term_calib[order(term_calib[,xvar]),]
		xout = c(as.character(outdata[!inx,xvar]),as.character(xvar_factor_tags[i] + 4*matb))
		yout = c(outdata[!inx,'response'],approx(x,term_calib$response,matb,rule = 2)$y)
		outdata <- data.frame(ID = 1, SECTOR='muni',AS_OF_DATE=as_of,ATTRIBUTE=xvar,VALUE1=xout,VALUE2=0,OAS=yout)
		
		if(xvar %in% xvar_pr & do_pr)
		{
			x <- sort(unique(data_pr[,xvar]))
			if(xvar != 'zero_coupon' | do_pr_zero)
			{
				outdata_pr <- data.frame(x=x,response=res_pr[1:length(x),xvar])
				colnames(outdata_pr)[1] <- xvar 
				wgts <- aggregate(fit_pr$weights,by=list(data_pr[,xvar]),FUN=sum)
				names(wgts) <- c(xvar,'wgt')
				outdata_pr <- merge(outdata_pr,wgts,by = xvar)
				shift <- sum(outdata_pr$response*outdata_pr$wgt)/sum(outdata_pr$wgt)
					
				outdata_pr$response <- outdata_pr$response - shift
				index_oas_pr <- index_oas_pr + shift
					
				outdata_pr <- data.frame(ID = 1, SECTOR='muni',AS_OF_DATE=as_of,ATTRIBUTE=paste(xvar,'_pr',sep=''),VALUE1=outdata_pr[,xvar],VALUE2=0,OAS=outdata_pr$response)
				oas_attr_pr <- rbind(oas_attr_pr,outdata_pr)
			}
		}
			
		oas_attr <- rbind(oas_attr,outdata)
	}
	#################################################################################
	# deminimis
	outdata <- data.frame(ID = 1, SECTOR='muni',AS_OF_DATE=as_of,ATTRIBUTE='deminimis_buffer',
		VALUE1=deminimis_buffers,VALUE2=0,OAS=res[1:length(deminimis_buffers),'s(deminimis_buffer):hy0'])
	oas_attr <- rbind(oas_attr,outdata)
	if(dohy)
		outdata <- data.frame(ID = 1, SECTOR='muni',AS_OF_DATE=as_of,ATTRIBUTE='deminimis_buffer',
			VALUE1=deminimis_buffers,VALUE2=1,OAS=res[(length(deminimis_buffers)+1):(2*length(deminimis_buffers)),'s(deminimis_buffer):hy1'])
	else
		outdata <- data.frame(ID = 1, SECTOR='muni',AS_OF_DATE=as_of,ATTRIBUTE='deminimis_buffer',
			VALUE1=deminimis_buffers,VALUE2=1,OAS=res[(length(deminimis_buffers)+1):(2*length(deminimis_buffers)),'s(deminimis_buffer):hy0'])
	
	oas_attr <- rbind(oas_attr,outdata)
		# pre-refs
	if(do_pr)
	{	
		outdata_pr <- data.frame(ID = 1, SECTOR='muni',AS_OF_DATE=as_of,ATTRIBUTE='deminimis_buffer_pr',
			VALUE1=deminimis_buffers_pr,VALUE2=0,OAS=res_pr[1:length(deminimis_buffers_pr),'deminimis_buffer'])
		oas_attr_pr <- rbind(oas_attr_pr,outdata_pr)
	}
	################################################################################
	#index_oas
	outdata <- data.frame(ID = 1, SECTOR='muni',AS_OF_DATE=as_of,ATTRIBUTE='index_oas',VALUE1=1,VALUE2=0,OAS=index_oas)
	oas_attr <- rbind(oas_attr,outdata)
		# pre-refs
	if(do_pr)
	{	
		outdata_pr <- data.frame(ID = 1, SECTOR='muni',AS_OF_DATE=as_of,ATTRIBUTE='index_oas_pr',VALUE1=1,VALUE2=0,OAS=index_oas_pr)
		oas_attr_pr <- rbind(oas_attr_pr,outdata_pr)
		
		oas_attr = rbind(oas_attr,oas_attr_pr)
	}
	
	stmt <- paste("delete from OAS_ATTRIBUTION_FIT
			where SECTOR ='muni' and AS_OF_DATE='",format(as_of,'%d-%b-%Y'),"'
			",sep='')
				
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    sqlQuery(channel,query=stmt )
    odbcClose(channel)
    
    export2db(data=oas_attr,server_type='SQL',server=db_info$Database,db=db_info$InitDB,table='OAS_ATTRIBUTION_FIT',user=db_info$User,psw=db_info$Password,na='')	
				
	invisible()
}

clear_oas_fit_tables <- function()
{
	#dangerous action. ask the user for confirmation!
	cat("\n","About to delete all muni data in OAS_ATTRIBUTION_FIT table. Are you sure [y/n/a(bort)]?","\n") # prompt 
	y<-scan(what=character(),nmax=1,quiet=T) 
	while(y!='y' & y!='n' & y!='a')
	{
		cat('[y/n/a(bort)]?\n')
		y<-scan(what=character(),nmax=1,quiet=T) 
	}
	
	if(y=='a'){
		stop('abort\n')
	}
	else if(y=='n') 
	{
		cat('muni data in table OAS_ATTRIBUTION_FIT will not be deleted.\n')
	}else
	{
		cat('delete all muni data in OAS_ATTRIBUTION_FIT table.\n')
		channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
		stmt = paste("delete from OAS_ATTRIBUTION_FIT
			where SECTOR ='muni'",sep='')
	    sqlQuery(channel,query=stmt)
	    odbcClose(channel)
	}
}
################################################################################
################################################################################
	invisible()
library('getopt')
opt = getopt(matrix(
    c(
    'db',   's', 2, "character",   
    'as_of','d', 2, "character",
    'help', 'h', 0, "logical"
    ),ncol=4,byrow=TRUE)
)

if ( !is.null(opt$help) ) {
  self = 'Rscript update_factor_loading.R'
  cat(paste("
    Usage: ",self,"  [--all] [--help]  
    	db:   Database server to run the script on (PRD/QA/DEV).
    	as_of:as_of date in yyyy-mm-dd format. if missing, then fit surface for
    	      all month-end dates as well as the very last date. Optional      
        help: Show help.  Optional
    Example: RScript fit_surface.R --db QA --as_of 2012-02-15
  ",sep=""))
  q(status=1)
}

if ( is.null(opt$db) ) opt$db = 'QA'
###############################################################################
#source('H:/SVN/Muni/v1.0/Src/ExcessReturn/fit_surface.dev26.R') State term structure
#source('C:/SVN/Quant_Model-SQLServer/Muni/v1.0/Src/ExcessReturn/fit_surface.kal.R') Kalotay production
setwd(paste(Sys.getenv('ABFI_DATA_REPOSITORY'),'\\Muni\\v1.0',sep='') )

library(RODBC)
db_info <- get_db_info(opt$db)
#opt$as_of = as.Date('2018-08-31')
#cat('see db info below:\n')
#db_info
#print(opt$as_of)
src = 'Index'

if( !is.null(opt$as_of) ) 
{
	dates <- load_muni_analytics_dates(as.Date(opt$as_of),db_info,src=src)
	if(is.null(dates))
	{
		cat('No analytics data!\n')
		q(status = 1)
	}
	#print(dates)
	if(sum(dates==as.Date(opt$as_of)) > 0 | as.Date(opt$as_of) >= last.business.day(month.end(as.Date(opt$as_of))))
	{
		dates = dates[length(dates)] 
	}else 
	{
		cat('no date exist as of',format(opt$as_of),'\n')
		q(status=1)
	}
}else
{
	clear_oas_fit_tables()
	dates <- load_muni_analytics_dates(Sys.Date(),db_info,src=src)
}

#dates = dates[dates >= as.Date('2017-02-28')]
library(mgcv)
	
#postscript('Output/gam_plot.eps')
#par(mfrow=c(2,2))
#dates = dates[dates > as.Date('2011-12-31')]
for(i in 1:length(dates))
{	
	cat(format(Sys.time()),'loading data as of',format(dates[i]),'...\n')
	#opt$db = 'PRD'
	db_info <- get_db_info(opt$db)
	data <- load_data(dates[i],db_info,src=src,T)
	
	#remove 5% outliers
	ix <- data$muni_oas>quantile(data$muni_oas,0.975,na.rm=T) | data$muni_oas<quantile(data$muni_oas,0.025,na.rm=T)
	data <- data[!ix,]
	
	#remove rows with missing data
	xvars <- c('credit_rating','muni_oad','deminimis_buffer','state','ab_code','muni_taxability','extension_risk',
					'zero_coupon','time_to_maturity','ce_bucket','cal_impact')
					
	ix <- !is.na(data[,xvars]) & ( data[,xvars]==-Inf | data[,xvars]==Inf )
	data[,xvars][ix] <- NA
	
	data <- na.exclude(data[,c('identifier','muni_oas',xvars)])
	data = data[data$muni_oad >= 0,]
	#opt$db = 'DEV'
	#db_info <- get_db_info(opt$db)
	fit_data(dates[i],data)
	gc()
}

#dev.off()
#system(' cmd /c ps2pdf Output/gam_plot.eps Output/gam_plot.pdf ')
#unlink('*.eps')

#24-month momentum reversion!!
update_mean_oas_attr(db_info,dates,mv_lag=25)

cat(date(),'Done.\n')
q(status=0)

#source('H:/dev/Quant_Model-SQLServer/Muni/v1.0/Src/ExcessReturn/fit_surface.R')
###############################################################################

		