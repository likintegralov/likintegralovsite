
source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.kal.R',sep='') )


load_all_muni_analytics_dates <- function(as_of,dbi,src=NULL)
{
	require(RODBC)
	
	src_str <- ''
	if(!is.null(src)) src_str <- paste("and SOURCE='",src,"'\n",sep='')
	
	stmt <- paste("
		select AS_OF_DATE=EFFECTIVE_DATE,cnt=COUNT(*)
		from Optimizer.dbo.MUNI_ANALYTICS_KALOTAY
		where MUNI_10YR_KRD is not null
		",src_str,"and EFFECTIVE_DATE <= '", format(as_of,'%d-%b-%Y'),"'
		group by EFFECTIVE_DATE
	",sep='')
	
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',dbi$Database,';DataBase=',dbi$InitDB,';uid=',dbi$User,';pwd=',dbi$Password,sep=''))
    res <- sqlQuery(channel,query=stmt)
    odbcClose(channel)
    
    if(nrow(res)==0) return(NULL)
    
    names(res) <- casefold(names(res),F)
    res$as_of_date <- as.Date(res$as_of_date)
    
    res <- res[res$cnt>=10000,]
        
    res$as_of_date
}


load_prere <- function(db_info)
{
	dates = sort(load_all_muni_analytics_dates(Sys.Date(),db_info,'RS prod1'))
	prere = read.csv('H://Work//muni//oas analytics//prerefsKal.csv')
	prere$REFDATE = as.Date(prere$REFDATE)
	
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))

	
	for(i in 1)#length(dates))
	{
		cat(paste(format(dates[1]),"\n",sep=''))
		sqlQuery(channel,query=paste("delete from Optimizer.dbo.MUNI_PRERE where TRADEDATE = '",dates[i],"'",sep = '') )
		outdata = prere[prere$REFDATE <= as.Date(dates[i]),]
		t = outdata
		outdata$REFDATE = dates[i]
		outdata$CUSIP = substring(outdata$CUSIP,1,8)
		outdata = cbind(t$CUSIP,outdata)
		names(outdata)[1] = 'SECURITY_ID'
		names(outdata)[3] = 'TRADEDATE'
		outdata$PRE_REFUNDED = 'Y'
		
		export2db(data=outdata,server_type='SQL',server=db_info$Database,db='Optimizer',table='MUNI_PRERE',user=db_info$User,psw=db_info$Password,na='')
	}
	
    

	odbcClose(channel)	
}

load_ncl_curve <- function(db_info)
{
	crv = read.csv('N:/ABFI_PROD/Quant_Data_Repo/Muni/v1.0/Input/aaancl3m.csv')
	crv$AS_OF_DATE = as.Date(crv$AS_OF_DATE)
	
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
	
	sqlQuery(channel,query="delete from FIQModel.dbo.YIELD_CURVE_TIMESERIES where YC_NAME = 'MuniCurveNCL' and AS_OF_DATE <= '2018-03-05'" )

	export2db(data=crv,server_type='SQL',server=db_info$Database,db='FIQModel',table='YIELD_CURVE_TIMESERIES',user=db_info$User,psw=db_info$Password,na='')
}

load_bk_param <- function(db_info)
{
	crv = read.csv('N:/ABFI_PROD/Quant_Data_Repo/Muni/v1.0/Input/bkprod.csv')
	crv$AS_OF_DATE = as.Date(crv$AS_OF_DATE)
	
	crv = cbind(data.frame(ID = 0),crv)
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
	
	sqlQuery(channel,query="delete from MUNI.dbo.BK_PARAMETERS where AS_OF_DATE <= '2018-03-05'" )

	export2db(data=crv,server_type='SQL',server=db_info$Database,db='MUNI',table='BK_PARAMETERS',user=db_info$User,psw=db_info$Password,na='')
}

load_state_dummy <- function(db_info)
{
	stmap = read.csv('N:/ABFI_PROD/Quant_Data_Repo/Muni/v1.0/Input/statedummy.csv')
	#stmap = read.csv('N:/ABFI_PROD/Quant_Data_Repo/Muni/v1.0/Input/statedummyprod.csv')
	if(dim(stmap)[1] > 0)
	{
		channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
	
    	sqlQuery(channel,query="delete from FIQModel.dbo.MUNI_DUMMY_VARIABLE_MAP where ATTRIBUTE in ('state','muni_taxability')" )
    	odbcClose(channel)
    	
    	export2db(data=stmap,server_type='SQL',server=db_info$Database,db=db_info$InitDB,table='MUNI_DUMMY_VARIABLE_MAP',user=db_info$User,psw=db_info$Password,na='')
	}
}
    
load_oas_decomp <- function(date, dbi)
{
	q = paste("select AS_OF_DATE,IDENTIFIER, RESI_OAS from FIQModel..MUNI_OAS_DECOMPOSITION where AS_OF_DATE = '",date,"'",sep = '')
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',dbi$Database,';DataBase=',dbi$InitDB,';uid=',dbi$User,';pwd=',dbi$Password,sep=''))
	d = sqlQuery(channel,q)	
	odbcClose(channel)
	names(d) = tolower(names(d))
	d$as_of_date = as.Date(d$as_of_date)
	d
}

crmap = data.frame(credit = seq(1,21),creditmain = c(1, 2, 2, 2, 3, 3, 3, 4, 4, 4, 5, 5, 5, 6, 6, 6, 7, 7, 7, 8, 8))
crtag = data.frame(credit = seq(1:8),tag = c('AAA','AA','A','BBB','BB','B','CCC','CC'))
#setwd(paste(Sys.getenv('ABFI_DATA_REPOSITORY'),'\\Muni\\v1.0',sep='') )
#source('H:/SVN/Muni/v1.0/Src/ExcessReturn/tmp.R')
s1 = seq(302,336)
sf = c()
for(i in 1:length(s1))
	sf = c(sf,rep(s1[i],dim(crtag)[1]))
cf = rep(seq(1:8),length(s1))	
sect_cr = data.frame(sec = sf,cr = cf)

library(RODBC)
db_info <- get_db_info('QA')


dates = load_muni_analytics_dates(Sys.Date(),db_info,src='Index')
dates = dates[dates >= as.Date('2009-11-30')]
resihist = data.frame()
counthist = data.frame()
for(i in length(dates))
{
	data = load_data(dates[i],db_info,'Index')
	mresi = load_oas_decomp(dates[i],db_info)
	data = merge(data,mresi)
	data = data[!is.na(data$resi_oas),]
	data$credit_rating = round(data$credit_rating)
	data = merge(data,crmap,by.x = 'credit_rating',by.y = 'credit')
	meanresi = aggregate(data$resi_oas, by = list(sector = data$ab_code, credit = data$creditmain), FUN = mean)
	bcount = aggregate(rep(1,dim(data)[1]),by = list(sector = data$ab_code, credit = data$creditmain), FUN = sum)
	
	meanresi = meanresi[order(meanresi$sector,meanresi$credit),]
	bcount = bcount[order(bcount$sector,bcount$credit),]
	
	drow = data.frame(Date = dates[i])
	for(j in 1:dim(sect_cr)[1])
	{
		j1 = which(sect_cr$sec[j] == meanresi$sector & sect_cr$cr[j] == meanresi$credit)
		if(length(j1) > 0)
		{
			cname = paste(meanresi$sector[j1],'-',crtag$tag[crtag$credit == meanresi$credit[j1]],sep = '')
			drow = cbind(drow,meanresi$x[j1])
			names(drow)[dim(drow)[2]] = cname
		}else
		{
			cname = paste(sect_cr$sec[j],'-',crtag$tag[crtag$credit == sect_cr$cr[j]],sep = '')
			drow = cbind(drow,NA)
			names(drow)[dim(drow)[2]] = cname
		}
	}
	resihist = rbind(resihist,drow)
	
	drow = data.frame(Date = dates[i])
	for(j in 1:dim(sect_cr)[1])
	{
		j1 = which(sect_cr$sec[j] == bcount$sector & sect_cr$cr[j] == bcount$credit)
		if(length(j1) > 0)
		{
			cname = paste(bcount$sector[j1],'-',crtag$tag[crtag$credit == bcount$credit[j1]],sep = '')
			drow = cbind(drow,bcount$x[j1])
			names(drow)[dim(drow)[2]] = cname
		}else
		{
			cname = paste(sect_cr$sec[j],'-',crtag$tag[crtag$credit == sect_cr$cr[j]],sep = '')
			drow = cbind(drow,NA)
			names(drow)[dim(drow)[2]] = cname
		}
	}
	counthist = rbind(counthist,drow)
}