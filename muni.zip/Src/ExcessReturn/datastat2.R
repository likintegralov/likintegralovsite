#!\\nts0018\bond\ABFI_PROD\QuantApps\R-2.14.2\bin\Rscript

source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.R',sep='') )

load_raw_data <- function(as_of,dbi,src=NULL,init = F,cetags = F)
{
	require(RODBC)
	
	cat('loading data as of',format(as_of),' from ',src,' ...\n')
	stmt <- paste("
		SELECT anal.SOURCE,
		anal.IDENTIFIER,anal.EFFECTIVE_DATE AS AS_OF_DATE,anal.AMT_OUTSTANDING,
		INDEX_RATING,
		INDEX_RATING_NUM=idx.ID,
		MOODY_RATING=moody.ID,
		SP_RATING   =sp.ID,
		FITCH_RATING=fitch.ID,
		UND_MOODY_RATING = undmoody.ID,
		UND_SP_RATING = undsp.ID,
		APEX_MUNI_INSURANCE insurer,
		anal.STATE,
		MUNI_TAXABILITY,
		anal.ISSUE_PRICE,anal.ISSUE_YIELD,anal.YIELD_TO_MAT,
		anal.COUPON,anal.MATURITY_DATE,anal.PRICE,anal.NEXT_SINK_DATE,anal.NEXT_CALL_DATE,
		anal.MUNI_OAS_RISK AS MUNI_OAS,anal.MUNI_OAD_RISK AS MUNI_OAD,
		TIME_TO_WORST=(CASE WHEN anal.TIME_TO_WORST IS NULL THEN DATEDIFF(DAY,EFFECTIVE_DATE,MATURITY_DATE)/365.0 ELSE anal.TIME_TO_WORST END),
		TIME_TO_MATURITY=DATEDIFF(DAY,EFFECTIVE_DATE,MATURITY_DATE)/365.0,
		anal.PURPOSE_TYPE,
		anal.MUNI_6MO_KRD,anal.MUNI_2YR_KRD,anal.MUNI_5YR_KRD,
		anal.MUNI_10YR_KRD,anal.MUNI_20YR_KRD,anal.MUNI_30YR_KRD,
		anal.COUPON_RETURN_MTD,anal.PRICE_RETURN_MTD,anal.MUNI_OAC as convexity,anal.EDTS deminimis_buffer
		FROM Optimizer.dbo.MUNI_ANALYTICS_KALOTAY anal
		LEFT JOIN FIQModel.dbo.BOND_CREDIT_RATING idx
		ON UPPER(idx.MOODY)=anal.INDEX_RATING
		LEFT JOIN FIQModel.dbo.BOND_CREDIT_RATING moody
		ON UPPER(moody.MOODY)=anal.MOODY_RATING
		LEFT JOIN FIQModel.dbo.BOND_CREDIT_RATING sp
		ON UPPER(sp.SP)=anal.SP_RATING
		LEFT JOIN FIQModel.dbo.BOND_CREDIT_RATING fitch
		ON UPPER(fitch.FITCH)=anal.FITCH_RATING
		LEFT JOIN FIQModel.dbo.BOND_CREDIT_RATING undmoody
		ON UPPER(undmoody.MOODY)=anal.UI_MOODY_RATING
		LEFT JOIN FIQModel.dbo.BOND_CREDIT_RATING undsp
		ON UPPER(undsp.SP)=anal.UI_SP_RATING ",
		"where anal.EFFECTIVE_DATE='", format(as_of,'%d-%b-%Y'),"'		
	",sep='')
	if(!is.null(src)) stmt <- paste(stmt,"and SOURCE='",src,"'\n",sep='')
	
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',dbi$Database,';DataBase=',dbi$InitDB,';uid=',dbi$User,';pwd=',dbi$Password,sep=''))
    data <- sqlQuery(channel,query=stmt)
    odbcClose(channel)
    
    names(data) <- casefold(names(data),F)
    idx <- grep('date',names(data))
    for(id in idx) data[,id] <- as.Date(data[,id])

    data
}

load_all_dates <- function(as_of,dbi,src=NULL)
{
	require(RODBC)
	
	stmt <- paste("
		select AS_OF_DATE=EFFECTIVE_DATE,cnt=COUNT(*)
		from Optimizer.dbo.MUNI_ANALYTICS_KALOTAY
		where SOURCE='",src,"' ",
		"and EFFECTIVE_DATE <= '", format(as_of,'%d-%b-%Y'),"'
		group by EFFECTIVE_DATE
	",sep='')
	
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',dbi$Database,';DataBase=',dbi$InitDB,';uid=',dbi$User,';pwd=',dbi$Password,sep=''))
    res <- sqlQuery(channel,query=stmt)
    odbcClose(channel)
    
    if(nrow(res)==0) return(NULL)
    
    names(res) <- casefold(names(res),F)
    res$as_of_date <- as.Date(res$as_of_date)
    
    sort(res$as_of_date)
}

################################################################################
################################################################################
library('getopt')
opt = getopt(matrix(
    c(
    'db',   's', 2, "character",   
    'as_of','d', 2, "character",
    'help', 'h', 0, "logical"
    ),ncol=4,byrow=TRUE)
)

if ( !is.null(opt$help) ) {
  self = 'Rscript update_factor_loading.R'
  cat(paste("
    Usage: ",self,"  [--all] [--help]  
    	db:   Database server to run the script on (PRD/QA/DEV).
    	as_of:as_of date in yyyy-mm-dd format. if missing, then fit surface for
    	      all month-end dates as well as the very last date. Optional      
        help: Show help.  Optional
    Example: RScript fit_surface.R --db QA --as_of 2012-02-15
  ",sep=""))
  q(status=1)
}

if ( is.null(opt$db) ) opt$db = 'QA'
###############################################################################
#source('H:/SVN/Muni/v1.0/Src/ExcessReturn/datastat2.R')
setwd(paste(Sys.getenv('ABFI_DATA_REPOSITORY'),'\\Muni\\v1.0',sep='') )

library(RODBC)
db_info <- get_db_info(opt$db)
opt$as_of = as.Date('2017-08-18')
#cat('see db info below:\n')
#db_info
#print(opt$as_of)

dates <- load_muni_analytics_dates(Sys.Date(),db_info,src='Barcap')

library(mgcv)
	
#postscript('Output/gam_plot.eps')
#par(mfrow=c(2,2))
#dates = dates[dates > as.Date('2011-12-31')]
prestats = data.frame()
for(i in 1:100)#length(dates))
{	
	cat(format(Sys.time()),'loading data as of',format(dates[i]),'...\n')
	#opt$db = 'PRD'

	db_info <- get_db_info(opt$db)
	data <- load_data(dates[i],db_info,src='Barcap',T)
	
	tstat = data.frame(Date = data$as_of_date[1])
	
	tstat = cbind(tstat, data.frame(prerefs = sum(!is.na(data$ab_code) & data$ab_code == 333)))
	
	
	#remove rows with missing data
#	xvars <- c('credit_rating','muni_oad','deminimis_buffer','state','ab_code','muni_taxability','extension_risk',
#					'zero_coupon','time_to_maturity','ce_bucket')	
					
#	ix <- !is.na(data[,xvars]) & ( data[,xvars]==-Inf | data[,xvars]==Inf )
#	data[,xvars][ix] <- NA
	
#	data <- na.exclude(data[,c('identifier','muni_oas',xvars)])

#	gc()
    prestats = rbind(prestats,tstat)
}



#source('H:/dev/Quant_Model-SQLServer/Muni/v1.0/Src/ExcessReturn/fit_surface.R')
###############################################################################

		