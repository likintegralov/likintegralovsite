#!\\nts0018\bond\ABFI_PROD\QuantApps\R-2.14.2\bin\Rscript

source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.R',sep='') )

################################################################################
upload_sector_codes <- function(code_file)
{
	library(RODBC)
	db_info <- get_db_info(opt$db)

	data <- read.csv(code_file,header=F,col.names=c('IDENTIFIER','AB_CODE'),stringsAsFactors=F)
	data$IDENTIFIER <- substr(data$IDENTIFIER,1,8)
	
	stmt <- paste("
		SELECT * from MUNI_SECTOR_CODE	
	",sep='')
	
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
	res <- sqlQuery(channel,query=stmt)
	odbcClose(channel)
	
	idx <- !data$IDENTIFIER %in% res$IDENTIFIER
	if(sum(idx)>0)
	{
		cat(sum(idx),'new codes to load.\n')
		data <- data[idx,]
		export2db(data,server_type='SQL',server=db_info$Database,db=db_info$InitDB,table='MUNI_SECTOR_CODE',user=db_info$User,psw=db_info$Password,na='')	
	}else(
		cat('no new codes to load\n')
	)
	invisible()
}

################################################################################
library('getopt')
opt = getopt(matrix(
    c(
    'db',   's', 2, "character",   
    'help', 'h', 0, "logical"
    ),ncol=4,byrow=TRUE)
)

if ( !is.null(opt$help) ) {
  self = 'Rscript update_factor_loading.R'
  cat(paste("
    Usage: ",self,"  [--all] [--help]  
    	db:   Database server to run the script on (PRD/QA/DEV).
        help: Show help.  Optional
    Example: RScript fit_surface.R --db QA --as_of 2012-02-15
  ",sep=""))
  q(status=1)
}

if ( is.null(opt$db) ) opt$db = 'QA'
###############################################################################
#source('H:/dev/Quant_Model-SQLServer/Muni/v1.0/Src/ExcessReturn/load_sector_code.R')
setwd(paste(Sys.getenv('ABFI_DATA_REPOSITORY'),'\\Muni\\v1.0\\Output',sep='') )

code_file <- 'D:/FIQBatch/Data/SectorCodes/SectorCodes.txt'
if(file.exists('SectorCodes_lastUpdated.csv')) {
	last_updated <- as.Date(read.csv('SectorCodes_lastUpdated.csv',header=F)[1,1])
}else last_updated <- as.Date('1990-01-01')

modified <- as.Date( file.info(code_file)$mtime )
if(modified >= last_updated) 
{
	upload_sector_codes(code_file)
	write.table(modified,file='SectorCodes_lastUpdated.csv',row.names=F,col.names=F)
}else
{
	cat(code_file,'has not been udpated since',format(last_updated),'\n')
}

cat(date(),'Done.\n')
q(status=0)

#source('H:/dev/Quant_Model-SQLServer/Muni/v1.0/Src/ExcessReturn/load_sector_code.R')
###############################################################################

		