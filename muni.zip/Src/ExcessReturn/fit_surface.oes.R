#!\\nts0018\bond\ABFI_PROD\QuantApps\R-2.14.2\bin\Rscript

source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.oes.R',sep='') )

fit_data <- function(as_of,data)
{
	cat('total',nrow(data),'rows of data.\n')
	
	#winsorise
	data$muni_oad <- winsorise(data$muni_oad,lb=0.00,ub=0.99)
	data$deminimis_buffer <- winsorise(data$deminimis_buffer,lb=0.01,ub=0.99)
	
	#factorize
	data$state <- as.factor(data$state)
	data$ab_code <- as.factor(data$ab_code)
	data$muni_taxability <- as.factor(data$muni_taxability)
	data$zero_coupon = as.factor(data$zero_coupon)
	data$hy = as.factor(ifelse(data$credit_rating > 10,1,0))
	
	dohy = ifelse(sum(as.integer(data$hy)-1) > 10,1,0)
	
	cat(format(Sys.time()),'running gam...\n')
	fit <- gam( muni_oas ~ te(credit_rating, muni_oad,k=c(3,4)) + s(deminimis_buffer,k=4,by = hy) 
							+ state+ ab_code + muni_taxability + zero_coupon, data = data) 
	
	cat(format(Sys.time()),'done.\n')
	################################################################################
	r_sqr <- (fit$null.deviance-fit$deviance)/fit$null.deviance
	
	cat('r_sqr=',round(r_sqr,2),'\n')
	
	################################################################################
	#plot(fit,rug=F,pers=T,theta=-45,main=format(as_of))
		
	################################################################################
	#first fit credit curve
	x <- sort(unique(data$credit_rating))
	y <- unique( round( c(min(data$muni_oad),quantile(data$muni_oad,1:100/100) ), 4) )
	
	states <- sort(unique(data$state))
	ab_codes <- sort(unique(data$ab_code))
	taxabilities <- sort(unique(data$muni_taxability))
	zero_coupon = sort(unique(data$zero_coupon))
	
	deminimis_buffers <- seq(min(data$deminimis_buffer),max(data$deminimis_buffer),length.out=100)
	
	n <- length(x)*length(y)
	newdata <- data.frame(credit_rating=rep(x,length(y)),muni_oad=rep(y,rep(length(x),length(y))),
		deminimis_buffer=c(deminimis_buffers,deminimis_buffers,rep(deminimis_buffers[length(deminimis_buffers)],n-2*length(deminimis_buffers))),
		state=factor(c(levels(states)[states],rep(levels(states)[1],n-length(states)))),
		ab_code=factor(c(levels(ab_codes)[ab_codes],rep(levels(ab_codes)[1],n-length(ab_codes)))),
		muni_taxability=factor(c(levels(taxabilities)[taxabilities],rep(levels(taxabilities)[1],n-length(taxabilities)))),
		zero_coupon=factor(c(levels(zero_coupon)[zero_coupon],rep(levels(zero_coupon)[1],n-length(zero_coupon)))),
		hy = c(rep(0,length(deminimis_buffers)),rep(1,n-length(deminimis_buffers)))
		)
		
	res <- predict(fit,newdata=newdata,type='terms')
	
	#z <- matrix(res[,'te(credit_rating,muni_oad)'],nrow=length(x))
	#persp(x,y,z,theta=-45,xlab='Rating',ylab='muni_oad',zlab='muni_oas')
	
	################################################################################
	cat(format(Sys.time()),'writing results...\n')
	################################################################################
	#credit surface
	oas_attr <- data.frame(ID = 1, SECTOR='muni',AS_OF_DATE=as_of,ATTRIBUTE='credit_oad',VALUE1=newdata$credit_rating,VALUE2=newdata$muni_oad,OAS=res[,'te(credit_rating,muni_oad)'])
	################################################################################	
	xvars_ex_credit <- c('state','ab_code','muni_taxability','zero_coupon')
	
	index_oas <- attr(res,'constant')
	################################################################################
	for(xvar in xvars_ex_credit)
	{
		if(is.numeric(data[,xvar]))
		{
			x <- seq(min(data[,xvar]),max(data[,xvar]),length.out=100)
			outdata <- data.frame(x=x,response=res[1:length(x),paste('s(',xvar,')',sep='')])
			colnames(outdata)[1] <- xvar 
			outdata <- data.frame(ID = 1, SECTOR='muni',AS_OF_DATE=as_of,ATTRIBUTE=xvar,VALUE1=outdata[,xvar],VALUE2=0,OAS=outdata$response)			
		}else #is.factor
		{
			x <- sort(unique(data[,xvar]))
			outdata <- data.frame(x=x,response=res[1:length(x),xvar])
			colnames(outdata)[1] <- xvar 
			wgts <- aggregate(fit$weights,by=list(data[,xvar]),FUN=sum)
			names(wgts) <- c(xvar,'wgt')
			outdata <- merge(outdata,wgts)
			shift <- sum(outdata$response*outdata$wgt)/sum(outdata$wgt)
			
			outdata$response <- outdata$response - shift
			index_oas <- index_oas + shift
			
			outdata <- data.frame(ID = 1, SECTOR='muni',AS_OF_DATE=as_of,ATTRIBUTE=xvar,VALUE1=as.numeric(levels(outdata[,xvar])),VALUE2=0,OAS=outdata$response)
		}
		oas_attr <- rbind(oas_attr,outdata)
	}
	
	#################################################################################
	# deminimis
	outdata <- data.frame(ID = 1, SECTOR='muni',AS_OF_DATE=as_of,ATTRIBUTE='deminimis_buffer',
		VALUE1=deminimis_buffers,VALUE2=0,OAS=res[1:length(deminimis_buffers),'s(deminimis_buffer):hy0'])
	oas_attr <- rbind(oas_attr,outdata)
	if(dohy)
		outdata <- data.frame(ID = 1, SECTOR='muni',AS_OF_DATE=as_of,ATTRIBUTE='deminimis_buffer',
			VALUE1=deminimis_buffers,VALUE2=1,OAS=res[(length(deminimis_buffers)+1):(2*length(deminimis_buffers)),'s(deminimis_buffer):hy1'])
	else
		outdata <- data.frame(ID = 1, SECTOR='muni',AS_OF_DATE=as_of,ATTRIBUTE='deminimis_buffer',
			VALUE1=deminimis_buffers,VALUE2=1,OAS=res[(length(deminimis_buffers)+1):(2*length(deminimis_buffers)),'s(deminimis_buffer):hy0'])
	
	oas_attr <- rbind(oas_attr,outdata)
	
	################################################################################
	#index_oas
	outdata <- data.frame(ID = 1, SECTOR='muni',AS_OF_DATE=as_of,ATTRIBUTE='index_oas',VALUE1=1,VALUE2=0,OAS=index_oas)
	oas_attr <- rbind(oas_attr,outdata)

	oas_attr$MEAN_OAS <- NA
	
	stmt <- paste("delete from OAS_ATTRIBUTION_FIT
			where SECTOR ='muni' and AS_OF_DATE='",format(as_of,'%d-%b-%Y'),"'
			",sep='')
				
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    sqlQuery(channel,query=stmt )
    odbcClose(channel)
    
    export2db(data=oas_attr,server_type='SQL',server=db_info$Database,db=db_info$InitDB,table='OAS_ATTRIBUTION_FIT',user=db_info$User,psw=db_info$Password,na='')	
				
	invisible()
}

clear_oas_fit_tables <- function()
{
	#dangerous action. ask the user for confirmation!
	cat("\n","About to delete all muni data in OAS_ATTRIBUTION_FIT table. Are you sure [y/n/a(bort)]?","\n") # prompt 
	y<-scan(what=character(),nmax=1,quiet=T) 
	while(y!='y' & y!='n' & y!='a')
	{
		cat('[y/n/a(bort)]?\n')
		y<-scan(what=character(),nmax=1,quiet=T) 
	}
	
	if(y=='a'){
		stop('abort\n')
	}
	else if(y=='n') 
	{
		cat('muni data in table OAS_ATTRIBUTION_FIT will not be deleted.\n')
	}else
	{
		cat('delete all muni data in OAS_ATTRIBUTION_FIT table.\n')
		channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
		stmt = paste("delete from OAS_ATTRIBUTION_FIT
			where SECTOR ='muni'",sep='')
	    sqlQuery(channel,query=stmt)
	    odbcClose(channel)
	}
	invisible()
}
################################################################################
################################################################################
library('getopt')
opt = getopt(matrix(
    c(
    'db',   's', 2, "character",   
    'as_of','d', 2, "character",
    'help', 'h', 0, "logical"
    ),ncol=4,byrow=TRUE)
)

if ( !is.null(opt$help) ) {
  self = 'Rscript update_factor_loading.R'
  cat(paste("
    Usage: ",self,"  [--all] [--help]  
    	db:   Database server to run the script on (PRD/QA/DEV).
    	as_of:as_of date in yyyy-mm-dd format. if missing, then fit surface for
    	      all month-end dates as well as the very last date. Optional      
        help: Show help.  Optional
    Example: RScript fit_surface.R --db QA --as_of 2012-02-15
  ",sep=""))
  q(status=1)
}

if ( is.null(opt$db) ) opt$db = 'QA'
###############################################################################
#source('H:/SVN/Muni/v1.0/Src/ExcessReturn/fit_surface.oes.R')
setwd(paste(Sys.getenv('ABFI_DATA_REPOSITORY'),'\\Muni\\v1.0',sep='') )

library(RODBC)
db_info <- get_db_info(opt$db)
#db_load = get_db_info('PRD')
#opt$as_of = as.Date('2014-07-31')
#cat('see db info below:\n')
#db_info
#print(opt$as_of)
if( !is.null(opt$as_of) ) 
{
	dates <- load_muni_analytics_dates(as.Date(opt$as_of),db_info,src='OES')
	#print(dates)
	dates <- dates[dates==last.business.day(as.Date(opt$as_of))]
	if(length(dates)==0) 
	{
		cat('no date exist as of',opt$as_of,'\n')
		q(status=0)
	}
}else
{
	clear_oas_fit_tables()
	dates <- load_muni_analytics_dates(Sys.Date(),db_info,src='OES')
}

library(mgcv)
	
#postscript('Output/gam_plot.eps')
#par(mfrow=c(2,2))

for(i in 1:length(dates))
{	
	cat(format(Sys.time()),'loading data as of',format(dates[i]),'...\n')
	#opt$db = 'PRD'
	db_info <- get_db_info(opt$db)
	data <- load_data(dates[i],db_info,src='OES')
	
	#remove 5% outliers
	ix <- data$muni_oas>quantile(data$muni_oas,0.975,na.rm=T) | data$muni_oas<quantile(data$muni_oas,0.025,na.rm=T)
	data <- data[!ix,]
	
	#remove rows with missing data
	xvars <- c('credit_rating','muni_oad','deminimis_buffer','state','ab_code','muni_taxability','zero_coupon')
	
	ix <- !is.na(data[,xvars]) & ( data[,xvars]==-Inf | data[,xvars]==Inf )
	data[,xvars][ix] <- NA
	
	data <- na.exclude(data[,c('muni_oas',xvars)])
	#opt$db = 'DEV'
	db_info <- get_db_info(opt$db)
	fit_data(dates[i],data)
	gc()
}

#dev.off()
#system(' cmd /c ps2pdf Output/gam_plot.eps Output/gam_plot.pdf ')
#unlink('*.eps')

#24-month momentum reversion!!
update_mean_oas_attr(db_info,dates,mv_lag=25)

cat(date(),'Done.\n')
q(status=0)

#source('H:/dev/Quant_Model-SQLServer/Muni/v1.0/Src/ExcessReturn/fit_surface.R')
###############################################################################

		