#!\\nts0018\bond\ABFI_PROD\QuantApps\R-2.14.2\bin\Rscript

source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Utility\\R_Splus\\utility.R',sep='') )
source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.dev5.R',sep='') ) # rating for pre-refs is overwriten with AAA

load_reg_data <- function(as_of)
{
	cat(format(Sys.time()),'loading data as of',format(as_of),'from database...\n')
	stmt <- paste("
		SELECT 
		FWD_DATE,IDENTIFIER,
		EXCESS_RET_FWD3M,KRD_RET_FWD3M_FC,TOTAL_RET_FWD3M,
		INDEX_OAS,CREDIT_OAD,STATE,AB_CODE,MUNI_TAXABILITY,
		DEMINIMIS_BUFFER,RESI_OAS, AMT_OUTSTANDING
		FROM MUNI_MODEL_REGRESSION_DATA
        WHERE FWD_DATE <='", format(as_of,'%d-%b-%Y'),"'
	",sep='')
	
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    reg_data <- sqlQuery(channel,query=stmt)
    odbcClose(channel)
    names(reg_data) <- casefold(names(reg_data),F)
    reg_data$fwd_date <- as.Date(reg_data$fwd_date)
    cat(format(Sys.time()),'done.\n')
	#names(reg_data)[names(reg_data) == 'amt_outstanding'] = 'time_to_maturity'
    reg_data
}

###############################################################################
#source('H:/SVN/Muni/v1.0/Src/ExcessReturn/model_simulation.5.3.R') # run for AAA Maryland 5% State GO
setwd(paste(Sys.getenv('ABFI_DATA_REPOSITORY'),'\\Muni\\v1.0\\Output',sep='') )
#port_id = '2200590000'
#port_id = '2201923050'

#port_name = 'AMINAP'
#port_name = 'BDMP'
#port_name = '03910060'
#port_name = 'BNYMP'
#port_name = 'BCMP'
#port_name = '03973289'

library(RODBC)
db_info <- get_db_info('QA')


# reg_data <- load_reg_data(Sys.Date())

xvars <- c('credit_oad','resi_oas')

mf <- formula(paste('excess_ret_fwd3m ~',paste(xvars,collapse='+')))
        
fwd_dates <- sort(unique(reg_data$fwd_date))
fwd_dates <- fwd_dates[fwd_dates >= as.Date('2009-01-30')]

res <- c()
res.fact = c()
grp1_hist = c()
grp5_hist = c()
starti = 12
ntop = 5

for(i in starti:(length(fwd_dates)-3)) 
{
	cat(format(Sys.time()),'processing',format(fwd_dates[i]),'...\n' )
	q = paste("select a.IDENTIFIER, MATURITY_DATE maturity,  MUNI_OAS_RISK oas, MUNI_OAD_RISK oad, ",
			  "o.RESI_OAS misprice, o.CREDIT_CURVE credit_oad_attr, o.COUPON_EFFECT deminimis, o.EXTENSION_RISK ext_risk, ",
			  "a.YIELD_TO_MAT ytm, a.YIELD_TO_WORST ytw ", 
			  "from Optimizer..MUNI_ANALYTICS a, FIQModel..MUNI_OAS_DECOMPOSITION o where a.STATE = 'MARYLAND' and COUPON = 5 ",
			  "and a.IDENTIFIER = o.IDENTIFIER and a.EFFECTIVE_DATE = o.AS_OF_DATE ",
			  "and EFFECTIVE_DATE =  '",fwd_dates[i],"' and PURPOSE_TYPE = 'Muni GO' and SOURCE = 'Barcap' ",
			  "and PURPOSE_CLASS = 'Muni State'",sep='')
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    port_secs <- sqlQuery(channel,query=q)
	odbcClose(channel)
    
    if(dim(port_secs)[1] > 0)
    {
	model_data <- reg_data[reg_data$fwd_date<=fwd_dates[i],]
	for(xvar in xvars) model_data[,xvar] <- winsorise(model_data[,xvar])
	
	fit <- glm.wridge(
	    formula=mf,
	    data=model_data,
	    lambda=2,
	    batch.size=500000
    )
       
	cat(format(fwd_dates[i]),':b=(bps)',centered.coef(fit)*1e4,'\n')
	##################################################
	##################################################
	
	# get the portfolio securities

    
	pred_data <- reg_data[reg_data$fwd_date==fwd_dates[i+3],]
	inxa = which(!is.na(match(port_secs[,1], pred_data$identifier)))
    inxb = na.exclude(match(port_secs[,1], pred_data$identifier))
    #pred_data = cbind(pred_data[inxb,],data.frame(maturity = port_secs[inxa,2]))
    pred_data = cbind(pred_data[inxb,],port_secs[inxa,2:10])
    #pred_data = pred_data[inxb,]
	print(dim(pred_data))
	
    pred_data$excess_ret_fc_fwd3m <- predict.ridge(fit,newdata=pred_data,type='response',centered = T,winsorised = F)
	pred_data$total_ret_fc_fwd3m <- pred_data$excess_ret_fc_fwd3m + pred_data$krd_ret_fwd3m_fc
	
	ix <- is.na(pred_data$total_ret_fc_fwd3m)
	pred_data <- pred_data[!ix,]

	cor_total <- cor(pred_data$total_ret_fc_fwd3m,pred_data$total_ret_fwd3m,use='pair')
	cor_excess <- cor(pred_data$excess_ret_fc_fwd3m,pred_data$excess_ret_fwd3m,use='pair')
	rankcor_total <- cor(rank(pred_data$total_ret_fc_fwd3m),rank(pred_data$total_ret_fwd3m),use='pair')
	rankcor_excess <- cor(rank(pred_data$excess_ret_fc_fwd3m),rank(pred_data$excess_ret_fwd3m),use='pair')
	
	rank_total <- rank(-pred_data$total_ret_fc_fwd3m)
	n <- length(rank_total)
	grp1_total <- mean(pred_data$total_ret_fwd3m[rank_total<=n/5],na.rm=T)
	grp2_total <- mean(pred_data$total_ret_fwd3m[rank_total>n/5 & rank_total<=2*n/5],na.rm=T)
	grp3_total <- mean(pred_data$total_ret_fwd3m[rank_total>2*n/5 & rank_total<=3*n/5],na.rm=T)
	grp4_total <- mean(pred_data$total_ret_fwd3m[rank_total>3*n/5 & rank_total<=4*n/5],na.rm=T)
	grp5_total <- mean(pred_data$total_ret_fwd3m[rank_total>4*n/5],na.rm=T)
	
	rank_ex <- rank(-pred_data$excess_ret_fc_fwd3m)
	n <- length(rank_ex)
	#grp1_ex <- mean(pred_data$excess_ret_fwd3m[rank_ex<=n/5],na.rm=T)
	grp1_ex <- mean(pred_data$excess_ret_fwd3m[rank_ex<=ntop],na.rm=T)
	grp2_ex <- mean(pred_data$excess_ret_fwd3m[rank_ex>n/5 & rank_ex<=2*n/5],na.rm=T)
	grp3_ex <- mean(pred_data$excess_ret_fwd3m[rank_ex>2*n/5 & rank_ex<=3*n/5],na.rm=T)
	grp4_ex <- mean(pred_data$excess_ret_fwd3m[rank_ex>3*n/5 & rank_ex<=4*n/5],na.rm=T)
	#grp5_ex <- mean(pred_data$excess_ret_fwd3m[rank_ex>4*n/5],na.rm=T)
	grp5_ex <- mean(pred_data$excess_ret_fwd3m[rank_ex>(n-ntop)],na.rm=T)
	
	if(i == starti){
	inx = rank_ex <= ntop
	grp1_hist = data.frame(date = fwd_dates[i],cusip = pred_data$identifier[inx],oas = pred_data$oas[inx],oad = pred_data$oad[inx],
				resi_oas = pred_data$misprice[inx],credit_oad = pred_data$credit_oad_attr[inx],
				deminimis = pred_data$deminimis[inx],ext_risk = pred_data$ext_risk[inx],ytm = pred_data$ytm[inx],ytw = pred_data$ytw[inx],
				maturity = pred_data$maturity[inx], er_3m_act = pred_data$excess_ret_fwd3m[inx],
				tr_3m_act = pred_data$total_ret_fwd3m[inx],er_3m_fc = pred_data$excess_ret_fc_fwd3m[inx],
				krd_fc = pred_data$krd_ret_fwd3m_fc[inx],tr_3m_fc = pred_data$total_ret_fc_fwd3m[inx])
	grp1_hist = data.frame(grp1_hist[order(grp1_hist$cusip),])
	
	inx = rank_ex > (n-ntop)
	grp5_hist = data.frame(date = fwd_dates[i],cusip = pred_data$identifier[inx],oas = pred_data$oas[inx],oad = pred_data$oad[inx],
				resi_oas = pred_data$misprice[inx],credit_oad = pred_data$credit_oad_attr[inx],
				deminimis = pred_data$deminimis[inx],ext_risk = pred_data$ext_risk[inx],ytm = pred_data$ytm[inx],ytw = pred_data$ytw[inx],
				maturity = pred_data$maturity[inx], er_3m_act = pred_data$excess_ret_fwd3m[inx],
				tr_3m_act = pred_data$total_ret_fwd3m[inx],er_3m_fc = pred_data$excess_ret_fc_fwd3m[inx],
				krd_fc = pred_data$krd_ret_fwd3m_fc[inx],tr_3m_fc = pred_data$total_ret_fc_fwd3m[inx])
	grp5_hist = data.frame(grp5_hist[order(grp1_hist$cusip),])
	#names(grp5_hist) = fwd_dates[i+3]
	}else {
	inx = rank_ex <= ntop
	grp1tmp = data.frame(date = fwd_dates[i],cusip = pred_data$identifier[inx],oas = pred_data$oas[inx],oad = pred_data$oad[inx],
				resi_oas = pred_data$misprice[inx],credit_oad = pred_data$credit_oad_attr[inx],
				deminimis = pred_data$deminimis[inx],ext_risk = pred_data$ext_risk[inx],ytm = pred_data$ytm[inx],ytw = pred_data$ytw[inx],
				maturity = pred_data$maturity[inx], er_3m_act = pred_data$excess_ret_fwd3m[inx],
				tr_3m_act = pred_data$total_ret_fwd3m[inx],er_3m_fc = pred_data$excess_ret_fc_fwd3m[inx],
				krd_fc = pred_data$krd_ret_fwd3m_fc[inx],tr_3m_fc = pred_data$total_ret_fc_fwd3m[inx])
	grp1tmp = grp1tmp[order(grp1tmp$cusip),]
	#grp1_hist = rbind(grp1_hist,tmp)
	inx = rank_ex > (n-ntop)
	grp5tmp = data.frame(date = fwd_dates[i],cusip = pred_data$identifier[inx],oas = pred_data$oas[inx],oad = pred_data$oad[inx],
				resi_oas = pred_data$misprice[inx],credit_oad = pred_data$credit_oad_attr[inx],
				deminimis = pred_data$deminimis[inx],ext_risk = pred_data$ext_risk[inx],ytm = pred_data$ytm[inx],ytw = pred_data$ytw[inx],
				maturity = pred_data$maturity[inx], er_3m_act = pred_data$excess_ret_fwd3m[inx],
				tr_3m_act = pred_data$total_ret_fwd3m[inx],er_3m_fc = pred_data$excess_ret_fc_fwd3m[inx],
				krd_fc = pred_data$krd_ret_fwd3m_fc[inx],tr_3m_fc = pred_data$total_ret_fc_fwd3m[inx])
	grp5tmp = grp5tmp[order(grp5tmp$cusip),]
	
	}
	#grp1_hist = cbind(grp1_hist,as.character(pred_data$identifier[rank_ex <= ntop]))
	#grp5_hist = cbind(grp5_hist,as.character(pred_data$identifier[rank_ex > (n-ntop)]))
	
	# grp1_total <- mean(pred_data$total_ret_fwd3m[rank_ex<=n/5],na.rm=T)
	# grp2_total <- mean(pred_data$total_ret_fwd3m[rank_ex>n/5 & rank_ex<=2*n/5],na.rm=T)
	# grp3_total <- mean(pred_data$total_ret_fwd3m[rank_ex>2*n/5 & rank_ex<=3*n/5],na.rm=T)
	# grp4_total <- mean(pred_data$total_ret_fwd3m[rank_ex>3*n/5 & rank_ex<=4*n/5],na.rm=T)
	# grp5_total <- mean(pred_data$total_ret_fwd3m[rank_ex>4*n/5],na.rm=T)
	
	res <- rbind(res,data.frame(as_of=fwd_dates[i],cor_total=cor_total,cor_excess=cor_excess,
		rankcor_total=rankcor_total,rankcor_excess=rankcor_excess,
		grp1_total=grp1_total,grp2_total=grp2_total,grp3_total=grp3_total,
		grp4_total=grp4_total,grp5_total=grp5_total,
		grp1_ex=grp1_ex,grp2_ex=grp2_ex,grp3_ex=grp3_ex,
		grp4_ex=grp4_ex,grp5_ex=grp5_ex
		))
		
	factors = predict.ridge(fit,newdata=pred_data,type='terms',centered = T,winsorised = F)	
	
	rnk <- rank(-factors$credit_oad)
	n <- length(rnk)
	grp1_ex <- mean(pred_data$excess_ret_fwd3m[rnk<=n/5],na.rm=T)
	grp2_ex <- mean(pred_data$excess_ret_fwd3m[rnk>n/5 & rnk<=2*n/5],na.rm=T)
	grp3_ex <- mean(pred_data$excess_ret_fwd3m[rnk>2*n/5 & rnk<=3*n/5],na.rm=T)
	grp4_ex <- mean(pred_data$excess_ret_fwd3m[rnk>3*n/5 & rnk<=4*n/5],na.rm=T)
	grp5_ex <- mean(pred_data$excess_ret_fwd3m[rnk>4*n/5],na.rm=T)	
	
	# get matching factor contributions
	if(i == starti){
	inx = na.exclude(match(grp1_hist$cusip[grp1_hist$date == fwd_dates[i]],pred_data$identifier))
	grp1_hist = cbind(grp1_hist,data.frame(intercept = factors$Intercept[1],credit_dur = factors$credit_oad[inx],
	       resi = factors$resi_oas[inx]))
	
	inx = na.exclude(match(grp5_hist$cusip[grp5_hist$date == fwd_dates[i]],pred_data$identifier))
	grp5_hist = cbind(grp5_hist,data.frame(intercept = factors$Intercept[1],credit_dur = factors$credit_oad[inx],
	       resi = factors$resi_oas[inx]))
	}else {
	inx = na.exclude(match(grp1tmp$cusip[grp1tmp$date == fwd_dates[i]],pred_data$identifier))
	grp1tmp = cbind(grp1tmp,data.frame(intercept = factors$Intercept[1],credit_dur = factors$credit_oad[inx],
	       resi = factors$resi_oas[inx]))
	grp1_hist = rbind(grp1_hist,grp1tmp)

	inx = na.exclude(match(grp5tmp$cusip[grp5tmp$date == fwd_dates[i]],pred_data$identifier))
	grp5tmp = cbind(grp5tmp,data.frame(intercept = factors$Intercept[1],credit_dur = factors$credit_oad[inx],
	       resi = factors$resi_oas[inx]))
	grp5_hist = rbind(grp5_hist,grp5tmp)
	
	}

# 	rnk <- rank(-factors$deminimis_buffer)
# 	n <- length(rnk)
# 	grp1_db <- mean(pred_data$excess_ret_fwd3m[rnk<=n/5],na.rm=T)
# 	grp2_db <- mean(pred_data$excess_ret_fwd3m[rnk>n/5 & rnk<=2*n/5],na.rm=T)
# 	grp3_db <- mean(pred_data$excess_ret_fwd3m[rnk>2*n/5 & rnk<=3*n/5],na.rm=T)
# 	grp4_db <- mean(pred_data$excess_ret_fwd3m[rnk>3*n/5 & rnk<=4*n/5],na.rm=T)
# 	grp5_db <- mean(pred_data$excess_ret_fwd3m[rnk>4*n/5],na.rm=T)	
	
# 	rnk <- rank(-factors$state)
# 	n <- length(rnk)
# 	grp1_st <- mean(pred_data$excess_ret_fwd3m[rnk<=n/5],na.rm=T)
# 	grp2_st <- mean(pred_data$excess_ret_fwd3m[rnk>n/5 & rnk<=2*n/5],na.rm=T)
# 	grp3_st <- mean(pred_data$excess_ret_fwd3m[rnk>2*n/5 & rnk<=3*n/5],na.rm=T)
# 	grp4_st <- mean(pred_data$excess_ret_fwd3m[rnk>3*n/5 & rnk<=4*n/5],na.rm=T)
# 	grp5_st <- mean(pred_data$excess_ret_fwd3m[rnk>4*n/5],na.rm=T)	
# 	
# 	rnk <- rank(-factors$ab_code)
# 	n <- length(rnk)
# 	grp1_sec <- mean(pred_data$excess_ret_fwd3m[rnk<=n/5],na.rm=T)
# 	grp2_sec <- mean(pred_data$excess_ret_fwd3m[rnk>n/5 & rnk<=2*n/5],na.rm=T)
# 	grp3_sec <- mean(pred_data$excess_ret_fwd3m[rnk>2*n/5 & rnk<=3*n/5],na.rm=T)
# 	grp4_sec <- mean(pred_data$excess_ret_fwd3m[rnk>3*n/5 & rnk<=4*n/5],na.rm=T)
# 	grp5_sec <- mean(pred_data$excess_ret_fwd3m[rnk>4*n/5],na.rm=T)	
	
# 	rnk <- rank(-factors$muni_taxability)
# 	n <- length(rnk)
# 	grp1_tax <- mean(pred_data$excess_ret_fwd3m[rnk<=n/5],na.rm=T)
# 	grp2_tax <- mean(pred_data$excess_ret_fwd3m[rnk>n/5 & rnk<=2*n/5],na.rm=T)
# 	grp3_tax <- mean(pred_data$excess_ret_fwd3m[rnk>2*n/5 & rnk<=3*n/5],na.rm=T)
# 	grp4_tax <- mean(pred_data$excess_ret_fwd3m[rnk>3*n/5 & rnk<=4*n/5],na.rm=T)
# 	grp5_tax <- mean(pred_data$excess_ret_fwd3m[rnk>4*n/5],na.rm=T)	
	
# 	rnk <- rank(-factors$time_to_maturity)
# 	n <- length(rnk)
# 	grp1_mat <- mean(pred_data$excess_ret_fwd3m[rnk<=n/5],na.rm=T)
# 	grp2_mat <- mean(pred_data$excess_ret_fwd3m[rnk>n/5 & rnk<=2*n/5],na.rm=T)
# 	grp3_mat <- mean(pred_data$excess_ret_fwd3m[rnk>2*n/5 & rnk<=3*n/5],na.rm=T)
# 	grp4_mat <- mean(pred_data$excess_ret_fwd3m[rnk>3*n/5 & rnk<=4*n/5],na.rm=T)
# 	grp5_mat <- mean(pred_data$excess_ret_fwd3m[rnk>4*n/5],na.rm=T)	
	
	rnk <- rank(-factors$resi_oas)
	n <- length(rnk)
	grp1_res <- mean(pred_data$excess_ret_fwd3m[rnk<=n/5],na.rm=T)
	grp2_res <- mean(pred_data$excess_ret_fwd3m[rnk>n/5 & rnk<=2*n/5],na.rm=T)
	grp3_res <- mean(pred_data$excess_ret_fwd3m[rnk>2*n/5 & rnk<=3*n/5],na.rm=T)
	grp4_res <- mean(pred_data$excess_ret_fwd3m[rnk>3*n/5 & rnk<=4*n/5],na.rm=T)
	grp5_res <- mean(pred_data$excess_ret_fwd3m[rnk>4*n/5],na.rm=T)	
	
	res.fact = rbind(res.fact,data.frame(as_of=fwd_dates[i],q1_cd = grp1_ex,q2_cd = grp2_ex,q3_cd = grp3_ex,q4_cd = grp4_ex,q5_cd = grp5_ex,
	q1_res = grp1_res,q2_res = grp2_res,q3_res = grp3_res,q4_res = grp4_res,q5_res = grp5_res))
	}
	gc()	
}

# res.fact = c()
# for(i in 12:(length(fwd_dates)-3) )
# {
	# pred_data <- reg_data[reg_data$fwd_date==fwd_dates[i+3],]
	# rnk <- rank(-pred_data$credit_oad)
	# n <- length(rnk)
	# grp1_ex <- mean(pred_data$excess_ret_fwd3m[rnk<=n/5],na.rm=T)
	# grp2_ex <- mean(pred_data$excess_ret_fwd3m[rnk>n/5 & rnk<=2*n/5],na.rm=T)
	# grp3_ex <- mean(pred_data$excess_ret_fwd3m[rnk>2*n/5 & rnk<=3*n/5],na.rm=T)
	# grp4_ex <- mean(pred_data$excess_ret_fwd3m[rnk>3*n/5 & rnk<=4*n/5],na.rm=T)
	# grp5_ex <- mean(pred_data$excess_ret_fwd3m[rnk>4*n/5],na.rm=T)	
	# res.fact = rbind(res.fact,data.frame(as_of=fwd_dates[i+3],q1_cd = grp1_ex,q2_cd = grp2_ex,q3_cd = grp3_ex,q4_cd = grp4_ex,q5_cd = grp5_ex))
# }

####################################################	
###############################################################################

#save(res,file='simulation_result.RData')
#res <- res[res$as_of>='2010-01-01',]
for(i in 2:5)
{
	yrange <- range(res[,2:5])
	if(i==2) plot(res$as_of,res[,i],ylim=yrange,type='b',col=i,pch=i,xlab='date',ylab='corr(forecast,actual)',main='correlation between actual and forecasted returns')
	else lines(res$as_of,res[,i],col=i,pch=i,type='b')
}
legend('bottomleft',names(res)[2:5],col=2:5,pch=2:5,lwd=2)

vars <- names(res)[grep('grp',names(res))]
res_cum <- res[,c('as_of',vars)]
for(var in vars) res_cum[,var] <- cumsum(res_cum[,var]/3)
dev.new()
for(i in 1:5)
{
	yrange <- range(res_cum[,vars[1:5]])
	if(i==1) plot(res_cum$as_of,res_cum[,vars[i]],ylim=yrange,type='b',col=i,pch=i,xlab='date',ylab='cumret',main='quintile chart, total return, overlapped 3-month')
	else lines(res_cum$as_of,res_cum[,vars[i]],col=i,pch=i,type='b')
}
lines(res_cum$as_of,res_cum[,vars[1]]-res_cum[,vars[5]],col=6,pch=6,lwd=2,type='b')
legend('topleft',c(vars[1:5],'grp1-grp5'),col=1:6,pch=1:6,lwd=2)

dev.new()
for(i in 6:10)
{
	yrange <- range(res_cum[,vars[6:10]],res_cum[,vars[6]]-res_cum[,vars[10]])
	if(i==6) plot(res_cum$as_of,res_cum[,vars[i]],ylim=yrange,type='b',col=i-5,pch=i-5,xlab='date',ylab='cumret',main='quintile chart, excess return, overlapped 3-month')
	else lines(res_cum$as_of,res_cum[,vars[i]],col=i-5,pch=i-5,type='b')
}
lines(res_cum$as_of,res_cum[,vars[6]]-res_cum[,vars[10]],col=6,pch=6,lwd=2,type='b')
legend('topleft',c(vars[1:5+5],'grp1-grp5'),col=1:6,pch=1:6,lwd=2)

write.csv(res,file = 'tmp.csv')

