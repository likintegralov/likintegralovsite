
source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.R',sep='') )

#source('H:/SVN/Muni/v1.0/Src/ExcessReturn/oas_decomp.R')

setwd('H:/SVN/Muni/v1.0/Src/ExcessReturn')
library(RODBC)
library(timeDate)
library(mgcv)

db_info <- get_db_info('QA')

dates = seq(timeDate("2012-05-01"),timeDate(Sys.Date()),by="months")-1

for(i in 1:length(dates))
{
	while(!isWeekday(dates[i]))
	{
		dates[i] = dates[i] - 24*3600
	}
}
dates = as.Date(dates)

#dates = as.Date('2014-08-20')


#date.end.month <- seq(as.Date("2012-02-01"),length=4,by="months")-1
#attrdata = c();
dbconn = odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))

for(i in 1:length(dates))
{
q = paste("select d.AS_OF_DATE, d.IDENTIFIER,d.SECTOR,d.STATE,d.INDEX_OAS,d.COUPON_EFFECT, d.CREDIT_CURVE,d.RESI_OAS, a.CALL_TYPE, a.PRICE, ",
			"a.MUNI_OAD, a.COUPON, a.MUNI_OAS, a.MUNI_OAC convexity, a.TIME_TO_WORST, a.MATURITY_DATE,",
			"a.SP_RATING, a.FITCH_RATING,a.MOODY_RATING from FIQModel..MUNI_OAS_DECOMPOSITION d, Optimizer..MUNI_ANALYTICS a ",
			"WHERE d.AS_OF_DATE = a.EFFECTIVE_DATE ",
			"and d.IDENTIFIER = a.IDENTIFIER and d.AS_OF_DATE = '",format(dates[i],"%Y-%m-%d"),"' ",sep = '')

#attrdata = rbind(attrdata,sqlQuery(dbconn,query=q))
}
odbcClose(dbconn)

names(attrdata) <- tolower(names(attrdata))

#names(attrdata)[names(attrdata) == c('maturity_date')] = 'maturity'
#attrdata$maturity = as.numeric(difftime(as.Date(attrdata[,c('maturity')]), as.Date(attrdata[,c('as_of_date')])))/365.25

require(graphics)
palette()
dur = 1:20
mat = 1:20
dur1 = c(); count1 = c()
dur2 = c(); count2 = c()
#dates = dates[dates == as.Date('2014-01-31')]

for(i in 1:length(dates))
{
# pick a month
mdata = attrdata[as.Date(attrdata$as_of_date) == dates[i],]
if(dim(mdata)[1] > 0)
{
# only callable
mdata = mdata[mdata$call_type != 'NONCALL',]

ix <- mdata$muni_oas>quantile(mdata$muni_oas,0.975,na.rm=T) | mdata$muni_oas<quantile(mdata$muni_oas,0.025,na.rm=T)
	mdata <- mdata[!ix,]
#mdata$convexity = winsorise(mdata$convexity,lb=0.01,ub=0.99)

fit <- gam( resi_oas ~ s(convexity,k=6), data = mdata)
dev.new()
plot(fit,main = dates[i])#,xlim = c(-5,5))

oas = matrix(0,nrow = length(dur),ncol = length(mat))
count = matrix(0,nrow = length(dur),ncol = length(mat))

for(k in 2)#1:length(dur))
{
	for(l in 20)#1:length(mat))
	{
		if(k == 1)
		{
			if(l == 1)
			{
				ix = mdata$muni_oad <= dur[k] & mdata$maturity <= mat[l]
				oas[k,l] = mean(mdata[ix,c('resi_oas')],na.rm = T)
				count[k,l] = sum(!is.na(mdata[ix,c('resi_oas')]))
			}else
			{
				ix = mdata$muni_oad <= dur[k] & mdata$maturity > mat[l-1] & mdata$maturity <= mat[l]
				oas[k,l] = mean(mdata[ix,c('resi_oas')],na.rm = T)
				count[k,l] = sum(!is.na(mdata[ix,c('resi_oas')]))
			}
		}else
		{
			if(l == 1)
			{
				ix = mdata$muni_oad > dur[k-1] & mdata$muni_oad <= dur[k] & mdata$maturity <= mat[l]
				oas[k,l] = mean(mdata[ix,c('resi_oas')],na.rm = T)
				count[k,l] = sum(!is.na(mdata[ix,c('resi_oas')]))
			}else
			{
				ix = mdata$muni_oad > dur[k-1] & mdata$muni_oad <= dur[k] & mdata$maturity > mat[l-1] & mdata$maturity <= mat[l]
				oas[k,l] = mean(mdata[ix,c('resi_oas')],na.rm = T)
				count[k,l] = sum(!is.na(mdata[ix,c('resi_oas')]))
			}
		}
	}
}	
}

dur1 = rbind(dur1,oas[1,])
dur2 = rbind(dur2,oas[2,])

count1 = rbind(count1,count[1,])
count2 = rbind(count2,count[2,])

#if(i == 1)
#{
#plot(mat,oas[1,],type = 'b',col = i, pch = i) 
#}else
#{
#lines(mat,oas[1,],type = 'b', col = i, pch = i)
#}
}

write.csv(count1,file = 'tmp.csv')