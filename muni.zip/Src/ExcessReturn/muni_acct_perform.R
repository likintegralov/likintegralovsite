
source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.R',sep='') )

###############################################################################
#source('H:/SVN/Muni/v1.0/Src/ExcessReturn/muni_acct_perform.R')


db = 'QA'
library(RODBC)
db_info <- get_db_info(db)