#!\\nts0018\bond\ABFI_PROD\QuantApps\R-2.14.2\bin\Rscript

source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.dev6.2.R',sep='') )

load_reg_data <- function(cur_date,fwd_date,db_info)
{
	data <- load_data(cur_date,db_info,src='Barcap')
	
	stmt <- paste("
		SELECT fwd.EFFECTIVE_DATE AS FWD_DATE,
		fwd.IDENTIFIER,fwd.PRICE AS PRICE_FWD3M
		FROM Optimizer.dbo.MUNI_ANALYTICS fwd
		where fwd.SOURCE='Barcap'
		AND fwd.EFFECTIVE_DATE='", format(fwd_date,'%d-%b-%Y'),"'		
	",sep='')
	
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    data_fwd3m <- sqlQuery(channel,query=stmt)
    odbcClose(channel)
    names(data_fwd3m) <- casefold(names(data_fwd3m),F)
    
    data_fwd3m$fwd_date <- as.Date(data_fwd3m$fwd_date)
    data <- merge(data,data_fwd3m)
    
    #remove non rated
    data = data[!is.na(data$credit_rating),]
    #calculate factor exposures
    data <- get_factor_exposure(data,db_info,type='resi') # each factor is populated by attribution oas minus average attribution oas
    
    load('../Input/MuniParBondRet.RData')	
    data <- calc_returns(data,dur,ret_fc,ret_ac) # calculate forecast hedge, excess and total retruns
    
    #pre-multiply duration
    xvars <- c('index_oas','credit_oad','state','ab_code','deminimis_buffer','muni_taxability','resi_oas')
    for(xvar in xvars) data[,xvar] <- data[,xvar]*data$muni_oad
    #data$state = data$convexity # use state field as a storage for convexity factor
    
	#return only needed fields
	data <- na.exclude( data[,c('fwd_date','identifier','amt_outstanding',
		'index_oas','credit_oad','state','ab_code','deminimis_buffer','muni_taxability','resi_oas',
		'total_ret_fwd3m','krd_ret_fwd3m_fc','excess_ret_fwd3m')] )
	colnames(data) <- casefold(colnames(data),T)
	
	#delete existing data
	stmt <- paste("
        DELETE FROM MUNI_MODEL_REGRESSION_DATA
        WHERE FWD_DATE='", format(fwd_date,'%d-%b-%Y'),"'
        ",sep='')
        
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    sqlQuery(channel,query=stmt)
    odbcClose(channel)
    
    #populate data
	export2db(data,server_type='SQL',server=db_info$Database,db=db_info$InitDB,table='MUNI_MODEL_REGRESSION_DATA',user=db_info$User,psw=db_info$Password,na='')	
	
	invisible()
}

################################################################################
###############################################################################
#source('H:/SVN/Muni/v1.0/Src/ExcessReturn/load_reg_data.dev10.R') # convexity and expected tax impact
library('getopt')
opt = getopt(matrix(
    c(
    'db',   's', 2, "character",
    'as_of','d', 2, "character",
    'help', 'h', 0, "logical",
    'ver',  'v', 2, "integer"
    ),ncol=4,byrow=TRUE)
)

if ( !is.null(opt$help) ) {
  self = 'Rscript load_raw_data.R'
  cat(paste("
    Usage: ",self,"  [--as_of date] [--help]  
        db:   Database server to run the script on (PRD/QA/DEV).
        as_of:as_of date in yyyy-mm-dd format. default to last month-end date. Optional      
        help: Show help.  Optional
    Example: RScript load_raw_data.R --db PRD --as_of 2012-02-15
  ",sep=""))
  q(status=1)
}

if ( is.null(opt$db) ) opt$db <- 'QA'
#if ( is.null(opt$as_of) ) opt$as_of <- last.business.day(Sys.Date()-1)
#as_of <- as.Date(opt$as_of)
#opt$as_of = as.Date('2014-10-10')
###############################################################################
#source('H:/SVN/Muni/v1.0/Src/ExcessReturn/load_reg_data.dev10.1.R') expected tax impact, no extension risk

setwd(paste(Sys.getenv('ABFI_DATA_REPOSITORY'),'\\Muni\\v1.0\\Output',sep='') )

library(RODBC)
db_info <- get_db_info(opt$db)

#cat('load month-end regression data as of ',format(as_of),'...\n')

dates <- load_muni_analytics_dates(Sys.Date(),db_info,src='Barcap')

if( is.null(opt$as_of)) 
{
	dates <- dates[dates>='2008-10-31' & dates>=last.business.day(month.end(dates))]
	end_dates <- dates[4:length(dates)]
	st_dates <- dates[1:(length(dates)-3)]
}else
{
	end_dates = dates[dates == opt$as_of]
	st_dates = dates[which(dates == opt$as_of)-3]
}

load('../Input/MuniParBondRet.RData')

for(i in 1:(length(end_dates) ) )
{
	cat(format(Sys.time()),'processing returns ending',format(end_dates[i]),'...\n')
	load_reg_data(st_dates[i],end_dates[i],db_info)
	gc()
}
cat(date(),'Done.\n')
q(status=0)

####################################################	
###############################################################################
#source('H:/dev/Quant_Model-SQLServer/Muni/v1.0/Src/ExcessReturn/load_reg_data.R')

