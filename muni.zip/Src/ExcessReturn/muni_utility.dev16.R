#!\\nts0018\bond\ABFI_PROD\QuantApps\R-2.14.2\bin\Rscript
# sector/credit interaction
source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Utility\\R_Splus\\utility.R',sep='') )

term_calibration_buckets = c(2.5,10,20)
term_interpolation_buckets = seq(0,20,by = 0.25)
factors_interp_map = list(fact = c('muni_taxability','zero_coupon'),tags = c(20100,40200),fact_tags = c('muni_taxability','zero_coupon_gen'))
all_factors = c('index_oas','credit_oad','deminimis_buffer','extension_risk','state','ab_code','zero_coupon','muni_taxability',
			'ce_bucket','index_oas_pr','credit_oad_pr','deminimis_buffer_pr','state_pr','zero_coupon_pr')
			
all_factors_tags = c('index_gen','credit_oad','dm_tax_gen','ext_risk','state_gen','ab_code','zero_coupon_gen','muni_taxability',
			'ce_bucket','index_oas_pr','pr_oad','deminimis_buffer_pr','state_pr','zero_coupon_pr')

pr_states = c('126','145','146','143','141','115','119','110')
pr_factors_tags = c('index_oas_pr','pr_oad','deminimis_buffer_pr','state_pr','zero_coupon_pr')
#factors_curve_bucket_rel = c('credit_oad_pr','deminimis_buffer_pr')
factors_linear = c('credit_oad_pr','deminimis_buffer_pr')

get_tax_rate <- function(dbi)
{
	q = "select d.VALUE_DATE date,d.VALUE tax from TIMESERIES.dbo.GENERIC_TS_DATA d
         inner join TIMESERIES.dbo.GENERIC_TS_DEF f
         on d.GENERIC_TS_ID=f.GENERIC_TS_ID
         where f.NAME like 'TopMargTaxRate_USA' and d.VALUE_DATE > '1996-01-01'"
         
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',dbi$Database,';DataBase=',dbi$InitDB,';uid=',dbi$User,';pwd=',dbi$Password,sep=''))
	d <- sqlQuery(channel,query=q)
	odbcClose(channel)   
	
	d$date = as.Date(d$date)
	dd = data.frame(date = seq(d$date[1],d$date[dim(d)[1]],by = 1))
	dd = merge(dd,d,by = 'date',all.x = T)

	t = which(is.na(dd$tax))
	for(i in 1:length(t))
	{
		dd$tax[t[i]] = dd$tax[t[i]-1]
	}  
   # override with expected Trump tax
   	dd[dd$date >= as.Date('2016-11-09'),'tax'] = 35.0
	dd 
}				
								
deminimis_grades <- function()
{
	c('ig','hy')
}
factor_buckets <- function(f)
{
	if(f == 'dm_tax_gen')
		b = seq(0,1,length.out = 5)
# 	if(f == 'credit_oad_pr')
# 		b = seq(0,1,length.out = 4)
# 	if(f == 'deminimis_buffer_pr')
# 		b =seq(0.1,1,length.out = 4)
	b
}

make_crdur_grid <- function()
{
	require(fields)
	oad_b = c(0,5,10,15)  # duration key points
	credit_b = c(1,8,12,18) # credit key points

	make.surface.grid(list(oad_b,credit_b))	
}

get_db_info_muni <- function(db='PRD',user='PRD')
{
	dbi = get_db_info(db,user)
	dbi$InitDB = 'MUNI'
	dbi
}

load_tsy_yield_curve <- function(as_of,daily = F,flds = NULL)
{
	cat('loading lehman fitted treasury yield curve...\n')
    if(!daily)
	{
	    stmt <- paste("
	        select *
	        FROM YIELD_CURVE_TIMESERIES
	        WHERE
	        YC_NAME = 'LgtParBond'
	        AND COUNTRY='US'
	        and ( (IS_END_OF_MONTH='Y' and AS_OF_DATE<='",format(as_of,'%d-%b-%Y'),"')
	        or AS_OF_DATE='",format(as_of,'%d-%b-%Y'),"')
	        ORDER BY AS_OF_DATE
	    ",sep='')
	    
	    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
	    outdata <- sqlQuery(channel,query=stmt)
	    odbcClose(channel)
	    
	    names(outdata)<-casefold(names(outdata),upper=F)
	    outdata$as_of_date <- as.Date(outdata$as_of_date)
	    outdata$month_end_date <- month.end(outdata$as_of_date)
	    
	    vars <- names(outdata)[grep('point',names(outdata))]
	    outdata <- outdata[,c('as_of_date','month_end_date',vars)]
	    
	    	#apply tax
	    tax = get_tax_rate(db_info)
	    names(tax)[1] = 'as_of_date'
	    outdata = merge(outdata,tax, by = 'as_of_date',all.x = T)
	    
	    outdata[,3:(dim(outdata)[2] - 1)] = (1 - outdata$tax/100)*outdata[,3:(dim(outdata)[2] - 1)]	

	}else #daily data
	{
		if(is.null(flds))
		{
			stmt <- paste("
	        select *
	        FROM YIELD_CURVE_TIMESERIES
	        WHERE
	        YC_NAME = 'LgtParBond'
	        AND COUNTRY='US'
	        and AS_OF_DATE<='",format(as_of,'%d-%b-%Y'),"' ",
	        "ORDER BY AS_OF_DATE
	    ",sep='')
    	}else
    	{
	    	stmt <- paste("
	        select AS_OF_DATE date, ",paste(flds,collapse = ','),
	        " FROM YIELD_CURVE_TIMESERIES
	        WHERE
	        YC_NAME = 'LgtParBond'
	        AND COUNTRY='US'
	        and AS_OF_DATE<='",format(as_of,'%d-%b-%Y'),"' ",
	        "ORDER BY AS_OF_DATE
	    	",sep='')
    	}
    	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
	    outdata <- sqlQuery(channel,query=stmt)
	    odbcClose(channel)
	    
	    names(outdata)<-casefold(names(outdata),upper=F)
	    names(outdata)[names(outdata) == 'as_of_date'] = 'date'
	    outdata$date <- as.Date(outdata$date)
	    
	    	#apply tax
	    tax = get_tax_rate(db_info)

	    outdata = merge(outdata,tax, by = 'date',all.x = T)
	    
	    outdata[,grep('point',names(outdata))] = (1 - outdata$tax/100)*outdata[,grep('point',names(outdata))]	
	}
	   	# remove tax rate for compartibility
   	outdata = outdata[,-dim(outdata)[2]]
    outdata   
}

load_MMD_yield_curve <- function(as_of,daily = F, flds = NULL)
{
	if(!daily)
	{
	    cat('loading MMD AAA yield curve...\n')
	    stmt <- paste("
	        select *
	        from YIELD_CURVE_TIMESERIES
	        where
	        YC_NAME = 'MuniAaaMmd'
	        and ( (IS_END_OF_MONTH='Y' and AS_OF_DATE<='",format(as_of,'%d-%b-%Y'),"')
	        or AS_OF_DATE='",format(as_of,'%d-%b-%Y'),"')
	        ORDER BY AS_OF_DATE
	    ",sep='')
	    
	    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
	    outdata <- sqlQuery(channel,query=stmt )
	    odbcClose(channel)
	    
	    names(outdata)<-casefold(names(outdata),upper=F)
	    outdata$as_of_date <- as.Date(outdata$as_of_date)
	    outdata$month_end_date <- month.end(outdata$as_of_date)
	    
	    vars <- names(outdata)[grep('point',names(outdata))]
	    outdata <- outdata[,c('as_of_date','month_end_date',vars)]
	}else
	{
		if(is.null(flds))
		{
			stmt <- paste("
	        select *
	        FROM YIELD_CURVE_TIMESERIES
	        WHERE
	        YC_NAME = 'MuniAaaMmd'
	        AND COUNTRY='US'
	        and AS_OF_DATE<='",format(as_of,'%d-%b-%Y'),"' ",
	        "ORDER BY AS_OF_DATE
	    ",sep='')
    	}else
    	{
	    	stmt <- paste("
	        select AS_OF_DATE date, ",paste(flds,collapse = ','),
	        " FROM YIELD_CURVE_TIMESERIES
	        WHERE
	        YC_NAME = 'MuniAaaMmd'
	        AND COUNTRY='US'
	        and AS_OF_DATE<='",format(as_of,'%d-%b-%Y'),"' ",
	        "ORDER BY AS_OF_DATE
	    	",sep='')
    	}
    	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
	    outdata <- sqlQuery(channel,query=stmt)
	    odbcClose(channel)
	    
	    names(outdata)<-casefold(names(outdata),upper=F)
	    outdata$date <- as.Date(outdata$date)
	    names(outdata)[names(outdata) == 'as_of_date'] = 'date'    	
	}
	
    outdata
} 

add_resi_mean <- function(data,ap) # addd historical average residual
{
	require(zoo)
	data$resi_mean = NA
	data$resi_sdev = NA
	secs = sort(unique(data$identifier))
	starti = 1
	for(i in 1:length(secs))
	{
		if((i-starti+1)%%100 == 0) cat('processing ',i,'th security out of ',length(secs),'\n',sep='')
		
		ix = which(data$identifier == secs[i])
		secresi = data[ix,c('resi_oas')]
		if(length(secresi) >= ap)
		{
			mresi = rollapplyr(secresi,ap,FUN = mean,fill = NA)
			sdresi = rollapplyr(secresi,ap,FUN = sd,fill = NA)
			muse = !is.na(mresi)
			data$resi_mean[ix[muse]] = mresi[muse]
			data$resi_sdev[ix[muse]] = sdresi[muse]	
		}			
	}
	data
}

load_muni_analytics_dates <- function(as_of,dbi,src=NULL)
{
	require(RODBC)
	
	src_str <- ''
	if(!is.null(src)) src_str <- paste("and SOURCE='",src,"'\n",sep='')
	
	stmt <- paste("
		select AS_OF_DATE=EFFECTIVE_DATE,cnt=COUNT(*)
		from Optimizer.dbo.MUNI_ANALYTICS
		where MUNI_10YR_KRD is not null
		",src_str,"and EFFECTIVE_DATE <= '", format(as_of,'%d-%b-%Y'),"'
		group by EFFECTIVE_DATE
	",sep='')
	
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',dbi$Database,';DataBase=',dbi$InitDB,';uid=',dbi$User,';pwd=',dbi$Password,sep=''))
    res <- sqlQuery(channel,query=stmt)
    odbcClose(channel)
    
    if(nrow(res)==0) return(NULL)
    
    names(res) <- casefold(names(res),F)
    res$as_of_date <- as.Date(res$as_of_date)
    
    res <- res[res$cnt>=10000,]
    
    #only get the last day of each month
    res$month_end <- month.end(res$as_of_date)
    res <- sort.data.frame(res,by=~month_end - as_of_date)    
    idx <- match(unique(res$month_end),res$month_end)    
    res <- res[idx,]
    
    res$as_of_date
}

load_regression_data_dates <- function(db_info)
{
	require(RODBC)
	#first get month-end fits
	stmt <- paste("
        select DISTINCT FWD_DATE
        FROM MUNI_MODEL_REGRESSION_DATA
        ",sep='')
        
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    dates <- sqlQuery(channel,query=stmt)
    odbcClose(channel)
    as.Date(dates$FWD_DATE)
}

load_factor_loading <- function(as_of,dbi)
{	    
	require(RODBC)
	
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',dbi$Database,';DataBase=',dbi$InitDB,';uid=',dbi$User,';pwd=',dbi$Password,sep=''))
    
    stmt <- paste("
        select max(AS_OF)
        from MODEL_DESCRIPTION a,MODEL_SPECIFICATION b,MODEL_FACTOR_LOADING c
        WHERE a.MODEL_NAME = 'Muni Excess Return Model'
        AND a.VERSION='1.0'
        AND b.MODEL_ID=a.MODEL_ID
        AND c.FACTOR_ID=b.FACTOR_ID
        AND AS_OF <='",format(as_of,'%d-%b-%Y'),"'
        ",sep='')
    
	res <- sqlQuery(channel,stmt)
	if(nrow(res)==0) stop('no factor loading available.\n')
	
	last_as_of <- as.Date(res[1,1])
    
    stmt <- paste("
        select c.*
        from MODEL_DESCRIPTION a,MODEL_SPECIFICATION b,MODEL_FACTOR_LOADING c
        WHERE a.MODEL_NAME = 'Muni Excess Return Model'
        AND a.VERSION='1.0'
        AND b.MODEL_ID=a.MODEL_ID
        AND c.FACTOR_ID=b.FACTOR_ID
        AND AS_OF ='",format(last_as_of,'%d-%b-%Y'),"'
        ",sep='')
            
    factor_loading <- sqlQuery(channel,query=stmt)    
    odbcClose(channel)
    
    cat('use factor loading as of',format(last_as_of),'.\n')
    factor_loading
}

load_oas_fit <- function(as_of,dbi)
{
	require(RODBC)
	
	stmt_cont <- paste("
        select *
		from OAS_ATTRIBUTION_FIT
		where SECTOR = 'muni' and AS_OF_DATE = '",format(as_of,'%d-%b-%Y'),"'
		",sep='')
		
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',dbi$Database,';DataBase=',dbi$InitDB,';uid=',dbi$User,';pwd=',dbi$Password,sep=''))
    oas_fit <- sqlQuery(channel,query=stmt_cont)
    odbcClose(channel)
    
    if(nrow(oas_fit)==0 ) stop('fits not exist as of',format(as_of),'!\n')
    
    names(oas_fit) <- casefold(names(oas_fit),F)
    oas_fit$as_of_date <- as.Date(oas_fit$as_of_date)
    oas_fit
}

update_mean_oas_attr <- function(dbi,dates,mv_lag=NULL)
{
	cat('update mean oas with lag=',mv_lag,'\n')
	require(RODBC)
	#first get month-end fits
	stmt <- paste("
        select ID, SECTOR, AS_OF_DATE,ATTRIBUTE,VALUE1,VALUE2,OAS
		from OAS_ATTRIBUTION_FIT
		where SECTOR = 'muni' and AS_OF_DATE in
		(
			select max(AS_OF_DATE)
			from OAS_ATTRIBUTION_FIT where SECTOR ='muni'
			group by year(AS_OF_DATE)*100+month(AS_OF_DATE)
		)
        ",sep='')
        
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',dbi$Database,';DataBase=',dbi$InitDB,';uid=',dbi$User,';pwd=',dbi$Password,sep=''))
    data_me <- sqlQuery(channel,query=stmt)
    odbcClose(channel)
    
    names(data_me) <- casefold(names(data_me),F)
    data_me$as_of_date <- as.Date(data_me$as_of_date)
    
    max_date <- max(data_me$as_of_date)
    if(max_date<last.business.day(month.end(max_date)) )
    {
    	ix <- data_me$as_of_date==max_date
    	data_me <- data_me[!ix,]
	}
    
	##############################################################################
	#define an inline function 
	calc_mean_oas <- function(d,mv_lag)
	{
		last_day <- last.business.day(month.end(d$as_of_date[1]))
		d_wgt <- min(1, as.numeric( format(d$as_of_date[1],'%d') ) / as.numeric( format(last_day,'%d')) )
		
		#if mv_lag is null, take all past data
		ix <- data_me$as_of_date < d$as_of_date[1]
		xdates <- sort(unique(data_me$as_of_date[ix]),decreasing=T)
		if(!is.null(mv_lag)) ix <- ix & data_me$as_of_date %in% xdates[1:mv_lag]
		dd <- rbind(data_me[ix,],d[,names(data_me)]) # dataset with past mv_lag months of data
		
		dd$wgt <- 1			
		if(d_wgt==1) #remove one date
		{
			ix <- dd$as_of_date %in% xdates[mv_lag]
			dd <- dd[!ix,]
		}else #wgts are 1,wgt,1,1,...,(1-wgt)
		{
			ix <- dd$as_of_date %in% xdates[1]
			dd$wgt[ix] <- d_wgt
			ix <- dd$as_of_date %in% xdates[mv_lag]
			dd$wgt[ix] <- 1-d_wgt
		}
	    
		dd <- sort.data.frame(dd,by=~attribute+value1+value2+as_of_date)
		
	    attrs_cont <- c('deminimis_buffer','extension_risk','deminimis_buffer_pr','credit_oad_pr')
	    attrs_dummy <- c('index_oas','state','ab_code','muni_taxability','zero_coupon','ce_bucket','state_pr','zero_coupon_pr','index_oas_pr')
	    
	    d$mean_oas <- NA # current month data
	    #continuous
	    for(attr in attrs_cont)
	    {
		    for(v2 in sort(unique(d$value2[d$attribute == attr])))
		    {
			    ix <- dd$attribute==attr & dd$value2 == v2
			    ddd <- dd[ix,]
			    
			    ix <- d$attribute==attr & d$value2 == v2
			    xout <- sort(d$value1[ix])
			    
			    dates <- sort(unique(ddd$as_of_date))
			    mean_oas <- 0
			    wgt_total <- 0
			    for(i in 1:length(dates))
			    {
				    ix <- ddd$as_of_date==dates[i]
				    fit <- smooth.spline(ddd$value1[ix],ddd$oas[ix])
				    mean_oas <- mean_oas+predict(fit,x=xout)$y * ddd$wgt[ix][1]
				    wgt_total <- wgt_total + ddd$wgt[ix][1]
			    }
			    mean_oas <- mean_oas/wgt_total
			    
			    ix <- d$attribute==attr & d$value2 == v2
				d$mean_oas[ix] <- mean_oas
			}
	    }
	    
	    #dummy
	    ix <- dd$attribute %in% attrs_dummy
	    sum_oasxwgt <- aggregate(oas*wgt~attribute+value1,data=dd,FUN=sum,subset=ix)
	    sum_wgt <- aggregate(wgt~attribute+value1,data=dd,FUN=sum,subset=ix)
	    mean_oas <- merge(sum_oasxwgt,sum_wgt)
	    
		mean_oas$mean_oas <- mean_oas[,'oas * wgt'] / mean_oas[,'wgt']
		
		t = merge(d,mean_oas,by = c('attribute','value1'),all.x = T)
		t$mean_oas.x[!is.na(t$mean_oas.y)] = t$mean_oas.y[!is.na(t$mean_oas.y)]
		
		d = merge(d,t[,c('attribute','value1','value2','mean_oas.x')],by = c('attribute','value1','value2'))
		d$mean_oas = d$mean_oas.x
		
		#surface
	    ix <- dd$attribute=='credit_oad'
	    dd <- dd[ix,]
	    dd <- sort.data.frame(dd,by=~as_of_date + value2 + value1)
	    
	    dates <- sort(unique(dd$as_of_date))
	    
	    ix <- d$attribute=='credit_oad'
	    credit_out <- sort( unique(d$value1[ix]) )
	    oad_out <- sort( unique(d$value2[ix]) )
	    
	    library(fields)
	    
	    loc <- make.surface.grid(list(credit_out,oad_out) )
		z_out_total <- 0
	    wgt_total <- 0
		for(i in 1:length(dates))
	    {
		    ix <- dd$as_of_date==dates[i]
		    wgt <- dd$wgt[ix][1]
		    
		    x <- sort(unique(dd$value1[ix]))
		    y <-  sort(unique(dd$value2[ix]))
		    z <-  matrix(dd$oas[ix],nrow=length(x))
		    if( length(z) != length(x) * length(y) ) stop ('credit surface source data for',format(dates[i]),'corrupted\n')
		    
		    loc_idx <- loc
			loc_idx[,1] <- winsorise(loc_idx[,1],lb.value=min(x),ub.value=max(x) )
			loc_idx[,2] <- winsorise(loc_idx[,2],lb.value=min(y),ub.value=max(y) )
			
			z_out <- interp.surface(list(x=x,y=y,z=z), loc_idx)
			z_out <- matrix(z_out,nrow=length(credit_out))
			
			z_out_total <- z_out_total + z_out*wgt
			wgt_total <- wgt_total + wgt
		}
		
	    mean_oas <- matrix(z_out_total/wgt_total,nrow=length(credit_out) )
		
	    d <- sort.data.frame(d,by=~attribute + value2 + value1)
	    ix <- d$attribute=='credit_oad'
		d$mean_oas[ix] <- mean_oas
	    
		d <- d[,c('id','sector','as_of_date','attribute','value1','value2','oas','mean_oas')]
		names(d) <- casefold(names(d),T)
		d
	}
	#define an inline function 
	##############################################################################	
	
	#now work on each date
	me_dates <- sort(unique(data_me$as_of_date))
	fit_oas <- c()
	for(i in 1:length(dates) )
	{
		cur_date <- dates[i]
		cat('processing',format(cur_date),'...\n')
		if(cur_date %in% me_dates) 
		{
			res <- data_me[data_me$as_of_date==cur_date,]
		}else #query data
		{
			res <- load_oas_fit(cur_date,dbi)			
		}
		res <- calc_mean_oas(res,mv_lag)
		fit_oas <- rbind(fit_oas,res)
	}    

	names(fit_oas) <- casefold(names(fit_oas))
	
	cat('updating muni oas into database...\nDate str is ')

	
	dates_str <- paste(format(dates),collapse="','")
	cat(dates_str)
	cat('\n')
	stmt <- paste("
		delete from OAS_ATTRIBUTION_FIT
		where SECTOR ='muni' and AS_OF_DATE in ('",dates_str,"')
	",sep='')
	
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',dbi$Database,';DataBase=',dbi$InitDB,';uid=',dbi$User,';pwd=',dbi$Password,sep=''))
    sqlQuery(channel,query=stmt)
    odbcClose(channel)
	
    export2db(data=fit_oas,server_type='SQL',server=dbi$Database,db=dbi$InitDB,table='OAS_ATTRIBUTION_FIT',user=dbi$User,psw=dbi$Password,na='')	
	invisible()
}
# determine states with credit distribution significantly different from average and have sufficient  number of bonds
states_credit_deviation <- function(data)
{
	mincount = 50
	states = sort(unique(data$state))
	ob = c()
	obc = c()
	for(st in states)
	{
		ob = rbind(ob,data.frame(State = st, HG = sum(na.exclude(data$state == st & data$credit_rating <= 4.5))/sum(data$state == st & !is.na(data$credit_rating)),
											 LG = sum(na.exclude(data$state == st & data$credit_rating > 4.5))/sum(data$state == st & !is.na(data$credit_rating))))
		obc = rbind(obc,data.frame(State = st, HG = sum(na.exclude(data$state == st & data$credit_rating <= 4.5)),
											 LG = sum(na.exclude(data$state == st & data$credit_rating > 4.5))))									 
	}
	out = c()
	av = colMeans(ob[,c('HG','LG')])
	sdev = c(sd(ob[,2]),sd(ob[,3]))
	devlim = 1
	for(i in 1:dim(ob)[1])
	{
		if((ob[i,2] > av[1] + devlim*sdev[1] | ob[i,2] < av[1] - devlim*sdev[1]) 
			& (ob[i,3] > av[2] + devlim*sdev[2] | ob[i,3] < av[2] - devlim*sdev[2])
		   	& obc[i,2] > mincount & obc[i,3] > mincount)
		out = c(out,ob[i,'State'])
	}
	out
}

load_internal_ratings <- function(as_of,dbi)
{
	require(RODBC)
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',dbi$Database,';DataBase=',dbi$InitDB,';uid=',dbi$User,';pwd=',dbi$Password,sep=''))
  
	q = 'select MIN(VALUE_DATE) from Optimizer..MUNI_POSITION_HISTORY'
	fdate <- as.Date(sqlQuery(channel,query=q)[1,1])
    
	if(as_of < fdate)
	{
		q = paste("select distinct h.SECURITY_ID identifier,r.ID internal_rating from Optimizer..MUNI_INTERNAL_RATING_HIST h,",
			"FIQModel..BOND_CREDIT_RATING r ",
			"where h.VALUE_DATE = '", format(as_of,'%d-%b-%Y'),"' and h.RATING is not null ",
			"and h.RATING = r.SP order by 1",sep = '')
	}else 
	{
		q = paste("select distinct SECURITY_ID identifier,r.ID internal_rating from Optimizer..MUNI_POSITION_HISTORY p,",
			"FIQModel..BOND_CREDIT_RATING r ",
			"where p.VALUE_DATE = '", format(as_of,'%d-%b-%Y'),"' and p.INTERNAL_RATING is not null ",
			"and p.INTERNAL_RATING = r.SP order by 1",sep = '')
	}		
  	data <- sqlQuery(channel,query=q)		
    odbcClose(channel)
    data
}

populate_insurance_buckets <- function(as_of,bt,dbi)
{
	q = paste("delete from Optimizer.dbo.MUNI_INSURER_BUCKETS where AS_OF_DATE = '",as_of,"'",sep = '')
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',dbi$Database,';DataBase=',dbi$InitDB,';uid=',dbi$User,';pwd=',dbi$Password,sep=''))
    sqlQuery(channel,query=q)
    odbcClose(channel)
    
    export2db(data=data.frame(ID = 1,AS_OF_DATE = as_of, INSURER_BUCKET = bt$tags, CODE = bt$code),
    	server_type='SQL',server=dbi$Database,db='Optimizer',table='MUNI_INSURER_BUCKETS',user=dbi$User,psw=dbi$Password,na='')	
}

load_security_data <- function(as_of,db_info,init = F,cetags = F)
{
	data <- rbind(load_data(as_of,db_info,'Barcap',init,cetags),load_data(as_of,db_info,'AB',init,cetags))
	
	#AB data take priority over Barcap, if same cusip appear more than once
	ix <- data$source=='AB'
	jx <- data$source=='Barcap'
	kx <- jx & data$identifier %in% data$identifier[ix]
	data <- data[ix | (jx & !kx), ]
	
	data
}

load_data <- function(as_of,dbi,src=NULL,init = F,cetags = F)
{
	require(RODBC)
	
	cat('loading data as of',format(as_of),' from ',src,' ...\n')
	stmt <- paste("
		SELECT anal.SOURCE,
		anal.IDENTIFIER,anal.EFFECTIVE_DATE AS AS_OF_DATE,anal.AMT_OUTSTANDING,
		INDEX_RATING,
		INDEX_RATING_NUM=idx.ID,
		MOODY_RATING=moody.ID,
		SP_RATING   =sp.ID,
		FITCH_RATING=fitch.ID,
		UND_MOODY_RATING = undmoody.ID,
		UND_SP_RATING = undsp.ID,
		APEX_MUNI_INSURANCE insurer,
		anal.STATE,
		MUNI_TAXABILITY=(CASE anal.MUNI_TAXABILITY WHEN 'Build America Bonds Direct Pay' THEN 'Taxable'
			WHEN 'Unknown Tax Status' THEN 'Taxable'
			WHEN 'Recovery Zone Facilities Bonds' THEN 'Tax Exempt - No AMT'
			ELSE anal.MUNI_TAXABILITY END
			),
		anal.ISSUE_PRICE,anal.ISSUE_YIELD,anal.YIELD_TO_MAT,
		anal.COUPON,anal.MATURITY_DATE,anal.PRICE,anal.NEXT_SINK_DATE,anal.NEXT_CALL_DATE,
		anal.MUNI_OAS_RISK AS MUNI_OAS,anal.MUNI_OAD_RISK AS MUNI_OAD,
		TIME_TO_WORST=(CASE WHEN anal.TIME_TO_WORST IS NULL THEN DATEDIFF(DAY,EFFECTIVE_DATE,MATURITY_DATE)/365.0 ELSE anal.TIME_TO_WORST END),
		TIME_TO_MATURITY=DATEDIFF(DAY,EFFECTIVE_DATE,MATURITY_DATE)/365.0,
		AB_CODE=(CASE anal.PURPOSE_TYPE WHEN 'Muni PRE' THEN 'DIA' ELSE code.AB_CODE END),
		anal.MUNI_6MO_KRD,anal.MUNI_2YR_KRD,anal.MUNI_5YR_KRD,
		anal.MUNI_10YR_KRD,anal.MUNI_20YR_KRD,anal.MUNI_30YR_KRD,
		anal.COUPON_RETURN_MTD,anal.PRICE_RETURN_MTD,anal.MUNI_OAC as convexity,anal.EDTS deminimis_buffer
		FROM Optimizer.dbo.MUNI_ANALYTICS_VIEW anal
		LEFT JOIN FIQModel.dbo.BOND_CREDIT_RATING idx
		ON UPPER(idx.MOODY)=anal.INDEX_RATING
		LEFT JOIN FIQModel.dbo.BOND_CREDIT_RATING moody
		ON UPPER(moody.MOODY)=anal.MOODY_RATING
		LEFT JOIN FIQModel.dbo.BOND_CREDIT_RATING sp
		ON UPPER(sp.SP)=anal.SP_RATING
		LEFT JOIN FIQModel.dbo.BOND_CREDIT_RATING fitch
		ON UPPER(fitch.FITCH)=anal.FITCH_RATING
		LEFT JOIN FIQModel.dbo.BOND_CREDIT_RATING undmoody
		ON UPPER(undmoody.MOODY)=anal.UI_MOODY_RATING
		LEFT JOIN FIQModel.dbo.BOND_CREDIT_RATING undsp
		ON UPPER(undsp.SP)=anal.UI_SP_RATING ",
		"INNER JOIN (select IDENTIFIER, AB_CODE from FIQModel.dbo.MUNI_SECTOR_CODE ",
		"			where PREV_AB_CODE is null or (TIMESTAMP < '", format(as_of,'%d-%b-%Y'),"' and PREV_AB_CODE is not null) union ",
		"			select IDENTIFIER,PREV_AB_CODE AB_CODE  from FIQModel.dbo.MUNI_SECTOR_CODE ",
		"			where TIMESTAMP >= '", format(as_of,'%d-%b-%Y'),"' and PREV_AB_CODE is not null)  code ",
		"ON code.IDENTIFIER = anal.IDENTIFIER ",
		"where anal.EFFECTIVE_DATE='", format(as_of,'%d-%b-%Y'),"'		
	",sep='')
	if(!is.null(src)) stmt <- paste(stmt,"and SOURCE='",src,"'\n",sep='')
	
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',dbi$Database,';DataBase=',dbi$InitDB,';uid=',dbi$User,';pwd=',dbi$Password,sep=''))
    data <- sqlQuery(channel,query=stmt)
    dummy_map <- sqlQuery(channel,query='select * from FIQModel.dbo.MUNI_DUMMY_VARIABLE_MAP')
    odbcClose(channel)
    
    if(nrow(data)==0)
    {
	    cat('no muni analytics data as of ',format(as_of),' from ',src,'\n')
	    return(data)
    }
    
    names(data) <- casefold(names(data),F)
    idx <- grep('date',names(data))
    for(id in idx) data[,id] <- as.Date(data[,id])
    
    #############################################################
	#map state,sector,taxability
    names(dummy_map) <- casefold(names(dummy_map),F)
    attrs <- c('state','ab_code','muni_taxability')
    for(atr in attrs)
    {
	    map <- dummy_map[dummy_map$attribute==atr,c('orig_value','mapped_value')]
	    names(map) <- c(atr,paste('mapped',atr,sep=''))
	    data <- merge(data,map)
	    data <- data[,-match(atr,names(data))]
	}
    names(data) <- gsub('mapped','',names(data))
    
    #remove Housing - Single Family
    data = data[data$ab_code != 328,]

    #filter out active sinkers
    inx_sink = !is.na(data$next_sink_date) # all sinkers
    inx_call = !is.na(data$next_call_date) # all callables
    inx_sc = intersect(which(inx_call),which(inx_sink)) # callable sinkers
    inx_act = data$next_sink_date[inx_sc] - data$next_call_date[inx_sc] < 0 #active callable sinkers
    inx_snc = intersect(which(!inx_call),which(inx_sink)) # non callable sinkers
    asink = union(inx_snc,inx_sc[inx_act]) #all active sinkers
    if(length(asink) > 0)
    	data = data[-asink,]
    cat(length(asink),' active sinkers removed','\n')
    
    # remove pre-refs with classification conflicts
    
    q = paste("
    		select b.IDENTIFIER from (		
			select IDENTIFIER, AB_CODE from FIQModel.dbo.MUNI_SECTOR_CODE
			where PREV_AB_CODE is null or (TIMESTAMP < '", format(as_of,'%d-%b-%Y'),"' and PREV_AB_CODE is not null)
			union
			select IDENTIFIER,PREV_AB_CODE AB_CODE  from FIQModel.dbo.MUNI_SECTOR_CODE
			where TIMESTAMP >= '", format(as_of,'%d-%b-%Y'),"' and PREV_AB_CODE is not null
			) b, Optimizer..MUNI_ANALYTICS a
			where b.AB_CODE = 'DIA' and b.IDENTIFIER = a.IDENTIFIER and a.PURPOSE_TYPE <> 'Muni PRE'
			and a.EFFECTIVE_DATE = '", format(as_of,'%d-%b-%Y'),"'",
			sep = '')
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',dbi$Database,';DataBase=',dbi$InitDB,';uid=',dbi$User,';pwd=',dbi$Password,sep=''))
    mcsec <- sqlQuery(channel,query=q)
    odbcClose(channel)
    names(mcsec) <- casefold(names(mcsec),F)
    
    data = data[!(data$identifier %in% mcsec$identifier),]
    
    # remove pre-refs with non zero vol exposure (analytics is not reliable)
    
    q = paste("
			    select IDENTIFIER from Optimizer..MUNI_ANALYTICS  where PURPOSE_TYPE = 'Muni PRE'
				and MUNI_VEGA <> 0 and EFFECTIVE_DATE = '", format(as_of,'%d-%b-%Y'),"'",
				sep = '')
				
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',dbi$Database,';DataBase=',dbi$InitDB,';uid=',dbi$User,';pwd=',dbi$Password,sep=''))
    mcsec <- sqlQuery(channel,query=q)
    odbcClose(channel)
    names(mcsec) <- casefold(names(mcsec),F) 
    
    data = data[!(data$identifier %in% mcsec$identifier),]

	#############################################################
	# term structure for taxability
	if(init)
	{
  		data$muni_taxability[data$muni_taxability == 201 & data$time_to_maturity <= 5] = 2011
  		data$muni_taxability[data$muni_taxability == 201 & data$time_to_maturity > 5 & data$time_to_maturity <= 15] = 2012
  		data$muni_taxability[data$muni_taxability == 201 & data$time_to_maturity >15] = 2013
	}else
	{
		matb = seq(0,20,by = 0.25)
		for(i in 2:length(matb))
		{
			data$muni_taxability[data$muni_taxability == 201 & data$time_to_maturity > matb[i-1] & data$time_to_maturity <= matb[i]] = 20100 + i - 1
		}
		data$muni_taxability[data$muni_taxability == 201 & data$time_to_maturity > matb[i]] = 20100 + i - 1
	}
	
    data$credit_rating <- rowMeans(data[,c('moody_rating', 'sp_rating', 'fitch_rating')],na.rm=T )
    
    ix <- rowSums( is.na(data[,c('moody_rating', 'sp_rating', 'fitch_rating')]) ) == 3
	if(sum(ix)>0) data[ix,c('moody_rating', 'sp_rating', 'fitch_rating')] <- data[ix,'index_rating_num']
	
	#add credit buckets to sectors private higher education
#    data[data$ab_code == 312 & data$credit_rating <= 5 & !is.na(data$credit_rating) ,'ab_code'] = 3121
#    data[data$ab_code == 312 & data$credit_rating > 5 & data$credit_rating <= 8 & !is.na(data$credit_rating),'ab_code'] = 3122
#    data[data$ab_code == 312 & (data$credit_rating > 8 | is.na(data$credit_rating)),'ab_code'] = 3123
    
#    data[data$ab_code == 312 & data$credit_rating <= 1 & !is.na(data$credit_rating) ,'ab_code'] = 3121
#    data[data$ab_code == 312 & (data$credit_rating > 1 | is.na(data$credit_rating)),'ab_code'] = 3123
	for(sec in unique(data$ab_code))
	{
		data[data$ab_code == sec & data$credit_rating <= 5 & !is.na(data$credit_rating) ,'ab_code'] = sec*10 + 1
		data[data$ab_code == sec & (data$credit_rating > 5 | is.na(data$credit_rating)),'ab_code'] = sec*10 + 2
	}

	### credit enhancement
	
	data$credit_issuer = rowMeans(data[,c('und_moody_rating', 'und_sp_rating')],na.rm=T )
	
	### override credit with internal ratings
	
	ir = load_internal_ratings(as_of,db_info)
	if(dim(ir)[1] > 0)
	data[na.exclude(match(ir$identifier, data$identifier)),'credit_issuer'] = ir[!is.na(match( ir$identifier, data$identifier)),'internal_rating']

	### set credit rating to issuer rating
	#data$credit_rating = data$credit_issuer
	
	### create credit enhancement buckets
	
	data$credit_enhancement = as.character(data$insurer)
	data$credit_enhancement[is.na(data$credit_enhancement)] = 'None'
	
		# override credit rating with issuer rating if there is a credit enhancement (to build credit duration on issuer rating)
	data$credit_rating[data$credit_enhancement != 'None'] = data$credit_issuer[data$credit_enhancement != 'None']
	
	#add credit buckets
	cenh = sort(unique(data$credit_enhancement))
	cenh = cenh[cenh != 'None']
	codestart = 500
	data$ce_bucket = codestart
	if(cetags)
		data$ce_bucket = 'None'
	cebc = 1
	#cwd = getwd()
	#setwd(paste(Sys.getenv('ABFI_DATA_REPOSITORY'),'\\Muni\\v1.0\\Input',sep='') )
 	#setwd('H:\\tmp\\Muni')
 	
 	tags = data.frame(tag = character(0), code = numeric(0))
	for(i in 1:length(cenh))
	{
		# AAA buckets
		inx = data$credit_enhancement == cenh[i] & data$credit_rating <= 2
		tags = rbind(tags,data.frame(tags = paste(cenh[i]," AAA",sep = ''),code = codestart + cebc))
		if(sum(inx,na.rm = T) > 4) # use bucket if it has 5 securities or more, otherwise use 'None' bucket
		{
			data$ce_bucket[inx] = codestart + cebc
			if(cetags)
				data$ce_bucket[inx] = as.character(tags$tags[dim(tags)[1]])
		}else
		{
			if(!cetags)
				data$ce_bucket[inx] = codestart
		}
		cebc = cebc + 1
		# AA buckets
		inx = data$credit_enhancement == cenh[i] & data$credit_rating > 2 & data$credit_rating <= 5
		tags = rbind(tags,data.frame(tags = paste(cenh[i]," AA",sep = ''),code = codestart + cebc))
		if(sum(inx,na.rm = T) > 4)
		{
			data$ce_bucket[inx] = codestart + cebc
			if(cetags)
				data$ce_bucket[inx] = as.character(tags$tags[dim(tags)[1]])
		}else
		{
			if(!cetags)
				data$ce_bucket[inx] = codestart
		}			
		cebc = cebc + 1
		# A buckets
		inx = data$credit_enhancement == cenh[i] & data$credit_rating > 5 & data$credit_rating <= 7
		tags = rbind(tags,data.frame(tags = paste(cenh[i]," A",sep = ''),code = codestart + cebc))
		if(sum(inx,na.rm = T) > 4)
		{		
			data$ce_bucket[inx] = codestart + cebc
			if(cetags)
				data$ce_bucket[inx] = as.character(tags$tags[dim(tags)[1]])
		}else
		{
			if(!cetags)
				data$ce_bucket[inx] = codestart
		}
		cebc = cebc + 1
		
		# BBB buckets
		inx = data$credit_enhancement == cenh[i] & data$credit_rating > 7 & data$credit_rating <= 10
		if(sum(inx,na.rm = T) > 4)
		{
			data$ce_bucket[inx] = codestart + cebc
			tags = rbind(tags,data.frame(tags = paste(cenh[i]," BBB",sep = ''),code = codestart + cebc))
			if(cetags)
				data$ce_bucket[inx] = as.character(tags$tags[dim(tags)[1]])
		}else
		{
			if(!cetags)
				data$ce_bucket[inx] = codestart
		}
		cebc = cebc + 1
		# HY buckets
		inx = data$credit_enhancement == cenh[i] & data$credit_rating > 10
		tags = rbind(tags,data.frame(tags = paste(cenh[i]," HY",sep = ''),code = codestart + cebc))
		if(sum(inx,na.rm = T) > 4)
		{
			data$ce_bucket[inx] = codestart + cebc
			if(cetags)
				data$ce_bucket[inx] = as.character(tags$tags[dim(tags)[1]])
		}else
		{
			if(!cetags)
				data$ce_bucket[inx] = codestart
		}	
		cebc = cebc + 1

	}
	if(src == 'Barcap')
		populate_insurance_buckets(as_of,tags,dbi)
	
	#save(tags,file = 'insurance_buckets.RData')
	#setwd(cwd)
 	
	#### override credit for pre-refs with AAA
	data[data$ab_code == 333,'credit_rating'] = 1
	
	### set credit rating to issuer rating
	data$credit_rating = data$credit_issuer
	
	#############################################################
	
	#calculate deminimis. 
#############################################################################################
#The following code implements the logic used to compute EDTS field in MUNI_ANALYTICS table
##############################################################################################
# 	ix_OID <- data$issue_price>0 & data$issue_price < 100
# 	
# 	data$adjusted_basis <- 100
# 	
# 	#adjusted basis for OID bonds
# 	maturities <- as.numeric( difftime(data$maturity_date[ix_OID],data$as_of_date[ix_OID],units='days')/365 )
# 	data$adjusted_basis[ix_OID] <- 100*par_bond_price(data$coupon[ix_OID]/100,data$issue_yield[ix_OID]/100,maturities)
# 	
# 	ix <- data$adjusted_basis>100 | data$issue_Price==0 | data$issue_yield==0
# 	data$adjusted_basis[ix] <- NA
# 	
# 	data$deminimis <- ( as.numeric(difftime(data$maturity_date,data$as_of_date,unit='day'))/365 ) * 0.25
# 	data$deminimis_threshold <- data$adjusted_basis - data$deminimis
# 	
# 	cwd = getwd()
# 	#setwd(paste(Sys.getenv('ABFI_DATA_REPOSITORY'),'\\Muni\\v1.0\\Input',sep='') )
# 	setwd('H:\\tmp\\Muni')
# 	
# 	if(file.exists(paste("EDTI_",as_of,".RData",sep='')))
# 	{
# 		load(paste("EDTI_",as_of,".RData",sep=''))
# 		
# 		inxa = which(!is.na(match(data$identifier, edtidata$security)))
# 		inxb = na.exclude(match(data$identifier, edtidata$security))
# 		data$deminimis_buffer[inxa] = edtidata$edti[inxb]
# 	}else
# 	{
# 	
# 		data = data[!is.na(data$muni_oas) & !is.na(data$muni_oad) & !is.na(data$adjusted_basis),]
# 		data$deminimis_buffer = NA
# 		rate_vol = 0.02
# 		mat_all <- as.numeric( difftime(data$maturity_date,data$as_of_date,units='days')/365.25 )
# 		hold_frac = pmin(1,3/mat_all)
# 		tax_impact <- function(spread,price,deminimis_threshold,oad,basis,hold)
# 		{
# 			0.434*hold*ifelse(deminimis_threshold > price*(1 + oad*spread),basis - price*(1 + oad*spread),0)*dnorm(spread,0,rate_vol)
# 		}
# 		for(i in 1:dim(data)[1])
# 		{
# 			data$deminimis_buffer[i] = integrate(tax_impact,-4*rate_vol,4*rate_vol,price = data$price[i],deminimis_threshold = data$deminimis_threshold[i],
# 												oad = data$muni_oad[i],basis = data$adjusted_basis[i],hold = hold_frac[i])$value
# 			if(i%%1000 == 0) cat(paste('integrating ',i,'-th security\n',sep=''))
# 		}
# 		
# 		data$deminimis_buffer = 100*data$deminimis_buffer/data$price/data$muni_oad # tax impact in spread space
# 		edtidata = data.frame(security = data$identifier,edti = data$deminimis_buffer)
# 		save(edtidata,file = paste("EDTI_",as_of,".RData",sep=''))
# 	}
# 	setwd(cwd)
	
	data$extension_risk =  data$muni_oad/par_bond_dur(data$coupon/100,data$yield_to_mat/100,data$time_to_maturity) 
	data$extension_risk[data$extension_risk < 0] = 0
	data$extension_risk[data$extension_risk > 1] = 1
	
	data$total_return_mtd <- (data$coupon_return_mtd + data$price_return_mtd)/100
	data$market_value <- data$amt_outstanding * data$price/100
	
	# zero coupon
	data$zero_coupon = 401
	data$zero_coupon[data$coupon == 0] = 402
	
	if(init)
	{
  	data$zero_coupon[data$zero_coupon == 402 & data$time_to_maturity <= 5] = 4021
  	data$zero_coupon[data$zero_coupon == 402 & data$time_to_maturity > 5 & data$time_to_maturity <= 15] = 4022
  	data$zero_coupon[data$zero_coupon == 402 & data$time_to_maturity >15] = 4023
	}else
	{
		matb = seq(0,20,by = 0.25)
		for(i in 2:length(matb))
		{
			data$zero_coupon[data$zero_coupon == 402 & data$time_to_maturity > matb[i-1] & data$time_to_maturity <= matb[i]] = 40200 + i - 1
		}
		data$zero_coupon[data$zero_coupon == 402 & data$time_to_maturity > matb[i]] = 40200 + i - 1
	}
	
	data$hy = ifelse(data$credit_rating > 10,1,0)
	
    data
}

# extract pre-refs
get_prerefs <- function(data)
{
	data_pr = data[data$ab_code == 333,]
	
	prst = pr_states # redefine state factor for pre-refs
	data_pr$state[!(data_pr$state %in% prst)] = '100'
	data_pr$muni_taxability[data_pr$muni_taxability > 2010] = 201 # collapse AMT term structure for pre-refs
	data_pr$zero_coupon[data_pr$zero_coupon > 4020] = 402 # collapse zero coupon term structure for pre-refs
	
	data_pr
}

#get model factor exposure
#residual - difference between current attribution and its historical average
#attribution - OAS attributed to these factors
get_factor_exposure <- function(data,dbi,type=c('residual','attribution'),NR=FALSE)
{
	data$index_oas <- 1
	data$resi_oas <- data$muni_oas
	
	type <- match.arg(type)
    #calculate factor exposures
    oas_fit <- load_oas_fit(data$as_of_date[1],dbi)
    
    do_pr = F
    if(sum(oas_fit$attribute == 'index_oas_pr') > 0)
    {
		data_pr = get_prerefs(data)
		data = data[data$ab_code != 333,] #separate prerefs
		do_pr = T
	}
	
	xvars <- c('credit_rating','muni_oad','deminimis_buffer','state','ab_code','muni_taxability','index_oas','zero_coupon')	
	xvars_dummy <- c('state','ab_code','muni_taxability','index_oas','zero_coupon','ce_bucket')
	xvars_cont <- c('extension_risk')
	xvars_dummy_pr = c('state','zero_coupon','index_oas')
	xvars_cont_pr = c('deminimis_buffer','credit_oad')
	
	for(xvar in xvars_dummy)
	{
		fit <- oas_fit[oas_fit$attribute==xvar,]
		idx <- match(data[,xvar],fit$value1)
		y <- fit$oas[idx]
		y_bar <- fit$mean_oas[idx]
		if(type=='residual') data[,xvar] <- y - y_bar
		else data[,xvar] <- y
		data$resi_oas <- data$resi_oas - y
	}
	
	if(do_pr)
	for(xvar in xvars_dummy_pr)
	{
		fit <- oas_fit[oas_fit$attribute==paste(xvar,"_pr",sep=''),]
		idx <- match(data_pr[,xvar],fit$value1)
		y <- fit$oas[idx]
		y_bar <- fit$mean_oas[idx]
		if(type=='residual') data_pr[,xvar] <- y - y_bar
		else data_pr[,xvar] <- y
		data_pr$resi_oas <- data_pr$resi_oas - y
	}
	
	for(xvar in xvars_cont)
	{
		fit <- oas_fit[oas_fit$attribute==xvar,]		
		y <- approx(fit$value1,fit$oas,xout=data[,xvar],rule=2)$y
		y_bar <- approx(fit$value1,fit$mean_oas,xout=data[,xvar],rule=2)$y
		
		if(type=='residual') data[,xvar] <- y - y_bar
		else data[,xvar] <- y
		data$resi_oas <- data$resi_oas - y
	}
	
	if(do_pr)
	for(xvar in xvars_cont_pr)
	{
		fit <- oas_fit[oas_fit$attribute==paste(xvar,"_pr",sep=''),]	
		if(xvar == 'credit_oad')
		{
			xv = 'muni_oad'
			y <- approx(fit$value1,fit$oas,xout=data_pr[,xv],rule=2)$y
			y_bar <- approx(fit$value1,fit$mean_oas,xout=data_pr[,xv],rule=2)$y
			
			if(type=='residual') data_pr$credit_oad <- y - y_bar
			else data_pr$credit_oad <- y
		}else
		{	
			y <- approx(fit$value1,fit$oas,xout=data_pr[,xvar],rule=2)$y
			y_bar <- approx(fit$value1,fit$mean_oas,xout=data_pr[,xvar],rule=2)$y
		
			if(type=='residual') data_pr[,xvar] <- y - y_bar
			else data_pr[,xvar] <- y
		}
		data_pr$resi_oas <- data_pr$resi_oas - y
	}
		
	#########################################################
	# deminimis buffer (separately for IG and HY)
	ix_hy = data$credit_rating > 10 | is.na(data$credit_rating)
	xvar = 'deminimis_buffer'
	
	fit_ig <- oas_fit[oas_fit$attribute==xvar & oas_fit$value2 == 0,]		
	y <- approx(fit_ig$value1,fit_ig$oas,xout=data[!ix_hy,xvar],rule=2)$y
	y_bar <- approx(fit_ig$value1,fit_ig$mean_oas,xout=data[!ix_hy,xvar],rule=2)$y
	
	if(type=='residual') data[!ix_hy,xvar] <- y - y_bar
		else data[!ix_hy,xvar] <- y
	data$resi_oas[!ix_hy] <- data$resi_oas[!ix_hy] - y

	fit_hy <- oas_fit[oas_fit$attribute==xvar & oas_fit$value2 == 1,]		
	y <- approx(fit_hy$value1,fit_hy$oas,xout=data[ix_hy,xvar],rule=2)$y
	y_bar <- approx(fit_hy$value1,fit_hy$mean_oas,xout=data[ix_hy,xvar],rule=2)$y
	
	if(type=='residual') data[ix_hy,xvar] <- y - y_bar
		else data[ix_hy,xvar] <- y
	data$resi_oas[ix_hy] <- data$resi_oas[ix_hy] - y
					
	##########################################################
	# credit-duration 
	require(fields)
	fit <- oas_fit[oas_fit$attribute=='credit_oad',]
	fit <- sort.data.frame(fit,by=~value2+value1)
	
	xlim <- range(fit$value1)
	ylim <- range(fit$value2)		
	loc <- as.matrix(data[,c('credit_rating','muni_oad')])
	loc[,1] <- winsorise(loc[,1],lb.value=xlim[1],ub.value=xlim[2] )
	loc[,2] <- winsorise(loc[,2],lb.value=ylim[1],ub.value=ylim[2] )	
	
	x <- sort(unique(fit$value1))
	y <- sort(unique(fit$value2))
	obj <- list(x=x,y=y,z=matrix(fit$oas,nrow=length(x)) )
	z <- interp.surface(obj, loc)
	
	obj <- list(x=x,y=y,z=matrix(fit$mean_oas,nrow=length(x)) )
	z_bar <- interp.surface(obj, loc)
	
	if(NR)
	{
		# assume that non rated bonds are HY, average oas for each duration across hy 
		hy_fit = fit[fit$value1 >= 10,]
		hy_oas = aggregate(hy_fit,list(dur = hy_fit$value2), FUN = mean)
		# find non rated bonds
		ix = is.na(loc[,1])
		z[ix] = approx(hy_oas$value2,hy_oas$oas,xout = loc[ix,2],rule=2)$y
		z_bar[ix] = approx(hy_oas$value2,hy_oas$mean_oas,xout = loc[ix,2],rule=2)$y
	}
	
	if(type=='residual') data$credit_oad <- z - z_bar
	else data$credit_oad <- z
		
	data$resi_oas <- data$resi_oas - z
	
	if(do_pr)
		rbind(data,data_pr)
	else
		data
}
# calculates muni curve driven returns (potfolio matching curve exposure) for each security
calc_returns <- function(data,dur,ret_fc,ret_ac=NULL)
{
    #calculate factor exposures
    as_of <- data$as_of_date[1]
    
	################################################
	#calculate returns
	idx_fc <- match(as_of,ret_fc$as_of_date)
	if(is.na(idx_fc) & as_of>=last.business.day(month.end(as_of)) ) idx_fc <- match(month.end(as_of),ret_fc$as_of_date)
	if( is.na(idx_fc)) stop('muni bond return not availble as of ',format(as_of),'\n')
	
	idx_dur <- idx_ac <- idx_fc
	################################################
	
	data$krd_ret_fwd3m_fc <- ( data$muni_6mo_krd/dur[idx_dur,'dur_006m']*ret_fc[idx_fc,'fwd3m_fc_006m'] 
						+ data$muni_2yr_krd/dur[idx_dur,'dur_024m']*ret_fc[idx_fc,'fwd3m_fc_024m'] 
						+ data$muni_5yr_krd/dur[idx_dur,'dur_060m']*ret_fc[idx_fc,'fwd3m_fc_060m'] 
						+ data$muni_10yr_krd/dur[idx_dur,'dur_120m']*ret_fc[idx_fc,'fwd3m_fc_120m'] 
						+ data$muni_20yr_krd/dur[idx_dur,'dur_240m']*ret_fc[idx_fc,'fwd3m_fc_240m'] 
						+ data$muni_30yr_krd/dur[idx_dur,'dur_360m']*ret_fc[idx_fc,'fwd3m_fc_360m']) +
					    ( 1 - data$muni_6mo_krd/dur[idx_dur,'dur_006m']
							- data$muni_2yr_krd/dur[idx_dur,'dur_024m']
							- data$muni_5yr_krd/dur[idx_dur,'dur_060m']
							- data$muni_10yr_krd/dur[idx_dur,'dur_120m']
							- data$muni_20yr_krd/dur[idx_dur,'dur_240m']
							- data$muni_30yr_krd/dur[idx_dur,'dur_360m'])*ret_fc[idx_fc,'fwd3m_fc_003m']
							
	if(!is.null(ret_ac) & !is.null(data$price_fwd3m) )
	{
		data$total_ret_fwd3m <- (data$coupon/12*3 + data$price_fwd3m - data$price)/data$price
		
		data$krd_ret_fwd3m <- ( data$muni_6mo_krd/dur[idx_dur,'dur_006m']*ret_ac[idx_ac,'fwd3m_ac_006m'] 
							+ data$muni_2yr_krd/dur[idx_dur,'dur_024m']*ret_ac[idx_ac,'fwd3m_ac_024m'] 
							+ data$muni_5yr_krd/dur[idx_dur,'dur_060m']*ret_ac[idx_ac,'fwd3m_ac_060m'] 
							+ data$muni_10yr_krd/dur[idx_dur,'dur_120m']*ret_ac[idx_ac,'fwd3m_ac_120m'] 
							+ data$muni_20yr_krd/dur[idx_dur,'dur_240m']*ret_ac[idx_ac,'fwd3m_ac_240m'] 
							+ data$muni_30yr_krd/dur[idx_dur,'dur_360m']*ret_ac[idx_ac,'fwd3m_ac_360m']) +
						    ( 1 - data$muni_6mo_krd/dur[idx_dur,'dur_006m']
								- data$muni_2yr_krd/dur[idx_dur,'dur_024m']
								- data$muni_5yr_krd/dur[idx_dur,'dur_060m']
								- data$muni_10yr_krd/dur[idx_dur,'dur_120m']
								- data$muni_20yr_krd/dur[idx_dur,'dur_240m']
								- data$muni_30yr_krd/dur[idx_dur,'dur_360m'])*ret_ac[idx_ac,'fwd3m_ac_003m']
								
		data$excess_ret_fwd3m <- data$total_ret_fwd3m - data$krd_ret_fwd3m
	}
	
	data
}

get_required_dates <- function(as_of)
{
	stmt <- paste("
    	select DISTINCT FWD_DATE
    	FROM MUNI_MODEL_REGRESSION_DATA
        WHERE FWD_DATE <='", format(as_of,'%d-%b-%Y'),"'
	",sep='')
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    dates <- as.Date( sqlQuery(channel,query=stmt )[,1])
    odbcClose(channel)
    dates
}


#source('H:/dev/Quant_Model-SQLServer/Muni/v1.0/Src/ExcessReturn/muni_utility.R')

