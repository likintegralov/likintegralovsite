#!\\nts0018\bond\ABFI_PROD\QuantApps\R-2.14.2\bin\Rscript

source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Utility\\R_Splus\\utility.R',sep='') )

load_reg_data <- function(as_of)
{
	cat(format(Sys.time()),'loading data as of',format(as_of),'from database...\n')
	stmt <- paste("
		SELECT 
		FWD_DATE,
		EXCESS_RET_FWD3M,KRD_RET_FWD3M_FC,TOTAL_RET_FWD3M,
		INDEX_OAS,CREDIT_OAD,STATE,AB_CODE,MUNI_TAXABILITY,
		DEMINIMIS_BUFFER,RESI_OAS
		FROM MUNI_MODEL_REGRESSION_DATA
        WHERE FWD_DATE <='", format(as_of,'%d-%b-%Y'),"'
	",sep='')
	
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    reg_data <- sqlQuery(channel,query=stmt)
    odbcClose(channel)
    names(reg_data) <- casefold(names(reg_data),F)
    reg_data$fwd_date <- as.Date(reg_data$fwd_date)
    cat(format(Sys.time()),'done.\n')
    reg_data
}

###############################################################################
#source('H:/SVN/Muni/v1.0/Src/ExcessReturn/model_simulation.R')
setwd(paste(Sys.getenv('ABFI_DATA_REPOSITORY'),'\\Muni\\v1.0\\Output',sep='') )


library(RODBC)
db_info <- get_db_info('QA')

xvars <- c('index_oas','credit_oad','ab_code','deminimis_buffer','resi_oas')

reg_data <- load_reg_data(Sys.Date())

xvars <- c('index_oas','credit_oad','state','ab_code','muni_taxability','deminimis_buffer','resi_oas')
mf <- formula(paste('excess_ret_fwd3m ~',paste(xvars,collapse='+')))
        
fwd_dates <- sort(unique(reg_data$fwd_date))

res <- c()
for(i in 12:(length(fwd_dates)-3) )
{
	cat(format(Sys.time()),'processing',format(fwd_dates[i]),'...\n' )
	model_data <- reg_data[reg_data$fwd_date<=fwd_dates[i],]
	for(xvar in xvars) model_data[,xvar] <- winsorise(model_data[,xvar])
	
	fit <- glm.wridge(
	    formula=mf,
	    data=model_data,
	    lambda=2,
	    batch.size=500000
    )
       
	cat(format(fwd_dates[i]),':b=(bps)',centered.coef(fit)*1e4,'\n')
	####################################################
	####################################################
	
	pred_data <- reg_data[reg_data$fwd_date==fwd_dates[i+3],]
    pred_data$excess_ret_fc_fwd3m <- predict.ridge(fit,newdata=pred_data,type='response')
	pred_data$total_ret_fc_fwd3m <- pred_data$excess_ret_fc_fwd3m + pred_data$krd_ret_fwd3m_fc
	
	ix <- is.na(pred_data$total_ret_fc_fwd3m)
	pred_data <- pred_data[!ix,]

	cor_total <- cor(pred_data$total_ret_fc_fwd3m,pred_data$total_ret_fwd3m,use='pair')
	cor_excess <- cor(pred_data$excess_ret_fc_fwd3m,pred_data$excess_ret_fwd3m,use='pair')
	rankcor_total <- cor(rank(pred_data$total_ret_fc_fwd3m),rank(pred_data$total_ret_fwd3m),use='pair')
	rankcor_excess <- cor(rank(pred_data$excess_ret_fc_fwd3m),rank(pred_data$excess_ret_fwd3m),use='pair')
	
	rank_total <- rank(-pred_data$total_ret_fc_fwd3m)
	n <- length(rank_total)
	grp1_total <- mean(pred_data$total_ret_fwd3m[rank_total<=n/5],na.rm=T)
	grp2_total <- mean(pred_data$total_ret_fwd3m[rank_total>n/5 & rank_total<=2*n/5],na.rm=T)
	grp3_total <- mean(pred_data$total_ret_fwd3m[rank_total>2*n/5 & rank_total<=3*n/5],na.rm=T)
	grp4_total <- mean(pred_data$total_ret_fwd3m[rank_total>3*n/5 & rank_total<=4*n/5],na.rm=T)
	grp5_total <- mean(pred_data$total_ret_fwd3m[rank_total>4*n/5],na.rm=T)
	
	rank_ex <- rank(-pred_data$excess_ret_fc_fwd3m)
	n <- length(rank_ex)
	grp1_ex <- mean(pred_data$excess_ret_fwd3m[rank_ex<=n/5],na.rm=T)
	grp2_ex <- mean(pred_data$excess_ret_fwd3m[rank_ex>n/5 & rank_ex<=2*n/5],na.rm=T)
	grp3_ex <- mean(pred_data$excess_ret_fwd3m[rank_ex>2*n/5 & rank_ex<=3*n/5],na.rm=T)
	grp4_ex <- mean(pred_data$excess_ret_fwd3m[rank_ex>3*n/5 & rank_ex<=4*n/5],na.rm=T)
	grp5_ex <- mean(pred_data$excess_ret_fwd3m[rank_ex>4*n/5],na.rm=T)
	
	res <- rbind(res,data.frame(as_of=fwd_dates[i+3],cor_total=cor_total,cor_excess=cor_excess,
		rankcor_total=rankcor_total,rankcor_excess=rankcor_excess,
		grp1_total=grp1_total,grp2_total=grp2_total,grp3_total=grp3_total,
		grp4_total=grp4_total,grp5_total=grp5_total,
		grp1_ex=grp1_ex,grp2_ex=grp2_ex,grp3_ex=grp3_ex,
		grp4_ex=grp4_ex,grp5_ex=grp5_ex
		))
	gc()	
}

####################################################	
###############################################################################
#source('H:/SVN/Muni/v1.0/Src/ExcessReturn/model_simulation.R')
#save(res,file='simulation_result.RData')
#res <- res[res$as_of>='2010-01-01',]
for(i in 2:5)
{
	yrange <- range(res[,2:5])
	if(i==2) plot(res$as_of,res[,i],ylim=yrange,type='b',col=i,pch=i,xlab='date',ylab='corr(forecast,actual)',main='correlation between actual and forecasted returns')
	else lines(res$as_of,res[,i],col=i,pch=i,type='b')
}
legend('bottomleft',names(res)[2:5],col=2:5,pch=2:5,lwd=2)

vars <- names(res)[grep('grp',names(res))]
res_cum <- res[,c('as_of',vars)]
for(var in vars) res_cum[,var] <- cumsum(res_cum[,var]/3)

for(i in 1:5)
{
	yrange <- range(res_cum[,vars[1:5]])
	if(i==1) plot(res_cum$as_of,res_cum[,vars[i]],ylim=yrange,type='b',col=i,pch=i,xlab='date',ylab='cumret',main='quintile chart, total return, overlapped 3-month')
	else lines(res_cum$as_of,res_cum[,vars[i]],col=i,pch=i,type='b')
}
lines(res_cum$as_of,res_cum[,vars[1]]-res_cum[,vars[5]],col=6,pch=6,lwd=2,type='b')

legend('topleft',c(vars[1:5],'grp1-grp5'),col=1:6,pch=1:6,lwd=2)

for(i in 6:10)
{
	yrange <- range(res_cum[,vars[6:10]],res_cum[,vars[6]]-res_cum[,vars[10]])
	if(i==6) plot(res_cum$as_of,res_cum[,vars[i]],ylim=yrange,type='b',col=i-5,pch=i-5,xlab='date',ylab='cumret',main='quintile chart, excess return, overlapped 3-month')
	else lines(res_cum$as_of,res_cum[,vars[i]],col=i-5,pch=i-5,type='b')
}
lines(res_cum$as_of,res_cum[,vars[6]]-res_cum[,vars[10]],col=6,pch=6,lwd=2,type='b')
legend('topleft',c(vars[1:5+5],'grp1-grp5'),col=1:6,pch=1:6,lwd=2)



