
source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.R',sep='') )

###############################################################################
#source('H:/SVN/Muni/v1.0/Src/ExcessReturn/ReturnAttribution.R') 

library(RODBC)
db_info <- get_db_info('PRD')


pnames = c('AMIAZP')
#pnames = c('AMINAP')
#pnames = c('BDMP')
#pnames = c('03910060')
#pnames = c('BNYMP')

as_of = as.Date('2015-04-30')

start_date = as.Date(as_of - 740)

dates = load_muni_analytics_dates(as_of,db_info,'Barcap')
dates = dates[dates >= start_date]

excl = c('26116PAR','898728FM','29758FAA','38251TAP','72177MFN','722045BN','74526LEP','825373BT','867241AG','898728FM','89874LAT')

for(port_name in pnames)
{
	q = paste("select ACCOUNT_ID, SHORT_NAME, ALTERNATE_IDENTIFIER ALT_ID, LONG_NAME from DAILYVIEW..ACCTS_PORTFOLIOS
			where SHORT_NAME = '",port_name,"'",sep='')

	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))

	port_info <- sqlQuery(channel,query=q,as.is = T)		

	port_long_name = port_info$LONG_NAME[1]
	port_id = port_info$ACCOUNT_ID[1]
	muni_id = port_info$ALT_ID[1]		
	
	q = paste("select distinct p.BUSINESS_DATE date,substring(SECURITY_ID,1,8) identifier,p.POSITION_WEIGHT weight,a.DESCRIPTION description,a.COUPON coupon,a.PRICE,",
				"a.MATURITY_DATE maturity,a.MUNI_OAD_RISK dur,a.MUNI_OAS_RISK oas,s.AB_SECTOR sector,a.MUNI_6MO_KRD,",
				"a.MUNI_2YR_KRD,a.MUNI_5YR_KRD,a.MUNI_10YR_KRD,a.MUNI_20YR_KRD,a.MUNI_30YR_KRD ",
				"from DAILYVIEW..POSITION_HISTORY p,FIQModel..MUNI_SECTOR_CODE sc, FIQModel..MUNI_SECTOR s,",  
				"Optimizer..MUNI_ANALYTICS a where PORTFOLIO_ID = '",port_id,
				"' and BUSINESS_DATE in ('",paste(dates,collapse = "','"),"') and SUBSTRING( p.SECURITY_ID,1,8) = a.IDENTIFIER ",
				"and p.BUSINESS_DATE = a.EFFECTIVE_DATE and p.ASSET_CLASS = 'MUNI' and a.PRICE is not null
				and a.IDENTIFIER = sc.IDENTIFIER
				and sc.AB_CODE = s.AB_CODE order by date,identifier",sep='')

	port_data <- sqlQuery(channel,query=q)
	names(port_data) = tolower(names(port_data))
	
	port_data = port_data[!(port_data$identifier %in% excl),]
	
	dates = as.Date(unique(port_data$date))
	port_secs = unique(port_data$identifier)
	
	
	q = paste("select IDENTIFIER, NEXT_CALL_DATE call_date from Optimizer..MUNI_ANALYTICS ",
			"where IDENTIFIER in ('",paste(port_secs,collapse = "','"),"') and EFFECTIVE_DATE = '",as_of,"'",sep = '')
	call_data = sqlQuery(channel,query=q)
	names(call_data) = tolower(names(call_data))
			 
	port_data$call_date = as.Date('2200-01-01')
	for(i in 1:dim(call_data)[1])
	{
		port_data$call_date[port_data$identifier %in% call_data$identifier[i]] = as.Date(call_data$call_date[i])
	}
	port_data$call_date = as.Date(port_data$call_date)
		
	q <- paste("select AS_OF_DATE date,POINT_006M kr6m,POINT_024M kr2y,POINT_060M kr5y,POINT_120M kr10y,POINT_240M kr20y,POINT_360M kr30y ",
	 	"FROM FIQModel..YIELD_CURVE_TIMESERIES ",
        "WHERE YC_NAME = 'LgtParBond' AND COUNTRY='US' ",
        "and AS_OF_DATE in ('",paste(dates,collapse = "','"),"') ",
        "ORDER BY AS_OF_DATE",sep='')
	
    curve_data <- sqlQuery(channel,query=q)    
        
	odbcClose(channel)
	
	ret_decomp = c()
	
	for(i in 2:length(dates))
	{
		bofm = port_data[as.Date(port_data$date) == dates[i-1],]
		eofm = port_data[as.Date(port_data$date) == dates[i],]
		bofm = bofm[bofm$identifier %in% eofm$identifier,] 
		eofm = eofm[eofm$identifier %in% bofm$identifier,] 
				
		pret = 100*bofm$weight %*% (eofm$price/bofm$price - 1)
		cret = -bofm$weight %*% as.matrix(bofm[,c('muni_6mo_krd','muni_2yr_krd','muni_5yr_krd','muni_10yr_krd','muni_20yr_krd','muni_30yr_krd')]) %*% 
			as.matrix(t(curve_data[i,c('kr6m','kr2y','kr5y','kr10y','kr20y','kr30y')] - curve_data[i-1,c('kr6m','kr2y','kr5y','kr10y','kr20y','kr30y')]))
		sret = -bofm[,'dur'] %*% (eofm[,'oas'] - bofm[,'oas'])/10000	
		
		for(j in 1:dim(bofm)[1])
		{
			if(is.na(bofm$call_date[j])) bofm$call_date[j] = as.Date('2200-01-01')
		}
		
		p2pret = -100*bofm$weight %*% as.matrix((bofm$price - 100)/bofm$price * (as.numeric(dates[i] - dates[i-1])/as.numeric(pmin(as.Date(bofm$maturity) - dates[i-1], 
			bofm$call_date - dates[i-1]))))
			
		ret_decomp = rbind(ret_decomp,data.frame(date = dates[i],PriceReturn = pret,CurveRetrun = cret[1],SpreadReturn = sret,Pull2Par = p2pret,
		FactorReturn = cret[1]+sret+p2pret))	
	}
	sec_perf = c()
	sec_hist = c()
	for(sec in port_secs)
	{
		sdata = port_data[port_data$identifier == sec,]
		if(dim(sdata)[1] > 6)
		{
			n = dim(sdata)[1]
			pret = 100*diff(sdata$price)/sdata$price[1:(n-1)]
			scurve_data = curve_data[curve_data$date %in% sdata$date,]
			cret = c()
			for(i in 2:n)
			{
			cret = c(cret,-sum(diff(as.matrix(scurve_data[(i-1):i,c('kr6m','kr2y','kr5y','kr10y','kr20y','kr30y')])) *
				sdata[i-1,c('muni_6mo_krd','muni_2yr_krd','muni_5yr_krd','muni_10yr_krd','muni_20yr_krd','muni_30yr_krd')]))
			}
			sret = -sdata$dur[1:(n-1)] * diff(sdata$oas)/100
			
			mat = as.Date(sdata$maturity[1])
			cll = as.Date(ifelse(is.na(sdata$call_date[1]),as.Date('2200-01-01'),sdata$call_date[1]),'1970-01-01')
			p2pret = -(sdata$price[1:(n-1)] - 100) * as.numeric(diff(sdata$date)) / as.numeric(pmin(mat - sdata$date[1:(n-1)],
				 cll - as.Date(sdata$date[1:(n-1)])))
			fret = cret + sret + p2pret
			fit = lm(pret ~ fret)
			sec_perf = rbind(sec_perf,data.frame(security = sec,data_points = n,R2 = summary(fit)$r.squared))
			sec_hist = rbind(sec_hist,data.frame(as_of = sdata$date[2:n],coupon = sdata$coupon[2:n],price = sdata$price[2:n],
												maturity = sdata$maturity[2:n],dur = sdata$dur[2:n],oas = sdata$oas[2:n],
												call = sdata$call_date[2:n],
												security = sec,pret = pret,fret = fret,cret = cret, sret = sret, p2pret = p2pret))
		}
		
	}
}

