#!\\nts0018\bond\ABFI_PROD\QuantApps\R-2.14.2\bin\Rscript

source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.R',sep='') )


load_security_data <- function(as_of,db_info)
{
	data <- load_data(as_of,db_info)
	
	#AB data take priority over Barcap, if same cusip appear more than once
	ix <- data$source=='AB'
	jx <- data$source=='Barcap'
	kx <- jx & data$identifier %in% data$identifier[ix]
	data <- data[ix | (jx & !kx), ]
	
	data
}

calc_security_exposure <- function(data)
{	
	
	data <- get_factor_exposure(data,db_info,type='resi')
	
	load('../Input/MuniParBondRet.RData')	
	# add return forecat for treasury portfolio to krd_ret_fwd3m_fc
	data <- calc_returns(data,dur,ret_fc)
	#return only needed fields
	#xvars <- c('index_oas','credit_oad','state','ab_code','muni_taxability','deminimis_buffer','resi_oas')
	xvars <- c('credit_oad','resi_oas')
	data <- data[,c('as_of_date','identifier','muni_oad','market_value','total_return_mtd',xvars,
		'krd_ret_fwd3m_fc')]
	ix <- rowSums(is.na(data))==0 | ( rowSums(is.na(data))==1 & is.na(data$total_return_mtd) )
	data[ix,]
}

calc_security_return <- function(data,as_of,db_info)
{
	factor_loading <- load_factor_loading(as_of,db_info)
	#factor_loading = factor_loading[factor_loading$FACTOR_ID %in% c(1201,1202,1203,1208),]
	factor_loading = factor_loading[factor_loading$FACTOR_ID %in% c(1201,1203,1208),]
	var_map <- c(
		'Intercept','intercept',
		'index_oas','Index OAS',
		'credit_oad','Credit x OAD',
		'state', 'State',
		'ab_code','Sector',
		'muni_taxability','Taxability',
		'deminimis_buffer','Coupon Effect',
		'resi_oas','Residual OAS')
		
	stmt <- paste("
    	select MODEL_NAME,FACTOR_NAME,FACTOR_ID FROM 
        MODEL_DESCRIPTION a,MODEL_SPECIFICATION b
        WHERE a.MODEL_NAME = 'Muni Excess Return Model'
        AND b.MODEL_ID=a.MODEL_ID
        AND a.VERSION='1.0'
	",sep='')
	
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    id_map <- sqlQuery(channel,query=stmt)
    odbcClose(channel)
    
    idx <- match(id_map$FACTOR_NAME,var_map)
    id_map$xvar <- var_map[idx-1]
    
    factor_loading <- merge(factor_loading,id_map)
    
    data$Intercept <- 0
    data[,factor_loading$xvar] <- data[,factor_loading$xvar] * data$muni_oad
	
    for( xvar in factor_loading$xvar )
    {
	    if(xvar=='Intercept') data[,xvar] <- factor_loading$FACTOR_LOADING[factor_loading$xvar==xvar]
	    else{
		    f <- factor_loading[factor_loading$xvar==xvar,]
		    data[,xvar] <- winsorise(data[,xvar],lb.value=f$FACTOR_LB,ub.value=f$FACTOR_UB)
		    data[,xvar] <- f$FACTOR_LOADING*(data[,xvar]-f$FACTOR_MEAN)/f$FACTOR_STDEV
	    }
    }
    
    data$excess_ret_fwd3m_fc <- rowSums(data[,factor_loading$xvar])
    data$total_ret_fwd3m_fc <- data$excess_ret_fwd3m_fc + data$krd_ret_fwd3m_fc
    
    data
}

populate_security_forecast <- function(res)
{
    cat('populating model_forecast_security...\n')
    
    stmt <- paste("
        SELECT MODEL_ID
        FROM MODEL_DESCRIPTION
        WHERE MODEL_NAME = 'Muni Excess Return Model'
        AND VERSION='1.0'
        ",sep='')
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    ret <- sqlQuery(channel,query=stmt )
    odbcClose(channel)
    names(ret) <- casefold(names(ret),F)
        
    res$model_id <- ret$model_id[1]
    
    res$security_id <- res$identifier
    res$as_of <- res$as_of_date
    res$sector <- 'Muni'
    res$issuer_ticker <- NA
    res$credit_rating <- NA
    res$investable <- 1
    res$market_value <- res$market_value
    res$transaction_cost <- 0.005
    res$forecast_horizon <- 12
    res$total_return_fc <- 4*res$total_ret_fwd3m_fc
    res$excess_return_fc <- 4*res$excess_ret_fwd3m_fc 
    res$excess_return_mtd <- NA
    res$hedge_cost <- 0
    res$total_return_mtd_unhedged <- NA
    res$currency <- 'USD'
    
    stmt <- paste("DELETE FROM MODEL_FORECAST_SECURITY WHERE MODEL_ID =",ret$model_id[1]," and AS_OF='",format(res$as_of_date[1],'%d-%b-%Y'),"'",sep='')
    
    cat('deleting existing entries...\n')
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    sqlQuery(channel,query=stmt )
    odbcClose(channel)
    
    names(res) <- casefold(names(res),T)
    res <- res[,c('MODEL_ID','SECURITY_ID','AS_OF','SECTOR','ISSUER_TICKER',
        'CREDIT_RATING','INVESTABLE','MARKET_VALUE','TRANSACTION_COST',
        'FORECAST_HORIZON','TOTAL_RETURN_FC','EXCESS_RETURN_FC',
        'TOTAL_RETURN_MTD','EXCESS_RETURN_MTD','HEDGE_COST',
        'TOTAL_RETURN_MTD_UNHEDGED','CURRENCY')]
        
    export2db(data=res,server_type='SQL',server=db_info$Database,db=db_info$InitDB,table='MODEL_FORECAST_SECURITY',user=db_info$User,psw=db_info$Password,na='')
    invisible()
}

populate_aa_forecast_daily <- function(res)
{
	stmt <- paste("delete from AA_FORECAST2_DAILY where SECTOR='Muni' and VALUE_DATE='",format(res$as_of_date[1],'%d-%b-%Y'),"'",sep='')
	cat('deleting existing entries...\n')
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=Optimizer;uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    sqlQuery(channel,query=stmt )
    odbcClose(channel)
    
	####################################################
	year <- as.numeric(format(res$as_of_date[1],'%Y'))
	month <- as.numeric(format(res$as_of_date[1],'%m'))
	#200808 <-> 24104
	month_num <- 24104 + (year*12+month-2008*12-8)
	res <- data.frame(SECTOR='Muni',VALUE_DATE=res$as_of_date,MONTH_NUM=month_num,
		SECURITY_ID=as.character(res$identifier),TICKER=NA,INDEX_RATING=NA,
		INVESTABLE=1,MARKET_VALUE=res$market_value,TRD_CST=0.5,
		TOTAL_RET_ALL2=res$total_ret_fwd3m_fc*100/3,
		EX_RET_ALL2=res$excess_ret_fwd3m_fc*100/3,
		TOTAL_RETURN_1M=res$total_return_mtd,EXCESS_RETURN_1M=NA,HEDGE_COST=0,CURRENCY='USD',
		TOTAL_RETURN_1M_UNHEDGED=res$total_return_mtd,stringsAsFactors=F)
	export2db(data=res,server_type='SQL',server=db_info$Database,db='Optimizer',table='AA_FORECAST2_DAILY',user=db_info$User,psw=db_info$Password,na='')
    invisible()
}

populate_return_decomposition <- function(res)
{
	res = cbind(res,data.frame(index_oas = 0,state = 0,ab_code = 0,muni_taxability = 0,deminimis_buffer = 0))
	res <- res[,c('as_of_date','identifier','total_ret_fwd3m_fc','excess_ret_fwd3m_fc',
				  'Intercept','index_oas','credit_oad','state','ab_code','muni_taxability','deminimis_buffer','resi_oas')]
	names(res) <- c('AS_OF_DATE','IDENTIFIER','TOTAL_EXPECTED_RETURN_3M','EXCESS_EXPECTED_RETURN_3M',
		'INTERCEPT','INDEX_OAS_MOMENTUM','CREDIT_CURVE_REVERSION','STATE_OAS_REVERSION','SECTOR_OAS_REVERSION',
		'AMT_OAS_REVERSION','COUPON_EFFECT_REVERSION','RESIDUAL_OAS_REVERSION')
		
	stmt <- paste("delete from MUNI_EXPECTED_RETURN_DECOMPOSITION where AS_OF_DATE='",format(res$AS_OF_DATE[1],'%d-%b-%Y'),"'\n",sep='')
	cat('deleting existing entries...\n')
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    sqlQuery(channel,query=stmt )
    odbcClose(channel)
    export2db(data=res,server_type='SQL',server=db_info$Database,db=db_info$InitDB,table='MUNI_EXPECTED_RETURN_DECOMPOSITION',user=db_info$User,psw=db_info$Password,na='')
    invisible()
}

populate_oas_decomposition <- function(res)
{
	res <- res[,c('as_of_date','identifier','index_oas','credit_oad','state','ab_code','muni_taxability','deminimis_buffer','resi_oas')]
	names(res) <- c('AS_OF_DATE','IDENTIFIER','INDEX_OAS','CREDIT_CURVE','STATE','SECTOR','AMT','COUPON_EFFECT','RESI_OAS')
		
	stmt <- paste("delete from MUNI_OAS_DECOMPOSITION where AS_OF_DATE='",format(res$AS_OF_DATE[1],'%d-%b-%Y'),"'\n",sep='')
	cat('deleting existing entries...\n')
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    sqlQuery(channel,query=stmt )
    odbcClose(channel)
    export2db(data=res,server_type='SQL',server=db_info$Database,db=db_info$InitDB,table='MUNI_OAS_DECOMPOSITION',user=db_info$User,psw=db_info$Password,na='')
    invisible()
}


################################################################################
################################################################################
library('getopt')
opt = getopt(matrix(
    c(
    'db',   's', 2, "character",
    'as_of','d', 2, "character",
    'help', 'h', 0, "logical"
    ),ncol=4,byrow=TRUE)
)

if ( !is.null(opt$help) ) {
  self = 'Rscript load_data.R'
  cat(paste("
    Usage: ",self,"  [--as_of date] [--help]  
        db:   Database server to run the script on (PRD/QA/DEV).
        as_of:as_of date in yyyy-mm-dd format. default to last business day. Optional      
        help: Show help.  Optional
    Example: RScript load_data.R --db PRD --as_of 2012-02-15
  ",sep=""))
  q(status=1)
}

if ( is.null(opt$db) ) opt$db = 'QA'
if ( is.null(opt$as_of) ) { opt$as_of = Sys.Date()-1 }
as_of <- last.business.day( as.Date(opt$as_of) )
as_of = as.Date('2013-10-31')

required_dates = get_required_dates(as_of)
required_dates = required_dates[required_dates >= as.Date('2009-12-31')]
required_dates = required_dates[required_dates >= as.Date('2013-07-31')]

#port_id = '2200590000'

port_id = '2201923050'

###############################################################################
#source('H:/SVN/Muni/v1.0/Src/ExcessReturn/update_security_forecast.dev.R') # specific portfolio
setwd(paste(Sys.getenv('ABFI_DATA_REPOSITORY'),'\\Muni\\v1.0\\Output',sep='') )
library(RODBC)
db_info <- get_db_info(opt$db)
port_data = c();
grp1_hist = c();grp5_hist = c();
for(i in  1:length(required_dates))
{
	data <- load_security_data(required_dates[i],db_info)
	
	attrs <- get_factor_exposure(data,db_info,type='attr')
	
	data <- calc_security_exposure(data)
	
	data <- calc_security_return(data,required_dates[i],db_info)
	
	populate_oas_decomposition(attrs)
	populate_security_forecast(data)
	populate_return_decomposition(data)
	
	if(required_dates[i] >= as.Date('2013-08-30'))
	{
	q = paste("select distinct substring(SECURITY_ID,1,8),a.DESCRIPTION description,a.COUPON coupon,
				a.EFFECTIVE_MATURITY maturity from DAILYVIEW..POSITION_HISTORY p,
				Optimizer..MUNI_ANALYTICS a	where PORTFOLIO_ID = '",port_id,
				"' and BUSINESS_DATE = '",format(required_dates[i]),"' and SUBSTRING( p.SECURITY_ID,1,8) = a.IDENTIFIER
				and p.BUSINESS_DATE = a.EFFECTIVE_DATE",sep='')
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    port_secs <- sqlQuery(channel,query=q)
    odbcClose(channel)
    inxa = which(!is.na(match(port_secs[,1], data$identifier)))
    inxb = na.exclude(match(port_secs[,1], data$identifier))
    port_data = cbind(data[inxb,],port_secs[inxa,2:4])
    #port_data = cbind(data[inxb,],data.frame(description = port_secs[inxa,2]))
    #port_data = cbind(port_data,port_secs[inx,2])
    print(dim(port_data))
    port_data = port_data[order(port_data$identifier),]
    
    rank_ex <- rank(-port_data$excess_ret_fwd3m_fc)
	n <- length(rank_ex)
    #grp1_ex <- mean(pred_data$excess_ret_fwd3m[rank_ex<=10],na.rm=T)
    #grp5_ex <- mean(pred_data$excess_ret_fwd3m[rank_ex>(n-10)],na.rm=T)
    
    inx = rank_ex <= 10
    grp1tmp = data.frame(date = required_dates[i],cusip = port_data$identifier[inx],description = port_data$description[inx], 
				coupon = port_data$coupon[inx], maturity = port_data$maturity[inx],er_3m_fc = port_data$excess_ret_fwd3m_fc[inx],
				krd_fc = port_data$krd_ret_fwd3m_fc[inx],tr_3m_fc = port_data$total_ret_fwd3m_fc[inx],
				intercept = port_data$Intercept[1],credit_dur = port_data$credit_oad[inx],
	       		resi = port_data$resi_oas[inx])
	grp1tmp = grp1tmp[order(grp1tmp$cusip),]
    grp1_hist = rbind(grp1_hist,grp1tmp)
    
    inx = rank_ex > (n-10)
	grp5tmp = data.frame(date = required_dates[i],cusip = port_data$identifier[inx],description = port_data$description[inx],
				coupon = port_data$coupon[inx], maturity = port_data$maturity[inx],er_3m_fc = port_data$excess_ret_fwd3m_fc[inx],
				krd_fc = port_data$krd_ret_fwd3m_fc[inx],tr_3m_fc = port_data$total_ret_fwd3m_fc[inx],
				intercept = port_data$Intercept[1],credit_dur = port_data$credit_oad[inx],
	       		resi = port_data$resi_oas[inx])
	grp5tmp = grp5tmp[order(grp5tmp$cusip),]
    grp5_hist = rbind(grp5_hist,grp5tmp)
    
    #port_data = rbind(port_data,tmp_data)
	}
	
	cat(date(),'Done.\n')
}
#q(status=0)

# for(cdate in  required_dates)
# 
# data <- load_security_data(as_of,db_info)
# 
# attrs <- get_factor_exposure(data,db_info,type='attr')
# 
# data <- calc_security_exposure(data)
# 
# data <- calc_security_return(data,as_of,db_info)
# 
# populate_oas_decomposition(attrs)
# populate_security_forecast(data)
# populate_return_decomposition(data)
# 
# if(as_of>=business.month.end(as_of))	data$as_of_date <- month.end(as_of)
# 
# populate_aa_forecast_daily(data)
# 
# cat(date(),'Done.\n')

#source('H:/dev/Quant_Model-SQLServer/Muni/v1.0/Src/ExcessReturn/update_security_forecast.R')

