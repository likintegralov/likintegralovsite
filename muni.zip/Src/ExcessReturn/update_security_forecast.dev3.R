#!\\nts0018\bond\ABFI_PROD\QuantApps\R-2.14.2\bin\Rscript

source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.kal.R',sep='') )

calc_security_exposure <- function(data,gen = F)
{	
	if (gen)
	{	data <- get_factor_exposure_gen(data,db_info)
	}else data <- get_factor_exposure(data,db_info,type='resi',T)
	
	load('../Input/MuniParBondRet.RData')	
	# add return forecat for treasury portfolio to krd_ret_fwd3m_fc
	data = calc_returns(data,dur,yld_fixed)
	names(data)[names(data) == 'krd_ret_fwd3m_fc'] = 'carry'
	data = calc_returns(data,dur,roll)
	names(data)[names(data) == 'krd_ret_fwd3m_fc'] = 'roll'
	data = calc_returns(data,dur,term_tsy_fc)
	names(data)[names(data) == 'krd_ret_fwd3m_fc'] = 'term_tsy'
	data = calc_returns(data,dur,term_sprd_fc)
	names(data)[names(data) == 'krd_ret_fwd3m_fc'] = 'term_sprd'
	data <- calc_returns(data,dur,ret_fc)
	#return only needed fields
	#xvars <- c('index_oas','credit_oad','state','ab_code','muni_taxability','deminimis_buffer','resi_oas')
	if (!gen)
	{
		xvars <- c('credit_oad','resi_oas')
		data <- data[,c('as_of_date','identifier','muni_oad','muni_oas','market_value','total_return_mtd',xvars,
			'krd_ret_fwd3m_fc','carry','roll','term_tsy','term_sprd')]
		ix <- rowSums(is.na(data))==0 | ( rowSums(is.na(data))==1 & is.na(data$total_return_mtd) )
		data[ix,]
	}
	data
}

calc_security_return <- function(data,as_of,db_info,gen=F)
{
	factor_loading <- load_factor_loading(as_of,db_info)
	#use only credit/duration factor and residual
	if (!gen) {
		factor_loading = factor_loading[factor_loading$FACTOR_ID %in% c(1201,1203,1208),]
	}else factor_loading = factor_loading[factor_loading$FACTOR_ID %in% c(1201,1203),]
	
	var_map <- c(
		'Intercept','intercept',
		'index_oas','Index OAS',
		'credit_oad','Credit x OAD',
		'state', 'State',
		'ab_code','Sector',
		'muni_taxability','Taxability',
		'deminimis_buffer','Coupon Effect',
		'resi_oas','Residual OAS')
		
	stmt <- paste("
    	select MODEL_NAME,FACTOR_NAME,FACTOR_ID FROM 
        MODEL_DESCRIPTION a,MODEL_SPECIFICATION b
        WHERE a.MODEL_NAME = 'Muni Excess Return Model'
        AND b.MODEL_ID=a.MODEL_ID
        AND a.VERSION='1.0'
	",sep='')
	
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    id_map <- sqlQuery(channel,query=stmt)
    odbcClose(channel)
    
    idx <- match(id_map$FACTOR_NAME,var_map)
    id_map$xvar <- var_map[idx-1]
    
    factor_loading <- merge(factor_loading,id_map)
    
    data$Intercept <- 0
    #data[,factor_loading$xvar] <- data[,factor_loading$xvar] * data$muni_oad
	
    for( xvar in factor_loading$xvar )
    {
	    #if(xvar=='Intercept') data[,xvar] <- factor_loading$FACTOR_LOADING[factor_loading$xvar==xvar]
	    # excess carry (oas adjusted by reversion of residual oas) instead of intercept
	    if(gen & xvar=='Intercept') { data[,xvar] <- (data$muni_oas)/40000
		}else if(xvar=='Intercept') data[,xvar] <- (data$muni_oas - 0.1*data$resi_oas)/40000
	    
	    else{
		   f <- factor_loading[factor_loading$xvar==xvar,]
		   #remove capping here if necessary
		   # data[,xvar] <- winsorise(data[,xvar],lb.value=f$FACTOR_LB,ub.value=f$FACTOR_UB)
		   data[,xvar] <- f$FACTOR_LOADING*(data$muni_oad*data[,xvar]-f$FACTOR_MEAN)/f$FACTOR_STDEV
	    }
    }
    
    data$excess_ret_fwd3m_fc <- rowSums(data[,factor_loading$xvar])
    data$total_ret_fwd3m_fc <- data$excess_ret_fwd3m_fc + data$krd_ret_fwd3m_fc
    
    data
}

populate_security_forecast <- function(res)
{
    cat('populating model_forecast_security...\n')
    
    stmt <- paste("
        SELECT MODEL_ID
        FROM MODEL_DESCRIPTION
        WHERE MODEL_NAME = 'Muni Excess Return Model'
        AND VERSION='1.0'
        ",sep='')
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    ret <- sqlQuery(channel,query=stmt )
    odbcClose(channel)
    names(ret) <- casefold(names(ret),F)
        
    res$model_id <- ret$model_id[1]
    
    res$security_id <- res$identifier
    res$as_of <- res$as_of_date
    res$sector <- 'Muni'
    res$issuer_ticker <- NA
    res$credit_rating <- NA
    res$investable <- 1
    res$market_value <- res$market_value
    res$transaction_cost <- 0.005
    res$forecast_horizon <- 12
    res$total_return_fc <- 4*res$total_ret_fwd3m_fc
    res$excess_return_fc <- 4*res$excess_ret_fwd3m_fc 
    res$excess_return_mtd <- NA
    res$hedge_cost <- 0
    res$total_return_mtd_unhedged <- NA
    res$currency <- 'USD'
    
    stmt <- paste("DELETE FROM MODEL_FORECAST_SECURITY WHERE MODEL_ID =",ret$model_id[1]," and AS_OF='",format(res$as_of_date[1],'%d-%b-%Y'),"'",sep='')
    
    cat('deleting existing entries...\n')
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    sqlQuery(channel,query=stmt )
    odbcClose(channel)
    
    names(res) <- casefold(names(res),T)
    res <- res[,c('MODEL_ID','SECURITY_ID','AS_OF','SECTOR','ISSUER_TICKER',
        'CREDIT_RATING','INVESTABLE','MARKET_VALUE','TRANSACTION_COST',
        'FORECAST_HORIZON','TOTAL_RETURN_FC','EXCESS_RETURN_FC',
        'TOTAL_RETURN_MTD','EXCESS_RETURN_MTD','HEDGE_COST',
        'TOTAL_RETURN_MTD_UNHEDGED','CURRENCY')]
        
    export2db(data=res,server_type='SQL',server=db_info$Database,db=db_info$InitDB,table='MODEL_FORECAST_SECURITY',user=db_info$User,psw=db_info$Password,na='')
    invisible()
}

populate_aa_forecast_daily <- function(res)
{
	stmt <- paste("delete from AA_FORECAST10_DAILY where SECTOR='Muni' and VALUE_DATE='",format(res$as_of_date[1],'%d-%b-%Y'),"'",sep='')
	cat('deleting existing entries...\n')
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=Optimizer;uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    sqlQuery(channel,query=stmt )
    odbcClose(channel)
    
	####################################################
	year <- as.numeric(format(res$as_of_date[1],'%Y'))
	month <- as.numeric(format(res$as_of_date[1],'%m'))
	#200808 <-> 24104
	month_num <- 24104 + (year*12+month-2008*12-8)
	res <- data.frame(SECTOR='Muni',VALUE_DATE=res$as_of_date,MONTH_NUM=month_num,
		SECURITY_ID=as.character(res$identifier),TICKER=NA,INDEX_RATING=NA,
		INVESTABLE=1,MARKET_VALUE=res$market_value,TRD_CST=0.5,
		TOTAL_RET_ALL2=res$total_ret_fwd3m_fc*100/3,
		EX_RET_ALL2=res$excess_ret_fwd3m_fc*100/3,
		TOTAL_RETURN_1M=res$total_return_mtd,EXCESS_RETURN_1M=NA,HEDGE_COST=0,CURRENCY='USD',
		TOTAL_RETURN_1M_UNHEDGED=res$total_return_mtd,stringsAsFactors=F)
	export2db(data=res,server_type='SQL',server=db_info$Database,db='Optimizer',table='AA_FORECAST10_DAILY',user=db_info$User,psw=db_info$Password,na='')
    invisible()
}

populate_return_decomposition <- function(res,gen=F)
{
	# populate unused factors with zeros
	res = cbind(res,data.frame(index_oas = 0,state = 0,ab_code = 0,muni_taxability = 0,deminimis_buffer = 0))
	res <- res[,c('as_of_date','identifier','total_ret_fwd3m_fc','excess_ret_fwd3m_fc',
				  'Intercept','index_oas','credit_oad','state','ab_code','muni_taxability','deminimis_buffer','resi_oas','carry','roll','term_tsy','term_sprd')]
	names(res) <- c('AS_OF_DATE','IDENTIFIER','TOTAL_EXPECTED_RETURN_3M','EXCESS_EXPECTED_RETURN_3M',
		'INTERCEPT','INDEX_OAS_MOMENTUM','CREDIT_CURVE_REVERSION','STATE_OAS_REVERSION','SECTOR_OAS_REVERSION',
		'AMT_OAS_REVERSION','COUPON_EFFECT_REVERSION','RESIDUAL_OAS_REVERSION','AAA_CARRY','AAA_ROLL','TSY_TERM','AAA_SPREAD_TERM')
	
	if(!gen) {		
	stmt <- paste("delete from MUNI_EXPECTED_RETURN_DECOMPOSITION where AS_OF_DATE='",format(res$AS_OF_DATE[1],'%d-%b-%Y'),"'\n",sep='')
	}else stmt = paste("delete from MUNI_EXPECTED_RETURN_DECOMPOSITION where AS_OF_DATE='",format(res$AS_OF_DATE[1],'%d-%b-%Y'),
				"'	and IDENTIFIER in ('",paste(res$IDENTIFIER,collapse="','"),"')\n",sep='')
					
	cat('deleting existing entries...\n')
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    sqlQuery(channel,query=stmt )
    odbcClose(channel)
    export2db(data=res,server_type='SQL',server=db_info$Database,db=db_info$InitDB,table='MUNI_EXPECTED_RETURN_DECOMPOSITION',user=db_info$User,psw=db_info$Password,na='')
    invisible()
}

populate_oas_decomposition <- function(res)
{
	# zero out unused factors for pre-refs
	res[res$ab_sector_code == 333,c('ab_code','muni_taxability','extension_risk','ce_bucket','cal_impact')] = 0
	
	res <- res[,c('as_of_date','identifier','index_oas','credit_oad','state','ab_code','muni_taxability','deminimis_buffer','resi_oas','extension_risk',
					'zero_coupon','ce_bucket','sp','cal_impact','issuer')]
	names(res) <- c('AS_OF_DATE','IDENTIFIER','INDEX_OAS','CREDIT_CURVE','STATE','SECTOR','AMT','COUPON_EFFECT',
					'RESI_OAS','EXTENSION_RISK','ZERO_COUPON','CREDIT_ENHANCEMENT','MODEL_RATING','CAL_EFFECT','ISSUER')
		
	stmt <- paste("delete from MUNI_OAS_DECOMPOSITION where AS_OF_DATE='",format(res$AS_OF_DATE[1],'%d-%b-%Y'),"'\n",sep='')
	cat('deleting existing entries...\n')
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    sqlQuery(channel,query=stmt )
    odbcClose(channel)
    export2db(data=res,server_type='SQL',server=db_info$Database,db=db_info$InitDB,table='MUNI_OAS_DECOMPOSITION',user=db_info$User,psw=db_info$Password,na='')
    invisible()
}

load_security_data_a <- function(as_of,db_info,init = F,cetags = F,ronly = F)
{
	data <- rbind(load_data(as_of,db_info,'IndexBval',init,cetags,ronly),load_data(as_of,db_info,'ABBval',init,cetags,ronly))
	
	#AB data take priority over Barcap, if same cusip appear more than once
	ix <- data$source=='ABBval'
	jx <- data$source=='IndexBval'
	kx <- jx & data$identifier %in% data$identifier[ix]
	data <- data[ix | (jx & !kx), ]
	
	data
}

################################################################################
################################################################################
library('getopt')
opt = getopt(matrix(
    c(
    'db',   's', 2, "character",
    'as_of','d', 2, "character",
    'help', 'h', 0, "logical",
    'gen',	'g', 0, "logical"
    ),ncol=4,byrow=TRUE)
)

if ( !is.null(opt$help) ) {
  self = 'Rscript load_data.R'
  cat(paste("
    Usage: ",self,"  [--as_of date] [--help]  
        db:   Database server to run the script on (PRD/QA/DEV).
        as_of:as_of date in yyyy-mm-dd format. default to last business day. Optional      
        help: Show help.  Optional
    Example: RScript load_data.R --db PRD --as_of 2012-02-15
  ",sep=""))
  q(status=1)
}

if ( is.null(opt$db) ) opt$db = 'QA'
if ( is.null(opt$as_of) ) { opt$as_of = Sys.Date()-1 }

as_of = as.Date(opt$as_of)
as_of = as.Date('2018-11-30')
#opt$gen = T
if(as_of >= as.Date('2013-01-01'))
	as_of <- last.business.day(as_of)

###############################################################################
#source('H:/SVN/Muni/v1.0/Src/ExcessReturn/update_security_forecast.dev3.R') data from different source
#source('C:/SVN/Quant_Model-SQLServer/Muni/v1.0/Src/ExcessReturn/update_security_forecast.kal.R')
setwd(paste(Sys.getenv('ABFI_DATA_REPOSITORY'),'\\Muni\\v1.0\\Output',sep='') )
library(RODBC)
db_info <- get_db_info(opt$db)

if(is.null(opt$gen))
{	
	data <- load_security_data_a(as_of,db_info)

	
#clean data
	data = data[!is.na(data$muni_oas),]
	data$ab_sector_code = data$ab_code

	attrs <- get_factor_exposure(data,db_info,type='attr',T)
	
	#add alphabetic ratings to attrs
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
	crat_map <- sqlQuery(channel,query='select * from FIQModel.dbo.BOND_CREDIT_RATING')
	names(crat_map)<-tolower(names(crat_map))
	odbcClose(channel)

	attrs$credit_rating = round(attrs$credit_rating)
	attrs = merge(attrs,crat_map[,c('id','sp')],by.x = 'credit_rating',by.y = 'id',all.x = T)

	data <- calc_security_exposure(data)

	data <- calc_security_return(data,as_of,db_info)
	data = data[!is.na(data$total_ret_fwd3m_fc),]

	populate_oas_decomposition(attrs)
	populate_security_forecast(data)
	populate_return_decomposition(data)

	if(as_of>=business.month.end(as_of))	data$as_of_date <- month.end(as_of)

	populate_aa_forecast_daily(data)

}else 
{
	data <- load_gen_data(as_of,db_info)
	data <- calc_security_exposure(data,T)
	data$resi_oas = 0
	data <- calc_security_return(data,as_of,db_info,T)
	populate_return_decomposition(data,T)
}
	
cat(date(),'Done.\n')
q(status=0)

#source('C:/SVN/Quant_Model-SQLServer/Muni/v1.0/Src/ExcessReturn/update_security_forecast.R')

