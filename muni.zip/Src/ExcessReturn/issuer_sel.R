#!\\nts0018\bond\ABFI_PROD\QuantApps\R-2.14.2\bin\x64\Rscript

source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.kal.R',sep='') )


#source("H:\\SVN\\Muni\\v1.0\\Src\\ExcessReturn\\issuer_sel.R")

library(RODBC)
setwd(paste(Sys.getenv('ABFI_DATA_REPOSITORY'),'\\Muni\\v1.0\\Output',sep='') )


db = get_db_info('PRD')

q = "select d.AS_OF_DATE Date, a.DESCRIPTION descrip, sum(d.RESI_OAS)/count(d.RESI_OAS) resi_oas, sum(a.AMT_OUTSTANDING) amt_out, count(*) cnt
		from FIQModel..MUNI_OAS_DECOMPOSITION d, Optimizer..MUNI_ANALYTICS_KALOTAY a
		where a.EFFECTIVE_DATE = d.AS_OF_DATE
		and SOURCE = 'Index'
		and a.IDENTIFIER = d.IDENTIFIER
		and a.DESCRIPTION is not null
		group by d.AS_OF_DATE,a.DESCRIPTION
		order by 1,4 desc"
		
	#	and a.PURPOSE_TYPE <> 'Muni PRE'
channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db$Database,';DataBase=',db$InitDB,';uid=',db$User,';pwd=',db$Password,sep=''))
idata <- sqlQuery(channel,query=q)
odbcClose(channel)
idata$Date = as.Date(idata$Date)
dates = sort(unique(idata$Date))

tidata = data.frame()
for(i in 1:length(dates))
{
	tm = idata[idata$Date == dates[i],]
	#tm = tm[order(tm$amt_out),]
	tidata = rbind(tidata,tm[1:100,])
}

 write.csv(tidata,'tmp.csv')