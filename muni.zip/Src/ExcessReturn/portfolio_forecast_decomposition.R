#!\\nts0018\bond\ABFI_PROD\QuantApps\R-2.14.2\bin\Rscript

source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.R',sep='') )

setwd(paste(Sys.getenv('ABFI_DATA_REPOSITORY'),'\\Muni\\v1.0\\Input',sep='') )

load_security_data <- function(as_of,db_info)
{
	data <- rbind(load_data(as_of,db_info,'Barcap'),load_data(as_of,db_info,'AB'))
	
	#AB data take priority over Barcap, if same cusip appear more than once
	ix <- data$source=='AB'
	jx <- data$source=='Barcap'
	kx <- jx & data$identifier %in% data$identifier[ix]
	data <- data[ix | (jx & !kx), ]
	
	data
}

################################################################################
################################################################################
library('getopt')
opt = getopt(matrix(
    c(
    'db',   's', 2, "character",
    'as_of','d', 2, "character",
    'port',	'p', 2, "character",
    'repo', 'r', 2, "character",
    'help', 'h', 0, "logical"
    ),ncol=4,byrow=TRUE)
)

if ( !is.null(opt$help))# || is.null(opt$port)) 
{
  self = 'Rscript load_data.R'
  cat(paste("
    Usage: ",self,"  [--as_of date] [--help]  
        db:   Database server to run the script on (PRD/QA/DEV).
        as_of:as_of date in yyyy-mm-dd format. default to last business day. Optional
        port:	File with portfolio IDs. Optional      
        repo:	Location to save reports
        help: Show help.  Optional
    Example: RScript load_data.R --db PRD --as_of 2012-02-15
  ",sep=""))
  q(status=1)
}


if ( is.null(opt$db) ) opt$db = 'QA'
if ( is.null(opt$as_of) ) { opt$as_of = Sys.Date()-1 }
as_of <- last.business.day( as.Date(opt$as_of) )
#as_of = as.Date('2017-02-17')

load('MuniParBondRet.RData')

#port_name = opt$port
#port_name = 'AMINAP'
#port_name = 'BDMP'
#port_name = '03910060'
#port_name = 'BNYMP'
#port_name = 'BCMP'

#pnames = c('AMINAP','BDMP','03910060','BNYMP','BCMP')
#pnames = c('03910060')
opt$port = 'C:\\ABFI_PROD\\Quant_Data_Repo\\Muni\\v1.0\\Input\\portfolios.csv'
if(!is.null(opt$port))
{
	pnames = read.table(opt$port,colClasses = 'character')
	pnames = pnames$V1
}
 

#port_name = '03704501'
#port_name = '03973289'

###############################################################################
#source('H:/SVN/Muni/v1.0/Src/ExcessReturn/portfolio_forecast_decomposition.R') 
#source(C:/SVN/Quant_Model-SQLServer/Muni/v1.0/Src/ExcessReturn/portfolio_forecast_decomposition.R') 
setwd(paste(Sys.getenv('ABFI_DATA_REPOSITORY'),'\\Muni\\v1.0\\Output',sep='') )
library(RODBC)
#library(TTR)
db_info <- get_db_info(opt$db)
db_prd <- get_db_info('PRD')

#load oas decomposition history
channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
	
dates <- load_muni_analytics_dates(as.Date(as_of),db_info,src='Barcap')
dates = dates[dates >= as_of - 740]
q = paste("select * from FIQModel..MUNI_OAS_DECOMPOSITION where AS_OF_DATE in ('",paste(dates,collapse = "','"),"') ",
		  "order by AS_OF_DATE",sep = '')
oas_hist = sqlQuery(channel,query=q)
names(oas_hist)<-tolower(names(oas_hist))
odbcClose(channel)

for(port_name in pnames)
{
	q = paste("select ACCOUNT_ID, SHORT_NAME, ALTERNATE_IDENTIFIER ALT_ID, LONG_NAME from DAILYVIEW..ACCTS_PORTFOLIOS
			where SHORT_NAME = '",port_name,"'",sep='')

	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))

	port_info <- sqlQuery(channel,query=q,as.is = T)		

	channel_prd <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_prd$Database,';DataBase=',db_prd$InitDB,';uid=',db_prd$User,';pwd=',db_prd$Password,sep=''))
		
	for(i in 1:dim(port_info)[1])
	{
		port_long_name = port_info$LONG_NAME[i]
		port_id = port_info$ACCOUNT_ID[i]
		muni_id = port_info$ALT_ID[i]		
		
		if(is.na(muni_id)) { muni_id = port_id}
	
		q = paste("select distinct substring(SECURITY_ID,1,8),a.DESCRIPTION description,a.COUPON coupon,a.PRICE,",
					"a.MATURITY_DATE maturity,a.MUNI_OAD_RISK dur, s.AB_SECTOR sector,p.PAR, a.MUNI_OAS_RISK oas,a.MUNI_6MO_KRD,",
					"a.MUNI_2YR_KRD,a.MUNI_5YR_KRD,a.MUNI_10YR_KRD,a.MUNI_20YR_KRD,a.MUNI_30YR_KRD ",
					"from DAILYVIEW..POSITION_HISTORY p,FIQModel..MUNI_SECTOR_CODE sc, FIQModel..MUNI_SECTOR s,  
					Optimizer..MUNI_ANALYTICS a	 where PORTFOLIO_ID = '",port_id,
					"' and BUSINESS_DATE = '",format(as_of),"' and SUBSTRING( p.SECURITY_ID,1,8) = a.IDENTIFIER
					and p.BUSINESS_DATE = a.EFFECTIVE_DATE
					and a.IDENTIFIER = sc.IDENTIFIER
					and sc.AB_CODE = s.AB_CODE",sep='')
	
		port_secs <- sqlQuery(channel_prd,query=q)
		names(port_secs)<-tolower(names(port_secs))
		
		if(dim(port_secs)[1] > 0) break
	}
	odbcClose(channel_prd)

	gsize = 25
	
	
	q = paste("select er.*, oas.INDEX_OAS,oas.CREDIT_CURVE,oas.STATE,oas.SECTOR sector_oas,oas.COUPON_EFFECT,oas.EXTENSION_RISK,oas.RESI_OAS ",
			"from FIQModel..MUNI_EXPECTED_RETURN_DECOMPOSITION er, ",
			"FIQModel..MUNI_OAS_DECOMPOSITION oas ",
			"where er.AS_OF_DATE = '",format(as_of),"' and er.AS_OF_DATE = oas.AS_OF_DATE ",
			"and er.IDENTIFIER = oas.IDENTIFIER",sep='')

	ret_decomp <- sqlQuery(channel,query=q)
				  
	#odbcClose(channel)				

	#channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_prd$Database,';DataBase=',db_prd$InitDB,';uid=',db_prd$User,';pwd=',db_prd$Password,sep=''))

	q = paste("select VALUE_DATE as_of, SECURITY_ID security, UNREALIZED_GAIN_LOSS_PCT unrealized_gainloss,YIELD yield, 
			INTERNAL_RATING rating, NEXT_CALL_DATE calldate, MOODY_RATING rating_m, SP_RATING rating_sp, FITCH_RATING rating_f from Optimizer..MUNI_POSITION 
			where VALUE_DATE = '",format(as_of),"' and ACCOUNT = '",muni_id,"'",sep='')
	unreal_gl <- sqlQuery(channel,query=q)

	odbcClose(channel)				

	cat(paste("muni position available for ",dim(unreal_gl)[1]," securities\n",sep=''))

	minx = which(is.na(unreal_gl$rating))
	for(i in 1:length(minx))
	{
		if(!is.na(unreal_gl$rating_sp[minx[i]]) & unreal_gl$rating_sp[minx[i]] != 'NR')
		{
			unreal_gl$rating[minx[i]] = unreal_gl$rating_sp[minx[i]]
		}else if(!is.na(unreal_gl$rating_f[minx[i]]) & unreal_gl$rating_f[minx[i]] != 'NR')
		{
			unreal_gl$rating[minx[i]] = unreal_gl$rating_f[minx[i]]		
		}
	}

	names(ret_decomp) = casefold(names(ret_decomp),upper=F)

	inxa = which(!is.na(match(port_secs[,1], unreal_gl$security)))
	inxb = na.exclude(match(port_secs[,1], unreal_gl$security))
	port_secs = cbind(port_secs[inxa,],unreal_gl[inxb,c('unrealized_gainloss','rating','yield','calldate')])
	names(port_secs)[names(port_secs) == 'unrealized_gainloss'] = 'gain_loss'

	inxa = which(!is.na(match(port_secs[,1], ret_decomp$identifier)))
	inxb = na.exclude(match(port_secs[,1], ret_decomp$identifier))
	port_data = cbind(port_secs[inxa,],ret_decomp[inxb,c('excess_expected_return_3m','intercept','credit_curve_reversion','residual_oas_reversion',
															'index_oas','credit_curve','state','sector_oas','coupon_effect','extension_risk','resi_oas')])
	
	#add residual oas 
	inxb = na.exclude(match(port_secs[,1], oas_hist$identifier))
	oas_port_hist = oas_hist[oas_hist$identifier %in% port_secs[,1],]
	oas_port_hist = oas_port_hist[!is.na(oas_port_hist$resi_oas),]
	oas_port_hist = add_resi_mean(oas_port_hist,24)
	oas_port_hist = oas_port_hist[as.Date(oas_port_hist$as_of_date) == as_of,]
	
	inxa = which(!is.na(match(oas_port_hist$identifier, port_data[,1])))
	inxb = na.exclude(match(oas_port_hist$identifier, port_data[,1]))
	port_data$resi_mean[inxb] = oas_port_hist[inxa,'resi_mean']
	port_data$resi_sdev[inxb] = oas_port_hist[inxa,'resi_sdev']
	port_data$resi_z = (port_data$resi_oas - port_data$resi_mean)/port_data$resi_sdev
	
	names(port_data)[1] = 'security'
	names(port_data)[names(port_data) == 'excess_expected_return_3m'] = 'er_fc_3m'
	names(port_data)[names(port_data) == 'credit_curve_reversion'] = 'credit_duration'
	names(port_data)[names(port_data) == 'residual_oas_reversion'] = 'residual'
	port_data$as_of_date = as_of

port_data = calc_returns(port_data,dur,yld_fixed)
names(port_data)[names(port_data) == 'krd_ret_fwd3m_fc'] = 'carry'
port_data = calc_returns(port_data,dur,roll)
names(port_data)[names(port_data) == 'krd_ret_fwd3m_fc'] = 'roll'
port_data = calc_returns(port_data,dur,term_fc)
names(port_data)[names(port_data) == 'krd_ret_fwd3m_fc'] = 'term'
port_data = calc_returns(port_data,dur,conv)
names(port_data)[names(port_data) == 'krd_ret_fwd3m_fc'] = 'convexity'
port_data = calc_returns(port_data,dur,ret_fc)

port_data$tr_3m_fc = port_data$krd_ret_fwd3m_fc + port_data$er_fc_3m

allmunis = load_security_data(as_of,db_prd)

inxb = na.exclude(match(port_data[,1], allmunis$identifier))
portmunis = allmunis[inxb,]

portmunis = get_factor_exposure(portmunis,db_prd,'residual',T)
port_data = cbind(port_data,data.frame(credit_oad = portmunis$credit_oad))
port_data$credit_oad = port_data$credit_curve - port_data$credit_oad

port_data = port_data[order(port_data$security),]
# clean up blanks in credit labels

port_data$rating = gsub(" ","",as.character(port_data$rating))

#exlude defaults
inx = port_data$rating != 'D'
inx[is.na(inx)] = TRUE
port_data = port_data[inx,]

cat(paste("forecast available for ",dim(port_data)[1]," securities\n",sep=''))

rank_ex <- rank(-port_data$er_fc_3m)
n <- length(rank_ex)
#all portfolio holdings
port_out = data.frame(date = as_of,cusip = port_data$security,description = port_data$description,rating = port_data$rating, 
			coupon = port_data$coupon, maturity = port_data$maturity,Par = port_data$par,Price = port_data$price,OAS = format(port_data$oas,digits = 1),yield = port_data$yield,Duration = port_data$dur,
			calldate = port_data$calldate,sector = port_data$sector,unrealized_gainloss = port_data$gain_loss,
			er_3m_fc = port_data$er_fc_3m,intercept = port_data$intercept,credit_dur = port_data$credit_duration,
       		Mispricing = port_data$residual,tr_3m_fc = port_data$tr_3m_fc,Carry = port_data$carry,Roll = port_data$roll,
       		Term = port_data$term,Convexity = port_data$convexity,credit_curve = port_data$credit_curve,credit_oad = port_data$credit_oad,
       		state_oas = port_data$state,sector_oas = port_data$sector_oas,coupon_effect = port_data$coupon_effect,
       		extension_risk = port_data$extension_risk,resi_oas = port_data$resi_oas,resi_mean = port_data$resi_mean,
       		resi_sdev = port_data$resi_sdev,resi_z = port_data$resi_z)
port_out[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')] = 
	round(port_out[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')]*400,digits = 2)
port_out[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','resi_oas','credit_oad','resi_mean','resi_sdev')] = 
	round(port_out[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','resi_oas','credit_oad','resi_mean','resi_sdev')])
	port_out[,c('yield','unrealized_gainloss','Price','resi_z')] = round(port_out[,c('yield','unrealized_gainloss','Price','resi_z')],digits = 2)	       		
port_out = port_out[order(port_out$er_3m_fc,decreasing = T),]

#richest/cheapest holdings
inx = rank_ex <= max(gsize,min(rank_ex))
grp1tmp = data.frame(date = as_of,cusip = port_data$security[inx],description = port_data$description[inx],rating = port_data$rating[inx], 
			coupon = port_data$coupon[inx], maturity = port_data$maturity[inx],Par = port_data$par[inx],Price = port_data$price[inx],OAS = format(port_data$oas[inx],digits = 1),yield = port_data$yield[inx],Duration = port_data$dur[inx],
			calldate = port_data$calldate[inx],sector = port_data$sector[inx],unrealized_gainloss = port_data$gain_loss[inx],
			er_3m_fc = port_data$er_fc_3m[inx],intercept = port_data$intercept[inx],credit_dur = port_data$credit_duration[inx],
       		Mispricing = port_data$residual[inx],tr_3m_fc = port_data$tr_3m_fc[inx],Carry = port_data$carry[inx],Roll = port_data$roll[inx],
       		Term = port_data$term[inx],Convexity = port_data$convexity[inx],credit_curve = port_data$credit_curve[inx],credit_oad = port_data$credit_oad[inx],
       		state_oas = port_data$state[inx],sector_oas = port_data$sector_oas[inx],coupon_effect = port_data$coupon_effect[inx],
       		extension_risk = port_data$extension_risk[inx],resi_oas = port_data$resi_oas[inx],resi_mean = port_data$resi_mean[inx],
       		resi_sdev = port_data$resi_sdev[inx],resi_z = port_data$resi_z[inx])
grp1tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')] = 
	round(grp1tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')]*400,digits = 2)
grp1tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','resi_oas','credit_oad','resi_mean','resi_sdev')] = 
	round(grp1tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','resi_oas','credit_oad','resi_mean','resi_sdev')])
	grp1tmp[,c('yield','unrealized_gainloss','Price','resi_z')] = round(grp1tmp[,c('yield','unrealized_gainloss','Price','resi_z')],digits = 2)	       		
grp1tmp = grp1tmp[order(grp1tmp$er_3m_fc,decreasing = T),]
		
inx = rank_ex > min((n-gsize),max(rank_ex))
grp5tmp = data.frame(date = as_of,cusip = port_data$security[inx],description = port_data$description[inx],rating = port_data$rating[inx], 
			coupon = port_data$coupon[inx], maturity = port_data$maturity[inx],Par = port_data$par[inx],Price = port_data$price[inx],OAS = format(port_data$oas[inx],digits = 1),yield = port_data$yield[inx],Duration = port_data$dur[inx],
			calldate = port_data$calldate[inx],sector = port_data$sector[inx],unrealized_gainloss = port_data$gain_loss[inx],
			er_3m_fc = port_data$er_fc_3m[inx],intercept = port_data$intercept[inx],credit_dur = port_data$credit_duration[inx],
       		Mispricing = port_data$residual[inx],tr_3m_fc = port_data$tr_3m_fc[inx],Carry = port_data$carry[inx],Roll = port_data$roll[inx],
       		Term = port_data$term[inx],Convexity = port_data$convexity[inx],credit_curve = port_data$credit_curve[inx],credit_oad = port_data$credit_oad[inx],
       		state_oas = port_data$state[inx],sector_oas = port_data$sector_oas[inx],coupon_effect = port_data$coupon_effect[inx],
       		extension_risk = port_data$extension_risk[inx],resi_oas = port_data$resi_oas[inx],resi_mean = port_data$resi_mean[inx],
       		resi_sdev = port_data$resi_sdev[inx],resi_z = port_data$resi_z[inx])

grp5tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')] = 
	round(grp5tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')]*400,digits = 2)  
grp5tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','resi_oas','credit_oad','resi_mean','resi_sdev')] = 
	round(grp5tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','resi_oas','credit_oad','resi_mean','resi_sdev')])	
	grp5tmp[,c('yield','unrealized_gainloss','Price','resi_z')] = round(grp5tmp[,c('yield','unrealized_gainloss','Price','resi_z')],digits = 2)	
		
grp5tmp = grp5tmp[order(grp5tmp$er_3m_fc),]

rsize = 5
ratings = c('AAA','AA','A','BBB','BB','B','CCC','CC')
rgood = c(0,0,0,0,0,0,0,0)

for(i in 1:length(ratings))
{
	work_data = port_data[which(port_data$rating == ratings[i] | port_data$rating == paste(ratings[i],"-",sep = '')
						 | port_data$rating == paste(ratings[i],"+",sep = '')),]

	if(dim(work_data)[1] >= 2*rsize)
	{
		rgood[i] = 1
		rank_ex <- rank(-work_data$er_fc_3m,ties.method = 'min')
		n <- length(rank_ex)
		inx = rank_ex <= max(rsize,min(rank_ex))
		
		tmp1 = data.frame(date = as_of,cusip = work_data$security[inx],description = work_data$description[inx],rating = work_data$rating[inx], 
				coupon = work_data$coupon[inx], maturity = work_data$maturity[inx],Par = work_data$par[inx],Price = work_data$price[inx],OAS = format(work_data$oas[inx],digits = 1),
				yield = work_data$yield[inx],Duration = work_data$dur[inx],
				calldate = work_data$calldate[inx],sector = work_data$sector[inx],unrealized_gainloss = work_data$gain_loss[inx],
				er_3m_fc = work_data$er_fc_3m[inx],intercept = work_data$intercept[inx],credit_dur = work_data$credit_duration[inx],
	       		Mispricing = work_data$residual[inx],tr_3m_fc = work_data$tr_3m_fc[inx],Carry = work_data$carry[inx],Roll = work_data$roll[inx],
       			Term = work_data$term[inx],Convexity = work_data$convexity[inx],credit_curve = work_data$credit_curve[inx],credit_oad = work_data$credit_oad[inx],
       			state_oas = work_data$state[inx],sector_oas = work_data$sector_oas[inx],coupon_effect = work_data$coupon_effect[inx],
       			extension_risk = work_data$extension_risk[inx],resi_oas = work_data$resi_oas[inx],resi_mean = work_data$resi_mean[inx],
       			resi_sdev = work_data$resi_sdev[inx],resi_z = work_data$resi_z[inx])
    	tmp1[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')] = 
				round(tmp1[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')]*400,digits = 2)    
		tmp1[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','resi_oas','credit_oad','resi_mean','resi_sdev')] = 
				round(tmp1[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','resi_oas','credit_oad','resi_mean','resi_sdev')])	 	
		tmp1[,c('yield','unrealized_gainloss','Price','resi_z')] = round(tmp1[,c('yield','unrealized_gainloss','Price','resi_z')],digits = 2)	
		tmp1 = tmp1[order(tmp1$er_3m_fc,decreasing = T),]
	
		assign(paste(tolower(ratings[i]),"1tmp",sep = ''),tmp1)
	
		rank_ex <- rank(-work_data$er_fc_3m,ties.method = 'max')
		inx = rank_ex > min((n-rsize),max(rank_ex))
		tmp5 = data.frame(date = as_of,cusip = work_data$security[inx],description = work_data$description[inx],rating = work_data$rating[inx], 
				coupon = work_data$coupon[inx], maturity = work_data$maturity[inx],Par = work_data$par[inx],Price = work_data$price[inx],OAS = format(work_data$oas[inx],digits = 1),
				yield = work_data$yield[inx],Duration = work_data$dur[inx],
				calldate = work_data$calldate[inx],sector = work_data$sector[inx],unrealized_gainloss = work_data$gain_loss[inx],
				er_3m_fc = work_data$er_fc_3m[inx],intercept = work_data$intercept[inx],credit_dur = work_data$credit_duration[inx],
	       		Mispricing = work_data$residual[inx],tr_3m_fc = work_data$tr_3m_fc[inx],Carry = work_data$carry[inx],Roll = work_data$roll[inx],
       			Term = work_data$term[inx],Convexity = work_data$convexity[inx],credit_curve = work_data$credit_curve[inx],credit_oad = work_data$credit_oad[inx],
       			state_oas = work_data$state[inx],sector_oas = work_data$sector_oas[inx],coupon_effect = work_data$coupon_effect[inx],
       			extension_risk = work_data$extension_risk[inx],resi_oas = work_data$resi_oas[inx],resi_mean = work_data$resi_mean[inx],
       			resi_sdev = work_data$resi_sdev[inx],resi_z = work_data$resi_z[inx])
    	tmp5[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')] = 
				round(tmp5[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')]*400,digits = 2)     		
		tmp5[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','resi_oas','credit_oad','resi_mean','resi_sdev')] = 
				round(tmp5[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','resi_oas','credit_oad','resi_mean','resi_sdev')])	
		tmp5[,c('yield','unrealized_gainloss','Price','resi_z')] = round(tmp5[,c('yield','unrealized_gainloss','Price','resi_z')],digits = 2)
		tmp5 = tmp5[order(tmp5$er_3m_fc),]

		assign(paste(tolower(ratings[i]),"5tmp",sep = ''),tmp5)
	}
}


names(grp1tmp)[names(grp1tmp) == 'yield'] = "Yield"
names(grp5tmp)[names(grp5tmp) == 'yield'] = "Yield"
names(port_out)[names(port_out) == 'yield'] = "Yield"

names(grp1tmp)[names(grp1tmp) == 'calldate'] = "Call date"
names(grp5tmp)[names(grp5tmp) == 'calldate'] = "Call date"
names(port_out)[names(port_out) == 'calldate'] = "Call date"

names(grp1tmp)[names(grp1tmp) == 'sector'] = "Sector"
names(grp5tmp)[names(grp5tmp) == 'sector'] = "Sector"
names(port_out)[names(port_out) == 'sector'] = "Sector"

names(grp1tmp)[names(grp1tmp) == 'cusip'] = "Security"
names(grp5tmp)[names(grp5tmp) == 'cusip'] = "Security"
names(port_out)[names(port_out) == 'cusip'] = "Security"

names(grp1tmp)[names(grp1tmp) == 'description'] = "Description"
names(grp5tmp)[names(grp5tmp) == 'description'] = "Description"
names(port_out)[names(port_out) == 'description'] = "Description"

names(grp1tmp)[names(grp1tmp) == 'rating'] = "Rating"
names(grp5tmp)[names(grp5tmp) == 'rating'] = "Rating"
names(port_out)[names(port_out) == 'rating'] = "Rating"

names(grp1tmp)[names(grp1tmp) == 'coupon'] = "Coupon"
names(grp5tmp)[names(grp5tmp) == 'coupon'] = "Coupon"
names(port_out)[names(port_out) == 'coupon'] = "Coupon"

names(grp1tmp)[names(grp1tmp) == 'maturity'] = "Maturity"
names(grp5tmp)[names(grp5tmp) == 'maturity'] = "Maturity"
names(port_out)[names(port_out) == 'maturity'] = "Maturity"

names(grp1tmp)[names(grp1tmp) == 'unrealized_gainloss'] = "Gain/Loss"
names(grp5tmp)[names(grp5tmp) == 'unrealized_gainloss'] = "Gain/Loss"
names(port_out)[names(port_out) == 'unrealized_gainloss'] = "Gain/Loss"

names(grp1tmp)[names(grp1tmp) == 'er_3m_fc'] = "ER 3M FC"
names(grp5tmp)[names(grp5tmp) == 'er_3m_fc'] = "ER 3M FC"
names(port_out)[names(port_out) == 'er_3m_fc'] = "ER 3M FC"

names(grp1tmp)[names(grp1tmp) == 'intercept'] = "Excess Carry"
names(grp5tmp)[names(grp5tmp) == 'intercept'] = "Excess Carry"
names(port_out)[names(port_out) == 'intercept'] = "Excess Carry"

names(grp1tmp)[names(grp1tmp) == 'credit_dur'] = "Credit/Dur"
names(grp5tmp)[names(grp5tmp) == 'credit_dur'] = "Credut/Dur"
names(port_out)[names(port_out) == 'credit_dur'] = "Credit/Dur"

names(grp1tmp)[names(grp1tmp) == 'tr_3m_fc'] = "TR 3M FC"
names(grp5tmp)[names(grp5tmp) == 'tr_3m_fc'] = "TR 3M FC"
names(port_out)[names(port_out) == 'tr_3m_fc'] = "TR 3M FC"

names(grp1tmp)[names(grp1tmp) == 'credit_curve'] = "Credit/Dur OAS"
names(grp5tmp)[names(grp5tmp) == 'credit_curve'] = "Credit/Dur OAS"
names(port_out)[names(port_out) == 'credit_curve'] = "Credit/Dur OAS"

names(grp1tmp)[names(grp1tmp) == 'state_oas'] = "State OAS"
names(grp5tmp)[names(grp5tmp) == 'state_oas'] = "State OAS"
names(port_out)[names(port_out) == 'state_oas'] = "State OAS"

names(grp1tmp)[names(grp1tmp) == 'sector_oas'] = "Sector OAS"
names(grp5tmp)[names(grp5tmp) == 'sector_oas'] = "Sector OAS"
names(port_out)[names(port_out) == 'sector_oas'] = "Sector OAS"

names(grp1tmp)[names(grp1tmp) == 'coupon_effect'] = "Deminimis OAS"
names(grp5tmp)[names(grp5tmp) == 'coupon_effect'] = "Deminimis OAS"
names(port_out)[names(port_out) == 'coupon_effect'] = "Deminimis OAS"

names(grp1tmp)[names(grp1tmp) == 'resi_oas'] = "Residual OAS"
names(grp5tmp)[names(grp5tmp) == 'resi_oas'] = "Residual OAS"
names(port_out)[names(port_out) == 'resi_oas'] = "Residual OAS"

names(grp1tmp)[names(grp1tmp) == 'resi_mean'] = "Historical Residual"
names(grp5tmp)[names(grp5tmp) == 'resi_mean'] = "Historical Residual"
names(port_out)[names(port_out) == 'resi_mean'] = "Historical Residual"

names(grp1tmp)[names(grp1tmp) == 'Carry'] = "AAA Carry"
names(grp5tmp)[names(grp5tmp) == 'Carry'] = "AAA Carry"
names(port_out)[names(port_out) == 'Carry'] = "AAA Carry"

names(grp1tmp)[names(grp1tmp) == 'Term'] = "AAA Term"
names(grp5tmp)[names(grp5tmp) == 'Term'] = "AAA Term"
names(port_out)[names(port_out) == 'Term'] = "AAA Term"

names(grp1tmp)[names(grp1tmp) == 'Roll'] = "AAA Roll"
names(grp5tmp)[names(grp5tmp) == 'Roll'] = "AAA Roll"
names(port_out)[names(port_out) == 'Roll'] = "AAA Roll"

names(grp1tmp)[names(grp1tmp) == 'credit_oad'] = "Hist Credit/Dur"
names(grp5tmp)[names(grp5tmp) == 'credit_oad'] = "Hist Credit/Dur"
names(port_out)[names(port_out) == 'credit_oad'] = "Hist Credit/Dur"

names(grp1tmp)[names(grp1tmp) == 'extension_risk'] = "Extension Risk"
names(grp5tmp)[names(grp5tmp) == 'extension_risk'] = "Extension Risk"
names(port_out)[names(port_out) == 'extension_risk'] = "Extension Risk"

names(grp1tmp)[names(grp1tmp) == 'resi_sdev'] = "Residual SD"
names(grp5tmp)[names(grp5tmp) == 'resi_sdev'] = "Residual SD"
names(port_out)[names(port_out) == 'resi_sdev'] = "Residual SD"

names(grp1tmp)[names(grp1tmp) == 'resi_z'] = "Residual Z-score"
names(grp5tmp)[names(grp5tmp) == 'resi_z'] = "Residual Z-score"
names(port_out)[names(port_out) == 'resi_z'] = "Residual Z-score"

filename1 = paste(port_long_name," cheap ",format(as_of,format = "%Y%m%d"),".csv",sep='')
filename5 = paste(port_long_name," rich ",format(as_of,format = "%Y%m%d"),".csv",sep='')
filename_all = paste(port_long_name," All ",format(as_of,format = "%Y%m%d"),".csv",sep='')

if(!is.null(opt$repo)) setwd(opt$repo)


write.table(data.frame(date = grp1tmp[1,1],desc = paste(port_long_name," cheapest holdings",sep = ''),a1 = "",a2 = "",a3 = "",
a4 = "",a5 = "",a6 = "",a7 = "",a8 = "",a9 = "",a28 = "",a29 = "",a10 = "Cumulative",a11 = "Annual",a12 = "Annual",a13 = "Annual",
a14 = "Annual",a15 = "Annual",a16 = "Annual",a17 = "Annual",a18 = "Annual",a19 = "Annual",a20 = "Attrib OAS",a21 = "Attrib OAS",
a22 = "Attrib OAS",a23 = "Attrib OAS",a24 = "Attrib OAS",a25 = "Attrib OAS",a26 = "Attrib OAS",a27 = "Attrib OAS",a28 = "Attrib OAS",a29 = ""),
file = filename1,na = "",sep = ",",row.names = F,col.names = F)
grp1tmp = grp1tmp[,2:dim(grp1tmp)[2]]
row.names(grp1tmp) = 1:dim(grp1tmp)[1]
write.table(as.list(c("",names(grp1tmp))),file = filename1,na = "",sep = ",",row.names = F,col.names = F,append = T)
write.table(grp1tmp,file = filename1,na = "",sep = ",",row.names = T,col.names = F, append = T)
cstart = max(gsize,dim(grp1tmp)[1])+1
for(i in 1:length(ratings))
{
	if(rgood[i])
	{
	write.table(data.frame(desc = paste(ratings[i]," cheapest",sep='')),file = filename1,na = "",sep = ",",row.names = F,col.names = F,append = T)
	t2write = get(paste(tolower(ratings[i]),"1tmp",sep=''))
	row.names(t2write) = cstart:(cstart + max(rsize,dim(t2write)[1]) - 1)
	write.table(t2write[,2:dim(t2write)[2]],file = filename1,na = "",sep = ",",row.names = T,append = T,col.names = F)
	cstart = cstart + max(rsize,dim(t2write)[1])
	}
}

write.table(data.frame(date = grp5tmp[1,1],desc = paste(port_long_name," richest holdings",sep = ''),a1 = "",a2 = "",a3 = "",
a4 = "",a5 = "",a6 = "",a7 = "",a8 = "",a9 = "",a28 = "",a29 = "",a10 = "Cumulative",a11 = "Annual",a12 = "Annual",a13 = "Annual",
a14 = "Annual",a15 = "Annual",a16 = "Annual",a17 = "Annual",a18 = "Annual",a19 = "Annual",a20 = "Attrib OAS",a21 = "Attrib OAS",
a22 = "Attrib OAS",a23 = "Attrib OAS",a24 = "Attrib OAS",a25 = "Attrib OAS",a26 = "Attrib OAS",a27 = "Attrib OAS",a28 = "Attrib OAS",a29 = ""),
file = filename5,na = "",sep = ",",row.names = F,col.names = F)
grp5tmp = grp5tmp[,2:dim(grp5tmp)[2]]
row.names(grp5tmp) = 1:dim(grp5tmp)[1]
write.table(as.list(c("",names(grp5tmp))),file = filename5,na = "",sep = ",",row.names = F,col.names = F,append = T)
write.table(grp5tmp,file = filename5,na = "",sep = ",",row.names = T,col.names = F, append = T)
cstart = max(gsize,dim(grp5tmp)[1])+1
for(i in 1:length(ratings))
{
	if(rgood[i])
	{
	write.table(data.frame(desc = paste(ratings[i]," richest",sep='')),file = filename5,na = "",sep = ",",row.names = F,col.names = F,append = T)
	t2write = get(paste(tolower(ratings[i]),"5tmp",sep=''))
	row.names(t2write) = cstart:(cstart + max(rsize,dim(t2write)[1]) - 1)
	write.table(t2write[,2:dim(t2write)[2]],file = filename5,na = "",sep = ",",row.names = T,append = T,col.names = F)
	cstart = cstart + max(rsize,dim(t2write)[1])
	}
}

write.table(data.frame(date = grp5tmp[1,1],desc = paste(port_long_name," richest holdings",sep = ''),a1 = "",a2 = "",a3 = "",
a4 = "",a5 = "",a6 = "",a7 = "",a8 = "",a9 = "",a28 = "",a29 = "",a10 = "Cumulative",a11 = "Annual",a12 = "Annual",a13 = "Annual",
a14 = "Annual",a15 = "Annual",a16 = "Annual",a17 = "Annual",a18 = "Annual",a19 = "Annual",a20 = "Attrib OAS",a21 = "Attrib OAS",
a22 = "Attrib OAS",a23 = "Attrib OAS",a24 = "Attrib OAS",a25 = "Attrib OAS",a26 = "Attrib OAS",a27 = "Attrib OAS",a28 = "Attrib OAS",a29 = ""),
file = filename_all,na = "",sep = ",",row.names = F,col.names = F)
port_out = port_out[,2:dim(port_out)[2]]
row.names(port_out) = 1:dim(port_out)[1]
write.table(as.list(c("",names(port_out))),file = filename_all,na = "",sep = ",",row.names = F,col.names = F,append = T)
write.table(port_out,file = filename_all,na = "",sep = ",",row.names = T,col.names = F, append = T)

cat(paste("file ",filename1," saved to ",getwd(),"\n",sep=''))
cat(paste("file ",filename5," saved to ",getwd(),"\n",sep=''))
cat(paste("file ",filename_all," saved to ",getwd(),"\n",sep=''))
}