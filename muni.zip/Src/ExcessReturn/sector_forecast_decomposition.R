#!\\nts0018\bond\ABFI_PROD\QuantApps\R-2.14.2\bin\Rscript

source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.R',sep='') )

setwd(paste(Sys.getenv('ABFI_DATA_REPOSITORY'),'\\Muni\\v1.0\\Input',sep='') )


################################################################################
################################################################################
library('getopt')
opt = getopt(matrix(
    c(
    'db',   's', 2, "character",
    'as_of','d', 2, "character",
    'port',	'p', 1, "character",
    'repo', 'r', 2, "character",
    'help', 'h', 0, "logical"
    ),ncol=4,byrow=TRUE)
)

if ( !is.null(opt$help))# || is.null(opt$port)) 
{
  self = 'Rscript load_data.R'
  cat(paste("
    Usage: ",self,"  [--as_of date] [--help]  
        db:   Database server to run the script on (PRD/QA/DEV).
        as_of:as_of date in yyyy-mm-dd format. default to last business day. Optional
        port:	Portfolio ID (as in DAILYVIEW..POSITION_HISTORY). Required      
        repo:	Location to save reports
        help: Show help.  Optional
    Example: RScript load_data.R --db PRD --as_of 2012-02-15
  ",sep=""))
  q(status=1)
}


if ( is.null(opt$db) ) opt$db = 'QA'
if ( is.null(opt$as_of) ) { opt$as_of = Sys.Date()-1 }
as_of <- last.business.day( as.Date(opt$as_of) )
#as_of = as.Date('2015-03-19')

load('MuniParBondRet.RData')


###############################################################################
#source('H:/SVN/Muni/v1.0/Src/ExcessReturn/sector_forecast_decomposition.R') 
#source('C:/SVN/Quant_Model-SQLServer/Muni/v1.0/Src/ExcessReturn/sector_forecast_decomposition.R') 

setwd(paste(Sys.getenv('ABFI_DATA_REPOSITORY'),'\\Muni\\v1.0\\Output',sep='') )
library(RODBC)
db_info <- get_db_info(opt$db)
db_prd <- get_db_info('PRD')


channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
	
gsize = 25

channel_prd <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_prd$Database,';DataBase=',db_prd$InitDB,';uid=',db_prd$User,';pwd=',db_prd$Password,sep=''))

q = paste("select distinct substring(a.IDENTIFIER,1,8),a.DESCRIPTION description,a.COUPON coupon,",
				"a.MATURITY_DATE maturity,a.MUNI_OAD dur, s.AB_SECTOR sector, a.MUNI_OAS_RISK oas,a.MUNI_6MO_KRD,",
				"a.MUNI_2YR_KRD,a.MUNI_5YR_KRD,a.MUNI_10YR_KRD,a.MUNI_20YR_KRD,a.MUNI_30YR_KRD,a.SP_RATING rating, ",
				"a.YIELD_TO_WORST yield, a.NEXT_CALL_DATE calldate from FIQModel..MUNI_SECTOR_CODE sc, FIQModel..MUNI_SECTOR s, ",  
				"Optimizer..MUNI_ANALYTICS a where a.EFFECTIVE_DATE = '",format(as_of),"' ",
				"and a.IDENTIFIER = sc.IDENTIFIER ",
				"and sc.AB_CODE = s.AB_CODE",sep='')

port_secs <- sqlQuery(channel_prd,query=q)
names(port_secs)<-tolower(names(port_secs))

odbcClose(channel_prd)

q = paste("select er.*, oas.INDEX_OAS,oas.CREDIT_CURVE,oas.STATE,oas.SECTOR sector_oas,oas.COUPON_EFFECT,oas.EXTENSION_RISK,oas.ZERO_COUPON,oas.RESI_OAS ",
			"from FIQModel..MUNI_EXPECTED_RETURN_DECOMPOSITION er, ",
			"FIQModel..MUNI_OAS_DECOMPOSITION oas ",
			"where er.AS_OF_DATE = '",format(as_of),"' and er.AS_OF_DATE = oas.AS_OF_DATE ",
			"and er.IDENTIFIER = oas.IDENTIFIER",sep='')

ret_decomp <- sqlQuery(channel,query=q)

odbcClose(channel)				
channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_prd$Database,';DataBase=',db_prd$InitDB,';uid=',db_prd$User,';pwd=',db_prd$Password,sep=''))

q = paste("select distinct VALUE_DATE as_of, SECURITY_ID security, UNREALIZED_GAIN_LOSS_PCT unrealized_gainloss,YIELD yield, ", 
		"INTERNAL_RATING rating, NEXT_CALL_DATE calldate from Optimizer..MUNI_POSITION ",
		"where VALUE_DATE = '",format(as_of),"'",sep='')
unreal_gl <- sqlQuery(channel,query=q)

odbcClose(channel)				

names(ret_decomp) = casefold(names(ret_decomp),upper=F)

inxa = which(!is.na(match(port_secs[,1], unreal_gl$security)))
inxb = na.exclude(match(port_secs[,1], unreal_gl$security))
names(port_secs)[names(port_secs) == 'unrealized_gainloss'] = 'gain_loss'

port_secs$gain_loss = NA
port_secs$gain_loss[inxa] = unreal_gl$unrealized_gainloss[inxb]
port_secs$rating[inxa] = unreal_gl$rating[inxb]
port_secs$yield[inxa] = unreal_gl$yield[inxb]

port_secs$calldate = as.Date(port_secs$calldate)
port_secs$calldate[inxa] = as.Date(unreal_gl$calldate[inxb])

inxa = which(!is.na(match(port_secs[,1], ret_decomp$identifier)))
inxb = na.exclude(match(port_secs[,1], ret_decomp$identifier))
port_data = cbind(port_secs[inxa,],ret_decomp[inxb,c('excess_expected_return_3m','intercept','credit_curve_reversion','residual_oas_reversion',
										'index_oas','credit_curve','state','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')])

names(port_data)[1] = 'security'
names(port_data)[names(port_data) == 'excess_expected_return_3m'] = 'er_fc_3m'
names(port_data)[names(port_data) == 'credit_curve_reversion'] = 'credit_duration'
names(port_data)[names(port_data) == 'residual_oas_reversion'] = 'residual'
port_data$as_of_date = as_of

port_data = calc_returns(port_data,dur,yld_fixed)
names(port_data)[names(port_data) == 'krd_ret_fwd3m_fc'] = 'carry'
port_data = calc_returns(port_data,dur,roll)
names(port_data)[names(port_data) == 'krd_ret_fwd3m_fc'] = 'roll'
port_data = calc_returns(port_data,dur,term_fc)
names(port_data)[names(port_data) == 'krd_ret_fwd3m_fc'] = 'term'
port_data = calc_returns(port_data,dur,conv)
names(port_data)[names(port_data) == 'krd_ret_fwd3m_fc'] = 'convexity'
port_data = calc_returns(port_data,dur,ret_fc)

port_data$tr_3m_fc = port_data$krd_ret_fwd3m_fc + port_data$er_fc_3m

port_data = port_data[order(port_data$security),]
#exlude defaults
inx = port_data$rating != 'D'
inx[is.na(inx)] = TRUE
port_data = port_data[inx,]



sectors = unique(port_data$sector)
#sectors = sub("Muni - ","",sectors)

port_data_bk = port_data

for(sect in sectors)
{
	port_data = port_data[port_data$sector == sect,]	 
	if(dim(port_data)[1] >= gsize)
	{ 
	cat(paste("forecast available for ",dim(port_data)[1]," securities\n",sep=''))
	rank_ex <- rank(-port_data$er_fc_3m)
	n <- length(rank_ex)

	inx = rank_ex <= max(gsize,min(rank_ex))
	grp1tmp = data.frame(date = as_of,cusip = port_data$security[inx],description = port_data$description[inx],rating = port_data$rating[inx], 
			coupon = port_data$coupon[inx], maturity = port_data$maturity[inx],OAS = format(port_data$oas[inx],digits = 1),yield = port_data$yield[inx],Duration = port_data$dur[inx],
			calldate = port_data$calldate[inx],sector = port_data$sector[inx],unrealized_gainloss = port_data$gain_loss[inx],
			er_3m_fc = port_data$er_fc_3m[inx],intercept = port_data$intercept[1],credit_dur = port_data$credit_duration[inx],
       		Mispricing = port_data$residual[inx],tr_3m_fc = port_data$tr_3m_fc[inx],Carry = port_data$carry[inx],Roll = port_data$roll[inx],
       		Term = port_data$term[inx],Convexity = port_data$convexity[inx],credit_curve = port_data$credit_curve[inx],
       		state_oas = port_data$state[inx],sector_oas = port_data$sector_oas[inx],coupon_effect = port_data$coupon_effect[inx],
       		extension_risk = port_data$extension_risk[inx],zero_coupon = port_data$zero_coupon[inx],resi_oas = port_data$resi_oas[inx])
	grp1tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')] = 
		round(grp1tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')]*400,digits = 2)
	grp1tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')] = 
		round(grp1tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')])	   
	grp1tmp[,c('yield')] = round(as.numeric(as.character(grp1tmp[,c('yield')])),digits = 2)
	grp1tmp[,c('unrealized_gainloss')] = round(as.numeric(as.character(grp1tmp[,c('unrealized_gainloss')])),digits = 2)
	grp1tmp = grp1tmp[order(grp1tmp$er_3m_fc,decreasing = T),]
		
	inx = rank_ex >= min((n-gsize),max(rank_ex))
	grp5tmp = data.frame(date = as_of,cusip = port_data$security[inx],description = port_data$description[inx],rating = port_data$rating[inx], 
			coupon = port_data$coupon[inx], maturity = port_data$maturity[inx],OAS = format(port_data$oas[inx],digits = 1),yield = port_data$yield[inx],Duration = port_data$dur[inx],
			calldate = port_data$calldate[inx],sector = port_data$sector[inx],unrealized_gainloss = port_data$gain_loss[inx],
			er_3m_fc = port_data$er_fc_3m[inx],intercept = port_data$intercept[1],credit_dur = port_data$credit_duration[inx],
       		Mispricing = port_data$residual[inx],tr_3m_fc = port_data$tr_3m_fc[inx],Carry = port_data$carry[inx],Roll = port_data$roll[inx],
       		Term = port_data$term[inx],Convexity = port_data$convexity[inx],credit_curve = port_data$credit_curve[inx],
       		state_oas = port_data$state[inx],sector_oas = port_data$sector_oas[inx],coupon_effect = port_data$coupon_effect[inx],
       		extension_risk = port_data$extension_risk[inx],zero_coupon = port_data$zero_coupon[inx],resi_oas = port_data$resi_oas[inx])

	grp5tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')] = 
		round(grp5tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')]*400,digits = 2)  
	grp5tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')] = 
		round(grp5tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')])	
	grp5tmp[,c('yield')] = round(as.numeric(as.character(grp5tmp[,c('yield')])),digits = 2)
	grp5tmp[,c('unrealized_gainloss')] = round(as.numeric(as.character(grp5tmp[,c('unrealized_gainloss')])),digits = 2)
	
	grp5tmp = grp5tmp[order(grp5tmp$er_3m_fc),]

	rsize = 5

aaa_data = port_data[which(port_data$rating == 'AAA'),]
cat(paste("forecast available for ",dim(aaa_data)[1]," AAA securities\n",sep=''))
if(dim(aaa_data)[1] >= 2*rsize)
{
	rank_ex <- rank(-aaa_data$er_fc_3m)
	n <- length(rank_ex)
	
	inx = rank_ex <= max(rsize,min(rank_ex))
	aaa1tmp = data.frame(date = as_of,cusip = aaa_data$security[inx],description = aaa_data$description[inx],rating = aaa_data$rating[inx], 
				coupon = aaa_data$coupon[inx], maturity = aaa_data$maturity[inx],OAS = format(aaa_data$oas[inx],digits = 1),yield = aaa_data$yield[inx],Duration = aaa_data$dur[inx],
				calldate = aaa_data$calldate[inx],sector = aaa_data$sector[inx],unrealized_gainloss = aaa_data$gain_loss[inx],
				er_3m_fc = aaa_data$er_fc_3m[inx],intercept = aaa_data$intercept[1],credit_dur = aaa_data$credit_duration[inx],
	       		Mispricing = aaa_data$residual[inx],tr_3m_fc = aaa_data$tr_3m_fc[inx],Carry = aaa_data$carry[inx],Roll = aaa_data$roll[inx],
       		Term = aaa_data$term[inx],Convexity = aaa_data$convexity[inx],credit_curve = aaa_data$credit_curve[inx],
       		state_oas = aaa_data$state[inx],sector_oas = aaa_data$sector_oas[inx],coupon_effect = aaa_data$coupon_effect[inx],
       		extension_risk = aaa_data$extension_risk[inx],zero_coupon = aaa_data$zero_coupon[inx],resi_oas = aaa_data$resi_oas[inx])
    aaa1tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')] = 
	round(aaa1tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')]*400,digits = 2)    
	aaa1tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')] = 
	round(aaa1tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')])	 		
	aaa1tmp[,c('yield')] = round(as.numeric(as.character(aaa1tmp[,c('yield')])),digits = 2)
	aaa1tmp[,c('unrealized_gainloss')] = round(as.numeric(as.character(aaa1tmp[,c('unrealized_gainloss')])),digits = 2)
	aaa1tmp = aaa1tmp[order(aaa1tmp$er_3m_fc,decreasing = T),]
	
	inx = rank_ex >= min((n-rsize),max(rank_ex))
	aaa5tmp = data.frame(date = as_of,cusip = aaa_data$security[inx],description = aaa_data$description[inx],rating = aaa_data$rating[inx], 
				coupon = aaa_data$coupon[inx], maturity = aaa_data$maturity[inx],OAS = format(aaa_data$oas[inx],digits = 1),yield = aaa_data$yield[inx],Duration = aaa_data$dur[inx],
				calldate = aaa_data$calldate[inx],sector = aaa_data$sector[inx],unrealized_gainloss = aaa_data$gain_loss[inx],
				er_3m_fc = aaa_data$er_fc_3m[inx],intercept = aaa_data$intercept[1],credit_dur = aaa_data$credit_duration[inx],
	       		Mispricing = aaa_data$residual[inx],tr_3m_fc = aaa_data$tr_3m_fc[inx],Carry = aaa_data$carry[inx],Roll = aaa_data$roll[inx],
       		Term = aaa_data$term[inx],Convexity = aaa_data$convexity[inx],credit_curve = aaa_data$credit_curve[inx],
       		state_oas = aaa_data$state[inx],sector_oas = aaa_data$sector_oas[inx],coupon_effect = aaa_data$coupon_effect[inx],
       		extension_risk = aaa_data$extension_risk[inx],zero_coupon = aaa_data$zero_coupon[inx],resi_oas = aaa_data$resi_oas[inx])
    aaa5tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')] = 
	round(aaa5tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')]*400,digits = 2)     		
	aaa5tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')] = 
	round(aaa5tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')])	
	aaa5tmp[,c('yield')] = round(as.numeric(as.character(aaa5tmp[,c('yield')])),digits = 2)
	aaa5tmp[,c('unrealized_gainloss')] = round(as.numeric(as.character(aaa5tmp[,c('unrealized_gainloss')])),digits = 2)
	aaa5tmp = aaa5tmp[order(aaa5tmp$er_3m_fc),]
	
	#grp1tmp = rbind(grp1tmp,aaa1tmp)
	#grp5tmp = rbind(grp5tmp,aaa5tmp)
}

aa_data = port_data[which(port_data$rating == 'AA+' | port_data$rating == 'AA' | port_data$rating == 'AA-'),]
cat(paste("forecast available for ",dim(aa_data)[1]," AA securities\n",sep=''))
if(dim(aa_data)[1] >= 2*rsize)
{
	rank_ex <- rank(-aa_data$er_fc_3m)
	n <- length(rank_ex)
	
	inx = rank_ex <= max(rsize,min(rank_ex))
	aa1tmp = data.frame(date = as_of,cusip = aa_data$security[inx],description = aa_data$description[inx],rating = aa_data$rating[inx], 
				coupon = aa_data$coupon[inx], maturity = aa_data$maturity[inx],OAS = format(aa_data$oas[inx],digits = 1),yield = aa_data$yield[inx],Duration = aa_data$dur[inx],
				calldate = aa_data$calldate[inx],sector = aa_data$sector[inx],unrealized_gainloss = aa_data$gain_loss[inx],
				er_3m_fc = aa_data$er_fc_3m[inx],intercept = aa_data$intercept[1],credit_dur = aa_data$credit_duration[inx],
	       		Mispricing = aa_data$residual[inx],tr_3m_fc = aa_data$tr_3m_fc[inx],Carry = aa_data$carry[inx],Roll = aa_data$roll[inx],
       		Term = aa_data$term[inx],Convexity = aa_data$convexity[inx],credit_curve = aa_data$credit_curve[inx],
       		state_oas = aa_data$state[inx],sector_oas = aa_data$sector_oas[inx],coupon_effect = aa_data$coupon_effect[inx],
       		extension_risk = aa_data$extension_risk[inx],zero_coupon = aa_data$zero_coupon[inx],resi_oas = aa_data$resi_oas[inx])
    aa1tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')] = 
	round(aa1tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')]*400,digits = 2)     		
	aa1tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')] = 
	round(aa1tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')])	
	aa1tmp[,c('yield')] = round(as.numeric(as.character(aa1tmp[,c('yield')])),digits = 2)
	aa1tmp[,c('unrealized_gainloss')] = round(as.numeric(as.character(aa1tmp[,c('unrealized_gainloss')])),digits = 2)
	aa1tmp = aa1tmp[order(aa1tmp$er_3m_fc,decreasing = T),]
	
	inx = rank_ex >= min((n-rsize),max(rank_ex))
	aa5tmp = data.frame(date = as_of,cusip = aa_data$security[inx],description = aa_data$description[inx],rating = aa_data$rating[inx], 
				coupon = aa_data$coupon[inx], maturity = aa_data$maturity[inx],OAS = format(aa_data$oas[inx],digits = 1),yield = aa_data$yield[inx],Duration = aa_data$dur[inx],
				calldate = aa_data$calldate[inx],sector = aa_data$sector[inx],unrealized_gainloss = aa_data$gain_loss[inx],
				er_3m_fc = aa_data$er_fc_3m[inx],intercept = aa_data$intercept[1],credit_dur = aa_data$credit_duration[inx],
	       		Mispricing = aa_data$residual[inx],tr_3m_fc = aa_data$tr_3m_fc[inx],Carry = aa_data$carry[inx],Roll = aa_data$roll[inx],
       		Term = aa_data$term[inx],Convexity = aa_data$convexity[inx],credit_curve = aa_data$credit_curve[inx],
       		state_oas = aa_data$state[inx],sector_oas = aa_data$sector_oas[inx],coupon_effect = aa_data$coupon_effect[inx],
       		extension_risk = aa_data$extension_risk[inx],zero_coupon = aa_data$zero_coupon[inx],resi_oas = aa_data$resi_oas[inx])
    aa5tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')] = 
	round(aa5tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')]*400,digits = 2)     		
	aa5tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')] = 
	round(aa5tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')])	
	aa5tmp[,c('yield')] = round(as.numeric(as.character(aa5tmp[,c('yield')])),digits = 2)
	aa5tmp[,c('unrealized_gainloss')] = round(as.numeric(as.character(aa5tmp[,c('unrealized_gainloss')])),digits = 2)
	aa5tmp = aa5tmp[order(aa5tmp$er_3m_fc),]
	
	#grp1tmp = rbind(grp1tmp,aa1tmp)
	#grp5tmp = rbind(grp5tmp,aa5tmp)
}

a_data = port_data[which(port_data$rating == 'A+' | port_data$rating == 'A' | port_data$rating == 'A-'),]
cat(paste("forecast available for ",dim(a_data)[1]," A securities\n",sep=''))
if(dim(a_data)[1] >= 2*rsize)
{
	rank_ex <- rank(-a_data$er_fc_3m)
	n <- length(rank_ex)
	
	inx = rank_ex <= max(rsize,min(rank_ex))
	a1tmp = data.frame(date = as_of,cusip = a_data$security[inx],description = a_data$description[inx],rating = a_data$rating[inx], 
				coupon = a_data$coupon[inx], maturity = a_data$maturity[inx],OAS = format(a_data$oas[inx],digits = 1),yield = a_data$yield[inx],Duration = a_data$dur[inx],
				calldate = a_data$calldate[inx],sector = a_data$sector[inx],unrealized_gainloss = a_data$gain_loss[inx],
				er_3m_fc = a_data$er_fc_3m[inx],intercept = a_data$intercept[1],credit_dur = a_data$credit_duration[inx],
	       		Mispricing = a_data$residual[inx],tr_3m_fc = a_data$tr_3m_fc[inx],Carry = a_data$carry[inx],Roll = a_data$roll[inx],
       		Term = a_data$term[inx],Convexity = a_data$convexity[inx],credit_curve = a_data$credit_curve[inx],
       		state_oas = a_data$state[inx],sector_oas = a_data$sector_oas[inx],coupon_effect = a_data$coupon_effect[inx],
       		extension_risk = a_data$extension_risk[inx],zero_coupon = a_data$zero_coupon[inx],resi_oas = a_data$resi_oas[inx])
    a1tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')] = 
	round(a1tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')]*400,digits = 2)     		
	a1tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')] = 
	round(a1tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')])	
	a1tmp[,c('yield')] = round(as.numeric(as.character(a1tmp[,c('yield')])),digits = 2)
	a1tmp[,c('unrealized_gainloss')] = round(as.numeric(as.character(a1tmp[,c('unrealized_gainloss')])),digits = 2)
	a1tmp = a1tmp[order(a1tmp$er_3m_fc,decreasing = T),]
	
	inx = rank_ex >= min((n-rsize),max(rank_ex))
	a5tmp = data.frame(date = as_of,cusip = a_data$security[inx],description = a_data$description[inx],rating = a_data$rating[inx], 
				coupon = a_data$coupon[inx], maturity = a_data$maturity[inx],OAS = format(a_data$oas[inx],digits = 1),yield = a_data$yield[inx],Duration = a_data$dur[inx],
				calldate = a_data$calldate[inx],sector = a_data$sector[inx],unrealized_gainloss = a_data$gain_loss[inx],
				er_3m_fc = a_data$er_fc_3m[inx],intercept = a_data$intercept[1],credit_dur = a_data$credit_duration[inx],
	       		Mispricing = a_data$residual[inx],tr_3m_fc = a_data$tr_3m_fc[inx],Carry = a_data$carry[inx],Roll = a_data$roll[inx],
       		Term = a_data$term[inx],Convexity = a_data$convexity[inx],credit_curve = a_data$credit_curve[inx],
       		state_oas = a_data$state[inx],sector_oas = a_data$sector_oas[inx],coupon_effect = a_data$coupon_effect[inx],
       		extension_risk = a_data$extension_risk[inx],zero_coupon = a_data$zero_coupon[inx],resi_oas = a_data$resi_oas[inx])
    a5tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')] = 
	round(a5tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')]*400,digits = 2)     		
	a5tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')] = 
	round(a5tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')])	
	a5tmp[,c('yield')] = round(as.numeric(as.character(a5tmp[,c('yield')])),digits = 2)
	a5tmp[,c('unrealized_gainloss')] = round(as.numeric(as.character(a5tmp[,c('unrealized_gainloss')])),digits = 2)
	a5tmp = a5tmp[order(a5tmp$er_3m_fc),]
	
	#grp1tmp = rbind(grp1tmp,a1tmp)
	#grp5tmp = rbind(grp5tmp,a5tmp)
}

bbb_data = port_data[which(port_data$rating == 'BBB+' | port_data$rating == 'BBB' | port_data$rating == 'BBB-'),]
cat(paste("forecast available for ",dim(bbb_data)[1]," BBB securities\n",sep=''))
if(dim(bbb_data)[1] >= 2*rsize)
{
	rank_ex <- rank(-bbb_data$er_fc_3m)
	n <- length(rank_ex)
	
	inx = rank_ex <= max(rsize,min(rank_ex))
	bbb1tmp = data.frame(date = as_of,cusip = bbb_data$security[inx],description = bbb_data$description[inx],rating = bbb_data$rating[inx], 
				coupon = bbb_data$coupon[inx], maturity = bbb_data$maturity[inx],OAS = format(bbb_data$oas[inx],digits = 1),yield = bbb_data$yield[inx],Duration = bbb_data$dur[inx],
				calldate = bbb_data$calldate[inx],sector = bbb_data$sector[inx],unrealized_gainloss = bbb_data$gain_loss[inx],
				er_3m_fc = bbb_data$er_fc_3m[inx],intercept = bbb_data$intercept[1],credit_dur = bbb_data$credit_duration[inx],
	       		Mispricing = bbb_data$residual[inx],tr_3m_fc = bbb_data$tr_3m_fc[inx],Carry = bbb_data$carry[inx],Roll = bbb_data$roll[inx],
       		Term = bbb_data$term[inx],Convexity = bbb_data$convexity[inx],credit_curve = bbb_data$credit_curve[inx],
       		state_oas = bbb_data$state[inx],sector_oas = bbb_data$sector_oas[inx],coupon_effect = bbb_data$coupon_effect[inx],
       		extension_risk = bbb_data$extension_risk[inx],zero_coupon = bbb_data$zero_coupon[inx],resi_oas = bbb_data$resi_oas[inx])
    bbb1tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')] = 
	round(bbb1tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')]*400,digits = 2)     		
	bbb1tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')] = 
	round(bbb1tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')])	
	bbb1tmp[,c('yield')] = round(as.numeric(as.character(bbb1tmp[,c('yield')])),digits = 2)
	bbb1tmp[,c('unrealized_gainloss')] = round(as.numeric(as.character(bbb1tmp[,c('unrealized_gainloss')])),digits = 2)
	bbb1tmp = bbb1tmp[order(bbb1tmp$er_3m_fc,decreasing = T),]
	inx = rank_ex >= min((n-rsize),max(rank_ex))
	bbb5tmp = data.frame(date = as_of,cusip = bbb_data$security[inx],description = bbb_data$description[inx],rating = bbb_data$rating[inx], 
				coupon = bbb_data$coupon[inx], maturity = bbb_data$maturity[inx],OAS = format(bbb_data$oas[inx],digits = 1),yield = bbb_data$yield[inx],Duration = bbb_data$dur[inx],
				calldate = bbb_data$calldate[inx],sector = bbb_data$sector[inx],unrealized_gainloss = bbb_data$gain_loss[inx],
				er_3m_fc = bbb_data$er_fc_3m[inx],intercept = bbb_data$intercept[1],credit_dur = bbb_data$credit_duration[inx],
	       		Mispricing = bbb_data$residual[inx],tr_3m_fc = bbb_data$tr_3m_fc[inx],Carry = bbb_data$carry[inx],Roll = bbb_data$roll[inx],
       		Term = bbb_data$term[inx],Convexity = bbb_data$convexity[inx],credit_curve = bbb_data$credit_curve[inx],
       		state_oas = bbb_data$state[inx],sector_oas = bbb_data$sector_oas[inx],coupon_effect = bbb_data$coupon_effect[inx],
       		extension_risk = bbb_data$extension_risk[inx],zero_coupon = bbb_data$zero_coupon[inx],resi_oas = bbb_data$resi_oas[inx])
    bbb5tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')] = 
	round(bbb5tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')]*400,digits = 2)     		
	bbb5tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')] = 
	round(bbb5tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')])	
	bbb5tmp[,c('yield')] = round(as.numeric(as.character(bbb5tmp[,c('yield')])),digits = 2)
	bbb5tmp[,c('unrealized_gainloss')] = round(as.numeric(as.character(bbb5tmp[,c('unrealized_gainloss')])),digits = 2)
	bbb5tmp = bbb5tmp[order(bbb5tmp$er_3m_fc),]
	
	#grp1tmp = rbind(grp1tmp,bbb1tmp)
	#grp5tmp = rbind(grp5tmp,bbb5tmp)
}

bb_data = port_data[which(port_data$rating == 'BB+' | port_data$rating == 'BB' | port_data$rating == 'BB-'),]
cat(paste("forecast available for ",dim(bb_data)[1]," BB securities\n",sep=''))
if(dim(bb_data)[1] >= 2*rsize)
{
	rank_ex <- rank(-bb_data$er_fc_3m)
	n <- length(rank_ex)
	
	inx = rank_ex <= max(rsize,min(rank_ex))
	bb1tmp = data.frame(date = as_of,cusip = bb_data$security[inx],description = bb_data$description[inx],rating = bb_data$rating[inx], 
				coupon = bb_data$coupon[inx], maturity = bb_data$maturity[inx],OAS = format(bb_data$oas[inx],digits = 1),yield = bb_data$yield[inx],Duration = bb_data$dur[inx],
				calldate = bb_data$calldate[inx],sector = bb_data$sector[inx],unrealized_gainloss = bb_data$gain_loss[inx],
				er_3m_fc = bb_data$er_fc_3m[inx],intercept = bb_data$intercept[1],credit_dur = bb_data$credit_duration[inx],
	       		Mispricing = bb_data$residual[inx],tr_3m_fc = bb_data$tr_3m_fc[inx],Carry = bb_data$carry[inx],Roll = bb_data$roll[inx],
       		Term = bb_data$term[inx],Convexity = bb_data$convexity[inx],credit_curve = bb_data$credit_curve[inx],
       		state_oas = bb_data$state[inx],sector_oas = bb_data$sector_oas[inx],coupon_effect = bb_data$coupon_effect[inx],
       		extension_risk = bb_data$extension_risk[inx],zero_coupon = bb_data$zero_coupon[inx],resi_oas = bb_data$resi_oas[inx])
    bb1tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')] = 
	round(bb1tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')]*400,digits = 2)     		
	bb1tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')] = 
	round(bb1tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')])	
	bb1tmp[,c('yield')] = round(as.numeric(as.character(bb1tmp[,c('yield')])),digits = 2)
	bb1tmp[,c('unrealized_gainloss')] = round(as.numeric(as.character(bb1tmp[,c('unrealized_gainloss')])),digits = 2)
	bb1tmp = bb1tmp[order(bb1tmp$er_3m_fc,decreasing = T),]
	inx = rank_ex >= min((n-rsize),max(rank_ex))
	bb5tmp = data.frame(date = as_of,cusip = bb_data$security[inx],description = bb_data$description[inx],rating = bb_data$rating[inx], 
				coupon = bb_data$coupon[inx], maturity = bb_data$maturity[inx],OAS = format(bb_data$oas[inx],digits = 1),yield = bb_data$yield[inx],Duration = bb_data$dur[inx],
				calldate = bb_data$calldate[inx],sector = bb_data$sector[inx],unrealized_gainloss = bb_data$gain_loss[inx],
				er_3m_fc = bb_data$er_fc_3m[inx],intercept = bb_data$intercept[1],credit_dur = bb_data$credit_duration[inx],
	       		Mispricing = bb_data$residual[inx],tr_3m_fc = bb_data$tr_3m_fc[inx],Carry = bb_data$carry[inx],Roll = bb_data$roll[inx],
       		Term = bb_data$term[inx],Convexity = bb_data$convexity[inx],credit_curve = bb_data$credit_curve[inx],
       		state_oas = bb_data$state[inx],sector_oas = bb_data$sector_oas[inx],coupon_effect = bb_data$coupon_effect[inx],
       		extension_risk = bb_data$extension_risk[inx],zero_coupon = bb_data$zero_coupon[inx],resi_oas = bb_data$resi_oas[inx])
	bb5tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')] = 
	round(bb5tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')]*400,digits = 2)  
	bb5tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')] = 
	round(bb5tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')])	
	bb5tmp[,c('yield')] = round(as.numeric(as.character(bb5tmp[,c('yield')])),digits = 2)
	bb5tmp[,c('unrealized_gainloss')] = round(as.numeric(as.character(bb5tmp[,c('unrealized_gainloss')])),digits = 2)
	bb5tmp = bb5tmp[order(bb5tmp$er_3m_fc),]
	
	#grp1tmp = rbind(grp1tmp,bb1tmp)
	#grp5tmp = rbind(grp5tmp,bb5tmp)
}

b_data = port_data[which(port_data$rating == 'B+' | port_data$rating == 'B' | port_data$rating == 'B-'),]
cat(paste("forecast available for ",dim(b_data)[1]," B securities\n",sep=''))
if(dim(b_data)[1] >= 2*rsize)
{
	rank_ex <- rank(-b_data$er_fc_3m)
	n <- length(rank_ex)
	
	inx = rank_ex <= max(rsize,min(rank_ex))
	b1tmp = data.frame(date = as_of,cusip = b_data$security[inx],description = b_data$description[inx],rating = b_data$rating[inx], 
				coupon = b_data$coupon[inx], maturity = b_data$maturity[inx],OAS = format(b_data$oas[inx],digits = 1),yield = b_data$yield[inx],Duration = b_data$dur[inx],
				calldate = b_data$calldate[inx],sector = b_data$sector[inx],unrealized_gainloss = b_data$gain_loss[inx],
				er_3m_fc = b_data$er_fc_3m[inx],intercept = b_data$intercept[1],credit_dur = b_data$credit_duration[inx],
	       		Mispricing = b_data$residual[inx],tr_3m_fc = b_data$tr_3m_fc[inx],Carry = b_data$carry[inx],Roll = b_data$roll[inx],
       		Term = b_data$term[inx],Convexity = b_data$convexity[inx],credit_curve = b_data$credit_curve[inx],
       		state_oas = b_data$state[inx],sector_oas = b_data$sector_oas[inx],coupon_effect = b_data$coupon_effect[inx],
       		extension_risk = b_data$extension_risk[inx],zero_coupon = b_data$zero_coupon[inx],resi_oas = b_data$resi_oas[inx])
    b1tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')] = 
	round(b1tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')]*400,digits = 2)     		
	b1tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')] = 
	round(b1tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')])	
	b1tmp[,c('yield')] = round(as.numeric(as.character(b1tmp[,c('yield')])),digits = 2)
	b1tmp[,c('unrealized_gainloss')] = round(as.numeric(as.character(b1tmp[,c('unrealized_gainloss')])),digits = 2)
	b1tmp = b1tmp[order(b1tmp$er_3m_fc,decreasing = T),]
	inx = rank_ex >= min((n-rsize),max(rank_ex))
	b5tmp = data.frame(date = as_of,cusip = b_data$security[inx],description = b_data$description[inx],rating = b_data$rating[inx], 
				coupon = b_data$coupon[inx], maturity = b_data$maturity[inx],OAS = format(b_data$oas[inx],digits = 1),yield = b_data$yield[inx],Duration = b_data$dur[inx],
				calldate = b_data$calldate[inx],sector = b_data$sector[inx],unrealized_gainloss = b_data$gain_loss[inx],
				er_3m_fc = b_data$er_fc_3m[inx],intercept = b_data$intercept[1],credit_dur = b_data$credit_duration[inx],
	       		Mispricing = b_data$residual[inx],tr_3m_fc = b_data$tr_3m_fc[inx],Carry = b_data$carry[inx],Roll = b_data$roll[inx],
       		Term = b_data$term[inx],Convexity = b_data$convexity[inx],credit_curve = b_data$credit_curve[inx],
       		state_oas = b_data$state[inx],sector_oas = b_data$sector_oas[inx],coupon_effect = b_data$coupon_effect[inx],
       		extension_risk = b_data$extension_risk[inx],zero_coupon = b_data$zero_coupon[inx],resi_oas = b_data$resi_oas[inx])
    b5tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')] = 
	round(b5tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')]*400,digits = 2)     		
	b5tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')] = 
	round(b5tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')])	
	b5tmp[,c('yield')] = round(as.numeric(as.character(b5tmp[,c('yield')])),digits = 2)
	b5tmp[,c('unrealized_gainloss')] = round(as.numeric(as.character(b5tmp[,c('unrealized_gainloss')])),digits = 2)
	b5tmp = b5tmp[order(b5tmp$er_3m_fc),]
	
	#grp1tmp = rbind(grp1tmp,b1tmp)
	#grp5tmp = rbind(grp5tmp,b5tmp)
}

ccc_data = port_data[which(port_data$rating == 'CCC+' | port_data$rating == 'CCC' | port_data$rating == 'CCC-'),]
cat(paste("forecast available for ",dim(ccc_data)[1]," CCC securities\n",sep=''))
if(dim(ccc_data)[1] >= 2*rsize)
{
	rank_ex <- rank(-ccc_data$er_fc_3m)
	n <- length(rank_ex)
	
	inx = rank_ex <= max(rsize,min(rank_ex))
	ccc1tmp = data.frame(date = as_of,cusip = ccc_data$security[inx],description = ccc_data$description[inx],rating = ccc_data$rating[inx], 
				coupon = ccc_data$coupon[inx], maturity = ccc_data$maturity[inx],OAS = format(ccc_data$oas[inx],digits = 1),yield = ccc_data$yield[inx],Duration = ccc_data$dur[inx],
				calldate = ccc_data$calldate[inx],sector = ccc_data$sector[inx],unrealized_gainloss = ccc_data$gain_loss[inx],
				er_3m_fc = ccc_data$er_fc_3m[inx],intercept = ccc_data$intercept[1],credit_dur = ccc_data$credit_duration[inx],
	       		Mispricing = ccc_data$residual[inx],tr_3m_fc = ccc_data$tr_3m_fc[inx],Carry = ccc_data$carry[inx],Roll = ccc_data$roll[inx],
       		Term = ccc_data$term[inx],Convexity = ccc_data$convexity[inx],credit_curve = ccc_data$credit_curve[inx],
       		state_oas = ccc_data$state[inx],sector_oas = ccc_data$sector_oas[inx],coupon_effect = ccc_data$coupon_effect[inx],
       		extension_risk = ccc_data$extension_risk[inx],zero_coupon = ccc_data$zero_coupon[inx],resi_oas = ccc_data$resi_oas[inx])
    ccc1tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')] = 
	round(ccc1tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')]*400,digits = 2)     		
	ccc1tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')] = 
	round(ccc1tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')])	
	ccc1tmp[,c('yield')] = round(as.numeric(as.character(ccc1tmp[,c('yield')])),digits = 2)
	ccc1tmp[,c('unrealized_gainloss')] = round(as.numeric(as.character(ccc1tmp[,c('unrealized_gainloss')])),digits = 2)
	ccc1tmp = ccc1tmp[order(ccc1tmp$er_3m_fc,decreasing = T),]
	inx = rank_ex >= min((n-rsize),max(rank_ex))
	ccc5tmp = data.frame(date = as_of,cusip = ccc_data$security[inx],description = ccc_data$description[inx],rating = ccc_data$rating[inx], 
				coupon = ccc_data$coupon[inx], maturity = ccc_data$maturity[inx],OAS = format(ccc_data$oas[inx],digits = 1),yield = ccc_data$yield[inx],Duration = ccc_data$dur[inx],
				calldate = ccc_data$calldate[inx],sector = ccc_data$sector[inx],unrealized_gainloss = ccc_data$gain_loss[inx],
				er_3m_fc = ccc_data$er_fc_3m[inx],intercept = ccc_data$intercept[1],credit_dur = ccc_data$credit_duration[inx],
	       		Mispricing = ccc_data$residual[inx],tr_3m_fc = ccc_data$tr_3m_fc[inx],Carry = ccc_data$carry[inx],Roll = ccc_data$roll[inx],
       		Term = ccc_data$term[inx],Convexity = ccc_data$convexity[inx],credit_curve = ccc_data$credit_curve[inx],
       		state_oas = ccc_data$state[inx],sector_oas = ccc_data$sector_oas[inx],coupon_effect = ccc_data$coupon_effect[inx],
       		extension_risk = ccc_data$extension_risk[inx],zero_coupon = ccc_data$zero_coupon[inx],resi_oas = ccc_data$resi_oas[inx])
    ccc5tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')] = 
	round(ccc5tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')]*400,digits = 2)     		
	ccc5tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')] = 
	round(ccc5tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')])	
	ccc5tmp[,c('yield')] = round(as.numeric(as.character(ccc5tmp[,c('yield')])),digits = 2)
	ccc5tmp[,c('unrealized_gainloss')] = round(as.numeric(as.character(ccc5tmp[,c('unrealized_gainloss')])),digits = 2)
	ccc5tmp = ccc5tmp[order(ccc5tmp$er_3m_fc),]
	
	#grp1tmp = rbind(grp1tmp,ccc1tmp)
	#grp5tmp = rbind(grp5tmp,ccc5tmp)
}

cc_data = port_data[which(port_data$rating == 'CC+' | port_data$rating == 'CC' | port_data$rating == 'CC-'),]
cat(paste("forecast available for ",dim(cc_data)[1]," CC securities\n",sep=''))
if(dim(cc_data)[1] >= 2*rsize)
{
	rank_ex <- rank(-cc_data$er_fc_3m)
	n <- length(rank_ex)
	
	inx = rank_ex <= max(rsize,min(rank_ex))
	cc1tmp = data.frame(date = as_of,cusip = cc_data$security[inx],description = cc_data$description[inx],rating = cc_data$rating[inx], 
				coupon = cc_data$coupon[inx], maturity = cc_data$maturity[inx],OAS = format(cc_data$oas[inx],digits = 1),yield = cc_data$yield[inx],Duration = cc_data$dur[inx],
				calldate = cc_data$calldate[inx],sector = cc_data$sector[inx],unrealized_gainloss = cc_data$gain_loss[inx],
				er_3m_fc = cc_data$er_fc_3m[inx],intercept = cc_data$intercept[1],credit_dur = cc_data$credit_duration[inx],
	       		Mispricing = cc_data$residual[inx],tr_3m_fc = cc_data$tr_3m_fc[inx],Carry = cc_data$carry[inx],Roll = cc_data$roll[inx],
       		Term = cc_data$term[inx],Convexity = cc_data$convexity[inx],credit_curve = cc_data$credit_curve[inx],
       		state_oas = cc_data$state[inx],sector_oas = cc_data$sector_oas[inx],coupon_effect = cc_data$coupon_effect[inx],
       		extension_risk = cc_data$extension_risk[inx],zero_coupon = cc_data$zero_coupon[inx],resi_oas = cc_data$resi_oas[inx])
    cc1tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')] = 
	round(cc1tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')]*400,digits = 2)     		
	cc1tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')] = 
	round(cc1tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')])	
	cc1tmp[,c('yield')] = round(as.numeric(as.character(cc1tmp[,c('yield')])),digits = 2)
	cc1tmp[,c('unrealized_gainloss')] = round(as.numeric(as.character(cc1tmp[,c('unrealized_gainloss')])),digits = 2)
	cc1tmp = cc1tmp[order(cc1tmp$er_3m_fc,decreasing = T),]
	inx = rank_ex >= min((n-rsize),max(rank_ex))
	cc5tmp = data.frame(date = as_of,cusip = cc_data$security[inx],description = cc_data$description[inx],rating = cc_data$rating[inx], 
				coupon = cc_data$coupon[inx], maturity = cc_data$maturity[inx],OAS = format(cc_data$oas[inx],digits = 1),yield = cc_data$yield[inx],Duration = cc_data$dur[inx],
				calldate = cc_data$calldate[inx],sector = cc_data$sector[inx],unrealized_gainloss = cc_data$gain_loss[inx],
				er_3m_fc = cc_data$er_fc_3m[inx],intercept = cc_data$intercept[1],credit_dur = cc_data$credit_duration[inx],
	       		Mispricing = cc_data$residual[inx],tr_3m_fc = cc_data$tr_3m_fc[inx],Carry = cc_data$carry[inx],Roll = cc_data$roll[inx],
       		Term = cc_data$term[inx],Convexity = cc_data$convexity[inx],credit_curve = cc_data$credit_curve[inx],
       		state_oas = cc_data$state[inx],sector_oas = cc_data$sector_oas[inx],coupon_effect = cc_data$coupon_effect[inx],
       		extension_risk = cc_data$extension_risk[inx],zero_coupon = cc_data$zero_coupon[inx],resi_oas = cc_data$resi_oas[inx])
    cc5tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')] = 
	round(cc5tmp[,c('er_3m_fc','intercept','credit_dur','Mispricing','tr_3m_fc','Carry','Roll','Term','Convexity')]*400,digits = 2)     		
	cc5tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')] = 
	round(cc5tmp[,c('credit_curve','state_oas','sector_oas','coupon_effect','extension_risk','zero_coupon','resi_oas')])	
	cc5tmp[,c('yield')] = round(as.numeric(as.character(cc5tmp[,c('yield')])),digits = 2)
	cc5tmp[,c('unrealized_gainloss')] = round(as.numeric(as.character(cc5tmp[,c('unrealized_gainloss')])),digits = 2)
	cc5tmp = cc5tmp[order(cc5tmp$er_3m_fc),]
	
	#grp1tmp = rbind(grp1tmp,cc1tmp)
	#grp5tmp = rbind(grp5tmp,cc5tmp)
}

names(grp1tmp)[names(grp1tmp) == 'yield'] = "Yield"
names(grp5tmp)[names(grp5tmp) == 'yield'] = "Yield"

names(grp1tmp)[names(grp1tmp) == 'calldate'] = "Call date"
names(grp5tmp)[names(grp5tmp) == 'calldate'] = "Call date"

names(grp1tmp)[names(grp1tmp) == 'sector'] = "Sector"
names(grp5tmp)[names(grp5tmp) == 'sector'] = "Sector"

names(grp1tmp)[names(grp1tmp) == 'cusip'] = "Security"
names(grp5tmp)[names(grp5tmp) == 'cusip'] = "Security"

names(grp1tmp)[names(grp1tmp) == 'description'] = "Description"
names(grp5tmp)[names(grp5tmp) == 'description'] = "Description"

names(grp1tmp)[names(grp1tmp) == 'rating'] = "Rating"
names(grp5tmp)[names(grp5tmp) == 'rating'] = "Rating"

names(grp1tmp)[names(grp1tmp) == 'coupon'] = "Coupon"
names(grp5tmp)[names(grp5tmp) == 'coupon'] = "Coupon"

names(grp1tmp)[names(grp1tmp) == 'maturity'] = "Maturity"
names(grp5tmp)[names(grp5tmp) == 'maturity'] = "Maturity"

names(grp1tmp)[names(grp1tmp) == 'unrealized_gainloss'] = "Gain/Loss"
names(grp5tmp)[names(grp5tmp) == 'unrealized_gainloss'] = "Gain/Loss"

names(grp1tmp)[names(grp1tmp) == 'er_3m_fc'] = "ER 3M FC"
names(grp5tmp)[names(grp5tmp) == 'er_3m_fc'] = "ER 3M FC"

names(grp1tmp)[names(grp1tmp) == 'intercept'] = "Average ER"
names(grp5tmp)[names(grp5tmp) == 'intercept'] = "Average ER"

names(grp1tmp)[names(grp1tmp) == 'credit_dur'] = "Credit/Dur"
names(grp5tmp)[names(grp5tmp) == 'credit_dur'] = "Credut/Dur"

names(grp1tmp)[names(grp1tmp) == 'tr_3m_fc'] = "TR 3M FC"
names(grp5tmp)[names(grp5tmp) == 'tr_3m_fc'] = "TR 3M FC"

names(grp1tmp)[names(grp1tmp) == 'credit_curve'] = "Credit/Dur OAS"
names(grp5tmp)[names(grp5tmp) == 'credit_curve'] = "Credit/Dur OAS"

names(grp1tmp)[names(grp1tmp) == 'state_oas'] = "State OAS"
names(grp5tmp)[names(grp5tmp) == 'state_oas'] = "State OAS"

names(grp1tmp)[names(grp1tmp) == 'sector_oas'] = "Sector OAS"
names(grp5tmp)[names(grp5tmp) == 'sector_oas'] = "Sector OAS"

names(grp1tmp)[names(grp1tmp) == 'coupon_effect'] = "Deminimis OAS"
names(grp5tmp)[names(grp5tmp) == 'coupon_effect'] = "Deminimis OAS"

names(grp1tmp)[names(grp1tmp) == 'resi_oas'] = "Residual OAS"
names(grp5tmp)[names(grp5tmp) == 'resi_oas'] = "Residual OAS"

names(grp1tmp)[names(grp1tmp) == 'Carry'] = "AAA Carry"
names(grp5tmp)[names(grp5tmp) == 'Carry'] = "AAA Carry"

names(grp1tmp)[names(grp1tmp) == 'Term'] = "AAA Term"
names(grp5tmp)[names(grp5tmp) == 'Term'] = "AAA Term"

names(grp1tmp)[names(grp1tmp) == 'Roll'] = "AAA Roll"
names(grp5tmp)[names(grp5tmp) == 'Roll'] = "AAA Roll"

names(grp1tmp)[names(grp1tmp) == 'extension_risk'] = "Extension Risk"
names(grp5tmp)[names(grp5tmp) == 'extension_risk'] = "Extension Risk"

names(grp1tmp)[names(grp1tmp) == 'zero_coupon'] = "Zero Coupon"
names(grp5tmp)[names(grp5tmp) == 'zero_coupon'] = "Zero Coupon"

sect = sub("Muni - ","",sect)
sect = sub("/"," ",sect)
filename1 = paste(sect," ",format(as_of,format = "%Y%m%d"),".csv",sep='')


if(!is.null(opt$repo)) setwd(opt$repo)

write.table(data.frame(date = grp1tmp[1,1],desc = paste(sect," cheapest holdings",sep = '')),file = filename1,na = "",sep = ",",row.names = F,col.names = F)
write.table(grp1tmp[,2:dim(grp1tmp)[2]],file = filename1,na = "",sep = ",",row.names = F,append = T)
if(dim(aaa_data)[1] >= 2*rsize)
{
write.table(data.frame(desc = "AAA cheapest"),file = filename1,na = "",sep = ",",row.names = F,col.names = F,append = T)
write.table(aaa1tmp[,2:dim(grp1tmp)[2]],file = filename1,na = "",sep = ",",row.names = F,append = T,col.names = F)
}
if(dim(aa_data)[1] >= 2*rsize)
{
write.table(data.frame(desc = "AA cheapest"),file = filename1,na = "",sep = ",",row.names = F,col.names = F,append = T)
write.table(aa1tmp[,2:dim(grp1tmp)[2]],file = filename1,na = "",sep = ",",row.names = F,append = T,col.names = F)
}
if(dim(a_data)[1] >= 2*rsize)
{
write.table(data.frame(desc = "A cheapest"),file = filename1,na = "",sep = ",",row.names = F,col.names = F,append = T)
write.table(a1tmp[,2:dim(grp1tmp)[2]],file = filename1,na = "",sep = ",",row.names = F,append = T,col.names = F)
}
if(dim(bbb_data)[1] >= 2*rsize)
{
write.table(data.frame(desc = "BBB cheapest"),file = filename1,na = "",sep = ",",row.names = F,col.names = F,append = T)
write.table(bbb1tmp[,2:dim(grp1tmp)[2]],file = filename1,na = "",sep = ",",row.names = F,append = T,col.names = F)
}
if(dim(bb_data)[1] >= 2*rsize)
{
write.table(data.frame(desc = "BB cheapest"),file = filename1,na = "",sep = ",",row.names = F,col.names = F,append = T)
write.table(bb1tmp[,2:dim(grp1tmp)[2]],file = filename1,na = "",sep = ",",row.names = F,append = T,col.names = F)
}
if(dim(b_data)[1] >= 2*rsize)
{
write.table(data.frame(desc = "B cheapest"),file = filename1,na = "",sep = ",",row.names = F,col.names = F,append = T)
write.table(b1tmp[,2:dim(grp1tmp)[2]],file = filename1,na = "",sep = ",",row.names = F,append = T,col.names = F)
}	
if(dim(ccc_data)[1] >= 2*rsize)
{
write.table(data.frame(desc = "CCC cheapest"),file = filename1,na = "",sep = ",",row.names = F,col.names = F,append = T)
write.table(ccc1tmp[,2:dim(grp1tmp)[2]],file = filename1,na = "",sep = ",",row.names = F,append = T,col.names = F)
}
if(dim(cc_data)[1] >= 2*rsize)
{
write.table(data.frame(desc = "CC cheapest"),file = filename1,na = "",sep = ",",row.names = F,col.names = F,append = T)
write.table(cc1tmp[,2:dim(grp1tmp)[2]],file = filename1,na = "",sep = ",",row.names = F,append = T,col.names = F)
}

write.table(data.frame(date = grp5tmp[1,1],desc = paste(sect," richest holdings",sep = '')),file = filename1,
	na = "",sep = ",",row.names = F,col.names = F,append = T)
write.table(grp5tmp[,2:dim(grp5tmp)[2]],file = filename1,na = "",sep = ",",row.names = F,append = T)
if(dim(aaa_data)[1] >= 2*rsize)
{
write.table(data.frame(desc = "AAA richest"),file = filename1,na = "",sep = ",",row.names = F,col.names = F,append = T)
write.table(aaa5tmp[,2:dim(grp5tmp)[2]],file = filename1,na = "",sep = ",",row.names = F,append = T,col.names = F)
}
if(dim(aa_data)[1] >= 2*rsize)
{
write.table(data.frame(desc = "AA richest"),file = filename1,na = "",sep = ",",row.names = F,col.names = F,append = T)
write.table(aa5tmp[,2:dim(grp5tmp)[2]],file = filename1,na = "",sep = ",",row.names = F,append = T,col.names = F)
}
if(dim(a_data)[1] >= 2*rsize)
{
write.table(data.frame(desc = "A richest"),file = filename1,na = "",sep = ",",row.names = F,col.names = F,append = T)
write.table(a5tmp[,2:dim(grp5tmp)[2]],file = filename1,na = "",sep = ",",row.names = F,append = T,col.names = F)
}
if(dim(bbb_data)[1] >= 2*rsize)
{
write.table(data.frame(desc = "BBB richest"),file = filename1,na = "",sep = ",",row.names = F,col.names = F,append = T)
write.table(bbb5tmp[,2:dim(grp5tmp)[2]],file = filename1,na = "",sep = ",",row.names = F,append = T,col.names = F)
}
if(dim(bb_data)[1] >= 2*rsize)
{
write.table(data.frame(desc = "BB richest"),file = filename1,na = "",sep = ",",row.names = F,col.names = F,append = T)
write.table(bb5tmp[,2:dim(grp5tmp)[2]],file = filename1,na = "",sep = ",",row.names = F,append = T,col.names = F)
}
if(dim(b_data)[1] >= 2*rsize)
{
write.table(data.frame(desc = "B richest"),file = filename1,na = "",sep = ",",row.names = F,col.names = F,append = T)
write.table(b5tmp[,2:dim(grp5tmp)[2]],file = filename1,na = "",sep = ",",row.names = F,append = T,col.names = F)
}	
if(dim(ccc_data)[1] >= 2*rsize)
{
write.table(data.frame(desc = "CCC richest"),file = filename1,na = "",sep = ",",row.names = F,col.names = F,append = T)
write.table(ccc5tmp[,2:dim(grp5tmp)[2]],file = filename1,na = "",sep = ",",row.names = F,append = T,col.names = F)
}	
if(dim(cc_data)[1] >= 2*rsize)
{
write.table(data.frame(desc = "CC richest"),file = filename1,na = "",sep = ",",row.names = F,col.names = F,append = T)
write.table(cc5tmp[,2:dim(cc5tmp)[2]],file = filename1,na = "",sep = ",",row.names = F,append = T,col.names = F)
}	


cat(paste("file ",filename1," saved to ",getwd(),"\n",sep=''))


port_data = port_data_bk
}
}

q(status=0)