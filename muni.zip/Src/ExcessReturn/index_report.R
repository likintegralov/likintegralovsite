#!\\nts0018\bond\ABFI_PROD\QuantApps\R-2.14.2\bin\Rscript

source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.dev2.R',sep='') )

setwd(paste(Sys.getenv('ABFI_DATA_REPOSITORY'),'\\Muni\\v1.0\\Input',sep='') )


################################################################################
################################################################################
library('getopt')
opt = getopt(matrix(
    c(
    'db',   's', 2, "character",
    'as_of','d', 2, "character",
    'port',	'p', 1, "character",
    'repo', 'r', 2, "character",
    'help', 'h', 0, "logical"
    ),ncol=4,byrow=TRUE)
)

if ( !is.null(opt$help))# || is.null(opt$port)) 
{
  self = 'Rscript load_data.R'
  cat(paste("
    Usage: ",self,"  [--as_of date] [--help]  
        db:   Database server to run the script on (PRD/QA/DEV).
        as_of:as_of date in yyyy-mm-dd format. default to last business day. Optional
        port:	Portfolio ID (as in DAILYVIEW..POSITION_HISTORY). Required      
        repo:	Location to save reports
        help: Show help.  Optional
    Example: RScript load_data.R --db PRD --as_of 2012-02-15
  ",sep=""))
  q(status=1)
}


if ( is.null(opt$db) ) opt$db = 'QA'
if ( is.null(opt$as_of) ) { opt$as_of = Sys.Date()-1 }
as_of <- last.business.day( as.Date(opt$as_of) )
as_of = as.Date('2016-06-03')

load('MuniParBondRet.RData')


###############################################################################
#source('H:/SVN/Muni/v1.0/Src/ExcessReturn/index_report.R') 
setwd(paste(Sys.getenv('ABFI_DATA_REPOSITORY'),'\\Muni\\v1.0\\Output',sep='') )
library(RODBC)
db_info <- get_db_info(opt$db)
db_prd <- get_db_info('PRD')

#q = paste("select ACCOUNT_ID, SHORT_NAME, ALTERNATE_IDENTIFIER ALT_ID, LONG_NAME from DAILYVIEW..ACCTS_PORTFOLIOS
#		where SHORT_NAME = '",port_name,"'",sep='')

channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
	
gsize = 25

channel_prd <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_prd$Database,';DataBase=',db_prd$InitDB,';uid=',db_prd$User,';pwd=',db_prd$Password,sep=''))

q = paste("select distinct substring(a.IDENTIFIER,1,8),a.DESCRIPTION description,a.COUPON coupon,",
				"a.MATURITY_DATE maturity,a.MUNI_OAD dur, s.AB_SECTOR sector, a.MUNI_OAS_RISK oas,a.MUNI_6MO_KRD,",
				"a.MUNI_2YR_KRD,a.MUNI_5YR_KRD,a.MUNI_10YR_KRD,a.MUNI_20YR_KRD,a.MUNI_30YR_KRD,a.SP_RATING rating, ",
				"a.YIELD_TO_WORST yield,a.TIME_TO_WORST from FIQModel..MUNI_SECTOR_CODE sc, FIQModel..MUNI_SECTOR s, ",  
				"Optimizer..MUNI_ANALYTICS a where a.EFFECTIVE_DATE = '",format(as_of),"' ",
				"and a.IDENTIFIER = sc.IDENTIFIER ",
				"and sc.AB_CODE = s.AB_CODE and a.SOURCE = 'Barcap'",sep='')

port_secs <- sqlQuery(channel_prd,query=q)
names(port_secs)<-tolower(names(port_secs))

odbcClose(channel_prd)

q = paste("select er.*, oas.INDEX_OAS,oas.CREDIT_CURVE,oas.STATE,oas.SECTOR sector_oas,oas.COUPON_EFFECT,oas.RESI_OAS ",
			"from FIQModel..MUNI_EXPECTED_RETURN_DECOMPOSITION er, ",
			"FIQModel..MUNI_OAS_DECOMPOSITION oas ",
			"where er.AS_OF_DATE = '",format(as_of),"' and er.AS_OF_DATE = oas.AS_OF_DATE ",
			"and er.IDENTIFIER = oas.IDENTIFIER",sep='')

ret_decomp <- sqlQuery(channel,query=q)

odbcClose(channel)				
channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_prd$Database,';DataBase=',db_prd$InitDB,';uid=',db_prd$User,';pwd=',db_prd$Password,sep=''))

q = paste("select distinct VALUE_DATE as_of, SECURITY_ID security, UNREALIZED_GAIN_LOSS_PCT unrealized_gainloss,YIELD yield, ", 
		"INTERNAL_RATING rating, NEXT_CALL_DATE calldate from Optimizer..MUNI_POSITION ",
		"where VALUE_DATE = '",format(as_of),"'",sep='')
unreal_gl <- sqlQuery(channel,query=q)

odbcClose(channel)				

names(ret_decomp) = casefold(names(ret_decomp),upper=F)

inxa = which(!is.na(match(port_secs[,1], unreal_gl$security)))
inxb = na.exclude(match(port_secs[,1], unreal_gl$security))
names(port_secs)[names(port_secs) == 'unrealized_gainloss'] = 'gain_loss'

port_secs$gain_loss = NA
port_secs$gain_loss[inxa] = unreal_gl$unrealized_gainloss[inxb]
port_secs$rating = as.character(port_secs$rating)
port_secs$rating[inxa] = sub("/","",unreal_gl$rating[inxb])
port_secs$yield[inxa] = unreal_gl$yield[inxb]
port_secs$calldate = as.Date('1970-01-01')
port_secs$calldate[inxa] = as.Date(unreal_gl$calldate[inxb])
port_secs$calldate[port_secs$calldate == as.Date('1970-01-01')] = NA

inxa = which(!is.na(match(port_secs[,1], ret_decomp$identifier)))
inxb = na.exclude(match(port_secs[,1], ret_decomp$identifier))
port_data = cbind(port_secs[inxa,],ret_decomp[inxb,c('excess_expected_return_3m','intercept','credit_curve_reversion','residual_oas_reversion',
														'index_oas','credit_curve','state','sector_oas','coupon_effect','resi_oas')])

names(port_data)[1] = 'security'
names(port_data)[names(port_data) == 'excess_expected_return_3m'] = 'er_fc_3m'
names(port_data)[names(port_data) == 'credit_curve_reversion'] = 'credit_duration'
names(port_data)[names(port_data) == 'residual_oas_reversion'] = 'residual'
port_data$as_of_date = as_of

port_data = calc_returns(port_data,dur,yld_fixed)
names(port_data)[names(port_data) == 'krd_ret_fwd3m_fc'] = 'carry'
port_data = calc_returns(port_data,dur,roll)
names(port_data)[names(port_data) == 'krd_ret_fwd3m_fc'] = 'roll'
port_data = calc_returns(port_data,dur,term_fc)
names(port_data)[names(port_data) == 'krd_ret_fwd3m_fc'] = 'term'
port_data = calc_returns(port_data,dur,conv)
names(port_data)[names(port_data) == 'krd_ret_fwd3m_fc'] = 'convexity'
port_data = calc_returns(port_data,dur,ret_fc)

port_data$tr_3m_fc = port_data$krd_ret_fwd3m_fc + port_data$er_fc_3m

port_data = port_data[order(port_data$security),]
#exlude defaults
inx = port_data$rating != 'D'
inx[is.na(inx)] = TRUE
port_data = port_data[inx,]

#apply filter if needed


# portmunis = get_factor_exposure(portmunis,db_prd,'residual',T)
# port_data = cbind(port_data,data.frame(credit_oad = portmunis$credit_oad))
# port_data$credit_oad = port_data$credit_curve - port_data$credit_oad

names(port_data)[names(port_data) == 'yield'] = "Yield"
names(port_data)[names(port_data) == 'calldate'] = "Call date"
names(port_data)[names(port_data) == 'sector'] = "Sector"
names(port_data)[names(port_data) == 'security'] = "Security"
names(port_data)[names(port_data) == 'dur'] = "Duration"
names(port_data)[names(port_data) == 'oas'] = "OAS"
names(port_data)[names(port_data) == 'description'] = "Description"
names(port_data)[names(port_data) == 'rating'] = "Rating"
names(port_data)[names(port_data) == 'coupon'] = "Coupon"
names(port_data)[names(port_data) == 'maturity'] = "Maturity"
names(port_data)[names(port_data) == 'gain_loss'] = "Gain/Loss"
names(port_data)[names(port_data) == 'er_fc_3m'] = "ER 3M FC"
names(port_data)[names(port_data) == 'intercept'] = "Average ER"
names(port_data)[names(port_data) == 'credit_duration'] = "Credit/Dur"
names(port_data)[names(port_data) == 'tr_3m_fc'] = "TR 3M FC"
names(port_data)[names(port_data) == 'index_oas'] = "Index OAS"
names(port_data)[names(port_data) == 'credit_curve'] = "Credit/Dur OAS"
names(port_data)[names(port_data) == 'state_oas'] = "State OAS"
names(port_data)[names(port_data) == 'sector_oas'] = "Sector OAS"
names(port_data)[names(port_data) == 'coupon_effect'] = "Deminimis OAS"
names(port_data)[names(port_data) == 'residual'] = "Mispricing"
names(port_data)[names(port_data) == 'resi_oas'] = "Residual OAS"
names(port_data)[names(port_data) == 'carry'] = "AAA Carry"
names(port_data)[names(port_data) == 'term'] = "AAA Term"
names(port_data)[names(port_data) == 'roll'] = "AAA Roll"
names(port_data)[names(port_data) == 'convexity'] = "AAA convexity"
names(port_data)[names(port_data) == 'state'] = "State OAS"
#names(port_data)[names(port_data) == 'credit_oad'] = "Hist Credit/Dur"

port_data = port_data[,!(names(port_data) == 'as_of_date' | names(port_data) == 'krd_ret_fwd3m_fc')]

#tmp = port_data[(port_data$Rating == 'AAA' | port_data$Rating == 'AAA-' | port_data$Rating == 'AA+' | port_data$Rating == 'AA' | port_data$Rating == 'AA-') &
#						(is.na(port_data$time_to_worst) | port_data$time_to_worst > 5) & 
#						(as.Date(port_data$Maturity) > as.Date('2025-01-12') & as.Date(port_data$Maturity) < as.Date('2035-01-12')),]

write.csv(port_data,file = paste("Index 3 ",as_of,".csv",sep=''))
#write.csv(tmp,file = paste("Index filtered ",as_of,".csv",sep=''))