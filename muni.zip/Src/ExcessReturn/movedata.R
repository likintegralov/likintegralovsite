
source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.kal.R',sep='') )

#source('H:/SVN/Muni/v1.0/Src/ExcessReturn/movedata.R')

dates = as.Date(c('2017-01-31',
'2017-02-28',
'2017-03-31',
'2017-04-28',
'2017-05-31',
'2017-06-30',
'2017-07-31',
'2017-08-31',
'2017-09-29',
'2017-10-31',
'2017-11-30',
'2017-12-29',
'2018-01-31',
'2018-02-28',
'2018-03-29',
'2018-04-30'))

#dates = as.Date('2017-01-30')

library(RODBC)
db_qa <- get_db_info('QA')
db_prd <- get_db_info('PRD')

for( i in 1:length(dates))
{
	q = paste("select * from Optimizer..MUNI_ANALYTICS_KALOTAY where EFFECTIVE_DATE = '",format(dates[i],'%d-%b-%Y'),"' and SOURCE = 'Index'",sep = '')
	prd = channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_prd$Database,';DataBase=',db_prd$InitDB,';uid=',db_prd$User,';pwd=',db_prd$Password,sep=''))
	data = sqlQuery(prd,query=q )
	
	odbcClose(prd)
	
	qa = channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_qa$Database,';DataBase=',db_qa$InitDB,';uid=',db_qa$User,';pwd=',db_qa$Password,sep=''))
	sqlQuery(qa,query=paste("delete from Optimizer..MUNI_ANALYTICS_KALOTAY where EFFECTIVE_DATE = '",format(dates[i],'%d-%b-%Y'),"' and SOURCE = 'Index'",sep='') )
	
	export2db(data=data,server_type='SQL',server=db_qa$Database,db='Optimizer',table='MUNI_ANALYTICS_KALOTAY',user=db_qa$User,psw=db_qa$Password,na='')
}