
source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.R',sep='') )

#source('H:/SVN/Muni/v1.0/Src/ExcessReturn/oas_decomp.1.R')

setwd('H:/SVN/Muni/v1.0/Src/ExcessReturn')
library(RODBC)
library(timeDate)
library(mgcv)

db_info <- get_db_info('PRD')

dates = seq(timeDate("2012-05-01"),timeDate(Sys.Date()),by="months")-1

for(i in 1:length(dates))
{
	while(!isWeekday(dates[i]))
	{
		dates[i] = dates[i] - 24*3600
	}
}
dates = as.Date(dates)

dates = as.Date('2014-08-20')


#date.end.month <- seq(as.Date("2012-02-01"),length=4,by="months")-1
attrdata = c();
dbconn = odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))

for(i in 1:length(dates))
{
# q = paste("select d.AS_OF_DATE, d.IDENTIFIER,d.SECTOR,d.STATE,d.INDEX_OAS,d.COUPON_EFFECT, d.CREDIT_CURVE,d.RESI_OAS, a.CALL_TYPE, a.PRICE, ",
# 			"a.MUNI_OAD, a.COUPON, a.MUNI_OAS, a.MUNI_OAC convexity, a.TIME_TO_WORST, a.MATURITY_DATE,",
# 			"a.SP_RATING, a.FITCH_RATING,a.MOODY_RATING from FIQModel..MUNI_OAS_DECOMPOSITION d, Optimizer..MUNI_ANALYTICS a ",
# 			"WHERE d.AS_OF_DATE = a.EFFECTIVE_DATE ",
# 			"and d.IDENTIFIER = a.IDENTIFIER and d.AS_OF_DATE = '",format(dates[i],"%Y-%m-%d"),"' ",sep = '')
			
q = paste("select d.AS_OF_DATE, d.IDENTIFIER, d.TOTAL_EXPECTED_RETURN_3M,d.EXCESS_EXPECTED_RETURN_3M, ",
			"d.INTERCEPT,d.CREDIT_CURVE_REVERSION,d.RESIDUAL_OAS_REVERSION, a.CALL_TYPE, a.PRICE, ",
			"a.MUNI_OAD, a.COUPON, a.MUNI_OAS, a.MUNI_OAC convexity, a.TIME_TO_WORST, a.MATURITY_DATE,",
			"a.SP_RATING, a.FITCH_RATING,a.MOODY_RATING from FIQModel..MUNI_EXPECTED_RETURN_DECOMPOSITION d, Optimizer..MUNI_ANALYTICS a ",
			"WHERE d.AS_OF_DATE = a.EFFECTIVE_DATE ",
			"and d.IDENTIFIER = a.IDENTIFIER and d.AS_OF_DATE = '",format(dates[i],"%Y-%m-%d"),"' ",sep = '')

#attrdata = sqlQuery(dbconn,query=q)			
attrdata = rbind(attrdata,sqlQuery(dbconn,query=q))
}
odbcClose(dbconn)

names(attrdata) <- tolower(names(attrdata))

names(attrdata)[names(attrdata) == c('maturity_date')] = 'maturity'
attrdata$maturity = as.numeric(difftime(as.Date(attrdata[,c('maturity')]), as.Date(attrdata[,c('as_of_date')])))/365.25

require(graphics)
palette()
# dur = seq(1,max(attrdata$muni_oad),1)
# mat = seq(1,max(attrdata$maturity),1)

dur_bksize = 2
dur = seq(1,17,dur_bksize)
mat_bksize = 2
mat = seq(2,30,2)

#dates = dates[dates == as.Date('2014-01-31')]

#for(i in 1:length(dates))
#{
## pick a month
#mdata = attrdata[as.Date(attrdata$as_of_date) == dates[i],]
#if(dim(mdata)[1] > 0)
#{
## only callable
#mdata = mdata[mdata$call_type != 'NONCALL',]

#ix <- mdata$muni_oas>quantile(mdata$muni_oas,0.975,na.rm=T) | mdata$muni_oas<quantile(mdata$muni_oas,0.025,na.rm=T)
#	mdata <- mdata[!ix,]
##mdata$convexity = winsorise(mdata$convexity,lb=0.01,ub=0.99)

attrdata = attrdata[attrdata$call_type != 'NONCALL',]
attrdata = attrdata[!is.na(attrdata$time_to_worst),]

#firstcall = seq(1,max(attrdata$time_to_worst),1)

cpn = seq(0.25,max(attrdata$coupon),0.5)

fc_bksize = 1
firstcall = seq(1,10,1)



for(k in 1:length(dur))
{
	if(k == 1)
	{
		ix = attrdata$muni_oad <= dur[k]
		attrdata$dur_bucket[ix] = dur[1]
	}else
	{ 
		ix = attrdata$muni_oad > dur[k-1] & attrdata$muni_oad <= dur[k]
		attrdata$dur_bucket[ix] = dur[k]
	}
	if(k == length(dur))
	{
		ix = attrdata$muni_oad > dur[k]
		attrdata$dur_bucket[ix] = dur[k]+dur_bksize
	}
}

for(k in 1:length(mat))
{
	if(k == 1)
	{
		ix = attrdata$maturity <= mat[k]
		attrdata$mat_bucket[ix] = mat[1]
	}else
	{ 
		ix = attrdata$maturity > mat[k-1] & attrdata$maturity <= mat[k]
		attrdata$mat_bucket[ix] = mat[k]
	}
	if(k == length(mat))
	{
		ix = attrdata$maturity > mat[k]
		attrdata$mat_bucket[ix] = mat[k]+1
	}
}

for(k in 1:length(firstcall))
{
	if(k == 1)
	{
		ix = attrdata$muni_oad <= firstcall[k]
		attrdata$firstcall_bucket[ix] = firstcall[1]
	}else
	{ 
		ix = attrdata$muni_oad > firstcall[k-1] & attrdata$muni_oad <= firstcall[k]
		attrdata$firstcall_bucket[ix] = firstcall[k]
	}
	if(k == length(firstcall))
	{
		ix = attrdata$muni_oad > firstcall[k]
		attrdata$firstcall_bucket[ix] = firstcall[k]+fc_bksize
	}
}

for(k in 1:length(cpn))
{
	if(k == 1)
	{
		ix = attrdata$coupon <= cpn[k] - 0.25
		attrdata$coupon_bucket[ix] = cpn[1]
	}else
	{ 
		ix = attrdata$coupon > cpn[k-1] & attrdata$coupon <= cpn[k]
		attrdata$coupon_bucket[ix] = cpn[k] - 0.25
	}
	if(k == length(cpn))
	{
		ix = attrdata$coupon > cpn[k]
		attrdata$coupon_bucket[ix] = cpn[k]+0.25
	}
}

write.csv(attrdata,file = 'tmp.csv')