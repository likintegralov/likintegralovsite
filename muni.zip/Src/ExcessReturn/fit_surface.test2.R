#!\\nts0018\bond\ABFI_PROD\QuantApps\R-2.14.2\bin\Rscript

source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.R',sep='') )

fit_data <- function(as_of,data)
{
	cat('total',nrow(data),'rows of data.\n')
	
	#winsorise
	data$muni_oad <- winsorise(data$muni_oad,lb=0.00,ub=0.99)
	data$deminimis_buffer <- winsorise(data$deminimis_buffer,lb=0.01,ub=0.99)
	data$deminimis_buffer1 <- winsorise(data$deminimis_buffer1,lb=0.01,ub=0.99)
	data$deminimis_buffer2 <- winsorise(data$deminimis_buffer2,lb=0.01,ub=0.99)
	data$time_ratio <- winsorise(data$time_ratio,lb=0.01,ub=0.99)
	
	#factorize
	data$state <- as.factor(data$state)
	data$ab_code <- as.factor(data$ab_code)
	data$muni_taxability <- as.factor(data$muni_taxability)
	
	cat(format(Sys.time()),'running gam...\n')
	fit <- gam( coupon ~ s(deminimis_buffer1,k=4), data = data) 
														
	xnum = 100												
	x = seq(min(data$deminimis_buffer1),max(data$deminimis_buffer1),length.out=xnum)						
	fitres = predict(fit,newdata = data.frame(deminimis_buffer1=x))#,type='terms')	
	#cat(format(Sys.time()),'done.\n')
	
	f1 <- gam( coupon ~ s(deminimis_buffer1,k=4), data = data[data$time_to_maturity-data$time_to_worst < 0.02,]) 
	fitres1 = predict(f1,newdata = data.frame(deminimis_buffer1=x))#,type='terms')
	
	f2 <- gam( coupon ~ s(deminimis_buffer1,k=4), data = data[data$time_to_maturity-data$time_to_worst > 0.02,])

	fitres2 = predict(f2,newdata = data.frame(deminimis_buffer1=x))#,type='terms')
	
	plot(x,fitres,type='line',col='blue',xlab='deminimis buffer',ylab='coupon',
			ylim = range(c(fitres,fitres1,fitres2)))					
	
	lines(x,fitres1,type='line',col='red',lty=2)
	lines(x,fitres2,type='line',col='green',lty=3)

	legend('topright',c('All','Non Callable','Callable'),lty = c(1,2,3),col = c('blue','red','green'),
	bty = 'o',bg = 'white',box.col = 'white',inset = 0.05,cex = 0.8)
	
	title(main = format(as_of))
	#y = predict(f1,newdata = data.frame(deminimis_buffer = x))
	#X =  matrix(c(x,x^2,x^3),nrow = xnum)
	#cinx = grep('deminimis_buffer',names(fit$coefficients))
	#y = X%*%as.matrix(fit$coefficients[cinx])
	
	#plot(fit,select = 2)#,shift = fit$coefficients[1],n = 100,col = 'blue')
	#lines(x,y,type='line',col='blue')
	#f1 = gam(muni_oas ~ s(deminimis_buffer,k=4),data = data)
	#par(new = TRUE)
	#lines(x,y,type = 'line',col = 'red')
	#plot(f1,select = 2)#, shift=f1$coefficients[1],col = 'red', n = 100)
	################################################################################
	#r_sqr <- (fit$null.deviance-fit$deviance)/fit$null.deviance
	
	#cat('r_sqr=',round(r_sqr,2),'\n')
	
	#fit1 <- gam( muni_oas ~ te(credit_rating, muni_oad,k=c(3,4)) + s(deminimis_buffer2,k=4) 
	#						+ state+ ab_code + muni_taxability, data = data) 
	
	#cat('r_sqr2=',round(r_sqr,2),'\n')
	#cat(format(Sys.time()),'done.\n')
	################################################################################
	#r_sqr <- (fit1$null.deviance-fit1$deviance)/fit1$null.deviance
	
	################################################################################
#	plot(fit,rug=F,pers=T,theta=-45,main=format(as_of))
		
	################################################################################
	#first fit credit curve
# 	x <- sort(unique(data$credit_rating))
# 	y <- unique( round( c(min(data$muni_oad),quantile(data$muni_oad,1:100/100) ), 4) )
# 	
# 	states <- sort(unique(data$state))
# 	ab_codes <- sort(unique(data$ab_code))
# 	taxabilities <- sort(unique(data$muni_taxability))
# 	
# 	deminimis_buffers <- seq(min(data$deminimis_buffer),max(data$deminimis_buffer),length.out=100)
# 	
# 	n <- length(x)*length(y)
# 	newdata <- data.frame(credit_rating=rep(x,length(y)),muni_oad=rep(y,rep(length(x),length(y))),
# 		deminimis_buffer=c(deminimis_buffers,rep(deminimis_buffers[length(deminimis_buffers)],n-length(deminimis_buffers))),
# 		state=factor(c(levels(states)[states],rep(levels(states)[1],n-length(states)))),
# 		ab_code=factor(c(levels(ab_codes)[ab_codes],rep(levels(ab_codes)[1],n-length(ab_codes)))),
# 		muni_taxability=factor(c(levels(taxabilities)[taxabilities],rep(levels(taxabilities)[1],n-length(taxabilities))))
# 		)
		
# 	res <- predict(fit,newdata=newdata,type='terms')
	
	#z <- matrix(res[,'te(credit_rating,muni_oad)'],nrow=length(x))
	#persp(x,y,z,theta=-45,xlab='Rating',ylab='muni_oad',zlab='muni_oas')
	
	################################################################################
# 	cat(format(Sys.time()),'writing results...\n')
# 	################################################################################
# 	#credit surface
# 	oas_attr <- data.frame(ID = 1, SECTOR='muni',AS_OF_DATE=as_of,ATTRIBUTE='credit_oad',VALUE1=newdata$credit_rating,VALUE2=newdata$muni_oad,OAS=res[,'te(credit_rating,muni_oad)'])
# 	################################################################################	
# 	xvars_ex_credit <- c('deminimis_buffer','state','ab_code','muni_taxability')
# 	
# 	index_oas <- attr(res,'constant')
# 	################################################################################
# 	for(xvar in xvars_ex_credit)
# 	{
# 		if(is.numeric(data[,xvar]))
# 		{
# 			x <- seq(min(data[,xvar]),max(data[,xvar]),length.out=100)
# 			outdata <- data.frame(x=x,response=res[1:length(x),paste('s(',xvar,')',sep='')])
# 			colnames(outdata)[1] <- xvar 
# 			outdata <- data.frame(ID = 1, SECTOR='muni',AS_OF_DATE=as_of,ATTRIBUTE=xvar,VALUE1=outdata[,xvar],VALUE2=0,OAS=outdata$response)			
# 		}else #is.factor
# 		{
# 			x <- sort(unique(data[,xvar]))
# 			outdata <- data.frame(x=x,response=res[1:length(x),xvar])
# 			colnames(outdata)[1] <- xvar 
# 			wgts <- aggregate(fit$weights,by=list(data[,xvar]),FUN=sum)
# 			names(wgts) <- c(xvar,'wgt')
# 			outdata <- merge(outdata,wgts)
# 			shift <- sum(outdata$response*outdata$wgt)/sum(outdata$wgt)
# 			
# 			outdata$response <- outdata$response - shift
# 			index_oas <- index_oas + shift
# 			
# 			outdata <- data.frame(ID = 1, SECTOR='muni',AS_OF_DATE=as_of,ATTRIBUTE=xvar,VALUE1=as.numeric(levels(outdata[,xvar])),VALUE2=0,OAS=outdata$response)
# 		}
# 		oas_attr <- rbind(oas_attr,outdata)
# 	}
# 	################################################################################
# 	#index_oas
# 	outdata <- data.frame(ID = 1, SECTOR='muni',AS_OF_DATE=as_of,ATTRIBUTE='index_oas',VALUE1=1,VALUE2=0,OAS=index_oas)
# 	oas_attr <- rbind(oas_attr,outdata)
# 
# 	oas_attr$MEAN_OAS <- NA
	
# 	stmt <- paste("delete from OAS_ATTRIBUTION_FIT
# 			where SECTOR ='muni' and AS_OF_DATE='",format(as_of,'%d-%b-%Y'),"'
# 			",sep='')
# 				
# 	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
#     sqlQuery(channel,query=stmt )
#     odbcClose(channel)
#     
#     export2db(data=oas_attr,server_type='SQL',server=db_info$Database,db=db_info$InitDB,table='OAS_ATTRIBUTION_FIT',user=db_info$User,psw=db_info$Password,na='')	
				
	invisible()
}

clear_oas_fit_tables <- function()
{
	#dangerous action. ask the user for confirmation!
	cat("\n","About to delete all muni data in OAS_ATTRIBUTION_FIT table. Are you sure [y/n/a(bort)]?","\n") # prompt 
	y<-scan(what=character(),nmax=1,quiet=T) 
	while(y!='y' & y!='n' & y!='a')
	{
		cat('[y/n/a(bort)]?\n')
		y<-scan(what=character(),nmax=1,quiet=T) 
	}
	
	if(y=='a'){
		stop('abort\n')
	}
	else if(y=='n') 
	{
		cat('muni data in table OAS_ATTRIBUTION_FIT will not be deleted.\n')
	}else
	{
		cat('delete all muni data in OAS_ATTRIBUTION_FIT table.\n')
		channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
		stmt = paste("delete from OAS_ATTRIBUTION_FIT
			where SECTOR ='muni'",sep='')
	    sqlQuery(channel,query=stmt)
	    odbcClose(channel)
	}
	invisible()
}
################################################################################
################################################################################
library('getopt')
opt = getopt(matrix(
    c(
    'db',   's', 2, "character",   
    'as_of','d', 2, "character",
    'help', 'h', 0, "logical"
    ),ncol=4,byrow=TRUE)
)

if ( !is.null(opt$help) ) {
  self = 'Rscript update_factor_loading.R'
  cat(paste("
    Usage: ",self,"  [--all] [--help]  
    	db:   Database server to run the script on (PRD/QA/DEV).
    	as_of:as_of date in yyyy-mm-dd format. if missing, then fit surface for
    	      all month-end dates as well as the very last date. Optional      
        help: Show help.  Optional
    Example: RScript fit_surface.R --db QA --as_of 2012-02-15
  ",sep=""))
  q(status=1)
}

if ( is.null(opt$db) ) opt$db = 'PRD'
###############################################################################
#source('H:/SVN/Muni/v1.0/Src/ExcessReturn/fit_surface.test2.R')
setwd(paste(Sys.getenv('ABFI_DATA_REPOSITORY'),'\\Muni\\v1.0',sep='') )

library(RODBC)
db_info <- get_db_info(opt$db)

#cat('see db info below:\n')
#db_info
#opt$as_of = as.Date('2013-04-30')
#opt$as_of = as.Date('2010-04-30')


if( !is.null(opt$as_of) ) 
{
	dates <- load_muni_analytics_dates(as.Date(opt$as_of),db_info,src='Barcap')
	dates <- dates[dates==last.business.day(as.Date(opt$as_of))]
	if(length(dates)==0) 
	{
		cat('no date exist as of',opt$as_of,'\n')
		q(status=0)
	}
}else
{
	#clear_oas_fit_tables()
	dates <- load_muni_analytics_dates(Sys.Date(),db_info,src='Barcap')
}

library(mgcv)
	
#postscript('Output/gam_plot.eps')
#par(mfrow=c(2,2))
#dev.new(width = 9,height = 6)
#par(mfrow = c(2,3))

#for(i in 1:length(dates))
for(i in 1:36)#length(dates))
{	
	cat(format(Sys.time()),'loading data as of',format(dates[i]),'...\n')
	#opt$db = 'PRD' #
	#db_info <- get_db_info(opt$db)
	data <- load_data(dates[i],db_info,src='Barcap')
	
	#remove 5% outliers
	ix <- data$muni_oas>quantile(data$muni_oas,0.975,na.rm=T) | data$muni_oas<quantile(data$muni_oas,0.025,na.rm=T)
	data <- data[!ix,]
	
	#remove rows with missing data
	xvars <- c('credit_rating','muni_oad','deminimis_buffer','state','ab_code','muni_taxability',
	'coupon','deminimis_buffer1','deminimis_buffer2','time_to_worst','time_to_maturity','time_ratio')
	
	ix <- !is.na(data[,xvars]) & ( data[,xvars]==-Inf | data[,xvars]==Inf )
	data[,xvars][ix] <- NA
	
	data <- na.exclude(data[,c('muni_oas',xvars)])
	#opt$db = 'DEV'
	#db_info <- get_db_info(opt$db)
	if(i%%6 == 1) 
	{dev.new(width = 9,height = 6) 
	par(mfrow = c(2,3))}
	fit_data(dates[i],data)
	gc()
}

#dev.off()
#system(' cmd /c ps2pdf Output/gam_plot.eps Output/gam_plot.pdf ')
#unlink('*.eps')

#24-month momentum reversion!!
#update_mean_oas_attr(db_info,dates,mv_lag=25)

cat(date(),'Done.\n')
#q(status=0)

#source('H:/dev/Quant_Model-SQLServer/Muni/v1.0/Src/ExcessReturn/fit_surface.R')
###############################################################################

		