#!\\nts0018\bond\ABFI_PROD\QuantApps\R-2.14.2\bin\Rscript

source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.R',sep='') )

fit_data <- function(as_of,data)
{
	cat('total',nrow(data),'rows of data.\n')
	
	#winsorise
	data$muni_oad <- winsorise(data$muni_oad,lb=0.00,ub=0.99)
	data$deminimis_buffer <- winsorise(data$deminimis_buffer,lb=0.01,ub=0.99)
	#data$deminimis_buffer1 <- winsorise(data$deminimis_buffer1,lb=0.01,ub=0.99)
	#data$deminimis_buffer2 <- winsorise(data$deminimis_buffer2,lb=0.01,ub=0.99)
	#data$time_ratio <- winsorise(data$time_ratio,lb=0.01,ub=0.99)
	
	#data$callable = 1;
	#data$callable[data$time_to_maturity - data$time_to_worst < 0.02] = 0
	
	#data$demin_buf_call = data$deminimis_buffer1*data$callable
	
	#factorize
	data$state <- as.factor(data$state)
	data$ab_code <- as.factor(data$ab_code)
	data$muni_taxability <- as.factor(data$muni_taxability)
	data$callable = as.factor(data$callable)
	
	cat(format(Sys.time()),'running gam...\n')
	fit <- gam( muni_oas ~ te(credit_rating, muni_oad,k=c(3,4)) + s(deminimis_buffer,by=callable,k=4) 
							+ state+ ab_code + muni_taxability, data = data) 
	#fit <- gam( muni_oas ~ te(credit_rating, muni_oad,k=c(3,4)) + s(deminimis_buffer,k=4) 
	#						+ state+ ab_code + muni_taxability, data = data) 
	xnum = 100
	x = seq(min(data$deminimis_buffer),max(data$deminimis_buffer),length.out=xnum)						
	#fitres = predict(fit,newdata = data.frame(credit_rating=1,muni_oad=1,deminimis_buffer=x,state=factor(102),
	#	ab_code=factor(302),muni_taxability=factor(201),callable = factor(c(rep(0,length(x)),rep(1,length(x))))),type='terms')	
	fitres = predict(fit,newdata = data.frame(credit_rating=1,muni_oad=1,deminimis_buffer=x,state=factor(102),
		ab_code=factor(302),muni_taxability=factor(201),callable = factor(c(0,1))),type='terms')													
	r_sqr <- (fit$null.deviance-fit$deviance)/fit$null.deviance
	cat('r_sqr=',round(r_sqr,2),'\n')
	
	f1 <- gam( muni_oas ~ te(credit_rating, muni_oad,k=c(3,4)) + s(deminimis_buffer,by=callable,k=4) 
							+ state+ ab_code + muni_taxability, data = data)
	
	r_sqr <- (f1$null.deviance-f1$deviance)/f1$null.deviance
	cat('r_sqr=',round(r_sqr,2),'\n')
													
				
	invisible()
}

clear_oas_fit_tables <- function()
{
	#dangerous action. ask the user for confirmation!
	cat("\n","About to delete all muni data in OAS_ATTRIBUTION_FIT table. Are you sure [y/n/a(bort)]?","\n") # prompt 
	y<-scan(what=character(),nmax=1,quiet=T) 
	while(y!='y' & y!='n' & y!='a')
	{
		cat('[y/n/a(bort)]?\n')
		y<-scan(what=character(),nmax=1,quiet=T) 
	}
	
	if(y=='a'){
		stop('abort\n')
	}
	else if(y=='n') 
	{
		cat('muni data in table OAS_ATTRIBUTION_FIT will not be deleted.\n')
	}else
	{
		cat('delete all muni data in OAS_ATTRIBUTION_FIT table.\n')
		channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
		stmt = paste("delete from OAS_ATTRIBUTION_FIT
			where SECTOR ='muni'",sep='')
	    sqlQuery(channel,query=stmt)
	    odbcClose(channel)
	}
	invisible()
}
################################################################################
################################################################################
library('getopt')
opt = getopt(matrix(
    c(
    'db',   's', 2, "character",   
    'as_of','d', 2, "character",
    'help', 'h', 0, "logical"
    ),ncol=4,byrow=TRUE)
)

if ( !is.null(opt$help) ) {
  self = 'Rscript update_factor_loading.R'
  cat(paste("
    Usage: ",self,"  [--all] [--help]  
    	db:   Database server to run the script on (PRD/QA/DEV).
    	as_of:as_of date in yyyy-mm-dd format. if missing, then fit surface for
    	      all month-end dates as well as the very last date. Optional      
        help: Show help.  Optional
    Example: RScript fit_surface.R --db QA --as_of 2012-02-15
  ",sep=""))
  q(status=1)
}

if ( is.null(opt$db) ) opt$db = 'PRD'
###############################################################################
#source('H:/SVN/Muni/v1.0/Src/ExcessReturn/fit_surface.test3.R')
setwd(paste(Sys.getenv('ABFI_DATA_REPOSITORY'),'\\Muni\\v1.0',sep='') )

library(RODBC)
db_info <- get_db_info(opt$db)

#cat('see db info below:\n')
#db_info
opt$as_of = as.Date('2013-04-30')
#opt$as_of = as.Date('2010-04-30')


if( !is.null(opt$as_of) ) 
{
	dates <- load_muni_analytics_dates(as.Date(opt$as_of),db_info,src='Barcap')
	dates <- dates[dates==last.business.day(as.Date(opt$as_of))]
	if(length(dates)==0) 
	{
		cat('no date exist as of',opt$as_of,'\n')
		q(status=0)
	}
}else
{
	#clear_oas_fit_tables()
	dates <- load_muni_analytics_dates(Sys.Date(),db_info,src='Barcap')
}

library(mgcv)
	
#postscript('Output/gam_plot.eps')
#par(mfrow=c(2,2))
#dev.new(width = 9,height = 6)
#par(mfrow = c(2,3))

for(i in 1:length(dates))
#for(i in 73:length(dates))
{	
	cat(format(Sys.time()),'loading data as of',format(dates[i]),'...\n')
	#opt$db = 'PRD' #
	#db_info <- get_db_info(opt$db)
	data <- load_data(dates[i],db_info,src='Barcap')
	
	#remove 5% outliers
	ix <- data$muni_oas>quantile(data$muni_oas,0.975,na.rm=T) | data$muni_oas<quantile(data$muni_oas,0.025,na.rm=T)
	data <- data[!ix,]
	
	#remove rows with missing data
	xvars <- c('credit_rating','muni_oad','deminimis_buffer','state','ab_code','muni_taxability',
	'callable')
	#'coupon','deminimis_buffer1','deminimis_buffer2','time_to_worst','time_to_maturity','time_ratio')
	
	ix <- !is.na(data[,xvars]) & ( data[,xvars]==-Inf | data[,xvars]==Inf )
	data[,xvars][ix] <- NA
	
	data <- na.exclude(data[,c('muni_oas',xvars)])
	#opt$db = 'DEV'
	#db_info <- get_db_info(opt$db)
	
	fit_data(dates[i],data)
	gc()
}

#dev.off()
#system(' cmd /c ps2pdf Output/gam_plot.eps Output/gam_plot.pdf ')
#unlink('*.eps')

#24-month momentum reversion!!
#update_mean_oas_attr(db_info,dates,mv_lag=25)

cat(date(),'Done.\n')
#q(status=0)

#source('H:/dev/Quant_Model-SQLServer/Muni/v1.0/Src/ExcessReturn/fit_surface.R')
###############################################################################

		