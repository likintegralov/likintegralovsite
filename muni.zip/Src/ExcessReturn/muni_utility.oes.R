#!\\nts0018\bond\ABFI_PROD\QuantApps\R-2.14.2\bin\Rscript
source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Utility\\R_Splus\\utility.R',sep='') )

oas_vol <- function(data) # adjust for security wise average residual
{
	secs = sort(unique(data$identifier))
	starti = 1
	data$conv_er = NA
	for(i in 1:length(secs))
	{
		if(i%%100 == 1) cat('Computing OAS vol for ',i,'th security out of ',length(secs),'\n',sep='')
		
		ix = which(data$identifier == secs[i])
		secoas = data[ix,c('oas')]
		if(length(secoas) >= 12)
		{
			hvol = runSD(secoas,n=min(24,length(secoas)))
			muse = !is.na(hvol)
			data$conv_er[ix[muse]] = data$convexity[ix[muse]]*hvol[muse]^2
		}			
	}
	data
}

res_adjust <- function(data) # adjust for security wise average residual
{
	secs = sort(unique(data$identifier))
	starti = 1
	for(i in 1:length(secs))
	{
		if((i-starti)%%100 == 1) cat('adjusting ',i,'th security out of ',length(secs),')\n',sep='')
		
		ix = which(data$identifier == secs[i])
		secresi = data[ix,c('resi_oas')]
		if(length(secresi) >= 24)
		{
			mresi = SAM(secresi,n=24)
			muse = !is.na(mresi)
			data$resi_oas[ix[muse]] = data$resi_oas[ix[muse]] - mresi[muse]
		}			
	}
	data
}

residual_mom <- function(data) # residual momentum
{
	
	secs = sort(unique(data$identifier))
	data$resi_mom = 0
	for(i in 1:length(secs))
	{
		if(i%%100 == 1) cat('computing residual momentum for ',i,'th security out of ',length(secs),'...\n',sep='')
		
		ix = which(data$identifier == secs[i])
		# current minus 3 month average
# 		if(length(ix) >= 3)
# 		{
# 		secresi = data[ix,c('resi_oas')]
# 		
# 			mresi = SMA(secresi,n=3)
# 			muse = !is.na(mresi)
# 			data$resi_mom[ix[muse]] = data$resi_oas[ix[muse]] - mresi[muse]
# 		}
		# current month minus last month
		if(length(ix) >= 2)
		{
			secresi = data[ix,c('resi_oas')]
			
			data$resi_mom[ix[2:length(ix)]] = diff(secresi)
		}
	}
	data
}

load_muni_analytics_dates <- function(as_of,dbi,src=NULL)
{
	require(RODBC)
	
	src_str <- ''
	if(!is.null(src)) src_str <- paste("and SOURCE='",src,"'\n",sep='')
	
	stmt <- paste("
		select AS_OF_DATE=EFFECTIVE_DATE,cnt=COUNT(*)
		from Optimizer.dbo.MUNI_ANALYTICS_VIEW
		where MUNI_10YR_KRD is not null
		",src_str,"and EFFECTIVE_DATE <= '", format(as_of,'%d-%b-%Y'),"'
		group by EFFECTIVE_DATE
	",sep='')
	
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',dbi$Database,';DataBase=',dbi$InitDB,';uid=',dbi$User,';pwd=',dbi$Password,sep=''))
    res <- sqlQuery(channel,query=stmt)
    odbcClose(channel)
    
    if(nrow(res)==0) return(NULL)
    
    names(res) <- casefold(names(res),F)
    res$as_of_date <- as.Date(res$as_of_date)
    
    res <- res[res$cnt>=10000,]
    
    #only get the last day of each month
    res$month_end <- month.end(res$as_of_date)
    res <- sort.data.frame(res,by=~month_end - as_of_date)    
    idx <- match(unique(res$month_end),res$month_end)    
    res <- res[idx,]
    
    res$as_of_date
}

load_regression_data_dates <- function(db_info)
{
	require(RODBC)
	#first get month-end fits
	stmt <- paste("
        select DISTINCT FWD_DATE
        FROM MUNI_MODEL_REGRESSION_DATA
        ",sep='')
        
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    dates <- sqlQuery(channel,query=stmt)
    odbcClose(channel)
    as.Date(dates$FWD_DATE)
}

load_factor_loading <- function(as_of,dbi)
{	    
	require(RODBC)
	
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',dbi$Database,';DataBase=',dbi$InitDB,';uid=',dbi$User,';pwd=',dbi$Password,sep=''))
    
    stmt <- paste("
        select max(AS_OF)
        from MODEL_DESCRIPTION a,MODEL_SPECIFICATION b,MODEL_FACTOR_LOADING c
        WHERE a.MODEL_NAME = 'Muni Excess Return Model'
        AND a.VERSION='1.0'
        AND b.MODEL_ID=a.MODEL_ID
        AND c.FACTOR_ID=b.FACTOR_ID
        AND AS_OF <='",format(as_of,'%d-%b-%Y'),"'
        ",sep='')
    
	res <- sqlQuery(channel,stmt)
	if(nrow(res)==0) stop('no factor loading available.\n')
	
	last_as_of <- as.Date(res[1,1])
    
    stmt <- paste("
        select c.*
        from MODEL_DESCRIPTION a,MODEL_SPECIFICATION b,MODEL_FACTOR_LOADING c
        WHERE a.MODEL_NAME = 'Muni Excess Return Model'
        AND a.VERSION='1.0'
        AND b.MODEL_ID=a.MODEL_ID
        AND c.FACTOR_ID=b.FACTOR_ID
        AND AS_OF ='",format(last_as_of,'%d-%b-%Y'),"'
        ",sep='')
            
    factor_loading <- sqlQuery(channel,query=stmt)    
    odbcClose(channel)
    
    cat('use factor loading as of',format(last_as_of),'.\n')
    factor_loading
}

load_oas_fit <- function(as_of,dbi)
{
	require(RODBC)
	
	stmt_cont <- paste("
        select *
		from OAS_ATTRIBUTION_FIT
		where SECTOR = 'muni' and AS_OF_DATE = '",format(as_of,'%d-%b-%Y'),"'
		",sep='')
		
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',dbi$Database,';DataBase=',dbi$InitDB,';uid=',dbi$User,';pwd=',dbi$Password,sep=''))
    oas_fit <- sqlQuery(channel,query=stmt_cont)
    odbcClose(channel)
    
    if(nrow(oas_fit)==0 ) stop('fits not exist as of',format(as_of),'!\n')
    
    names(oas_fit) <- casefold(names(oas_fit),F)
    oas_fit$as_of_date <- as.Date(oas_fit$as_of_date)
    oas_fit
}

update_mean_oas_attr <- function(dbi,dates,mv_lag=NULL)
{
	cat('update mean oas with lag=',mv_lag,'\n')
	require(RODBC)
	#first get month-end fits
	stmt <- paste("
        select ID, SECTOR, AS_OF_DATE,ATTRIBUTE,VALUE1,VALUE2,OAS
		from OAS_ATTRIBUTION_FIT
		where SECTOR = 'muni' and AS_OF_DATE in
		(
			select max(AS_OF_DATE)
			from OAS_ATTRIBUTION_FIT where SECTOR ='muni'
			group by year(AS_OF_DATE)*100+month(AS_OF_DATE)
		)
        ",sep='')
        
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',dbi$Database,';DataBase=',dbi$InitDB,';uid=',dbi$User,';pwd=',dbi$Password,sep=''))
    data_me <- sqlQuery(channel,query=stmt)
    odbcClose(channel)
    
    names(data_me) <- casefold(names(data_me),F)
    data_me$as_of_date <- as.Date(data_me$as_of_date)
    
    max_date <- max(data_me$as_of_date)
    if(max_date<last.business.day(month.end(max_date)) )
    {
    	ix <- data_me$as_of_date==max_date
    	data_me <- data_me[!ix,]
	}
    
	##############################################################################
	#define an inline function 
	calc_mean_oas <- function(d,mv_lag)
	{
		last_day <- last.business.day(month.end(d$as_of_date[1]))
		d_wgt <- min(1, as.numeric( format(d$as_of_date[1],'%d') ) / as.numeric( format(last_day,'%d')) )
		
		#if mv_lag is null, take all past data
		ix <- data_me$as_of_date < d$as_of_date[1]
		xdates <- sort(unique(data_me$as_of_date[ix]),decreasing=T)
		if(!is.null(mv_lag)) ix <- ix & data_me$as_of_date %in% xdates[1:mv_lag]
		dd <- rbind(data_me[ix,],d[,names(data_me)]) # dataset with past mv_lag months of data
		
		dd$wgt <- 1			
		if(d_wgt==1) #remove one date
		{
			ix <- dd$as_of_date %in% xdates[mv_lag]
			dd <- dd[!ix,]
		}else #wgts are 1,wgt,1,1,...,(1-wgt)
		{
			ix <- dd$as_of_date %in% xdates[1]
			dd$wgt[ix] <- d_wgt
			ix <- dd$as_of_date %in% xdates[mv_lag]
			dd$wgt[ix] <- 1-d_wgt
		}
	    
		dd <- sort.data.frame(dd,by=~attribute+value1+value2+as_of_date)
		
	    attrs_cont <- c('deminimis_buffer')
	    attrs_dummy <- c('index_oas','state','ab_code','muni_taxability','zero_coupon')
	    
	    d$mean_oas <- NA # current month data
	    #continuous
	    for(attr in attrs_cont)
	    {
		    for(v2 in sort(unique(d$value2[d$attribute == attr])))
		    {
			    ix <- dd$attribute==attr & dd$value2 == v2
			    ddd <- dd[ix,]
			    
			    ix <- d$attribute==attr & d$value2 == v2
			    xout <- sort(d$value1[ix])
			    
			    dates <- sort(unique(ddd$as_of_date))
			    mean_oas <- 0
			    wgt_total <- 0
			    for(i in 1:length(dates))
			    {
				    ix <- ddd$as_of_date==dates[i]
				    fit <- smooth.spline(ddd$value1[ix],ddd$oas[ix])
				    mean_oas <- mean_oas+predict(fit,x=xout)$y * ddd$wgt[ix][1]
				    wgt_total <- wgt_total + ddd$wgt[ix][1]
			    }
			    mean_oas <- mean_oas/wgt_total
			    
			    ix <- d$attribute==attr & d$value2 == v2
				d$mean_oas[ix] <- mean_oas
			}
	    }
	    
	    #dummy
	    ix <- dd$attribute %in% attrs_dummy
	    sum_oasxwgt <- aggregate(oas*wgt~attribute+value1,data=dd,FUN=sum,subset=ix)
	    sum_wgt <- aggregate(wgt~attribute+value1,data=dd,FUN=sum,subset=ix)
	    mean_oas <- merge(sum_oasxwgt,sum_wgt)
	    
		mean_oas$mean_oas <- mean_oas[,'oas * wgt'] / mean_oas[,'wgt']
		
		ix <- d$attribute %in% attrs_dummy
		idx <- match(d$value1[ix],mean_oas$value1)
		
		d$mean_oas[ix] <- mean_oas$mean_oas[idx]
		
		#surface
	    ix <- dd$attribute=='credit_oad'
	    dd <- dd[ix,]
	    dd <- sort.data.frame(dd,by=~as_of_date + value2 + value1)
	    
	    dates <- sort(unique(dd$as_of_date))
	    
	    ix <- d$attribute=='credit_oad'
	    credit_out <- sort( unique(d$value1[ix]) )
	    oad_out <- sort( unique(d$value2[ix]) )
	    
	    library(fields)
	    
	    loc <- make.surface.grid(list(credit_out,oad_out) )
		z_out_total <- 0
	    wgt_total <- 0
		for(i in 1:length(dates))
	    {
		    ix <- dd$as_of_date==dates[i]
		    wgt <- dd$wgt[ix][1]
		    
		    x <- sort(unique(dd$value1[ix]))
		    y <-  sort(unique(dd$value2[ix]))
		    z <-  matrix(dd$oas[ix],nrow=length(x))
		    if( length(z) != length(x) * length(y) ) stop ('credit surface source data for',format(dates[i]),'corrupted\n')
		    
		    loc_idx <- loc
			loc_idx[,1] <- winsorise(loc_idx[,1],lb.value=min(x),ub.value=max(x) )
			loc_idx[,2] <- winsorise(loc_idx[,2],lb.value=min(y),ub.value=max(y) )
			
			z_out <- interp.surface(list(x=x,y=y,z=z), loc_idx)
			z_out <- matrix(z_out,nrow=length(credit_out))
			
			z_out_total <- z_out_total + z_out*wgt
			wgt_total <- wgt_total + wgt
		}
		
	    mean_oas <- matrix(z_out_total/wgt_total,nrow=length(credit_out) )
		
	    d <- sort.data.frame(d,by=~attribute + value2 + value1)
	    ix <- d$attribute=='credit_oad'
		d$mean_oas[ix] <- mean_oas
	    
		d <- d[,c('id','sector','as_of_date','attribute','value1','value2','oas','mean_oas')]
		names(d) <- casefold(names(d),T)
		d
	}
	#define an inline function 
	##############################################################################	
	
	#now work on each date
	me_dates <- sort(unique(data_me$as_of_date))
	fit_oas <- c()
	for(i in 1:length(dates) )
	{
		cur_date <- dates[i]
		cat('processing',format(cur_date),'...\n')
		if(cur_date %in% me_dates) 
		{
			res <- data_me[data_me$as_of_date==cur_date,]
		}else #query data
		{
			res <- load_oas_fit(cur_date,dbi)			
		}
		res <- calc_mean_oas(res,mv_lag)
		fit_oas <- rbind(fit_oas,res)
	}    

	names(fit_oas) <- casefold(names(fit_oas))
	
	cat('updating muni oas into database...\nDate str is ')

	
	dates_str <- paste(format(dates),collapse="','")
	cat(dates_str)
	cat('\n')
	stmt <- paste("
		delete from OAS_ATTRIBUTION_FIT
		where SECTOR ='muni' and AS_OF_DATE in ('",dates_str,"')
	",sep='')
	
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',dbi$Database,';DataBase=',dbi$InitDB,';uid=',dbi$User,';pwd=',dbi$Password,sep=''))
    sqlQuery(channel,query=stmt)
    odbcClose(channel)
	
    export2db(data=fit_oas,server_type='SQL',server=dbi$Database,db=dbi$InitDB,table='OAS_ATTRIBUTION_FIT',user=dbi$User,psw=dbi$Password,na='')	
	invisible()
}


load_data <- function(as_of,dbi,src=NULL)
{
	require(RODBC)
	
	cat('loading data as of',format(as_of),' from ',src,' ...\n')
	stmt <- paste("
		SELECT anal.SOURCE,
		anal.IDENTIFIER,anal.EFFECTIVE_DATE AS AS_OF_DATE,anal.AMT_OUTSTANDING,
		INDEX_RATING,
		INDEX_RATING_NUM=idx.ID,
		MOODY_RATING=moody.ID,
		SP_RATING   =sp.ID,
		FITCH_RATING=fitch.ID,
		anal.STATE,
		MUNI_TAXABILITY=(CASE anal.MUNI_TAXABILITY WHEN 'Build America Bonds Direct Pay' THEN 'Taxable'
			WHEN 'Unknown Tax Status' THEN 'Taxable'
			WHEN 'Recovery Zone Facilities Bonds' THEN 'Tax Exempt - No AMT'
			ELSE anal.MUNI_TAXABILITY END
			),
		anal.ISSUE_PRICE,anal.ISSUE_YIELD,anal.YIELD_TO_WORST yield2w,
		anal.COUPON,anal.MATURITY_DATE,anal.PRICE,
		anal.MUNI_OAS AS MUNI_OAS,anal.MUNI_OAD_RISK AS MUNI_OAD,
		TIME_TO_WORST=(CASE WHEN anal.TIME_TO_WORST IS NULL THEN DATEDIFF(DAY,EFFECTIVE_DATE,MATURITY_DATE)/365.0 ELSE anal.TIME_TO_WORST END),
		TIME_TO_MATURITY=DATEDIFF(DAY,EFFECTIVE_DATE,MATURITY_DATE)/365.0,
		AB_CODE=(CASE anal.PURPOSE_TYPE WHEN 'Muni PRE' THEN 'DIA' ELSE code.AB_CODE END),
		anal.MUNI_6MO_KRD,anal.MUNI_2YR_KRD,anal.MUNI_5YR_KRD,
		anal.MUNI_10YR_KRD,anal.MUNI_20YR_KRD,anal.MUNI_30YR_KRD,
		anal.COUPON_RETURN_MTD,anal.PRICE_RETURN_MTD,anal.MUNI_OAC as convexity,anal.CALL_TYPE 
		FROM Optimizer.dbo.MUNI_ANALYTICS_VIEW anal
		LEFT JOIN FIQModel.dbo.BOND_CREDIT_RATING idx
		ON UPPER(idx.MOODY)=anal.INDEX_RATING
		LEFT JOIN FIQModel.dbo.BOND_CREDIT_RATING moody
		ON UPPER(moody.MOODY)=anal.MOODY_RATING
		LEFT JOIN FIQModel.dbo.BOND_CREDIT_RATING sp
		ON UPPER(sp.SP)=anal.SP_RATING
		LEFT JOIN FIQModel.dbo.BOND_CREDIT_RATING fitch
		ON UPPER(fitch.FITCH)=anal.FITCH_RATING
		INNER JOIN FIQModel.dbo.MUNI_SECTOR_CODE code
		ON code.IDENTIFIER = anal.IDENTIFIER
		where anal.EFFECTIVE_DATE='", format(as_of,'%d-%b-%Y'),"'		
	",sep='')
	if(!is.null(src)) stmt <- paste(stmt,"and SOURCE='",src,"'\n",sep='')
	
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',dbi$Database,';DataBase=',dbi$InitDB,';uid=',dbi$User,';pwd=',dbi$Password,sep=''))
    data <- sqlQuery(channel,query=stmt)
    dummy_map <- sqlQuery(channel,query='select * from FIQModel.dbo.MUNI_DUMMY_VARIABLE_MAP')
    odbcClose(channel)
    
    #if(nrow(data)==0) stop('no muni analytics data as of ',format(as_of),'\n')
    
    if(nrow(data)==0) return(data)
    
    
    names(data) <- casefold(names(data),F)
    idx <- grep('date',names(data))
    for(id in idx) data[,id] <- as.Date(data[,id])
    
    #############################################################
	#map state,sector,taxability
    names(dummy_map) <- casefold(names(dummy_map),F)
    attrs <- c('state','ab_code','muni_taxability')
    for(atr in attrs)
    {
	    map <- dummy_map[dummy_map$attribute==atr,c('orig_value','mapped_value')]
	    names(map) <- c(atr,paste('mapped',atr,sep=''))
	    data <- merge(data,map)
	    data <- data[,-match(atr,names(data))]
	}
    names(data) <- gsub('mapped','',names(data))
	#############################################################
	
    data$credit_rating <- rowMeans(data[,c('moody_rating', 'sp_rating', 'fitch_rating')],na.rm=T )
    
    ix <- rowSums( is.na(data[,c('moody_rating', 'sp_rating', 'fitch_rating')]) ) == 3
	if(sum(ix)>0) data[ix,c('moody_rating', 'sp_rating', 'fitch_rating')] <- data[ix,'index_rating_num']
	#############################################################
	
	#calculate deminimis
	ix_OID <- data$issue_price>0 & data$issue_price < 100
	
	data$adjusted_basis <- 100
	
	#adjusted basis for OID bonds
	maturities <- as.numeric( difftime(data$maturity_date[ix_OID],data$as_of_date[ix_OID],units='days')/365 )
	data$adjusted_basis[ix_OID] <- 100*par_bond_price(data$coupon[ix_OID]/100,data$issue_yield[ix_OID]/100,maturities)
	
	ix <- data$adjusted_basis>100 | data$issue_Price==0 | data$issue_yield==0
	data$adjusted_basis[ix] <- NA
	
	ix = data$call_type == 'NONCALL'
	data$callable = 1
	data$callable[ix] = 0
	
	data$deminimis <- ( as.numeric(difftime(data$maturity_date,data$as_of_date,unit='day'))/365 ) * 0.25
	data$deminimis_threshold <- data$adjusted_basis - data$deminimis
	
	data$deminimis_buffer <- data$time_to_worst/data$time_to_maturity*(data$price - data$deminimis_threshold)/data$deminimis_threshold
	#data$deminimis_buffer <- (data$price - data$deminimis_threshold)/data$deminimis_threshold
	
	data$total_return_mtd <- (data$coupon_return_mtd + data$price_return_mtd)/100
	data$market_value <- data$amt_outstanding * data$price/100
	
	data$zero_coupon = 401
	data$zero_coupon[data$coupon == 0] = 402
	
    data
}

#get model factor exposure
#residual - difference between current attribution and its historical average
#attribution - OAS attributed to these factors
get_factor_exposure <- function(data,dbi,type=c('residual','attribution'),NR=FALSE)
{
	type <- match.arg(type)
    #calculate factor exposures
    oas_fit <- load_oas_fit(data$as_of_date[1],dbi)
	
	data$index_oas <- 1
	data$resi_oas <- data$muni_oas
	
	xvars <- c('credit_rating','muni_oad','deminimis_buffer','state','ab_code','muni_taxability','index_oas','zero_coupon')	
	xvars_dummy <- c('state','ab_code','muni_taxability','index_oas','zero_coupon')
	xvars_cont <- c()

	for(xvar in xvars_dummy)
	{
		fit <- oas_fit[oas_fit$attribute==xvar,]
		idx <- match(data[,xvar],fit$value1)
		y <- fit$oas[idx]
		y_bar <- fit$mean_oas[idx]
		if(type=='residual') data[,xvar] <- y - y_bar
		else data[,xvar] <- y
		data$resi_oas <- data$resi_oas - y
	}
	
	for(xvar in xvars_cont)
	{
		fit <- oas_fit[oas_fit$attribute==xvar,]		
		y <- approx(fit$value1,fit$oas,xout=data[,xvar],rule=2)$y
		y_bar <- approx(fit$value1,fit$mean_oas,xout=data[,xvar],rule=2)$y
		
		if(type=='residual') data[,xvar] <- y - y_bar
		else data[,xvar] <- y
		data$resi_oas <- data$resi_oas - y
	}
	#########################################################
	# deminimis buffer (separately for IG and HY)
	ix_hy = data$credit_rating > 10 | is.na(data$credit_rating)
	xvar = 'deminimis_buffer'
	
	fit_ig <- oas_fit[oas_fit$attribute==xvar & oas_fit$value2 == 0,]		
	y <- approx(fit_ig$value1,fit_ig$oas,xout=data[!ix_hy,xvar],rule=2)$y
	y_bar <- approx(fit_ig$value1,fit_ig$mean_oas,xout=data[!ix_hy,xvar],rule=2)$y
	
	if(type=='residual') data[!ix_hy,xvar] <- y - y_bar
		else data[!ix_hy,xvar] <- y
	data$resi_oas[!ix_hy] <- data$resi_oas[!ix_hy] - y

	fit_hy <- oas_fit[oas_fit$attribute==xvar & oas_fit$value2 == 1,]		
	y <- approx(fit_hy$value1,fit_hy$oas,xout=data[ix_hy,xvar],rule=2)$y
	y_bar <- approx(fit_hy$value1,fit_hy$mean_oas,xout=data[ix_hy,xvar],rule=2)$y
	
	if(type=='residual') data[ix_hy,xvar] <- y - y_bar
		else data[ix_hy,xvar] <- y
	data$resi_oas[ix_hy] <- data$resi_oas[ix_hy] - y
					
	##########################################################
	# credit-duration 
	require(fields)
	fit <- oas_fit[oas_fit$attribute=='credit_oad',]
	fit <- sort.data.frame(fit,by=~value2+value1)
	
	xlim <- range(fit$value1)
	ylim <- range(fit$value2)		
	loc <- as.matrix(data[,c('credit_rating','muni_oad')])
	loc[,1] <- winsorise(loc[,1],lb.value=xlim[1],ub.value=xlim[2] )
	loc[,2] <- winsorise(loc[,2],lb.value=ylim[1],ub.value=ylim[2] )	
	
	x <- sort(unique(fit$value1))
	y <- sort(unique(fit$value2))
	obj <- list(x=x,y=y,z=matrix(fit$oas,nrow=length(x)) )
	z <- interp.surface(obj, loc)
	
	obj <- list(x=x,y=y,z=matrix(fit$mean_oas,nrow=length(x)) )
	z_bar <- interp.surface(obj, loc)
	
	if(NR)
	{
		# assume that non rated bonds are HY, average oas for each duration across hy 
		hy_fit = fit[fit$value1 >= 10,]
		hy_oas = aggregate(hy_fit,list(dur = hy_fit$value2), FUN = mean)
		# find non rated bonds
		ix = is.na(loc[,1])
		z[ix] = approx(hy_oas$value2,hy_oas$oas,xout = loc[ix,2],rule=2)$y
		z_bar[ix] = approx(hy_oas$value2,hy_oas$mean_oas,xout = loc[ix,2],rule=2)$y
	}
	
	if(type=='residual') data$credit_oad <- z - z_bar
	else data$credit_oad <- z
		
	data$resi_oas <- data$resi_oas - z
	
	#return only needed fields
	data
}

calc_returns <- function(data,dur,ret_fc,ret_ac=NULL)
{
    #calculate factor exposures
    as_of <- data$as_of_date[1]
    
	################################################
	#calculate returns
	idx_fc <- match(as_of,ret_fc$as_of_date)
	if(is.na(idx_fc) & as_of>=last.business.day(month.end(as_of)) ) idx_fc <- match(month.end(as_of),ret_fc$as_of_date)
	if( is.na(idx_fc)) stop('muni bond return not availble as of ',format(as_of),'\n')
	
	idx_dur <- idx_ac <- idx_fc
	################################################
	
	data$krd_ret_fwd3m_fc <- ( data$muni_6mo_krd/dur[idx_dur,'dur_006m']*ret_fc[idx_fc,'fwd3m_fc_006m'] 
						+ data$muni_2yr_krd/dur[idx_dur,'dur_024m']*ret_fc[idx_fc,'fwd3m_fc_024m'] 
						+ data$muni_5yr_krd/dur[idx_dur,'dur_060m']*ret_fc[idx_fc,'fwd3m_fc_060m'] 
						+ data$muni_10yr_krd/dur[idx_dur,'dur_120m']*ret_fc[idx_fc,'fwd3m_fc_120m'] 
						+ data$muni_20yr_krd/dur[idx_dur,'dur_240m']*ret_fc[idx_fc,'fwd3m_fc_240m'] 
						+ data$muni_30yr_krd/dur[idx_dur,'dur_360m']*ret_fc[idx_fc,'fwd3m_fc_360m']) +
					    ( 1 - data$muni_6mo_krd/dur[idx_dur,'dur_006m']
							- data$muni_2yr_krd/dur[idx_dur,'dur_024m']
							- data$muni_5yr_krd/dur[idx_dur,'dur_060m']
							- data$muni_10yr_krd/dur[idx_dur,'dur_120m']
							- data$muni_20yr_krd/dur[idx_dur,'dur_240m']
							- data$muni_30yr_krd/dur[idx_dur,'dur_360m'])*ret_fc[idx_fc,'fwd3m_fc_003m']
							
	if(!is.null(ret_ac) & !is.null(data$price_fwd3m) )
	{
		data$total_ret_fwd3m <- (data$coupon/12*3 + data$price_fwd3m - data$price)/data$price
		
		data$krd_ret_fwd3m <- ( data$muni_6mo_krd/dur[idx_dur,'dur_006m']*ret_ac[idx_ac,'fwd3m_ac_006m'] 
							+ data$muni_2yr_krd/dur[idx_dur,'dur_024m']*ret_ac[idx_ac,'fwd3m_ac_024m'] 
							+ data$muni_5yr_krd/dur[idx_dur,'dur_060m']*ret_ac[idx_ac,'fwd3m_ac_060m'] 
							+ data$muni_10yr_krd/dur[idx_dur,'dur_120m']*ret_ac[idx_ac,'fwd3m_ac_120m'] 
							+ data$muni_20yr_krd/dur[idx_dur,'dur_240m']*ret_ac[idx_ac,'fwd3m_ac_240m'] 
							+ data$muni_30yr_krd/dur[idx_dur,'dur_360m']*ret_ac[idx_ac,'fwd3m_ac_360m']) +
						    ( 1 - data$muni_6mo_krd/dur[idx_dur,'dur_006m']
								- data$muni_2yr_krd/dur[idx_dur,'dur_024m']
								- data$muni_5yr_krd/dur[idx_dur,'dur_060m']
								- data$muni_10yr_krd/dur[idx_dur,'dur_120m']
								- data$muni_20yr_krd/dur[idx_dur,'dur_240m']
								- data$muni_30yr_krd/dur[idx_dur,'dur_360m'])*ret_ac[idx_ac,'fwd3m_ac_003m']
								
		data$excess_ret_fwd3m <- data$total_ret_fwd3m - data$krd_ret_fwd3m
	}
	
	data
}

get_required_dates <- function(as_of)
{
	stmt <- paste("
    	select DISTINCT FWD_DATE
    	FROM MUNI_MODEL_REGRESSION_DATA
        WHERE FWD_DATE <='", format(as_of,'%d-%b-%Y'),"'
	",sep='')
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    dates <- as.Date( sqlQuery(channel,query=stmt )[,1])
    odbcClose(channel)
    dates
}

#source('H:/SVN/Muni/v1.0/Src/ExcessReturn/muni_utility.R')

