
source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.kal.R',sep='') )
#source('H:/SVN/Muni/v1.0/Src/ExcessReturn/deskpr.R')

oasd = read.csv('H:/MATLAB/Kalotay/deskoasres.csv')

wd = oasd[substr(oasd$HowOffered,1,10) == 'DEALER BUY' | substr(oasd$HowOffered,1,11) == 'DEALER SELL' | substr(oasd$Status,1,8) == 'EXECUTED',]

ioas = aggregate(oasd$OAS, by = list(date = oasd$TradeDate),FUN = mean, na.rm = T)

oasd$TradeDate = as.Date(oasd$TradeDate,format = '%m/%d/%Y' )
dates = sort(unique(oasd$TradeDate))

dbi <- get_db_info(opt$db)

inddata = data.frame()
for(i in 1:length(dates))
{
	inddatat = load_security_data(dates[i],dbi)
	inddata = rbind(inddata, inddatat)
}

data = merge(oasd,inddata, by.x = c('TradeDate','cusip'),by.y = c('as_of_date','identifier'))
