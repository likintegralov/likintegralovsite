
source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.kal.R',sep='') )

#source('H:/SVN/Muni/v1.0/Src/ExcessReturn/loadanldata.R')


indata = read.csv('H:/MATLAB/Kalotay/bvalres20181130.csv')
indata$PriceEffectiveDate = as.Date(indata$PriceEffectiveDate,'%d-%b-%Y')

dates = indata$PriceEffectiveDate[1]

library(RODBC)
db_qa <- get_db_info('QA')
#db_prd <- get_db_info('PRD')

for( i in 1:length(dates))
{
	q = paste("select * from Optimizer..MUNI_ANALYTICS_KALOTAY where EFFECTIVE_DATE = '",format(dates[i],'%d-%b-%Y'),"' and SOURCE = 'AB'",sep = '')
	db = channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_qa$Database,';DataBase=',db_qa$InitDB,';uid=',db_qa$User,';pwd=',db_qa$Password,sep=''))
	data = sqlQuery(db,query=q )
	odbcClose(db)
	
	data$EFFECTIVE_DATE = as.Date(data$EFFECTIVE_DATE)
	
	data = merge(data,indata,by.x = c('IDENTIFIER','EFFECTIVE_DATE'),by.y = c('Cusip','PriceEffectiveDate'))
	data$SOURCE = 'ABBval'
	data$PRRICE = data$Price
	data$MUNI_OAS = data$OAS
	data$MUNI_OAD = data$OAD
	data$MUNI_OAC = data$OAC
	data$MUNI_6MO_KRD = data$krd6m
	data$MUNI_2YR_KRD = data$krd2y
	data$MUNI_5YR_KRD = data$krd5y
	data$MUNI_10YR_KRD = data$krd10y
	data$MUNI_20YR_KRD = data$krd20y
	data$MUNI_30YR_KRD = data$krd30y
	
	data =  data[,-(74:84)]
	
	data = data[,c(3,4,1,2,5:dim(data)[2])]
	data$TIMESTAMP = as.Date(data$TIMESTAMP)
	
	qa = channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_qa$Database,';DataBase=',db_qa$InitDB,';uid=',db_qa$User,';pwd=',db_qa$Password,sep=''))
	sqlQuery(qa,query=paste("delete from Optimizer..MUNI_ANALYTICS_KALOTAY where EFFECTIVE_DATE = '",format(dates[i],'%d-%b-%Y'),"' and SOURCE = 'ABBval'",sep='') )
	odbcClose(qa)
	export2db(data=data,server_type='SQL',server=db_qa$Database,db='Optimizer',table='MUNI_ANALYTICS_KALOTAY',user=db_qa$User,psw=db_qa$Password,na='')
	
}