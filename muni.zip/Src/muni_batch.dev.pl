#!C:\Perl\bin\perl -w
# This script is used to update muni model every day

use strict;
use DBI;

use Getopt::Long;
use File::Spec::Functions qw(rel2abs);
use File::Basename;
use Date::Calc qw(Day_of_Week);

############################## Initializing data for the script####################################
#my $msdb_url = "dbi:ODBC:$ENV{FIQUANT_SQL_DATABASE}";
#my $msdb_username = $ENV{FIQUANT_SQL_USER};
#my $msdb_password = '1xdl8v0v';
###################################################################################################

# Define global variables here
use vars qw($usage $scriptname %opts $year $month $day);

# Strip path from script
($scriptname = $0) =~ s!.*/!!;

# Usage
$usage = <<_USAGE_END_;

 Usage: $scriptname
    -h      : help
    -as_of  : as_of date in yyyy-mm-dd format
    -db     : database server, PRD/QA/DEV
    -g	: run generic securities only
    example : perl muni_batch.pl -as_of 2012-02-15 -db QA
_USAGE_END_

# Parse the command line options
GetOptions(\%opts,"h","as_of:s","db:s","g");

if($opts{h} or !defined($opts{as_of}) or !defined($opts{db})
            or not $opts{as_of} =~ /(\d{4})-(\d{2})-(\d{2})/
            or not grep ($_ eq $opts{db}, qw/PRD QA DEV/ ) ) 
{
	print $usage;
    exit(1);
}

chdir dirname(rel2abs($0)) or die "Can't cd to ".dirname(rel2abs($0))."n";

my ($year,$month,$day) = $opts{as_of} =~ /(\d{4})-(\d{2})-(\d{2})/;
#print $year." ".$month." ".$day." ".Day_of_Week($year,$month,$day)."\n";
my $app_home = $ENV{ABFI_APP_HOME};
my $model_home = $ENV{ABFI_MODEL_HOME};
my $data_repository = $ENV{ABFI_DATA_REPOSITORY};
my $network_repo = "N:\\ABFI_PROD\\Quant_Data_Repo\\Muni\\v1.0\\Output";

if(!$app_home or !$model_home or !$data_repository)
{
    print "ABFI_APP_HOME,ABFI_MODEL_HOME,or ABFI_DATA_REPOSITORY environment variable not found. Abort\n";
    exit(1);
}

my $Rscript = $app_home."\\R-3.0.0\\bin\\x64\\Rscript ".$model_home."\\Muni\\v1.0\\Src\\";


if(!$opts{g})
{
#update muni MMD yield curve spread model
my $cmd;
$cmd = $Rscript."MMDYieldCurve\\load_data.kal.R --as_of ".$opts{as_of}." --db ".$opts{db}."\n";
print $cmd;
if( system($cmd) ) { exit(1); }

$cmd = $Rscript."MMDYieldCurve\\update_factor_loading.kal.R --as_of ".$opts{as_of}." --db ".$opts{db}."\n";
print $cmd;
if( system($cmd) ) { exit(1); }

$cmd = $Rscript."MMDYieldCurve\\update_factor_score.kal.R --as_of ".$opts{as_of}." --db ".$opts{db}."\n";
print $cmd;
if( system($cmd) ) { exit(1); }

$cmd = $Rscript."MMDYieldCurve\\update_yield_curve_forecast.kal.R --as_of ".$opts{as_of}." --db ".$opts{db}."\n";
print $cmd;
if( system($cmd) ) { exit(1); }

print "\nMuni MMD Yield Spread Models update completed.\n";
print "------------------------------------------------\n";

#update muni bond excess return model
#$cmd = $Rscript."ExcessReturn\\load_sector_code.R --db ".$opts{db}."\n";
#print $cmd;
#if( system($cmd) ) { exit(1); }

$cmd = $Rscript."ExcessReturn\\fit_surface.dev22.R --as_of ".$opts{as_of}." --db ".$opts{db}."\n";
print $cmd;
if( system($cmd) ) { exit(1); }

$cmd = $Rscript."ExcessReturn\\load_reg_data.dev14.R --as_of ".$opts{as_of}." --db ".$opts{db}."\n";
print $cmd;
if( system($cmd) ) { exit(1); }

$cmd = $Rscript."ExcessReturn\\update_factor_loading.kal.R --as_of ".$opts{as_of}." --db ".$opts{db}."\n";
print $cmd;
if( system($cmd) ) { exit(1); }

$cmd = $Rscript."ExcessReturn\\update_security_forecast.kal.R --as_of ".$opts{as_of}." --db ".$opts{db}."\n";
print $cmd;
if( system($cmd) ) { exit(1); }

# Risk model
# $cmd = $Rscript."RiskModel\\calc_cov_matrix.R --as_of ".$opts{as_of}." --db ".$opts{db}."\n";
# print $cmd;
# if( system($cmd) ) { exit(1); }
# 
# $cmd = $Rscript."RiskModel\\calc_risk_exposure.kal.R --as_of ".$opts{as_of}." --db ".$opts{db}." --ret \n";
# print $cmd;
# if( system($cmd) ) { exit(1); }

#if(Day_of_Week($year,$month,$day) == 10)# | Day_of_Week($year,$month,$day) == 4) #run reports on Fridays only
#{
# $cmd = $Rscript."ExcessReturn\\sector_forecast_decomposition.R --as_of ".$opts{as_of}." --db ".$opts{db}." --repo ".$network_repo."\n";
# print $cmd;
# if( system($cmd) ) { exit(1); }
# 
# $cmd = $Rscript."ExcessReturn\\portfolio_forecast_decomposition.R --as_of ".$opts{as_of}." --db ".$opts{db}." --repo ".$network_repo." --port N:\\ABFI_PROD\\Quant_Data_Repo\\Muni\\v1.0\\Input\\portfolios.csv\n";
# print $cmd;
# if( system($cmd) ) { exit(1); }
# 
# $cmd = $Rscript."ExcessReturn\\ReportGenerator.R  ".$opts{as_of}." ".$network_repo." ".$opts{db}."\n";
# print $cmd;
# if( system($cmd) ) { exit(1); }

# $cmd = $Rscript."ExcessReturn\\holdings_report.R --as_of ".$opts{as_of}." --db ".$opts{db}." --repo ".$network_repo."\n";
# print $cmd;
# if( system($cmd) ) { exit(1); }
#}
#### connect to MSSQL ####
# my $dbhmssql = DBI->connect( $msdb_url,
#                         $msdb_username,
#                         $msdb_password, 
#                         {PrintError => 1, RaiseError => 0, AutoCommit => 1}) 
# or die "Cannot connect to SQL database : $!\n";
# 
# 
# my $stmt = $dbhmssql->prepare(<<SQL);
# SELECT  LAST_BUS_DT
# FROM    DAILYVIEW.dbo.BUSINESS_DATE
# SQL
# $stmt->execute();
# my $value_date = ($stmt->fetchrow_array)[0];
# 
# $stmt = $dbhmssql->prepare(<<SQL);
# EXEC OptimizerExtract.dbo.Batch_UPDATE_FIO_DATES ? , 'MUNI_RETURN';
# SQL
# $stmt->execute($value_date);
# #$stmt->execute($opts{as_of};
# 
# 
# $stmt->finish;
# 
# $dbhmssql->disconnect();
}
else
{
	my $cmd = $Rscript."ExcessReturn\\update_security_forecast.kal.R --as_of ".$opts{as_of}." --db ".$opts{db}." -g\n";
	print $cmd;
	if( system($cmd) ) { exit(1); }
}
print "\nMuni Models update completed.\n";

