

source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.kal.R',sep='') )

coef4to12 <- function(a,x)
{
	xm = max(x)
	x1 = xm/3
	x2 = 2*xm/3
	
	
	a2_0 = a[1] + x1*a[2]/3 - x1*a[3]/3
	#a3_0 = a[1] - x1/3*a[2] + (x1 + x2)/3*a[3] - x2/3*a[4]
	
	a2_2 = a[2]/x1 - a[3]/x1
	a3_2 = a[2]/x1 + (1/x2 - 1/x1)*a[3] - a[4]/x2
	
	a1_3 = 1/3*((1/x1^2 - 1/x1/xm)*a[2] + (1/x1/xm - 1/x1^2 + 1/x2^2 -1/x2/xm)*a[3] - (1/x2^2 - 1/x2/xm)*a[4])
	a2_3 = 1/3*(-1/x1/xm*a[2] + (1/x1/xm + 1/x2^2 - 1/x2/xm)*a[3] - (1/x2^2 - 1/x2/xm)*a[4])
	a3_3 = -1/3*(1/x1/xm*a[2] + (1/x2/xm - 1/x1/xm)*a[3] - 1/x2/xm*a[4])
	
	a3_0 = a2_0 + a[3]*x2 +a2_2*x2^2 + a2_3 * x2^3 - a[4]*x2 - a3_2*x2^2 - a3_3*x2^3
	
	A = c(a[1],a[2],0,a1_3,a2_0,a[3],a2_2,a2_3,a3_0,a[4],a3_2,a3_3)
}

fcurve_3 <- function(a,x,y2f = NULL)
{
	x1 = max(x)/3
	x2 = 2*max(x)/3
	xm = max(x)
	
	A = coef4to12(a,x)
	
	y = x;
	y[x <= x1] = outer(x[x <= x1],0:3,"^") %*% A[1:4]
	y[x > x1 & x <= x2] = outer(x[x > x1 & x <= x2],0:3,"^") %*% A[5:8]
	y[x > x2] = outer(x[x > x2],0:3,"^") %*% A[9:12]
	
	if(is.null(y2f))
		y
	else{
		sum((y - y2f)^2)
	}
		
}

fcurve_poly3 <- function(a,x,y2f = NULL)
{
	
	
	y = outer(x,0:3,"^") %*% a
	
	if(is.null(y2f))
		y
	else{
		sum((y - y2f)^2)
	}
		
}

fcurve_plot <- function(a,x,xlim)
{
	y[x <= xlim[1]] = outer(x[x <= xlim[1]],0:3,"^") %*% a[1:4]
	y[x > xlim[1] & x <= xlim[2]] = outer(x[x > xlim[1] & x <= xlim[2]],0:3,"^") %*% a[5:8]
	y[x > xlim[2]] = outer(x[x > xlim[2]],0:3,"^") %*% a[9:12]
	
	y
}

calc_fexp2d <- function(samp, fgrid)
{
	np = dim(samp)[1]
	nf = dim(fgrid)[1]
	mexp = matrix(0,nrow = np,ncol = nf)  # (number of factors)X(number of points) matrix
	
	xval = sort(unique(fgrid[,1]))
	yval = sort(unique(fgrid[,2]))
	
	tm = interp.surface.ext(list(x=xval,y=yval,
		z=matrix(1,nrow=length(xval),ncol=length(yval))), samp,rule = 2,factors = TRUE)
	
	tm1 = tm[,-grep('exp',names(tm))]	
	
	for(i in 1:np)
	{	#x1y1
		ix = fgrid[,1] == xval[tm1[i,grep('x1',names(tm1))[1]]] & fgrid[,2] == yval[tm1[i,grep('y1',names(tm1))[1]]]
		mexp[i,ix] = tm[i,grep('x1y1',names(tm))]
		#x2y1
		ix = fgrid[,1] == xval[tm1[i,grep('x2',names(tm1))[1]]] & fgrid[,2] == yval[tm1[i,grep('y1',names(tm1))[1]]]
		mexp[i,ix] = tm[i,grep('x2y1',names(tm))]
		#x1y2
		ix = fgrid[,1] == xval[tm1[i,grep('x1',names(tm1))[1]]] & fgrid[,2] == yval[tm1[i,grep('y2',names(tm1))[1]]]
		mexp[i,ix] = tm[i,grep('x1y2',names(tm))]
		#x2y2
		ix = fgrid[,1] == xval[tm1[i,grep('x2',names(tm1))[1]]] & fgrid[,2] == yval[tm1[i,grep('y2',names(tm1))[1]]]
		mexp[i,ix] = tm[i,grep('x2y2',names(tm))]
	}
	mexp
}

calc_fexp <- function(samp, fgrid)
{
	np = length(samp)
	nf = length(fgrid)
	mexp = matrix(0,nrow = np,ncol = nf)  # (number of factors)X(number of points) matrix
	
	xval = sort(unique(fgrid))
	
	lx = approx(fgrid,1:nf,samp,rule = 2)$y
	lx1 <- floor(lx)
	ex <- lx - lx1
	ex[lx1 == nf] <- 1
	lx1[lx1 == nf] <- nf - 1
	
	mexp[cbind(1:np,lx1)] = 1 - ex
	mexp[cbind(1:np,lx1+1)] = ex
	mexp
}


#source('H:/SVN/Muni/v1.0/Src/RiskModel/risk_contrib.R')

library(RODBC)
db_info <- get_db_info('PRD')

as_of = as.Date('2018-04-19')

isRet = F  # switch for spread or return risk

sdata = load_data(as_of,db_info,src='Index',init = F,TRUE)
sdata = sdata[!(is.na(sdata$credit_rating) & sdata$credit_enhancement != 'None'),] # remove insured without issuer credit

sdata = sdata[!is.na(sdata$credit_rating),] # remove non-rated for now

sdata = sdata[!is.na(sdata$deminimis_buffer),]  # remove if no deminimis tax
sdata = sdata[order(sdata$identifier),]
#sdata = sdata[1:10,]

# convert deminimis to relative
dates = sort(unique(fact_hist$date))  # requires factors' history

ix = dates == as_of # check if the current date is in history

if(sum(ix) == 1)
{
	sdata$deminimis_buffer[!sdata$hy] = sdata$deminimis_buffer[!sdata$hy]/dmmax_ig[ix,'xm']
	sdata$deminimis_buffer[sdata$hy] = sdata$deminimis_buffer[sdata$hy]/dmmax_hy[ix,'xm']
}else
{ # use the latest data
	sdata$deminimis_buffer[!sdata$hy] = sdata$deminimis_buffer[!sdata$hy]/dmmax_ig[dim(dmmax_g)[1],'xm']
	sdata$deminimis_buffer[sdata$hy] = sdata$deminimis_buffer[sdata$hy]/dmmax_hy[dim(dmmax_g)[1],'xm']
}

# separate pre-refs
data_pr = get_prerefs(sdata)
sdata = sdata[sdata$ab_code != 333,]

#
# prepare exposures matrix
expdata = cbind(data.frame(id = sdata$identifier),data.frame(matrix(0,nrow = dim(sdata)[1],ncol = dim(fact_hist)[2]-1)))
names(expdata)[2:dim(expdata)[2]] = names(fact_hist)[2:dim(fact_hist)[2]]

Ns = dim(sdata)[1]

dummy_fact = c('state_gen','ab_code','ce_bucket')
dummy_fact_pr = c('state_pr','zero_coupon_pr')
dfc = c(100,300)

for(cfact in all_factors_tags)
{
#
# credit/duration
	if(cfact == 'credit_oad')
	{
		fexp = calc_fexp2d(sdata[,c('muni_oad','credit_rating')],f_grid)
		expdata[,grep(cfact,names(expdata))] = fexp
	}
#
# deminimis buffer
	if(cfact == 'dm_tax_gen')
	{
		fexp = calc_fexp(sdata$deminimis_buffer[!as.logical(sdata$hy)],factor_buckets(cfact))
		expdata[!as.logical(sdata$hy),grep(paste(cfact,'ig',sep=''),names(expdata))] = fexp

		fexp = calc_fexp(sdata$deminimis_buffer[as.logical(sdata$hy)],factor_buckets(cfact))
		expdata[as.logical(sdata$hy),grep(paste(cfact,'hy',sep=''),names(expdata))] = fexp
	}

#
# extension risk
	if(cfact == 'ext_risk')
		expdata[,grep(cfact,names(expdata))] = outer(sdata$extension_risk,0:3,'^')

# index 
	if(cfact == 'index_gen')
		expdata$index_gen = 1



	if(cfact %in% dummy_fact)
	{
		fexp = matrix(0,nrow = dim(expdata)[1],ncol = length(grep(cfact,names(expdata))))
		#tf =  matrix(rep(as.numeric(sub(dummy_fact[i],'',names(expdata)[grep(dummy_fact[i],names(expdata))])),Ns),nrow = Ns,byrow = T) #matrix of factors
		tf =  matrix(rep(sub(cfact,'',names(expdata)[grep(cfact,names(expdata))]),Ns),nrow = Ns,byrow = T)
		#cix = which(tf - sdata[,cfact] == 0,arr.ind = T) # find corresponding columns
		cix = which(tf == sdata[,attrs[all_factors_tags == cfact]],arr.ind = T)
	
		fexp[cix] = 1
		expdata[,grep(cfact,names(expdata))] = fexp
	}

	if(cfact %in% factors_interp_map$fact_tags)
	{
		f = factors_interp_map$fact[factors_interp_map$fact_tags == cfact]
		fexp = matrix(0,nrow = dim(expdata)[1],ncol = length(grep(cfact,names(expdata))))
		allexp = sort(unique(sdata[,f]))
		iexp = sdata[,f] != allexp[1] # smalest factor represents not being exposed
		fexp[!iexp,1] = 1
	
		fexpval = as.numeric(sub(cfact,'',names(expdata)[grep(cfact,names(expdata))]))
	
		fexp[iexp,2:dim(fexp)[2]] = calc_fexp(sdata[iexp,f],fexpval[2:length(fexpval)])
		expdata[,grep(cfact,names(expdata))] = fexp
	}
}

if(isRet)
{
	expdata[,2:dim(expdata)[2]] = sdata$muni_oad*expdata[,2:dim(expdata)[2]]
	expdata[,grep('tsy',names(expdata))] = sdata[,grep('krd',names(sdata))]
	expdata[,grep('aaammd',names(expdata))] = sdata[,grep('krd',names(sdata))]
}
# prepare pre-refs exposures matrix

expdata_pr = cbind(data.frame(id = data_pr$identifier),data.frame(matrix(0,nrow = dim(data_pr)[1],ncol = dim(fact_hist)[2]-1)))
names(expdata_pr)[2:dim(expdata_pr)[2]] = names(fact_hist)[2:dim(fact_hist)[2]]

Ns_pr = dim(data_pr)[1]

for(cfact in pr_factors_tags)
{
	if(cfact == 'index_oas_pr')
		expdata_pr$index_oas_pr1 = 1
	
	if(cfact == 'pr_oad')
		expdata_pr[,paste(cfact,'_b1',sep='')] = data_pr$muni_oad
	
	if(cfact == 'deminimis_buffer_pr')
		expdata_pr$deminimis_buffer_pr_b1 = data_pr$deminimis_buffer
					
	if(cfact %in% dummy_fact_pr)
	{
		fexp = matrix(0,nrow = dim(expdata_pr)[1],ncol = length(grep(cfact,names(expdata_pr))))
		tf =  matrix(rep(sub(cfact,'',names(expdata_pr)[grep(cfact,names(expdata_pr))]),Ns_pr),nrow = Ns_pr,byrow = T)
		cix = which(tf == data_pr[,sub('_pr','',cfact)],arr.ind = T)
	
		fexp[cix] = 1
		expdata_pr[,grep(cfact,names(expdata_pr))] = fexp
	}
}
if(isRet)
{
	expdata_pr[,2:dim(expdata_pr)[2]] = data_pr$muni_oad*expdata_pr[,2:dim(expdata_pr)[2]]
	expdata_pr[,grep('tsy',names(expdata_pr))] = data_pr[,grep('krd',names(data_pr))]
	expdata_pr[,grep('aaammd',names(expdata_pr))] = data_pr[,grep('krd',names(data_pr))]
}

#expdata = rbind(expdata,expdata_pr)
#sdata = rbind(sdata,data_pr)

cov_fact_hist = fact_hist[fact_hist$date <= as_of,]
n = dim(cov_fact_hist)[1]
Nf = dim(cov_fact_hist)[2] - 1

hrz = 1
lg = 0
freq = 0
if(mean(diff(cov_fact_hist$date)) > 25) {
	lb = 24  # 2 year look back for monthly data
	lg = hrz
	freq = 1
}else
{
	lb = 126
	lb = 504  # estimation sample length (number of observations)
	lg = hrz*21  # time span to use for computing the spread change
	#lg = 1
	freq = 21  # reporting time period (1 month)
}
goodf = rep(TRUE,Nf)
for(i in 1:Nf)
{
	fsd = sd(diff(cov_fact_hist[(n - lb + 1 - lg):n,i + 1],lag = lg))
	if(is.na(fsd) | fsd == 0)
		goodf[i] = FALSE
}
goodf = which(goodf) + 1

stdate = cov_fact_hist$date[n - lb] 
cov_fact_hist = cbind(data.frame(date = cov_fact_hist$date[(n - lb + 1):n]),diff(as.matrix(cov_fact_hist[(n - lb + 1 - lg):n,goodf]),lag = lg))
Nf = dim(cov_fact_hist)[2] - 1
	
Cov = cov(cov_fact_hist[,2:(Nf+1)])	

### exponential weighting
hlife = 63
lam = 0.5^(1/(hlife-1))
wt = as.vector(outer(lam,0:(dim(cov_fact_hist)[1]-1),'^'))
Cov = cov.wt(cov_fact_hist[,2:(Nf+1)],wt[order(wt)]/sum(wt),center = F)$cov

fvol = sqrt(diag(Cov))
Cor = 	cov2cor(Cov)

risksys = data.frame()

for(i in 1:10)#dim(expdata)[1])
{
	if(i %% 1000 == 0) print(i)
	
	dln = data.frame(id = expdata$id[i], spread_vol = sqrt(as.matrix(expdata[i,goodf]) %*% Cov %*% t(as.matrix(expdata[i,goodf]))))
	names(dln)[2] = 'spread_vol'
	for(j in 1:length(all_factors))
	{
		inx = grep(all_factors_tags[j],names(expdata))
		inx = inx[inx %in% goodf]
		inxcov = goodf %in% inx
		dln = cbind(dln, (as.matrix(expdata[i,goodf]) %*% Cov[,inxcov] %*% t(as.matrix(expdata[i,inx])))/(dln$spread_vol^2))
		names(dln)[dim(dln)[2]] = all_factors_tags[j]
	} 
	risksys = rbind(risksys,dln)
#risksys = cbind(risksys,sqrt(diag(as.matrix(expdata[,goodf]) %*% Cov %*% t(as.matrix(expdata[,goodf])))))
}

blocks = seq(1,dim(expdata)[1],by = 1000) #process secs by block 1000 secs each to avoid memory issues
blocks = c(blocks,dim(expdata)[1]+1)
risksys = data.frame()
for(i in 2:length(blocks))
{
	print(blocks[i]-1)
	expdataw = expdata[blocks[i-1]:(blocks[i]-1),]
	if(!isRet) {
		rs = data.frame(id = expdataw$id, spread_vol = sqrt(diag(as.matrix(expdataw[,goodf]) %*% Cov %*% t(as.matrix(expdataw[,goodf])))))
	}else {
		rs = data.frame(id = expdataw$id, ret_vol = sqrt(diag(as.matrix(expdataw[,goodf]) %*% Cov %*% t(as.matrix(expdataw[,goodf])))))
	}
	
	for(j in 1:length(all_factors))
	{
		inx = grep(all_factors_tags[j],names(expdataw))
		inx = inx[inx %in% goodf]
		inxcov = goodf %in% inx
		if(!isRet) {
			rs = cbind(rs, diag(as.matrix(expdataw[,goodf]) %*% Cov[,inxcov] %*% t(as.matrix(expdataw[,inx])))/(rs$spread_vol^2))
		}else {
			rs = cbind(rs, diag(as.matrix(expdataw[,goodf]) %*% Cov[,inxcov] %*% t(as.matrix(expdataw[,inx])))/(rs$ret_vol^2))
		}
		names(rs)[dim(rs)[2]] = all_factors_tags[j]
	} 
	if(isRet)
	{
		# treasury
		inx = grep('tsy',names(expdataw))
		inx = inx[inx %in% goodf]
		inxcov = goodf %in% inx
		rs = cbind(rs, diag(as.matrix(expdataw[,goodf]) %*% Cov[,inxcov] %*% t(as.matrix(expdataw[,inx])))/(rs$ret_vol^2))
		names(rs)[dim(rs)[2]] = 'tsy'
		# spread
		inx = grep('aaammd',names(expdataw))
		inx = inx[inx %in% goodf]
		inxcov = goodf %in% inx
		rs = cbind(rs, diag(as.matrix(expdataw[,goodf]) %*% Cov[,inxcov] %*% t(as.matrix(expdataw[,inx])))/(rs$ret_vol^2))
		names(rs)[dim(rs)[2]] = 'aaammd'
	}

	for(j in 1:length(all_factors)) #stand-along risk
	{
		inx = grep(all_factors_tags[j],names(expdataw))
		inx = inx[inx %in% goodf]
		inxcov = goodf %in% inx
		rs = cbind(rs, sqrt(freq*hrz/lg*diag(as.matrix(expdataw[,inx]) %*% Cov[inxcov,inxcov] %*% t(as.matrix(expdataw[,inx])))))
		names(rs)[dim(rs)[2]] = paste('sa_',all_factors_tags[j],sep = '')
	} 
	
	if(isRet)
	{
		# treasury
		inx = grep('tsy',names(expdataw))
		inx = inx[inx %in% goodf]
		inxcov = goodf %in% inx
		rs = cbind(rs, sqrt(freq*hrz/lg*diag(as.matrix(expdataw[,inx]) %*% Cov[inxcov,inxcov] %*% t(as.matrix(expdataw[,inx])))))
		names(rs)[dim(rs)[2]] = 'sa_tsy'
		# spread
		inx = grep('aaammd',names(expdataw))
		inx = inx[inx %in% goodf]
		inxcov = goodf %in% inx
		rs = cbind(rs, sqrt(freq*hrz/lg*diag(as.matrix(expdataw[,inx]) %*% Cov[inxcov,inxcov] %*% t(as.matrix(expdataw[,inx])))))
		names(rs)[dim(rs)[2]] = 'sa_aaammd'
	}
	risksys = rbind(risksys,rs)
}
# last block
risksys = risksys[order(risksys$id),]
output = cbind(risksys,sdata[,c('index_rating','coupon','maturity_date','price','next_call_date','muni_oas','muni_oad',
	'deminimis_buffer','state','ab_code','muni_taxability','credit_rating','ce_bucket','extension_risk','zero_coupon','hy')])
output = output[order(output$id),]
if(!isRet) {
	output = output[!is.na(output$spread_vol),]
	output$spread_vol = output$spread_vol*sqrt(freq*hrz/lg)
}else {
	output = output[!is.na(output$ret_vol),]
	output$ret_vol = output$ret_vol*sqrt(freq*hrz/lg)
}

setwd('H://tmp')
write.csv(output,'t.csv')





