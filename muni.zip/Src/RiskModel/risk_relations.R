
#source('H:/SVN/Muni/v1.0/Src/RiskModel/risk_relations.R')

st = cov_fact_hist$date[1]
require(RODBC)


q = paste("select AS_OF_DATE date, IDENTIFIER id, INDEX_OAS+CREDIT_CURVE+STATE+SECTOR+AMT+COUPON_EFFECT+RESI_OAS+EXTENSION_RISK+ZERO_COUPON+CREDIT_ENHANCEMENT oas,
	INDEX_OAS+CREDIT_CURVE+STATE+SECTOR+AMT+COUPON_EFFECT+EXTENSION_RISK+ZERO_COUPON+CREDIT_ENHANCEMENT oas_sys,RESI_OAS oas_nonsys from FIQModel..MUNI_OAS_DECOMPOSITION
	where AS_OF_DATE <= '",as_of,"' and AS_OF_DATE >= '",st,"' order by 1",sep = '')

# q = paste("select AS_OF_DATE date, IDENTIFIER id, INDEX_OAS+CREDIT_CURVE+STATE+SECTOR+AMT+COUPON_EFFECT+RESI_OAS+EXTENSION_RISK+ZERO_COUPON+CREDIT_ENHANCEMENT oas,
# 	INDEX_OAS+CREDIT_CURVE+STATE+SECTOR+AMT+COUPON_EFFECT+EXTENSION_RISK+ZERO_COUPON+CREDIT_ENHANCEMENT oas_sys,RESI_OAS oas_nonsys from FIQModel..MUNI_OAS_DECOMPOSITION
# 	where AS_OF_DATE <= '",as_of,"' and AS_OF_DATE >= '",st,"' 
# 	and AS_OF_DATE in (select MAX(AS_OF_DATE) from FIQModel..MUNI_OAS_DECOMPOSITION group by substring(convert(varchar, AS_OF_DATE, 112),1,6)) order by 1",sep = '')	

	
 channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
 riskdata <- sqlQuery(channel,query=q)
 odbcClose(channel)

sprd_chng = aggregate(. ~ id,riskdata[,c('id','oas','oas_sys','oas_nonsys')],function(x) diff(x,lag = lg))

sprd_chng = sprd_chng[sprd_chng$id %in% risksys$id,]

riskact = data.frame()
for(i in 1:dim(sprd_chng)[1])
{
	if(i %% 1000 == 0) cat(paste(i,"\n",sep = ''))
	dln = data.frame(id = sprd_chng$id[i], vol = sd(sprd_chng$oas[[i]]), vol_sys = sd(sprd_chng$oas_sys[[i]]), 
		vol_nonsys = sd(sprd_chng$oas_nonsys[[i]]),cr = cor(sprd_chng$oas_sys[[i]],sprd_chng$oas_nonsys[[i]]))
	riskact = rbind(riskact,dln)	
}




