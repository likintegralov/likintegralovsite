
#source('H:/SVN/Muni/v1.0/Src/RiskModel/fcperf.R')

source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.kal.R',sep='') )

st = as.Date('2015-01-01')
#st = as.Date('2014-08-09')

setwd('H:/tmp')
load('actrisk3m_fwd.RData')	

dates = sort(unique(actrisk$date))
dates = dates[dates > st]

exfact = 'deminimis_buffer_pr_b1'

hrz = 1
lb = 504  # estimation sample length (number of observations)
lg = hrz*1  # time span to use for computing the spread change
freq = 21  # reporting time period (1 month)

db_info <- get_db_info('QA')
fc_all = data.frame()
fc_mean = data.frame()
for(i in 1:length(dates))
{
	cov_fact_hist = fact_hist[fact_hist$date <= dates[i],]
	n = dim(cov_fact_hist)[1]
	Nf = dim(cov_fact_hist)[2] - 1

	goodf = rep(TRUE,Nf)
	for(j in 1:Nf)
	{
		fsd = sd(diff(cov_fact_hist[(n - lb + 1 - lg):n,j + 1],lag = lg))
		if(is.na(fsd) | fsd == 0)
			goodf[j] = FALSE
	}
	goodf = which(goodf) + 1
	
	goodf = goodf[!(goodf %in% which(names(cov_fact_hist) %in% exfact))]
	
	stdate = cov_fact_hist$date[n - lb] 
	cov_fact_hist = cbind(data.frame(date = cov_fact_hist$date[(n - lb + 1):n]),diff(as.matrix(cov_fact_hist[(n - lb + 1 - lg):n,goodf]),lag = lg))
	Nf = dim(cov_fact_hist)[2] - 1
		
	#Cov = cov(cov_fact_hist[,2:(Nf+1)])	

	### exponential weighting
	hlife = 252
	lam = 0.5^(1/(hlife-1))
	wt = as.vector(outer(lam,0:(dim(cov_fact_hist)[1]-1),'^'))
	Cov = cov.wt(cov_fact_hist[,2:(Nf+1)],wt[order(wt)]/sum(wt),center = F)$cov
	
	fvol = sqrt(diag(Cov))
	Cor = 	cov2cor(Cov)

	secs = actrisk[actrisk$date == dates[i],'id']
	arisk = actrisk[actrisk$date == dates[i],]
	
	sdata = load_data(dates[i],db_info,src='Index',init = F,TRUE)
	sdata = sdata[sdata$identifier %in% secs,] 
	
	sdata = sdata[!(is.na(sdata$credit_rating) & sdata$credit_enhancement != 'None'),] # remove insured without issuer credit

	sdata = sdata[!is.na(sdata$credit_rating),] # remove non-rated for now
	sdata = sdata[!is.na(sdata$deminimis_buffer),]  # remove if no deminimis tax
	sdata = sdata[order(sdata$identifier),]
	#sdata = sdata[1:10,]
	
	# convert deminimis to relative
	dts = sort(unique(fact_hist$date))  # requires factors' history
	
	ix = dts == dates[i] # check if the current date is in history

	sdata$deminimis_buffer[!sdata$hy] = sdata$deminimis_buffer[!sdata$hy]/dmmax_ig[ix,'xm']
	sdata$deminimis_buffer[sdata$hy] = sdata$deminimis_buffer[sdata$hy]/dmmax_hy[ix,'xm']
	
	# separate pre-refs
	data_pr = get_prerefs(sdata)
	sdata = sdata[sdata$ab_code != 333,]
	
	# prepare exposures matrix
	expdata = cbind(data.frame(id = sdata$identifier),data.frame(matrix(0,nrow = dim(sdata)[1],ncol = dim(fact_hist)[2]-1)))
	names(expdata)[2:dim(expdata)[2]] = names(fact_hist)[2:dim(fact_hist)[2]]
	
	Ns = dim(sdata)[1]
	
	dummy_fact = c('state_gen','ab_code','ce_bucket')
	dummy_fact_pr = c('state_pr','zero_coupon_pr')
	dfc = c(100,300)
	
	for(cfact in all_factors_tags)
	{
	#
	# credit/duration
		if(cfact == 'credit_oad')
		{
			fexp = calc_fexp2d(sdata[,c('muni_oad','credit_rating')],f_grid)
			expdata[,grep(cfact,names(expdata))] = fexp
		}
	#
	# deminimis buffer
		if(cfact == 'dm_tax_gen')
		{
			fexp = calc_fexp(sdata$deminimis_buffer[!as.logical(sdata$hy)],factor_buckets(cfact))
			expdata[!as.logical(sdata$hy),grep(paste(cfact,'ig',sep=''),names(expdata))] = fexp
	
			fexp = calc_fexp(sdata$deminimis_buffer[as.logical(sdata$hy)],factor_buckets(cfact))
			expdata[as.logical(sdata$hy),grep(paste(cfact,'hy',sep=''),names(expdata))] = fexp
		}
	
	#
	# extension risk
		if(cfact == 'ext_risk')
			expdata[,grep(cfact,names(expdata))] = outer(sdata$extension_risk,0:3,'^')
	
	# index 
		if(cfact == 'index_gen')
			expdata$index_gen = 1
	
	
	
		if(cfact %in% dummy_fact)
		{
			fexp = matrix(0,nrow = dim(expdata)[1],ncol = length(grep(cfact,names(expdata))))
			#tf =  matrix(rep(as.numeric(sub(dummy_fact[i],'',names(expdata)[grep(dummy_fact[i],names(expdata))])),Ns),nrow = Ns,byrow = T) #matrix of factors
			tf =  matrix(rep(sub(cfact,'',names(expdata)[grep(cfact,names(expdata))]),Ns),nrow = Ns,byrow = T)
			#cix = which(tf - sdata[,cfact] == 0,arr.ind = T) # find corresponding columns
			cix = which(tf == sdata[,attrs[all_factors_tags == cfact]],arr.ind = T)
		
			fexp[cix] = 1
			expdata[,grep(cfact,names(expdata))] = fexp
		}
	
		if(cfact %in% factors_interp_map$fact_tags)
		{
			f = factors_interp_map$fact[factors_interp_map$fact_tags == cfact]
			fexp = matrix(0,nrow = dim(expdata)[1],ncol = length(grep(cfact,names(expdata))))
			allexp = sort(unique(sdata[,f]))
			iexp = sdata[,f] != allexp[1] # smalest factor represents not being exposed
			fexp[!iexp,1] = 1
		
			fexpval = as.numeric(sub(cfact,'',names(expdata)[grep(cfact,names(expdata))]))
		
			fexp[iexp,2:dim(fexp)[2]] = calc_fexp(sdata[iexp,f],fexpval[2:length(fexpval)])
			expdata[,grep(cfact,names(expdata))] = fexp
		}
	}

	if(dim(data_pr)[1]>0)
	{
		expdata_pr = cbind(data.frame(id = data_pr$identifier),data.frame(matrix(0,nrow = dim(data_pr)[1],ncol = dim(fact_hist)[2]-1)))
		names(expdata_pr)[2:dim(expdata_pr)[2]] = names(fact_hist)[2:dim(fact_hist)[2]]
		
		Ns_pr = dim(data_pr)[1]
		
		for(cfact in pr_factors_tags)
		{
			if(cfact == 'index_oas_pr')
				expdata_pr$index_oas_pr1 = 1
			
			if(cfact == 'pr_oad')
				expdata_pr[,paste(cfact,'_b1',sep='')] = data_pr$muni_oad
			
			if(cfact == 'deminimis_buffer_pr')
				expdata_pr$deminimis_buffer_pr_b1 = data_pr$deminimis_buffer
							
			if(cfact %in% dummy_fact_pr)
			{
				fexp = matrix(0,nrow = dim(expdata_pr)[1],ncol = length(grep(cfact,names(expdata_pr))))
				tf =  matrix(rep(sub(cfact,'',names(expdata_pr)[grep(cfact,names(expdata_pr))]),Ns_pr),nrow = Ns_pr,byrow = T)
				cix = which(tf == data_pr[,sub('_pr','',cfact)],arr.ind = T)
			
				fexp[cix] = 1
				expdata_pr[,grep(cfact,names(expdata_pr))] = fexp
			}
		}
		expdata = rbind(expdata,expdata_pr)
		expdata[expdata$deminimis_buffer_pr_b1 > mean(expdata_pr$deminimis_buffer_pr_b1) + 2*sd(expdata_pr$deminimis_buffer_pr_b1),
				'deminimis_buffer_pr_b1'] = mean(expdata_pr$deminimis_buffer_pr_b1) + 2*sd(expdata_pr$deminimis_buffer_pr_b1)
	}
	
	expdata = expdata[!(rowSums(expdata[,goodf]) == 0),]
	
	blocks = seq(1,dim(expdata)[1],by = 2000) #process secs by block 1000 secs each to avoid memory issues
	blocks = c(blocks,dim(expdata)[1]+1)
	risksys = data.frame()
	for(k in 2:length(blocks))
	{
		print(blocks[k]-1)
		expdataw = expdata[blocks[k-1]:(blocks[k]-1),]
		
		rs = data.frame(id = expdataw$id, spread_vol = sqrt(freq/lg)*sqrt(diag(as.matrix(expdataw[,goodf]) %*% Cov %*% t(as.matrix(expdataw[,goodf])))))
	
		for(j in 1:length(all_factors))
		{
			inx = grep(all_factors_tags[j],names(expdataw))
			inx = inx[inx %in% goodf]
			inxcov = goodf %in% inx
		
			rs = cbind(rs, diag(as.matrix(expdataw[,goodf]) %*% Cov[,inxcov] %*% t(as.matrix(expdataw[,inx])))/(rs$spread_vol^2)*sqrt(freq/lg))
		
			names(rs)[dim(rs)[2]] = all_factors_tags[j]
		}
		
		
		tm = merge(rs[,c('id','spread_vol')],arisk[,c('id','oas_sys','date')])
		tm = tm[,c('date','id','spread_vol','oas_sys')]
		names(tm)[3:4] = c('vol_fc','vol_act')
	
		fc_all = rbind(fc_all,tm)
	}
	fc_mean = rbind(fc_mean,data.frame(date = dates[i],vol_fc = mean(tm$vol_fc),vol_act = mean(tm$vol_act)))
}

fc_all = fc_all[!(fc_all$id %in% c('957480AB','59465ESE','59465ESG','940157QC','917567AG','072024MF','2463802J','2463802K','64971M6F',
									'645918XV','64971MZQ','940157QD','940157QE','010891PK','68304EBR')),]