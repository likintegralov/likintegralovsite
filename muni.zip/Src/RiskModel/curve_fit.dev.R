

source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.R',sep='') )

load_curve <- function(adt,attr,db_info,v2 = 0)
{
	q = paste("select VALUE1 x, OAS oas from FIQModel..OAS_ATTRIBUTION_FIT ",
			"where SECTOR = 'muni' ",
			"and ATTRIBUTE = '",attr,"' ",
			"and VALUE2 = ",v2," ",
			"and AS_OF_DATE = '",adt,"' order by x",sep = '')
			
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    out <- sqlQuery(channel,query=q)
    odbcClose(channel)
    
    out			
}

load_curves <- function(attr,db_info,v2 = 0,monthly = TRUE)
{
	if(monthly)
	{
		q = paste("select AS_OF_DATE date, VALUE1 x, OAS oas from FIQModel..OAS_ATTRIBUTION_FIT ",
			"where SECTOR = 'muni' ",
			"and ATTRIBUTE = '",attr,"' ",
			"and VALUE2 = ",v2," ",
			"and AS_OF_DATE in (select MAX(AS_OF_DATE) from FIQModel..OAS_ATTRIBUTION_FIT group by substring(convert(varchar, AS_OF_DATE, 112),1,6)) ",
			"order by AS_OF_DATE,x",sep = '')		
	}else
	{
		q = paste("select AS_OF_DATE date, VALUE1 x, OAS oas from FIQModel..OAS_ATTRIBUTION_FIT ",
			"where SECTOR = 'muni' ",
			"and ATTRIBUTE = '",attr,"' ",
			"and VALUE2 = ",v2," ",
			"order by AS_OF_DATE,x",sep = '')
	}		
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    out <- sqlQuery(channel,query=q)
    odbcClose(channel)
    
    out			
}

load_surface <- function(adt,attr,db_info)
{
	q = paste("select AS_OF_DATE date, VALUE1 x, VALUE2 y, OAS oas from FIQModel..OAS_ATTRIBUTION_FIT ",
			"where SECTOR = 'muni' ",
			"and ATTRIBUTE = '",attr,"' ",
			"and AS_OF_DATE = '",adt,"' ",
			"order by AS_OF_DATE,x",sep = '')
			
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    out <- sqlQuery(channel,query=q)
    odbcClose(channel)
    
    out			
}

load_surfaces <- function(attr,db_info,monthly = TRUE)
{
	if(monthly)
	{
		q = paste("select AS_OF_DATE date, VALUE1 x, VALUE2 y, OAS oas from FIQModel..OAS_ATTRIBUTION_FIT ",
			"where SECTOR = 'muni' ",
			"and ATTRIBUTE = '",attr,"' ",
			"and AS_OF_DATE in (select MAX(AS_OF_DATE) from FIQModel..OAS_ATTRIBUTION_FIT group by substring(convert(varchar, AS_OF_DATE, 112),1,6)) ",
			"order by AS_OF_DATE,x",sep = '')
	}else
	{
		q = paste("select AS_OF_DATE date, VALUE1 x, VALUE2 y, OAS oas from FIQModel..OAS_ATTRIBUTION_FIT ",
			"where SECTOR = 'muni' ",
			"and ATTRIBUTE = '",attr,"' ",
			"order by AS_OF_DATE,x",sep = '')
	}	
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    out <- sqlQuery(channel,query=q)
    odbcClose(channel)
    
    out			
}
coef4to12 <- function(a,x)
{
	xm = max(x)
	x1 = xm/3
	x2 = 2*xm/3
	
	
	a2_0 = a[1] + x1*a[2]/3 - x1*a[3]/3
	#a3_0 = a[1] - x1/3*a[2] + (x1 + x2)/3*a[3] - x2/3*a[4]
	
	a2_2 = a[2]/x1 - a[3]/x1
	a3_2 = a[2]/x1 + (1/x2 - 1/x1)*a[3] - a[4]/x2
	
	a1_3 = 1/3*((1/x1^2 - 1/x1/xm)*a[2] + (1/x1/xm - 1/x1^2 + 1/x2^2 -1/x2/xm)*a[3] - (1/x2^2 - 1/x2/xm)*a[4])
	a2_3 = 1/3*(-1/x1/xm*a[2] + (1/x1/xm + 1/x2^2 - 1/x2/xm)*a[3] - (1/x2^2 - 1/x2/xm)*a[4])
	a3_3 = -1/3*(1/x1/xm*a[2] + (1/x2/xm - 1/x1/xm)*a[3] - 1/x2/xm*a[4])
	
	a3_0 = a2_0 + a[3]*x2 +a2_2*x2^2 + a2_3 * x2^3 - a[4]*x2 - a3_2*x2^2 - a3_3*x2^3
	
	A = c(a[1],a[2],0,a1_3,a2_0,a[3],a2_2,a2_3,a3_0,a[4],a3_2,a3_3)
}

fcurve_3 <- function(a,x,y2f = NULL)
{
	x1 = max(x)/3
	x2 = 2*max(x)/3
	xm = max(x)
	
# 	a2_0 = a[1] + x1*a[2]/3 - x1*a[3]/3
# 	#a3_0 = a[1] - x1/3*a[2] + (x1 + x2)/3*a[3] - x2/3*a[4]
# 	
# 	a2_2 = a[2]/x1 - a[3]/x1
# 	a3_2 = a[2]/x1 + (1/x2 - 1/x1)*a[3] - a[4]/x2
# 	
# 	a1_3 = 1/3*((1/x1^2 - 1/x1/xm)*a[2] + (1/x1/xm - 1/x1^2 + 1/x2^2 -1/x2/xm)*a[3] - (1/x2^2 - 1/x2/xm)*a[4])
# 	a2_3 = 1/3*(-1/x1/xm*a[2] + (1/x1/xm + 1/x2^2 - 1/x2/xm)*a[3] - (1/x2^2 - 1/x2/xm)*a[4])
# 	a3_3 = -1/3*(1/x1/xm*a[2] + (1/x2/xm - 1/x1/xm)*a[3] - 1/x2/xm*a[4])
# 	
# 	a3_0 = a2_0 + a[3]*x2 +a2_2*x2^2 + a2_3 * x2^3 - a[4]*x2 - a3_2*x2^2 - a3_3*x2^3
# 
# 	
# 	A = as.matrix(c(a[1],a[2],0,a1_3,a2_0,a[3],a2_2,a2_3,a3_0,a[4],a3_2,a3_3))
	
	A = coef4to12(a,x)
	
	y = x;
	y[x <= x1] = outer(x[x <= x1],0:3,"^") %*% A[1:4]
	y[x > x1 & x <= x2] = outer(x[x > x1 & x <= x2],0:3,"^") %*% A[5:8]
	y[x > x2] = outer(x[x > x2],0:3,"^") %*% A[9:12]
	
	if(is.null(y2f))
		y
	else{
		sum((y - y2f)^2)
	}
		
}

fcurve_poly3 <- function(a,x,y2f = NULL)
{
	
	
	y = outer(x,0:3,"^") %*% a
	
	if(is.null(y2f))
		y
	else{
		sum((y - y2f)^2)
	}
		
}

fcurve_plot <- function(a,x,xlim)
{
	y[x <= xlim[1]] = outer(x[x <= xlim[1]],0:3,"^") %*% a[1:4]
	y[x > xlim[1] & x <= xlim[2]] = outer(x[x > xlim[1] & x <= xlim[2]],0:3,"^") %*% a[5:8]
	y[x > xlim[2]] = outer(x[x > xlim[2]],0:3,"^") %*% a[9:12]
	
	y
}



#source('H:/SVN/Muni/v1.0/Src/RiskModel/curve_fit.R')

library(RODBC)
db_info <- get_db_info('QA')

as_of = as.Date('2016-01-29')


attr = 'deminimis_buffer'
#attr = 'extension_risk'
attr = 'credit_oad'

if(attr == 'deminimis_buffer')
{
	c2fhist = load_curves(attr,db_info,0)
	c2fhist$date = as.Date(c2fhist$date)
	dates = unique(c2fhist$date)
	
	if(1)
	{
		dmfact = seq(0,1,length.out = 11)
		c2fhist_rel = data.frame()
		dmfact_hist = data.frame()
		for(i in 1:length(dates))
		{
			ccurve = c2fhist[c2fhist$date == dates[i],]
			xm = max(ccurve$x)
			ccurve$x = ccurve$x / xm
			c2fhist_rel = rbind(c2fhist_rel,ccurve)
			cfact = approx(ccurve$x,ccurve$oas,dmfact,method = 'linear',rule = 2)$y
			cf_df = data.frame(date = dates[i],xm = xm)
			for(j in 1:length(cfact))
				cf_df = cbind(cf_df,data.frame(x = cfact[j]))
			dmfact_hist = rbind(dmfact_hist,cf_df)
		}
		for(i in 3:dim(dmfact_hist)[2])
			names(dmfact_hist)[i] = paste('f',dmfact[i-2],sep = '')
				
	}else
	{
		Ahist = data.frame()
		allAhist = data.frame()
		fitres = data.frame()
		for(i in 1:length(dates))
		{
			c2f = c2fhist[c2fhist$date == dates[i],-1]
			x1 = max(c2f[,names(c2f) == 'x'])/3
			x2 = 2*max(c2f[,names(c2f) == 'x'])/3
			xm = max(c2f[,names(c2f) == 'x'])
		
			x = c2f[seq(1,dim(c2f)[1],length.out = 12),1]
		
			R = matrix(ncol = 12,nrow = 0)
			for(xc in x)
			{
				if(xc <= x1)
				R = rbind(R, t(as.matrix(c(1,xc,xc^2,xc^3,0,0,0,0,0,0,0,0))))
				else if(xc > x1 & xc <= x2)
					R = rbind(R, t(as.matrix(c(0,0,0,0,1,xc,xc^2,xc^3,0,0,0,0))))
				else
					R = rbind(R, t(as.matrix(c(0,0,0,0,0,0,0,0,1,xc,xc^2,xc^3))))
			}
		
			A0 = solve(R,c2f[seq(1,dim(c2f)[1],length.out = 12),2])
		
		#	Rp = outer(c(0,x1,x2,xm),0:3,"^")
		#	A0p = solve(Rp,c2f[seq(1,dim(c2f)[1],length.out = 4),2])
		
		
		#fcurve = fcurve_3(c(A[1],A[2],A[5],A[10]),c2f[,1])
		
			aopt = optim(c(A0[1],A0[2],A0[5],A0[10]),fcurve_3,x = c2f[,1],y2f = c2f[,2])
			
			Ahist = rbind(Ahist,data.frame(date = dates[i],Int = aopt$par[1],S1 = aopt$par[2],S2 = aopt$par[3],S3 = aopt$par[4],
						x1 = x1, x2 = x2, xm = xm))
			fitres = rbind(fitres,data.frame(date = dates[i],err = aopt$value))
		#aoptpoly = optim(A0p,fcurve_poly3,x = c2f[,1],y2f = c2f[,2])
		
			fcurve = fcurve_3(aopt$par,c2f[,1])
			#as.matrix(fcurve)
		
		#fcurvepoly = outer(c2f[,1],0:3,"^") %*% aoptpoly$par
		#as.matrix(fcurvepoly)
		}
	}
}

if(attr == 'extension_risk')
{
	c2fhist = load_curves(attr,db_info)
	
	dates = unique(c2fhist$date)
	
	Ahist = data.frame()
	fitres = data.frame()
	for(i in 1:length(dates))
	{
		c2f = c2fhist[c2fhist$date == dates[i],-1]
		xi = seq(1,dim(c2f)[1],length.out = 4)
		x = c2f[xi,1]
		R = outer(x,0:3,"^")
			
		A0 = solve(R,c2f[xi,2])
		
		aopt = optim(A0,fcurve_poly3,x = c2f[,1],y2f = c2f[,2])
		
		Ahist = rbind(Ahist,data.frame(date = dates[i],b0 = aopt$par[1],b1 = aopt$par[2],b2 = aopt$par[3],b3 = aopt$par[4]))
		
		fitres = rbind(fitres,data.frame(date = dates[i],err = aopt$value))
		
		fcurve = fcurve_poly3(aopt$par,c2f[,1])
	}
}

if(attr == 'credit_oad')
{
	
	require(fields)
	
	credit_bn = c('AAA','BBB+','BB','CCC')
	credit_b = c(1,3,6,9,12,18)
	oad_b = c(0,5,10,15)  
	#oad_b = c(0,4,10,15)  #a
	#oad_b = c(0,6,10,15)  #b
	#oad_b = c(0,7,10,15)  #c
	#oad_b = c(0,5,9,15)    #d
	#oad_b = c(0,5,11,15)   #e
	
	#credit_b = c(1,6,9,12,18)
	#credit_b = c(1,9,12,18)
	#credit_b = c(1,6,12,18) #a
	credit_b = c(1,8,12,18) #b
	#credit_b = c(1,10,18)
	
	#credit_b = c(1,8,13,18) #c
	
	
	credit_s = sort(round(runif(5,1,19),1))
	oad_s = sort(round(runif(10,0,15),1))
	
	credit_s = round(seq(1,20,length.out = 10),1)
	oad_s = round(seq(0,16,length.out = 10),1)

	#credit_s = credit_b
	#oad_s = oad_b
			
	f_grid = make.surface.grid(list(oad_b,credit_b))
	s_grid = make.surface.grid(list(oad_s,credit_s))
		
	cd_hist = load_surfaces(attr,db_info)
	cd_hist$date = as.Date(cd_hist$date)
	
	dates = unique(cd_hist$date)
	cdfact_hist = data.frame()
	sp_hist = data.frame()
	
	for(i in 1:length(dates))
	{
		cd = cd_hist[cd_hist$date == dates[i],]
		
		dur <-  sort(unique(cd$y))
		credit <- sort(unique(cd$x))
	    
	    z <-  matrix(cd$oas,nrow=length(dur))
	    
	    z_vec <- interp.surface.ext(list(x=dur,y=credit,z=z), f_grid,rule = 2)
		z_mat <- matrix(z_vec,nrow=length(oad_b))
	    s_out <- interp.surface.ext(list(x=dur,y=credit,z=z), s_grid,rule = 2)

		colnames(z_mat) = credit_b
	    rownames(z_mat) = oad_b
	    
	    fline = data.frame(date = dates[i])
	    for(l in 1:length(credit_b))
	    	for(k in 1:length(oad_b))
	    	{
		    	fdp = data.frame(s = z_mat[k,l])
		    	names(fdp) = paste(credit_bn[l],'oad',oad_b[k],sep='')
		    	fline = cbind(fline,fdp)
	    	}
	    cdfact_hist = rbind(cdfact_hist,fline)
	    
	    sline = data.frame(date = dates[i])
	    for(j in 1:length(s_out))
	    	sline = cbind(sline,s_out[j])
    	sp_hist = rbind(sp_hist,sline)
	}
	for(i in 2:dim(sp_hist)[2])
		names(sp_hist)[i] = paste('cr',s_grid[i-1,2],'dur',s_grid[i-1,1],sep='')   
}
