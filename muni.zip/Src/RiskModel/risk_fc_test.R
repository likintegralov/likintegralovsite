
#source('H:/SVN/Muni/v1.0/Src/RiskModel/risk_fc_test.R')


dts = data.frame(dates=fact_hist$date,month = format(fact_hist$date,'%Y%m'))
dts = unique(ave(dts$dates,dts$month,FUN=max))

st = as.Date('2015-06-01')
#st = as.Date('2014-08-09')

dates = dts[dts > st]
if(dates[length(dates)] != month.end(dates[length(dates)])) 
	dates = dates[1:(length(dates)-1)]
	
lg = 1
hor = 63
require(RODBC)

riskact = data.frame()
 channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
 
q = "select distinct IDENTIFIER from Optimizer..MUNI_ANALYTICS_KALOTAY where SOURCE = 'Index' and EFFECTIVE_DATE >= '2015-01-01' order by 1" 

id = sqlQuery(channel,query=q)
id = as.character(id[,1])
 
actrisk = data.frame()
for(i in 1:length(id))
{
q = paste("select AS_OF_DATE date, IDENTIFIER id, INDEX_OAS indx,CREDIT_CURVE credit_oad,STATE state,SECTOR sector,AMT amt,COUPON_EFFECT dm,EXTENSION_RISK extrisk,ZERO_COUPON zc,CREDIT_ENHANCEMENT ce,
	INDEX_OAS+CREDIT_CURVE+STATE+SECTOR+AMT+COUPON_EFFECT+RESI_OAS+EXTENSION_RISK+ZERO_COUPON+CREDIT_ENHANCEMENT oas,
	INDEX_OAS+CREDIT_CURVE+STATE+SECTOR+AMT+COUPON_EFFECT+EXTENSION_RISK+ZERO_COUPON+CREDIT_ENHANCEMENT oas_sys,RESI_OAS oas_nonsys from FIQModel..MUNI_OAS_DECOMPOSITION
	where AS_OF_DATE <= '",Sys.Date(),"' and AS_OF_DATE >= '",st,"' and IDENTIFIER = '",id[i],"' and RESI_OAS is not null order by 1",sep = '')
 
# q = paste("select AS_OF_DATE date, IDENTIFIER id, INDEX_OAS indx,CREDIT_CURVE credit_oad,STATE state,SECTOR sector,AMT amt,COUPON_EFFECT dm,EXTENSION_RISK extrisk,ZERO_COUPON zc,CREDIT_ENHANCEMENT ce,
# 	INDEX_OAS+CREDIT_CURVE+STATE+SECTOR+AMT+COUPON_EFFECT+RESI_OAS+EXTENSION_RISK+ZERO_COUPON+CREDIT_ENHANCEMENT oas,
# 	INDEX_OAS+CREDIT_CURVE+STATE+SECTOR+AMT+COUPON_EFFECT+EXTENSION_RISK+ZERO_COUPON+CREDIT_ENHANCEMENT oas_sys,RESI_OAS oas_nonsys from FIQModel..MUNI_OAS_DECOMPOSITION
# 	where AS_OF_DATE <= '",as_of,"' and AS_OF_DATE >= '",st,"' and IDENTIFIER = '",risksys$id[i],"' ",
# 	"and AS_OF_DATE in (select MAX(AS_OF_DATE) from FIQModel..MUNI_OAS_DECOMPOSITION group by substring(convert(varchar, AS_OF_DATE, 112),1,6)) order by 1",sep = '')	
	

riskdata <- sqlQuery(channel,query=q)
riskdata = riskdata[!is.na(riskdata$oas),]

if(dim(riskdata)[1] > hor)
{
	sprd_chng = data.frame(date = as.Date(riskdata$date[1:(dim(riskdata)[1]-1)]),diff(as.matrix(riskdata[,c('oas','oas_sys','oas_nonsys','indx','credit_oad','state','sector','amt','dm','extrisk','zc','ce')]),lag = lg))

	dts = sprd_chng$date[sprd_chng$date %in% dates]
	dts = dts[dts < sprd_chng$date[dim(sprd_chng)[1]-hor]] 
	
	#tm = rollapply(sprd_chng[,2:dim(sprd_chng)[2]],hor,sd)
	
	rd = data.frame()
	for(dt in dts)
	{
		j = which(sprd_chng$date == dt)
		rd = rbind(rd,cbind(data.frame(id = id[i],date = dts[dts==dt]), data.frame(sqrt(21)*t(as.matrix(apply(sprd_chng[j:(j+hor-1),2:dim(sprd_chng)[2]],2,sd))))))
	}
	#rd$date = as.Date(rd$date)
	
	if(sum(rd$oas_sys > 50) == 0)
		actrisk = rbind(actrisk,rd)
	
	if(i %% 50 == 0)
	 cat('security ',i,'\n')
}
}
 odbcClose(channel)


