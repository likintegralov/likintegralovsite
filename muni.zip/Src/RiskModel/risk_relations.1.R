
#source('H:/SVN/Muni/v1.0/Src/RiskModel/risk_relations.1.R')
source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.kal.R',sep='') )

#st = stdate
st = as.Date('2014-08-08')
lg = 21
require(RODBC)
as_of = Sys.Date()
as_of = as.Date('2016-08-09')


db_info = get_db_info('QA')
sdata = load_data(as_of,db_info,src='Index',init = F,TRUE)


riskact = data.frame()
 channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
 
for(i in 1:length(sdata$identifier))
{
q = paste("select AS_OF_DATE date, IDENTIFIER id, INDEX_OAS indx,CREDIT_CURVE credit_oad,STATE state,SECTOR sector,AMT amt,COUPON_EFFECT dm,EXTENSION_RISK extrisk,ZERO_COUPON zc,CREDIT_ENHANCEMENT ce,
	INDEX_OAS+CREDIT_CURVE+STATE+SECTOR+AMT+COUPON_EFFECT+RESI_OAS+EXTENSION_RISK+ZERO_COUPON+CREDIT_ENHANCEMENT oas,
	INDEX_OAS+CREDIT_CURVE+STATE+SECTOR+AMT+COUPON_EFFECT+EXTENSION_RISK+ZERO_COUPON+CREDIT_ENHANCEMENT oas_sys,RESI_OAS oas_nonsys from FIQModel..MUNI_OAS_DECOMPOSITION
	where AS_OF_DATE <= '",as_of,"' and AS_OF_DATE >= '",st,"' and IDENTIFIER = '",sdata$identifier[i],"' and RESI_OAS is not null order by 1",sep = '')
# 
# q = paste("select AS_OF_DATE date, IDENTIFIER id, INDEX_OAS indx,CREDIT_CURVE credit_oad,STATE state,SECTOR sector,AMT amt,COUPON_EFFECT dm,EXTENSION_RISK extrisk,ZERO_COUPON zc,CREDIT_ENHANCEMENT ce,
# 	INDEX_OAS+CREDIT_CURVE+STATE+SECTOR+AMT+COUPON_EFFECT+RESI_OAS+EXTENSION_RISK+ZERO_COUPON+CREDIT_ENHANCEMENT oas,
# 	INDEX_OAS+CREDIT_CURVE+STATE+SECTOR+AMT+COUPON_EFFECT+EXTENSION_RISK+ZERO_COUPON+CREDIT_ENHANCEMENT oas_sys,RESI_OAS oas_nonsys from FIQModel..MUNI_OAS_DECOMPOSITION
# 	where AS_OF_DATE <= '",as_of,"' and AS_OF_DATE >= '",st,"' and IDENTIFIER = '",risksys$id[i],"' ",
# 	"and AS_OF_DATE in (select MAX(AS_OF_DATE) from FIQModel..MUNI_OAS_DECOMPOSITION group by substring(convert(varchar, AS_OF_DATE, 112),1,6)) order by 1",sep = '')	

	

 riskdata <- sqlQuery(channel,query=q)
riskdata = riskdata[!is.na(riskdata$oas),]

if(dim(riskdata)[1] > lg + 10)
{
	sprd_chng = data.frame(diff(as.matrix(riskdata[,c('oas','oas_sys','oas_nonsys','indx','credit_oad','state','sector','amt','dm','extrisk','zc','ce')]),lag = lg))

	#wt = as.vector(outer(lam,0:(dim(sprd_chng)[1]-1),'^'))
	covone = cov(sprd_chng[,c('indx','credit_oad','state','sector','amt','dm','extrisk','zc','ce')])
	#covone = cov.wt(sprd_chng[,c('indx','credit_oad','state','sector','amt','dm','extrisk','zc','ce')],wt/sum(wt),center = F)$cov
	
	#names(sprd_chng) = c('oas','oas_sys','oas_nonsys')
	if(i %% 500 == 0) cat(paste(i,"\n",sep = ''))
	vars = sd(sprd_chng$oas_sys)^2
	dln = data.frame(id = sdata$identifier[i], vol = sd(sprd_chng$oas), vol_sys = sd(sprd_chng$oas_sys), 
		vol_nonsys = sd(sprd_chng$oas_nonsys),cr = cor(sprd_chng$oas_sys,sprd_chng$oas_nonsys),index = sum(covone[,1])/vars,
		cr_oad = sum(covone[,2])/vars,state = sum(covone[,3])/vars,sector = sum(covone[,4])/vars,amt = sum(covone[,5])/vars,
		dm = sum(covone[,6])/vars,extrisk = sum(covone[,7])/vars,zc = sum(covone[,8])/vars,ce = sum(covone[,9])/vars,
		sa_index = sd(sprd_chng$indx),sa_cr_oad = sd(sprd_chng$credit_oad),sa_state = sd(sprd_chng$state),sa_sector = sd(sprd_chng$sector),
		sa_amt = sd(sprd_chng$amt),sa_dm = sd(sprd_chng$dm),sa_extrisk = sd(sprd_chng$extrisk),sa_zc = sd(sprd_chng$zc),sa_ce = sd(sprd_chng$ce))
	riskact = rbind(riskact,dln)	
}
}

 odbcClose(channel)


