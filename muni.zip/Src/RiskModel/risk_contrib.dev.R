

source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.R',sep='') )

coef4to12 <- function(a,x)
{
	xm = max(x)
	x1 = xm/3
	x2 = 2*xm/3
	
	
	a2_0 = a[1] + x1*a[2]/3 - x1*a[3]/3
	#a3_0 = a[1] - x1/3*a[2] + (x1 + x2)/3*a[3] - x2/3*a[4]
	
	a2_2 = a[2]/x1 - a[3]/x1
	a3_2 = a[2]/x1 + (1/x2 - 1/x1)*a[3] - a[4]/x2
	
	a1_3 = 1/3*((1/x1^2 - 1/x1/xm)*a[2] + (1/x1/xm - 1/x1^2 + 1/x2^2 -1/x2/xm)*a[3] - (1/x2^2 - 1/x2/xm)*a[4])
	a2_3 = 1/3*(-1/x1/xm*a[2] + (1/x1/xm + 1/x2^2 - 1/x2/xm)*a[3] - (1/x2^2 - 1/x2/xm)*a[4])
	a3_3 = -1/3*(1/x1/xm*a[2] + (1/x2/xm - 1/x1/xm)*a[3] - 1/x2/xm*a[4])
	
	a3_0 = a2_0 + a[3]*x2 +a2_2*x2^2 + a2_3 * x2^3 - a[4]*x2 - a3_2*x2^2 - a3_3*x2^3
	
	A = c(a[1],a[2],0,a1_3,a2_0,a[3],a2_2,a2_3,a3_0,a[4],a3_2,a3_3)
}

fcurve_3 <- function(a,x,y2f = NULL)
{
	x1 = max(x)/3
	x2 = 2*max(x)/3
	xm = max(x)
	
	A = coef4to12(a,x)
	
	y = x;
	y[x <= x1] = outer(x[x <= x1],0:3,"^") %*% A[1:4]
	y[x > x1 & x <= x2] = outer(x[x > x1 & x <= x2],0:3,"^") %*% A[5:8]
	y[x > x2] = outer(x[x > x2],0:3,"^") %*% A[9:12]
	
	if(is.null(y2f))
		y
	else{
		sum((y - y2f)^2)
	}
		
}

fcurve_poly3 <- function(a,x,y2f = NULL)
{
	
	
	y = outer(x,0:3,"^") %*% a
	
	if(is.null(y2f))
		y
	else{
		sum((y - y2f)^2)
	}
		
}

fcurve_plot <- function(a,x,xlim)
{
	y[x <= xlim[1]] = outer(x[x <= xlim[1]],0:3,"^") %*% a[1:4]
	y[x > xlim[1] & x <= xlim[2]] = outer(x[x > xlim[1] & x <= xlim[2]],0:3,"^") %*% a[5:8]
	y[x > xlim[2]] = outer(x[x > xlim[2]],0:3,"^") %*% a[9:12]
	
	y
}

calc_fexp2d <- function(samp, fgrid)
{
	np = dim(samp)[1]
	nf = dim(fgrid)[1]
	mexp = matrix(0,nrow = np,ncol = nf)  # (number of factors)X(number of points) matrix
	
	xval = sort(unique(fgrid[,1]))
	yval = sort(unique(fgrid[,2]))
	
	tm = interp.surface.ext(list(x=xval,y=yval,
		z=matrix(1,nrow=length(xval),ncol=length(yval))), samp,rule = 2,factors = TRUE)
	
	tm1 = tm[,-grep('exp',names(tm))]	
	
	for(i in 1:np)
	{	#x1y1
		ix = fgrid[,1] == xval[tm1[i,grep('x1',names(tm1))[1]]] & fgrid[,2] == yval[tm1[i,grep('y1',names(tm1))[1]]]
		mexp[i,ix] = tm[i,grep('x1y1',names(tm))]
		#x2y1
		ix = fgrid[,1] == xval[tm1[i,grep('x2',names(tm1))[1]]] & fgrid[,2] == yval[tm1[i,grep('y1',names(tm1))[1]]]
		mexp[i,ix] = tm[i,grep('x2y1',names(tm))]
		#x1y2
		ix = fgrid[,1] == xval[tm1[i,grep('x1',names(tm1))[1]]] & fgrid[,2] == yval[tm1[i,grep('y2',names(tm1))[1]]]
		mexp[i,ix] = tm[i,grep('x1y2',names(tm))]
		#x2y2
		ix = fgrid[,1] == xval[tm1[i,grep('x2',names(tm1))[1]]] & fgrid[,2] == yval[tm1[i,grep('y2',names(tm1))[1]]]
		mexp[i,ix] = tm[i,grep('x2y2',names(tm))]
	}
	mexp
}

cnames = c('b01','b11','b21','b31','b02','b12','b22','b32','b03','b13','b23','b33')

#source('H:/SVN/Muni/v1.0/Src/RiskModel/risk_contrib.R')

library(RODBC)
db_info <- get_db_info('QA')

lb = 24

if(attr == 'deminimis_buffer')
{
	expo = seq(0.01,0.2,by = 0.01)
	if(1)
	{
		rc_hist = data.frame()
		fcol = grep('f',names(dmfact_hist))
		for(i in lb:dim(dmfact_hist)[1])
		#for(i in 92:92)
		{
			expo_rel = expo/dmfact_hist$xm[i]
			fexp = matrix(,ncol = length(fcol),nrow = 0)
			for(j in 1:length(expo_rel))
			{
				pfexp = rep(0,length(fcol))
				nf = length(fcol)
				for(k in 1:nf)
					if(k == 1) {
						pfexp[k] = approx(c(0,k/(nf-1)),c(1,0),expo_rel[j],yleft = 0,yright = 0)$y
					}else if(k == length(fcol)) {
						pfexp[k] = approx(c((k-2)/(nf-1),1),c(0,1),expo_rel[j],yleft = 0,yright = 0)$y
					}else				
						pfexp[k] = approx(c((k-2)/(nf-1),(k-1)/(nf-1),k/(nf-1)),c(0,1,0),expo_rel[j],yleft = 0,yright = 0)$y
				fexp = rbind(fexp,pfexp)
			}
			
			Cov = cov(dmfact_hist[(i-lb+1):i,grep('f',names(dmfact_hist))])
			rc = diag(fexp %*% Cov %*% t(fexp))^(1/2)
			
			rc_hist = rbind(rc_hist,cbind(data.frame(date = as.Date(dmfact_hist[i,1])),data.frame(t(as.matrix(rc)))))
		}
		
	}else
	{
		fullAhist = data.frame()
		
		for(i in 1:dim(Ahist)[1])
		{
			
			fullA = data.frame(coef4to12(Ahist[i,2:5],Ahist$xm[i]))
			names(fullA) = cnames
			fullAhist = rbind(fullAhist,cbind(data.frame(date = Ahist$date[i],xm = Ahist$xm[i]),fullA))
		}
			
		rc_hist = data.frame()
		for(i in lb:dim(fullAhist)[1])
	#	for(i in 81:81)
		{
			
			xp = cbind(outer(expo,0:3,"^"),outer(expo,0:3,"^"),outer(expo,0:3,"^"))
			
			for(j in 1:dim(xp)[1])
				if(expo[j] <= fullAhist$xm[i]/3)
				{
					xp[j,] = xp[j,]*c(1,1,1,1,0,0,0,0,0,0,0,0)
				}else if(expo[j] > fullAhist$xm[i]/3 & expo[j] <= 2*fullAhist$xm[i]/3)
				{
					xp[j,] = xp[j,]*c(0,0,0,0,1,1,1,1,0,0,0,0)
				}else if(expo[j] > 2*fullAhist$xm[i]/3 & expo[j] <= fullAhist$xm[i])
				{
					xp[j,] = xp[j,]*c(0,0,0,0,0,0,0,0,1,1,1,1)
				}else
					xp[j,] = xp[j,]*c(0,0,0,0,0,0,0,0,0,0,0,0)
			
			Cov = cov(fullAhist[(i-lb+1):i,grep('b',names(fullAhist))])
			
			rc = diag(xp %*% Cov %*% t(xp))^(1/2)
			
			rc_hist = rbind(rc_hist,cbind(data.frame(date = as.Date(fullAhist[i,1])),data.frame(t(as.matrix(rc)))))
		}
	}
}

if(attr == 'extension_risk')
{
	expo = seq(0.0,1.,by = 0.05)
	rc_hist = data.frame()
	for(i in lb:dim(Ahist)[1])
	{
		xp = outer(expo,0:3,"^")
		Cov = cov(Ahist[(i-lb+1):i,grep('b',names(Ahist))])
		
		rc = diag(xp %*% Cov %*% t(xp))^(1/2)
		rc_hist = rbind(rc_hist,cbind(data.frame(date = as.Date(Ahist[i,1])),data.frame(t(as.matrix(rc)))))
	}
}

if(attr == 'credit_oad')
{
	rc_hist = data.frame()
	fexp = calc_fexp2d(s_grid,f_grid)
	fact_chg = cbind(data.frame(date = cdfact_hist$date[2:dim(cdfact_hist)[1]]),diff(as.matrix(cdfact_hist[,2:dim(cdfact_hist)[2]])))
	
	for(i in lb:dim(fact_chg)[1])
	{
		Cov = cov(fact_chg[(i-lb+1):i,2:dim(fact_chg)[2]])
		rc = diag(fexp %*% Cov %*% t(fexp))^(1/2)
		
		rc_hist = rbind(rc_hist,cbind(data.frame(date = as.Date(fact_chg[i,1])),data.frame(t(as.matrix(rc)))))
	}	
	for(i in 2:dim(rc_hist)[2])
		names(rc_hist)[i] = paste('cr',s_grid[i-1,2],'dur',s_grid[i-1,1],sep='')
}