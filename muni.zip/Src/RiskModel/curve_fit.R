

source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.R',sep='') )

load_insurance <- function(adt,db_info)
{
	q = paste("select a.AS_OF_DATE date,n.INSURER_BUCKET ib, a.OAS oas from FIQModel..OAS_ATTRIBUTION_FIT a, Optimizer.dbo.MUNI_INSURER_BUCKETS n ",
			"where a.SECTOR = 'muni' ",
			"and a.ATTRIBUTE = 'ce_bucket' ",
			"and a.AS_OF_DATE = n.AS_OF_DATE ",
			"and a.VALUE1 = n.CODE ",
			"and a.AS_OF_DATE <= '",adt,"' ",
			"union ",
			"select AS_OF_DATE date,ib = 'None', OAS oas from FIQModel..OAS_ATTRIBUTION_FIT ",
			"where SECTOR = 'muni' ",
			"and ATTRIBUTE = 'ce_bucket' ",
			"and VALUE1 = 500 ",
			"and AS_OF_DATE <= '",adt,"' ",
			"order by date,ib",sep = '')
			
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    out <- sqlQuery(channel,query=q)
    odbcClose(channel)
    
    out			
}

load_curve <- function(adt,attr,db_info,v2 = 0)
{
	q = paste("select VALUE1 x, OAS oas from FIQModel..OAS_ATTRIBUTION_FIT ",
			"where SECTOR = 'muni' ",
			"and ATTRIBUTE = '",attr,"' ",
			"and VALUE2 = ",v2," ",
			"and AS_OF_DATE = '",adt,"' order by x",sep = '')
			
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    out <- sqlQuery(channel,query=q)
    odbcClose(channel)
    
    out			
}

load_curves <- function(attr,db_info,adt,v2 = 0,monthly = TRUE)
{
	if(monthly)
	{
		q = paste("select AS_OF_DATE date, VALUE1 x, OAS oas from FIQModel..OAS_ATTRIBUTION_FIT ",
			"where SECTOR = 'muni' ",
			"and ATTRIBUTE = '",attr,"' ",
			"and VALUE2 = ",v2," ",
			"and AS_OF_DATE in (select MAX(AS_OF_DATE) from FIQModel..OAS_ATTRIBUTION_FIT group by substring(convert(varchar, AS_OF_DATE, 112),1,6)) ",
			"and AS_OF_DATE <= '",adt,"' ",
			"order by AS_OF_DATE,x",sep = '')		
	}else
	{
		q = paste("select AS_OF_DATE date, VALUE1 x, OAS oas from FIQModel..OAS_ATTRIBUTION_FIT ",
			"where SECTOR = 'muni' ",
			"and ATTRIBUTE = '",attr,"' ",
			"and VALUE2 = ",v2," ",
			"and AS_OF_DATE <= '",adt,"' ",
			"order by AS_OF_DATE,x",sep = '')
	}		
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    out <- sqlQuery(channel,query=q)
    odbcClose(channel)
    
    out			
}


load_surface <- function(adt,attr,db_info)
{
	q = paste("select AS_OF_DATE date, VALUE1 x, VALUE2 y, OAS oas from FIQModel..OAS_ATTRIBUTION_FIT ",
			"where SECTOR = 'muni' ",
			"and ATTRIBUTE = '",attr,"' ",
			"and AS_OF_DATE = '",adt,"' ",
			"order by AS_OF_DATE,x",sep = '')
			
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    out <- sqlQuery(channel,query=q)
    odbcClose(channel)
    
    out			
}

load_surfaces <- function(attr,db_info,adt,monthly = TRUE)
{
	if(monthly)
	{
		q = paste("select AS_OF_DATE date, VALUE1 x, VALUE2 y, OAS oas from FIQModel..OAS_ATTRIBUTION_FIT ",
			"where SECTOR = 'muni' ",
			"and ATTRIBUTE = '",attr,"' ",
			"and AS_OF_DATE in (select MAX(AS_OF_DATE) from FIQModel..OAS_ATTRIBUTION_FIT group by substring(convert(varchar, AS_OF_DATE, 112),1,6)) ",
			"and AS_OF_DATE <= '",adt,"' ",
			"order by AS_OF_DATE,x,y",sep = '')
	}else
	{
		q = paste("select AS_OF_DATE date, VALUE1 x, VALUE2 y, OAS oas from FIQModel..OAS_ATTRIBUTION_FIT ",
			"where SECTOR = 'muni' ",
			"and ATTRIBUTE = '",attr,"' ",
			"and AS_OF_DATE <= '",adt,"' ",
			"order by AS_OF_DATE,x,y",sep = '')
	}	
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    out <- sqlQuery(channel,query=q)
    odbcClose(channel)
    
    out			
}
coef4to12 <- function(a,x)
{
	xm = max(x)
	x1 = xm/3
	x2 = 2*xm/3
	
	
	a2_0 = a[1] + x1*a[2]/3 - x1*a[3]/3
	#a3_0 = a[1] - x1/3*a[2] + (x1 + x2)/3*a[3] - x2/3*a[4]
	
	a2_2 = a[2]/x1 - a[3]/x1
	a3_2 = a[2]/x1 + (1/x2 - 1/x1)*a[3] - a[4]/x2
	
	a1_3 = 1/3*((1/x1^2 - 1/x1/xm)*a[2] + (1/x1/xm - 1/x1^2 + 1/x2^2 -1/x2/xm)*a[3] - (1/x2^2 - 1/x2/xm)*a[4])
	a2_3 = 1/3*(-1/x1/xm*a[2] + (1/x1/xm + 1/x2^2 - 1/x2/xm)*a[3] - (1/x2^2 - 1/x2/xm)*a[4])
	a3_3 = -1/3*(1/x1/xm*a[2] + (1/x2/xm - 1/x1/xm)*a[3] - 1/x2/xm*a[4])
	
	a3_0 = a2_0 + a[3]*x2 +a2_2*x2^2 + a2_3 * x2^3 - a[4]*x2 - a3_2*x2^2 - a3_3*x2^3
	
	A = c(a[1],a[2],0,a1_3,a2_0,a[3],a2_2,a2_3,a3_0,a[4],a3_2,a3_3)
}

fcurve_3 <- function(a,x,y2f = NULL)
{
	x1 = max(x)/3
	x2 = 2*max(x)/3
	xm = max(x)
	
	A = coef4to12(a,x)
	
	y = x;
	y[x <= x1] = outer(x[x <= x1],0:3,"^") %*% A[1:4]
	y[x > x1 & x <= x2] = outer(x[x > x1 & x <= x2],0:3,"^") %*% A[5:8]
	y[x > x2] = outer(x[x > x2],0:3,"^") %*% A[9:12]
	
	if(is.null(y2f))
		y
	else{
		sum((y - y2f)^2)
	}
		
}

fcurve_poly3 <- function(a,x,y2f = NULL)
{
	
	
	y = outer(x,0:3,"^") %*% a
	
	if(is.null(y2f))
		y
	else{
		sum((y - y2f)^2)
	}
		
}

fcurve_plot <- function(a,x,xlim)
{
	y[x <= xlim[1]] = outer(x[x <= xlim[1]],0:3,"^") %*% a[1:4]
	y[x > xlim[1] & x <= xlim[2]] = outer(x[x > xlim[1] & x <= xlim[2]],0:3,"^") %*% a[5:8]
	y[x > xlim[2]] = outer(x[x > xlim[2]],0:3,"^") %*% a[9:12]
	
	y
}



#source('H:/SVN/Muni/v1.0/Src/RiskModel/curve_fit.R')

library(RODBC)
db_info <- get_db_info('PRD')

as_of = as.Date('2016-05-31')


attrs = all_factors
attrs_dummy = c('state','ab_code','index_oas_pr','state_pr','zero_coupon_pr')
attrs_dummy_interp = c('zero_coupon','muni_taxability')


monthly = TRUE
monthly = F

fact_hist = data.frame()

for(i_a in 1:length(attrs))
{
	cat(paste('processing ',attrs[i_a],'...\n',sep = ''))
	if(attrs[i_a] == 'index_oas')
	{
		fh = load_curves(attrs[i_a],db_info,as_of,monthly = monthly)
		fh$date = as.Date(fh$date)
		fact_hist = data.frame(date = fh$date, index_gen = fh$oas)
	}
	if(attrs[i_a] == 'credit_oad') # special logic to deal with 2d surface (bucketed model)
	{
	
		require(fields)
		
		credit_bn = c('AAA','BBB+','BB','CCC')
		oad_b = c(0,5,10,15)  # duration key points
		credit_b = c(1,8,12,18) # credit key points
		
		f_grid = make.surface.grid(list(oad_b,credit_b))
			
		cd_hist = load_surfaces(attrs[i_a],db_info,as_of,monthly)
		cd_hist$date = as.Date(cd_hist$date)
		
		dates = unique(cd_hist$date)
		cdfact_hist = data.frame()
		
		for(i in 1:length(dates))
		{
			cd = cd_hist[cd_hist$date == dates[i],]
			
			dur <-  sort(unique(cd$y))
			credit <- sort(unique(cd$x))
		    
		    z <-  matrix(cd$oas,nrow=length(dur))
		    
		    z_vec <- interp.surface.ext(list(x=dur,y=credit,z=z), f_grid,rule = 2)
			z_mat <- matrix(z_vec,nrow=length(oad_b))
	
			colnames(z_mat) = credit_b
		    rownames(z_mat) = oad_b
		    
		    fline = data.frame(date = dates[i])
		    for(l in 1:length(credit_b))
		    	for(k in 1:length(oad_b))
		    	{
			    	fdp = data.frame(s = z_mat[k,l])
			    	names(fdp) = paste(all_factors_tags[i_a],credit_bn[l],oad_b[k],sep='')
			    	fline = cbind(fline,fdp)
		    	}
		    cdfact_hist = rbind(cdfact_hist,fline)
		}
		fact_hist = merge(fact_hist,cdfact_hist,by = 'date',all.x = T)
	}
	
	
	if(attrs[i_a] == 'deminimis_buffer') # special logic to deal with buckets in relative (normalized by max) factors, plus separate hy and ig
	{
		gr = deminimis_grades()
		dmfact = factor_buckets(all_factors_tags[i_a]) # set up factors
		
		for(k in 1:length(gr))
		{
		c2fhist = load_curves(attrs[i_a],db_info,as_of,k-1,monthly)
		c2fhist$date = as.Date(c2fhist$date)
		dates = unique(c2fhist$date)
		
		mxt = data.frame()
			
		c2fhist_rel = data.frame()
		dmfact_hist = data.frame()
		for(i in 1:length(dates))
		{
			ccurve = c2fhist[c2fhist$date == dates[i],]
			xm = max(ccurve$x)
			mxt = rbind(mxt,data.frame(date = dates[i],xm = xm))
			ccurve$x = ccurve$x / xm
			c2fhist_rel = rbind(c2fhist_rel,ccurve)
			cfact = approx(ccurve$x,ccurve$oas,dmfact,method = 'linear',rule = 2)$y
			cf_df = data.frame(date = dates[i])
			for(j in 1:length(cfact))
				cf_df = cbind(cf_df,data.frame(x = cfact[j]))
			dmfact_hist = rbind(dmfact_hist,cf_df)
		}
		for(i in 2:dim(dmfact_hist)[2])
			names(dmfact_hist)[i] = paste(all_factors_tags[i_a],gr[k],dmfact[i-1],sep = '')
				
		fact_hist = merge(fact_hist,dmfact_hist,by = 'date',all.x = T) # save factors history
		assign(paste('dmmax_',gr[k],sep=''),mxt) #save maximum dm values
		}
	}
	
# 	if(attrs[i_a] %in% factors_curve_bucket_rel)
# 	{
# 		factb = factor_buckets(attrs[i_a]) # set up factors
# 		
# 		c2fhist = load_curves(attrs[i_a],db_info,as_of)
# 		c2fhist$date = as.Date(c2fhist$date)
# 		dates = unique(c2fhist$date)
# 		
# 		mxt = data.frame()
# 			
# 		c2fhist_rel = data.frame()
# 		cfact_hist = data.frame()
# 		for(i in 1:length(dates))
# 		{
# 			ccurve = c2fhist[c2fhist$date == dates[i],]
# 			xm = max(ccurve$x)
# 			mxt = rbind(mxt,data.frame(date = dates[i],xm = xm))
# 			ccurve$x = ccurve$x / xm
# 			c2fhist_rel = rbind(c2fhist_rel,ccurve)
# 			cfact = approx(ccurve$x,ccurve$oas,factb,method = 'linear',rule = 2)$y
# 			cf_df = data.frame(date = dates[i])
# 			for(j in 1:length(cfact))
# 				cf_df = cbind(cf_df,data.frame(x = cfact[j])) # a row with bucket factors
# 			cfact_hist = rbind(cfact_hist,cf_df)
# 		}
# 		for(i in 2:dim(cfact_hist)[2])
# 			names(cfact_hist)[i] = paste(attrs[i_a],round(factb[i-1],2),sep = '')
# 				
# 		fact_hist = merge(fact_hist,cfact_hist,by = 'date',all.x = T) # save factors history
# 		assign(paste(attrs[i_a],'_max',sep=''),mxt) #save maximum factor values
# 		
# 	}
	
	if(attrs[i_a] %in% factors_linear)
	{
		c2fhist = load_curves(attrs[i_a],db_info,as_of,monthly = monthly)
		c2fhist$date = as.Date(c2fhist$date)
		dates = unique(c2fhist$date)
		
		Ahist = data.frame()
		for(i in 1:length(dates))
		{
			c2f = c2fhist[c2fhist$date == dates[i],-1]
			b = (c2f[dim(c2f)[1],'oas'] - c2f$oas[1])/(c2f$x[dim(c2f)[1]] - c2f$x[1])
			Ahist = rbind(Ahist,data.frame(date = dates[i], b1 = b))
		}
		names(Ahist)[names(Ahist) == 'b1'] = paste(all_factors_tags[i_a],'_b1',sep='')
		fact_hist = merge(fact_hist,Ahist,by = 'date',all.x = T)
	}
			
	
	if(attrs[i_a] == 'extension_risk') # special logic to deal with polynoms
	{
		c2fhist = load_curves(attrs[i_a],db_info,as_of,monthly = monthly)
		c2fhist$date = as.Date(c2fhist$date)
		dates = unique(c2fhist$date)
		
		Ahist = data.frame()
		fitres = data.frame()
		for(i in 1:length(dates))
		{
			c2f = c2fhist[c2fhist$date == dates[i],-1]
			xi = seq(1,dim(c2f)[1],length.out = 4)
			x = c2f[xi,1]
			R = outer(x,0:3,"^")
				
			A0 = solve(R,c2f[xi,2])
			
			aopt = optim(A0,fcurve_poly3,x = c2f[,1],y2f = c2f[,2])
			
			Ahist = rbind(Ahist,data.frame(date = dates[i],er_b0 = aopt$par[1],er_b1 = aopt$par[2],er_b2 = aopt$par[3],er_b3 = aopt$par[4]))
			
			fitres = rbind(fitres,data.frame(date = dates[i],err = aopt$value))
			
			fcurve = fcurve_poly3(aopt$par,c2f[,1])
		}
		names(Ahist)[grep('er',names(Ahist))] = sub('er',all_factors_tags[i_a],names(Ahist)[grep('er',names(Ahist))])
		fact_hist = merge(fact_hist,Ahist,by = 'date',all.x = T)
	}
	
	if(attrs[i_a] %in% attrs_dummy)
	{
		fh = load_curves(attrs[i_a],db_info,as_of,monthly = monthly)
		fh$date = as.Date(fh$date)
		fl = sort(unique(fh$x))
		for(i in 1:length(fl))
		{
			if(fl[i] != 333) # exclude pre-refs
			{
				facdata = fh[fh$x == fl[i],]
				fact_hist = merge(fact_hist,facdata[,c('date','oas')],by = 'date',all.x = T)
				names(fact_hist)[dim(fact_hist)[2]] = paste(all_factors_tags[i_a],fl[i],sep='')
			}
		}
	} 
	
	if(attrs[i_a] %in% attrs_dummy_interp)
	{
		fh = load_curves(attrs[i_a],db_info,as_of,monthly = monthly)
		fh$date = as.Date(fh$date)
		flall = sort(unique(fh$x))
		# select only calibration factors
		tag = factors_interp_map$tags[factors_interp_map$fact == attrs[i_a]]
		tag = tag + term_calibration_buckets*4
		fl = c(flall[1],flall[flall %in% tag])
		
		for(i in 1:length(fl))
		{
			facdata = fh[fh$x == fl[i],]
			fact_hist = merge(fact_hist,facdata[,c('date','oas')],by = 'date',all.x = T)
			names(fact_hist)[dim(fact_hist)[2]] = paste(all_factors_tags[i_a],fl[i],sep='')
		}
	}
	
	if(attrs[i_a] == 'ce_bucket') # special logic  to deal with time dependent buckets
	{
		ih = load_insurance(as_of,db_info)
		ih$date = as.Date(ih$date)
		il = sort(unique(ih$ib))
		
		for(i in 1:length(il))
		{
			facdata = ih[ih$ib == il[i],]
			fact_hist = merge(fact_hist,facdata[,c('date','oas')],by = 'date',all.x = T)
			names(fact_hist)[dim(fact_hist)[2]] = paste(attrs[i_a],il[i],sep = '')
		}
	}
}

# load treasury curve
flds = c('POINT_006M','POINT_024M','POINT_060M','POINT_120M','POINT_240M','POINT_360M')

tsy_hist = load_tsy_yield_curve(as_of,daily = T,flds = flds)
tsy_hist[,-1] = 100*tsy_hist[,-1] # convert to bps
names(tsy_hist) = sub('point','tsy',names(tsy_hist))
aaammd_hist = load_MMD_yield_curve(as_of,daily = T,flds = flds)
aaammd_hist[,-1] = 100*aaammd_hist[,-1] # convert to bps
names(aaammd_hist) = sub('point','aaammd',names(aaammd_hist))

aaasprd_hist = merge(tsy_hist,aaammd_hist,by = 'date')

fact_hist = merge(fact_hist,tsy_hist,by = 'date',all.x = T)
fact_hist = merge(fact_hist,aaammd_hist,by = 'date',all.x = T)

#fact_hist = fact_hist[fact_hist$date != as.Date('2015-04-30'),]
#fact_hist = cbind(data.frame(date = fact_hist$date,index_gen = fact_hist$index_gen1),fact_hist[,-c(1,which(names(fact_hist) == 'index_gen1'))])
