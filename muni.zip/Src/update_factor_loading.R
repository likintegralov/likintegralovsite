#!\\nts0018\bond\ABFI_PROD\QuantApps\R-2.14.2\bin\Rscript

source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.R',sep='') )

load_reg_data <- function(as_of)
{
	cat(format(Sys.time()),'loading data as of',format(as_of),'from database...\n')
	stmt <- paste("
		SELECT 
		FWD_DATE,
		EXCESS_RET_FWD3M,
		INDEX_OAS,CREDIT_OAD,STATE,AB_CODE,MUNI_TAXABILITY,
		DEMINIMIS_BUFFER,RESI_OAS
		FROM MUNI_MODEL_REGRESSION_DATA
        WHERE FWD_DATE <='", format(as_of,'%d-%b-%Y'),"'
	",sep='')
	
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    reg_data <- sqlQuery(channel,query=stmt)
    odbcClose(channel)
    names(reg_data) <- casefold(names(reg_data),F)
    reg_data$fwd_date <- as.Date(reg_data$fwd_date)
    cat(format(Sys.time()),'done.\n')
    reg_data
}

map_results <- function(fits)
{
	var_map <- c(
		'Intercept','intercept',
		'index_oas','Index OAS',
		'credit_oad','Credit x OAD',
		'state', 'State',
		'ab_code','Sector',
		'muni_taxability','Taxability',
		'deminimis_buffer','Coupon Effect',
		'resi_oas','Residual OAS')
		
	stmt <- paste("
    	select MODEL_NAME,FACTOR_NAME,FACTOR_ID FROM 
        MODEL_DESCRIPTION a,MODEL_SPECIFICATION b
        WHERE a.MODEL_NAME = 'Muni Excess Return Model'
        AND b.MODEL_ID=a.MODEL_ID
        AND a.VERSION='1.0'
	",sep='')
	
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    outdata <- sqlQuery(channel,query=stmt)
    odbcClose(channel)
    
    res <- c()
    for(i in 1:length(fits))
    {
	    coef <- fits[[i]]$coef
	    idx <- match(names(coef),var_map)
	    idx <- match(var_map[idx+1],outdata$FACTOR_NAME)
	    ix <- match(names(coef),names(fits[[i]]$xm))
	    entry <- data.frame(FACTOR_ID=outdata$FACTOR_ID[idx],
	    	AS_OF=as.Date(names(fits)[i]),
	    	FACTOR_LOADING=coef,
	    	FACTOR_MEAN=fits[[i]]$xm[ix],
	    	FACTOR_STDEV=fits[[i]]$scales[ix],
	    	FACTOR_LB=fits[[i]]$lb[ix],
	    	FACTOR_UB=fits[[i]]$ub[ix])	    	
		res <- rbind(res,entry)
    }
    res
}

get_required_dates <- function(as_of)
{
	stmt <- paste("
    	select DISTINCT FWD_DATE
    	FROM MUNI_MODEL_REGRESSION_DATA
        WHERE FWD_DATE <='", format(as_of,'%d-%b-%Y'),"'
	",sep='')
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    dates <- as.Date( sqlQuery(channel,query=stmt )[,1])
    odbcClose(channel)
    dates
}

get_available_dates <- function()
{
	stmt <- paste("
    	select DISTINCT AS_OF
    	FROM MODEL_FACTOR_LOADING
    	WHERE FACTOR_ID=1201
	",sep='')
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    dates <- as.Date( sqlQuery(channel,query=stmt )[,1])
    odbcClose(channel)
    dates
}

populate_factor_loading <- function(res)
{
	factor_ids <- sort(unique(res$FACTOR_ID))
	dates <- sort(unique(res$AS_OF))
	dates_str <- paste(format(dates,'%d-%b-%Y'),collapse="','")
	
	stmt <- paste("delete from MODEL_FACTOR_LOADING 
		where AS_OF in('",dates_str,"') and
		FACTOR_ID in (",paste(factor_ids,collapse=","),")
		",sep='')
		
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    sqlQuery(channel,query=stmt )
    odbcClose(channel)
    
	export2db(data=res,server_type='SQL',server=db_info$Database,db=db_info$InitDB,table='MODEL_FACTOR_LOADING',user=db_info$User,psw=db_info$Password,na='')	

	invisible()
}

################################################################################
################################################################################
library('getopt')
opt = getopt(matrix(
    c(
    'db',   's', 2, "character",    
    'as_of','d', 2, "character",
    'help', 'h', 0, "logical"
    ),ncol=4,byrow=TRUE)
)

if ( !is.null(opt$help) ) {
  self = 'Rscript update_factor_loading.R'
  cat(paste("
    Usage: ",self,"  [--all] [--help]  
    	db:   Database server to run the script on (PRD/QA/DEV).
        as_of:as_of date in yyyy-mm-dd format. if missing, update loadings for
              all month-end dates. Optional
        help: Show help.  Optional
    Example: RScript update_factor_loading.R --db QA --as_of 2012-02-15
  ",sep=""))
  q(status=1)
}

if ( is.null(opt$db) ) opt$db = 'QA'
if ( is.null(opt$as_of) ) opt$as_of = last.business.day(Sys.Date()-1);
###############################################################################
#source('H:/dev/Quant_Model-SQLServer/Muni/v1.0/Src/ExcessReturn/update_factor_loading.R')
setwd(paste(Sys.getenv('ABFI_DATA_REPOSITORY'),'\\Muni\\v1.0\\Output',sep='') )
library(RODBC)
db_info <- get_db_info(opt$db)

#check if the data is available
required_dates <- get_required_dates(as.Date(opt$as_of))
if(length(required_dates)<12) stop('need at least 12 months of regression data!')
required_dates <- required_dates[12:length(required_dates)]

available_dates <- get_available_dates()

fwd_dates <- required_dates[!required_dates %in% available_dates]
if(length(fwd_dates)==0)
{
	cat('no update to be done. factor loading last available',format(max(available_dates)),'\n')
	quit(status=0)
}
reg_data <- load_reg_data(as.Date(opt$as_of))

xvars <- c('index_oas','credit_oad','state','ab_code','muni_taxability','deminimis_buffer','resi_oas')
mf <- formula(paste('excess_ret_fwd3m ~',paste(xvars,collapse='+')))

#ridge regressions
fits <- list()
for(i in 1:length(fwd_dates) )
{
	cat(format(Sys.time()),'processing',format(fwd_dates[i]),'...\n' )
	
	fit <- glm.wridge(
	    formula=mf,
	    data=reg_data,
	    lambda=2,
	    batch.size=500000,
	    subset=reg_data$fwd_date<=fwd_dates[i],
	    winsor=T
    )
        
    cat(format(fwd_dates[i]),':b=(bps)',centered.coef(fit)*1e4,'\n')
	
    lb <- fit$lb[names(fit$xm)]
	ub <- fit$ub[names(fit$xm)]
	
	fits[[format(fwd_dates[i])]] <- list(coef=centered.coef(fit),xm=fit$xm,scales=fit$scales,lb=lb,ub=ub)
	gc()
}

#map results
res <- map_results(fits)

#populate results
populate_factor_loading(res)

cat(date(),'Done.\n')
q(status=0)

#source('H:/dev/Quant_Model-SQLServer/Muni/v1.0/Src/ExcessReturn/update_factor_loading.R')
###############################################################################
###############################################################################

