

source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.R',sep='') )

#source('H:/SVN/Muni/v1.0/Src/MMDYieldCurve/aaa_spread_model.R')

load_tsy_fc <- function(asof)
{
	# 3 month forecast
	stmt <- paste("select AS_OF_DATE, ",
        "POINT_120M/2 AS TSY_LEVEL_FC, ",
        "(POINT_120M - POINT_024M)/2 AS TSY_SLOPE_FC, ", 
        "(-2*POINT_024M + POINT_003M + POINT_120M)/2 AS TSY_CURVATURE_FC ",
        "FROM YIELD_CURVE_FORECAST_WIDE_VIEW ",
        "WHERE YC_NAME='Treasury' ",
        "and MODEL_ID = 17 ",
        "and FORECAST_HORIZON=6 ",
        "and CURRENCY='USD' ",
        "and AS_OF_DATE<='",format(asof,'%d-%b-%Y'),"'
        ",sep='')
        
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    tsy_fc <- sqlQuery(channel,query=stmt)
    odbcClose(channel)
    
    if(nrow(tsy_fc)==0) stop('no tsy forecst for ',asof,'\n',stmt)
    names(tsy_fc)<-casefold(names(tsy_fc),upper=F)
    tsy_fc$as_of_date <- as.Date(tsy_fc$as_of_date)
    #apply tax
 	tax = get_tax_rate(db_info)
	names(tax)[1] = 'as_of_date'
	tsy_fc = merge(tsy_fc,tax, by = 'as_of_date',all.x = T)
	    
	tsy_fc[,2:(dim(tsy_fc)[2] - 1)] = (1 - tsy_fc$tax/100)*tsy_fc[,2:(dim(tsy_fc)[2] - 1)]	
	   	# remove tax rate for compartibility
   	tsy_fc = tsy_fc[,-dim(tsy_fc)[2]]
    tsy_fc
}

load_crv_loading <- function()
{
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    crv_loading <- sqlQuery(channel,query="select * from YIELD_CURVE_LOADING where YC_NAME='Treasury' and CURRENCY='ALL' and VERSION='2.1' order by MATURITY" )
    odbcClose(channel)
    names(crv_loading) <- casefold(names(crv_loading),F)
    crv_loading$term <- crv_loading$maturity*12
    crv_loading <- crv_loading[,c('term','level_loading','slope_loading','curvature_loading')]
    crv_loading
}

# modify to calculate spread and rate change
cal_term_from_pc <- function(pc_data)
{
    crv <- load_crv_loading()
    
    vars_fc <- c('level','slope','curvature')
    vars_loading <- c('level_loading','slope_loading','curvature_loading')
    
    for(i in 1:length(vars_fc))
    {
        assign(vars_fc[i], as.matrix(pc_data[,i+1]) %*% t(crv[,vars_loading[i]]))
    }
    list(date = pc_data[,1], term_level=level,term_slope=slope,term_curvature=curvature,
    	 term_total=level + slope + curvature)
}

cal_term_from_pc_wa <- function(pc_data)
{
    crv <- load_crv_loading()
    crv[,3:4] = 1.1*crv[,3:4]
    
    vars_fc <- c('level','slope','curvature')
    vars_loading <- c('level_loading','slope_loading','curvature_loading')
    
    for(i in 1:length(vars_fc))
    {
        assign(vars_fc[i], as.matrix(pc_data[,i+1]) %*% t(crv[,vars_loading[i]]))
    }
    list(date = pc_data[,1], term_level=level,term_slope=slope,term_curvature=curvature,
    	 term_total=level + slope + curvature)
}

# load_tsy_yield_curve <- function(as_of)
# {
#     cat('loading lehman fitted treasury yield curve...\n')
#     stmt <- paste("
#         select *
#         FROM YIELD_CURVE_TIMESERIES
#         WHERE
#         YC_NAME = 'LgtParBond'
#         AND COUNTRY='US'
#         and ( (IS_END_OF_MONTH='Y' and AS_OF_DATE<='",format(as_of,'%d-%b-%Y'),"')
#         or AS_OF_DATE='",format(as_of,'%d-%b-%Y'),"')
#         ORDER BY AS_OF_DATE
#     ",sep='')
#     
#     channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
#     outdata <- sqlQuery(channel,query=stmt)
#     odbcClose(channel)
#     
#     names(outdata)<-casefold(names(outdata),upper=F)
#     outdata$as_of_date <- as.Date(outdata$as_of_date)
#     outdata$month_end_date <- month.end(outdata$as_of_date)
#     
#     vars <- names(outdata)[grep('point',names(outdata))]
#     outdata <- outdata[,c('as_of_date','month_end_date',vars)]
#     
# 
# 	outdata$tax_rate = 0				
# 	for(i in 1:dim(tax)[1])
# 	{
# 		outdata$tax_rate[as.numeric(format(as.Date(outdata$as_of_date),"%Y")) == tax[i,1]] = tax[i,2]
# 	}
#     
#     outdata   
#         
# }

# load_MMD_yield_curve <- function(as_of)
# {
#     cat('loading MMD AAA yield curve...\n')
#     stmt <- paste("
#         select *
#         from YIELD_CURVE_TIMESERIES
#         where
#         YC_NAME = 'MunAaaSpln'
#         and ( (IS_END_OF_MONTH='Y' and AS_OF_DATE<='",format(as_of,'%d-%b-%Y'),"')
#         or AS_OF_DATE='",format(as_of,'%d-%b-%Y'),"')
#         ORDER BY AS_OF_DATE
#     ",sep='')
#     
#     channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
#     outdata <- sqlQuery(channel,query=stmt )
#     odbcClose(channel)
#     
#     names(outdata)<-casefold(names(outdata),upper=F)
#     outdata$as_of_date <- as.Date(outdata$as_of_date)
#     outdata$month_end_date <- month.end(outdata$as_of_date)
#     
#     vars <- names(outdata)[grep('point',names(outdata))]
#     outdata <- outdata[,c('as_of_date','month_end_date',vars)]
# 
#     outdata
# } 

calc_spread_le <- function(tsy,muni)
{    
    dates <- intersect(tsy$month_end_date,muni$month_end_date)
    idx_tsy <- match(dates,tsy$month_end_date)
    idx_muni <- match(dates,muni$month_end_date)
        
    muni_sprd <- muni[idx_muni,-(1:2)] - tsy[idx_tsy,-(1:2)]
    sprd <- cbind(tsy[idx_tsy,c('as_of_date','month_end_date')], muni_sprd)
	sprd
}
calc_spread <- function(tsy,muni)
{    
    dates <- intersect(tsy$month_end_date,muni$month_end_date)
    idx_tsy <- match(dates,tsy$month_end_date)
    idx_muni <- match(dates,muni$month_end_date)
    


    
    muni_sprd <- muni[idx_muni,-(1:2)] - tsy[idx_tsy,-(1:2)]
    sprd <- cbind(tsy[idx_tsy,c('as_of_date','month_end_date')],
		data.frame(sprd_level = muni_sprd$point_120m,
		sprd_slope = muni_sprd$point_120m - muni_sprd$point_024m,
		sprd_curv  =  - 2*muni_sprd$point_060m + muni_sprd$point_024m + muni_sprd$point_120m) )
	sprd
}


load_vix <- function(as_of)
{
	stmt <- paste("select * from FIQModel.dbo.QM_DATA where PARAMETER_ID=49 and VALUE_DATE<='",format(as_of,'%d-%b-%Y'),"'",sep='')
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    vix <- sqlQuery(channel,stmt)
    odbcClose(channel)
    names(vix) <- casefold(names(vix),F)
    vix$as_of_date <- as.Date(vix$value_date)
    
    ix <- weekdays(vix$as_of_date) %in% c('Saturday','Sunday')
    vix <- vix[!ix,]
    
    vix <- sort.data.frame(vix,by=~as_of_date)
    
    vix$vix_1w <- movavg(vix$value,wgt=rep(1,5))
    vix$vix_6m <- movavg(vix$value,wgt=rep(1,126))
    vix$vix_5yr <- movavg(vix$value,wgt=rep(1,1250))
    
    vix$stmo_vix <- vix$vix_1w - vix$vix_6m
    vix$ltmo_vix <- vix$vix_1w - vix$vix_5yr
    
    vix$month_end_date <- month.end(vix$as_of_date)
    
    vix <- sort.data.frame(vix,by=~month_end_date - as_of_date)
    
    idx <- match(sort(unique(vix$month_end_date)),vix$month_end_date)    

    vix <- vix[idx,c('as_of_date','month_end_date','stmo_vix','ltmo_vix')]
}

# modify to calculate spread and rate change
cal_term_from_pc <- function(pc_data)
{
    crv <- load_crv_loading()
    
    vars_fc <- c('level','slope','curvature')
    vars_loading <- c('level_loading','slope_loading','curvature_loading')
    
    for(i in 1:length(vars_fc))
    {
        assign(vars_fc[i], as.matrix(pc_data[,i+1]) %*% t(crv[,vars_loading[i]]))
    }
    list(date = pc_data[,1], term_level=level,term_slope=slope,term_curvature=curvature,
    	 term_total=level + slope + curvature)
}

#source('H:/SVN/Muni/v1.0/Src/MMDYieldCurve/aaa_spread_model_le.R')

as_of = Sys.Date()
require(RODBC)
require(TTR)
db_info = get_db_info('QA')

tenors = seq(10,30,by = 1)
tsy_curve = load_tsy_yield_curve(as_of)
t2s = c();
for(t in tenors)
{
	t2s = c(t2s, grep(t*12,names(tsy_curve)))
}
tsy_curve_le = tsy_curve[,c(1,2,t2s)]

# 3m forward change in tresury yields
for(i in 3:dim(tsy_curve_le)[2])
{
	tsy_curve_le$tmp = NA
	tsy_curve_le$tmp[1:(dim(tsy_curve_le)[1] - 3)]= diff(tsy_curve_le[,i],lag = 3)
	names(tsy_curve_le)[dim(tsy_curve_le)[2]] = paste("tsy_",as.numeric(substring(names(tsy_curve_le)[i],7,9))/12,'Y_ch',sep = '')
}


# trasury forecast
k_rates = seq(40,120,4)
tr_fc = load_tsy_fc(as_of)
tr_term_fc = cal_term_from_pc(tr_fc)
tr_term_fc = data.frame(as_of = tr_term_fc$date,tr_term_fc$term_total[,k_rates])
for(i in 2:(1+length(k_rates)))
{
	names(tr_term_fc)[i] = paste("tsy_",k_rates[i-1]/4,'Y_fc',sep = '')
}

tr_term_fc = merge(tr_term_fc,tsy_curve_le[,c(1,grep('ch',names(tsy_curve_le)))],by.x = 'as_of',by.y = 'as_of_date',all.y = T)

muni_curve = load_MMD_yield_curve(as_of)



ncl_curve = read.table(file = "H:\\Work\\muni\\AAA spread model\\nclmeanrev.csv",header = T,sep = ",")
ncl_curve = cbind(data.frame(month_end_date = month.end(as.Date(ncl_curve$Date,'%d-%b-%y'))),ncl_curve)

ncl_curve = ncl_curve[,-(3:4)]

t2s = c();
for(t in tenors)
{
	t2s = c(t2s, grep(t,names(ncl_curve)))
}
ncl_curve = ncl_curve[,c(1,2,t2s)]

fwd_per = 3

tsy_curve_le = tsy_curve_le[,-grep('ch',names(tsy_curve_le))] # remove change before computing spread

aaa_spread_le = calc_spread_le(tsy_curve_le,ncl_curve)
for(i in 3:dim(aaa_spread_le)[2])
{
	aaa_spread_le$tmp = NA
	aaa_spread_le$tmp[1:(dim(aaa_spread_le)[1] - fwd_per)]= diff(aaa_spread_le[,i],lag = fwd_per)
	names(aaa_spread_le)[dim(aaa_spread_le)[2]] = paste(names(aaa_spread_le)[i],'ch',sep = '')
}

covmat = cov(aaa_spread_le[,grep('ch',names(aaa_spread_le))],use = "complete.obs")

evd = eigen(covmat)

aaa_spread = calc_spread(tsy_curve,muni_curve)



hl = dim(aaa_spread)[1]
# forward change for the specified horizon
reg_data = data.frame(month_end_date = aaa_spread$month_end_date[1:(hl-fwd_per)],
					  sprd_level_chg = diff(aaa_spread$sprd_level,lag = fwd_per),
					  sprd_level_1m_fwd_chg = diff(aaa_spread$sprd_level[1:(hl-fwd_per+1)],lag = 1),
					  sprd_level = aaa_spread$sprd_level[1:(hl-fwd_per)],
					  sprd_slope_chg = diff(aaa_spread$sprd_slope,lag = fwd_per),
					  sprd_slope = aaa_spread$sprd_slope[1:(hl-fwd_per)],
					  sprd_curv_chg = diff(aaa_spread$sprd_curv,lag = fwd_per),
					  sprd_curv = aaa_spread$sprd_curv[1:(hl-fwd_per)]
					  )
					  
				  
# # 1 month trailing change					  
# reg_data$sprd_level_1m_chg[2:dim(reg_data)[1]] = diff(reg_data$sprd_level,lag = 1)
# # 12 month linearly weighted momentum
# reg_data$sprd_level_12m_mom_lw = WMA(reg_data$sprd_level_1m_chg, n = 12)
# # 1 month slope trailing change					  
# reg_data$sprd_slope_1m_chg[2:dim(reg_data)[1]] = diff(reg_data$sprd_slope,lag = 1)
# # 12 month slope linearly weighted momentum
# reg_data$sprd_slope_12m_mom_lw = WMA(reg_data$sprd_slope_1m_chg, n = 12)
# 
# level deviation from long term average
for(i in 1:dim(reg_data)[1])
{
	reg_data$lt_mean_rev[i] = reg_data$sprd_level[i] - mean(reg_data$sprd_level[1:i])
}

# deviation from 2y average
reg_data$r10Y2y_mr = NA
for(i in 24:dim(reg_data)[1])
{
	reg_data$r10Y2y_mr[i] = reg_data$sprd_level[i] - mean(reg_data$sprd_level[(i-23):i])
}	
# # deviation from 5y average
# reg_data$fiveY_mean_rev = NA
# for(i in 60:dim(reg_data)[1])
# {
# 	reg_data$fiveY_mean_rev[i] = reg_data$sprd_level[i] - mean(reg_data$sprd_level[(i-59):i])
# }

# forecast based on 10Y forecast, shaped by 1pc for 10y-30y points
reg_data_le = merge(aaa_spread_le,reg_data[,c('month_end_date',	'lt_mean_rev','r10Y2y_mr')])
v1 = -evd$vectors[,1]
v1 = v1/v1[1]
for(i in 1:length(tenors))
{
	reg_data_le$tmp = reg_data_le[,grep('lt_mean_rev',names(reg_data_le))]*v1[i] 
	names(reg_data_le)[dim(reg_data_le)[2]] = paste('r',tenors[i],'Yfc',sep = '')
}

res1pc = data.frame()
iy = grep('ch',names(reg_data_le))
ix = grep('fc',names(reg_data_le))
for(i in 1:length(iy))
{
	pres = lm(as.formula(paste(names(reg_data_le)[iy[i]]," ~ ",names(reg_data_le)[ix[i]],sep = '')),reg_data_le)
	res1pc = rbind(res1pc,data.frame(Tenor = names(reg_data_le)[iy[i]], R2 = summary(pres)$adj.r.squared))
}

# 30y point forecast
reg_data_le = reg_data_le[,-ix]

ir = grep('r30Y',names(reg_data_le))
ir = ir[1]
for(i in 1:dim(reg_data_le)[1])
{
	reg_data_le[i,paste(names(reg_data_le)[ir],'lt_mr',sep = '')] = reg_data_le[i,ir] - mean(reg_data_le[1:i,ir])
	if(i >= 24)
	{
		reg_data_le[i,paste(names(reg_data_le)[ir],'2y_mr',sep = '')] = reg_data_le[i,ir] - mean(reg_data_le[(i-23):i,ir])
	}
	if(i >= 36)
	{
		reg_data_le[i,paste(names(reg_data_le)[ir],'3y_mr',sep = '')] = reg_data_le[i,ir] - mean(reg_data_le[(i-35):i,ir])
	}
	if(i >= 60)
	{
		reg_data_le[i,paste(names(reg_data_le)[ir],'5y_mr',sep = '')] = reg_data_le[i,ir] - mean(reg_data_le[(i-59):i,ir])
	}
}

res30 = lm('r30Ych ~ r30Ylt_mr',reg_data_le[24:dim(reg_data_le)[1],])
res30ni = lm('r30Ych ~ -1 + r30Ylt_mr',reg_data_le[24:dim(reg_data_le)[1],])
res30a = lm('r30Ych ~ r30Y2y_mr',reg_data_le[24:dim(reg_data_le)[1],])
res30b = lm('r30Ych ~ r30Y3y_mr',reg_data_le[36:dim(reg_data_le)[1],])
res30c = lm('r30Ych ~ r30Y5y_mr',reg_data_le[60:dim(reg_data_le)[1],])
res30ani = lm('r30Ych ~ -1 + r30Y2y_mr',reg_data_le[24:dim(reg_data_le)[1],])
res30bni = lm('r30Ych ~ -1 + r30Y3y_mr',reg_data_le[36:dim(reg_data_le)[1],])
res30cni = lm('r30Ych ~ -1 + r30Y5y_mr',reg_data_le[60:dim(reg_data_le)[1],])

res10 = lm('r10Ych ~ lt_mean_rev',reg_data_le)
res10a = lm('r10Ych ~ r10Y2y_mr',reg_data_le[24:dim(reg_data_le)[1],])

# 20Y point forecast
ir = grep('r20Y',names(reg_data_le))
ir = ir[1]
for(i in 1:dim(reg_data_le)[1])
{
	reg_data_le[i,paste(names(reg_data_le)[ir],'lt_mr',sep = '')] = reg_data_le[i,ir] - mean(reg_data_le[1:i,ir])
	if(i >= 24)
	{
		reg_data_le[i,paste(names(reg_data_le)[ir],'2y_mr',sep = '')] = reg_data_le[i,ir] - mean(reg_data_le[(i-23):i,ir])
	}
	if(i >= 36)
	{
		reg_data_le[i,paste(names(reg_data_le)[ir],'3y_mr',sep = '')] = reg_data_le[i,ir] - mean(reg_data_le[(i-35):i,ir])
	}
	if(i >= 60)
	{
		reg_data_le[i,paste(names(reg_data_le)[ir],'5y_mr',sep = '')] = reg_data_le[i,ir] - mean(reg_data_le[(i-59):i,ir])
	}
}

res20 = lm('r20Ych ~ -1 + r20Ylt_mr',reg_data_le[24:dim(reg_data_le)[1],])
res20a = lm('r20Ych ~ r20Y2y_mr',reg_data_le[24:dim(reg_data_le)[1],])
res20b = lm('r20Ych ~ r20Y3y_mr',reg_data_le[36:dim(reg_data_le)[1],])
res20c = lm('r20Ych ~ r20Y5y_mr',reg_data_le[60:dim(reg_data_le)[1],])

# 25Y point forecast
ir = grep('r25Y',names(reg_data_le))
ir = ir[1]
for(i in 1:dim(reg_data_le)[1])
{
	reg_data_le[i,paste(names(reg_data_le)[ir],'lt_mr',sep = '')] = reg_data_le[i,ir] - mean(reg_data_le[1:i,ir])
	if(i >= 24)
	{
		reg_data_le[i,paste(names(reg_data_le)[ir],'2y_mr',sep = '')] = reg_data_le[i,ir] - mean(reg_data_le[(i-23):i,ir])
	}
	if(i >= 36)
	{
		reg_data_le[i,paste(names(reg_data_le)[ir],'3y_mr',sep = '')] = reg_data_le[i,ir] - mean(reg_data_le[(i-35):i,ir])
	}
	if(i >= 60)
	{
		reg_data_le[i,paste(names(reg_data_le)[ir],'5y_mr',sep = '')] = reg_data_le[i,ir] - mean(reg_data_le[(i-59):i,ir])
	}
}

res25 = lm('r25Ych ~ -1 + r25Ylt_mr',reg_data_le[24:dim(reg_data_le)[1],])
res25a = lm('r25Ych ~ r25Y2y_mr',reg_data_le[24:dim(reg_data_le)[1],])
res25b = lm('r25Ych ~ r25Y3y_mr',reg_data_le[36:dim(reg_data_le)[1],])
res25c = lm('r25Ych ~ r25Y5y_mr',reg_data_le[60:dim(reg_data_le)[1],])



kt = c(10,30)
kttags = c('lt_mean_rev','r30Y3y_mr')
#kttags = c('lt_mean_rev','r30Ylt_mr')

acttags = c('r10Ych','r30Ych')

#   kt = c(10,25,30)
#   kttags = c('lt_mean_rev','r25Y3y_mr','r30Y3y_mr')
#   acttags = c('r10Ych','r25Ych','r30Ych')


t = which(!is.na(reg_data_le[,kttags]),arr.ind = T)
imin = 1
for(i in 1:length(kt))
{
	if(min(t[t[,2] == i,1]) > imin) imin = min(t[t[,2] == i,1])
}

reg_dataf = reg_data_le[imin:dim(reg_data_le)[1],]
# out of sample forecst for key points
strt = 12 + fwd_per
kfchist = data.frame()
for(i in strt:dim(reg_dataf)[1])
{
	kfc = data.frame(month_end_date = reg_dataf$month_end_date[i])
	for(j in 1:length(kt))
	{
		rt1 = lm(as.formula(paste(acttags[j]," ~ ",kttags[j],sep = '')),reg_dataf[1:(i - fwd_per),])
		kfc = cbind(kfc, data.frame(t = reg_dataf[i,kttags[j]]*rt1$coefficients[2],row.names = NULL))
		names(kfc)[dim(kfc)[2]] = paste(names(rt1$coefficients)[2],'_keyforecast',sep = '')
		kfc = cbind(kfc, data.frame(t = rt1$coefficients[2],row.names = NULL))
		names(kfc)[dim(kfc)[2]] = paste(names(rt1$coefficients)[2],'_loading',sep = '')
		
	}	
	kfchist = rbind(kfchist,kfc)
}

stdate = as.Date('2010-11-01')
kfchist = kfchist[kfchist$month_end_date >= stdate,]
tr_term_fc = tr_term_fc[tr_term_fc$as_of >= stdate,]

reg_dataf = merge(reg_dataf, kfchist, all.x = T)

#linear interpolate for non-key tenors
stp = which(apply(!is.na(reg_dataf[,grep('keyforecast',names(reg_dataf))]),1,sum) == length(kt))[1]
fchist = data.frame()
for(i in stp:dim(reg_dataf)[1])
{
	tfcn = approx(kt,reg_dataf[i,grep('keyforecast',names(reg_dataf))],tenors)$y
	tfc = data.frame(month_end_date = reg_dataf$month_end_date[i])
	for(j in 1:length(tenors))
	{
		tfc = cbind(tfc,data.frame(t = tfcn[j]))
		names(tfc)[dim(tfc)[2]] = paste('r',tenors[j],'Yfc',sep = '')
	}
	fchist = rbind(fchist,tfc)
}

reg_dataf = merge(reg_dataf, fchist, all.x = T)

resli = data.frame()
iy = grep('ch',names(reg_dataf))
ix = grep('fc',names(reg_dataf))
for(i in 1:length(iy))
{
	pres = lm(as.formula(paste(names(reg_dataf)[iy[i]]," ~ ",names(reg_dataf)[ix[i]],sep = '')),reg_dataf)
	resli = rbind(resli,data.frame(Tenor = names(reg_dataf)[iy[i]], R2 = summary(pres)$adj.r.squared))
}

restsy = data.frame()
iy = grep('ch',names(tr_term_fc))
ix = grep('fc',names(tr_term_fc))
for(i in 1:length(iy))
{
	pres = lm(as.formula(paste(names(tr_term_fc)[iy[i]]," ~  ",names(tr_term_fc)[ix[i]],sep = '')),tr_term_fc)
	restsy = rbind(restsy,data.frame(Tenor = substring(names(tr_term_fc)[iy[i]],5,7), R2 = summary(pres)$adj.r.squared))
}

