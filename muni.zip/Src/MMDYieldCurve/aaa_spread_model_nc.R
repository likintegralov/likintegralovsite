

source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.kal.R',sep='') )

#source('H:/SVN/Muni/v1.0/Src/MMDYieldCurve/aaa_spread_model.R')

load_tsy_fc <- function(asof)
{
	# 3 month forecast
	stmt <- paste("select AS_OF_DATE, ",
        "POINT_120M/2 AS TSY_LEVEL_FC, ",
        "(POINT_120M - POINT_024M)/2 AS TSY_SLOPE_FC, ", 
        "(-2*POINT_024M + POINT_003M + POINT_120M)/2 AS TSY_CURVATURE_FC ",
        "FROM YIELD_CURVE_FORECAST_WIDE_VIEW ",
        "WHERE YC_NAME='Treasury' ",
        "and MODEL_ID = 17 ",
        "and FORECAST_HORIZON=6 ",
        "and CURRENCY='USD' ",
        "and AS_OF_DATE<='",format(asof,'%d-%b-%Y'),"'
        ",sep='')
        
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    tsy_fc <- sqlQuery(channel,query=stmt)
    odbcClose(channel)
    
    if(nrow(tsy_fc)==0) stop('no tsy forecst for ',asof,'\n',stmt)
    names(tsy_fc)<-casefold(names(tsy_fc),upper=F)
    tsy_fc$as_of_date <- as.Date(tsy_fc$as_of_date)
    #apply tax
 	tax = get_tax_rate(db_info)
	names(tax)[1] = 'as_of_date'
	tsy_fc = merge(tsy_fc,tax, by = 'as_of_date',all.x = T)
	    
	tsy_fc[,2:(dim(tsy_fc)[2] - 1)] = (1 - tsy_fc$tax/100)*tsy_fc[,2:(dim(tsy_fc)[2] - 1)]	
	   	# remove tax rate for compartibility
   	tsy_fc = tsy_fc[,-dim(tsy_fc)[2]]
    tsy_fc
}

load_crv_loading <- function()
{
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    crv_loading <- sqlQuery(channel,query="select * from YIELD_CURVE_LOADING where YC_NAME='Treasury' and CURRENCY='ALL' and VERSION='2.1' order by MATURITY" )
    odbcClose(channel)
    names(crv_loading) <- casefold(names(crv_loading),F)
    crv_loading$term <- crv_loading$maturity*12
    crv_loading <- crv_loading[,c('term','level_loading','slope_loading','curvature_loading')]
    crv_loading
}

# modify to calculate spread and rate change
cal_term_from_pc <- function(pc_data)
{
    crv <- load_crv_loading()
    
    vars_fc <- c('level','slope','curvature')
    vars_loading <- c('level_loading','slope_loading','curvature_loading')
    
    for(i in 1:length(vars_fc))
    {
        assign(vars_fc[i], as.matrix(pc_data[,i+1]) %*% t(crv[,vars_loading[i]]))
    }
    list(date = pc_data[,1], term_level=level,term_slope=slope,term_curvature=curvature,
    	 term_total=level + slope + curvature)
}


cal_term_from_pc_muni <- function(pc_data)
{
    crv <- load_crv_loading()
    
    vars_fc <- c('level','slope','curvature')
    vars_loading <- c('level_loading','slope_loading','curvature_loading')
    
    for(i in 1:length(vars_fc))
    {
        assign(vars_fc[i], as.matrix(pc_data[,i+1]) %*% t(crv[,vars_loading[i]]))
    }
    
    # linear interpolate between 10y and 30y forecast
    term_total = level + slope + curvature
    for(i in 1:dim(term_total)[1])
    {
	    term_total[i,40:120] = approx(c(40,120),c(term_total[i,40],pc_data$sprd_30y[i]),40:120)$y
    }
    
    list(date = pc_data[,1], term_level=level,term_slope=slope,term_curvature=curvature,
    	 term_total=term_total)
}

cal_term_from_pc_wa <- function(pc_data)
{
    crv <- load_crv_loading()
    crv[,3:4] = 1.1*crv[,3:4]
    
    vars_fc <- c('level','slope','curvature')
    vars_loading <- c('level_loading','slope_loading','curvature_loading')
    
    for(i in 1:length(vars_fc))
    {
        assign(vars_fc[i], as.matrix(pc_data[,i+1]) %*% t(crv[,vars_loading[i]]))
    }
    list(date = pc_data[,1], term_level=level,term_slope=slope,term_curvature=curvature,
    	 term_total=level + slope + curvature)
}

# load_tsy_yield_curve <- function(as_of)
# {
#     cat('loading lehman fitted treasury yield curve...\n')
#     stmt <- paste("
#         select *
#         FROM YIELD_CURVE_TIMESERIES
#         WHERE
#         YC_NAME = 'LgtParBond'
#         AND COUNTRY='US'
#         and ( (IS_END_OF_MONTH='Y' and AS_OF_DATE<='",format(as_of,'%d-%b-%Y'),"')
#         or AS_OF_DATE='",format(as_of,'%d-%b-%Y'),"')
#         ORDER BY AS_OF_DATE
#     ",sep='')
#     
#     channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
#     outdata <- sqlQuery(channel,query=stmt)
#     odbcClose(channel)
#     
#     names(outdata)<-casefold(names(outdata),upper=F)
#     outdata$as_of_date <- as.Date(outdata$as_of_date)
#     outdata$month_end_date <- month.end(outdata$as_of_date)
#     
#     vars <- names(outdata)[grep('point',names(outdata))]
#     outdata <- outdata[,c('as_of_date','month_end_date',vars)]
#     
# 
# 	outdata$tax_rate = 0				
# 	for(i in 1:dim(tax)[1])
# 	{
# 		outdata$tax_rate[as.numeric(format(as.Date(outdata$as_of_date),"%Y")) == tax[i,1]] = tax[i,2]
# 	}
#     
#     outdata   
#         
# }
# 
# load_MMD_yield_curve <- function(as_of)
# {
#     cat('loading MMD AAA yield curve...\n')
#     stmt <- paste("
#         select *
#         from YIELD_CURVE_TIMESERIES
#         where
#         YC_NAME = 'MunAaaSpln'
#         and ( (IS_END_OF_MONTH='Y' and AS_OF_DATE<='",format(as_of,'%d-%b-%Y'),"')
#         or AS_OF_DATE='",format(as_of,'%d-%b-%Y'),"')
#         ORDER BY AS_OF_DATE
#     ",sep='')
#     
#     channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
#     outdata <- sqlQuery(channel,query=stmt )
#     odbcClose(channel)
#     
#     names(outdata)<-casefold(names(outdata),upper=F)
#     outdata$as_of_date <- as.Date(outdata$as_of_date)
#     outdata$month_end_date <- month.end(outdata$as_of_date)
#     
#     vars <- names(outdata)[grep('point',names(outdata))]
#     outdata <- outdata[,c('as_of_date','month_end_date',vars)]
# 
#     outdata
# } 

calc_spread <- function(tsy,muni)
{    
    dates <- intersect(tsy$month_end_date,muni$month_end_date)
    idx_tsy <- match(dates,tsy$month_end_date)
    idx_muni <- match(dates,muni$month_end_date)
    


    
    muni_sprd <- muni[idx_muni,-(1:2)] - tsy[idx_tsy,-(1:2)]
    sprd <- cbind(tsy[idx_tsy,c('as_of_date','month_end_date')],
		data.frame(sprd_level = muni_sprd$point_120m,
		sprd_slope = muni_sprd$point_120m - muni_sprd$point_024m,
		sprd_curv  =  - 2*muni_sprd$point_060m + muni_sprd$point_024m + muni_sprd$point_120m,
		sprd_30y = muni_sprd$point_360m) )
	sprd
}

load_MMD <- function(as_of,daily = F, flds = NULL)
{
	if(!daily)
	{
	    cat('loading MMD AAA yield curve...\n')
	    stmt <- paste("
	        select *
	        from YIELD_CURVE_TIMESERIES
	        where
	        YC_NAME = 'MuniAaaMmd'
	        and (AS_OF_DATE in (select min(AS_OF_DATE) from FIQModel..YIELD_CURVE_TIMESERIES  where IS_END_OF_MONTH = 'Y' 
			 and YC_NAME = 'MuniAaaMmd' and AS_OF_DATE<='",format(as_of,'%d-%b-%Y'),"' group by year(AS_OF_DATE),month(AS_OF_DATE))
			 or AS_OF_DATE='",format(as_of,'%d-%b-%Y'),"')
	        ORDER BY AS_OF_DATE
	    ",sep='')
	    
	    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
	    outdata <- sqlQuery(channel,query=stmt )
	    odbcClose(channel)
	    
	    names(outdata)<-casefold(names(outdata),upper=F)
	    outdata$as_of_date <- as.Date(outdata$as_of_date)
	    outdata$month_end_date <- month.end(outdata$as_of_date)
	    
	    vars <- names(outdata)[grep('point',names(outdata))]
	    outdata <- outdata[,c('as_of_date','month_end_date',vars)]
	}else
	{
		if(is.null(flds))
		{
			stmt <- paste("
	        select *
	        FROM YIELD_CURVE_TIMESERIES
	        WHERE
	        YC_NAME = 'MuniAaaMmd'
	        AND COUNTRY='US'
	        and AS_OF_DATE<='",format(as_of,'%d-%b-%Y'),"' ",
	        "ORDER BY AS_OF_DATE
	    ",sep='')
    	}else
    	{
	    	stmt <- paste("
	        select AS_OF_DATE date, ",paste(flds,collapse = ','),
	        " FROM YIELD_CURVE_TIMESERIES
	        WHERE
	        YC_NAME = 'MuniAaaMmd'
	        AND COUNTRY='US'
	        and AS_OF_DATE<='",format(as_of,'%d-%b-%Y'),"' ",
	        "ORDER BY AS_OF_DATE
	    	",sep='')
    	}
    	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
	    outdata <- sqlQuery(channel,query=stmt)
	    odbcClose(channel)
	    
	    names(outdata)<-casefold(names(outdata),upper=F)
	    outdata$date <- as.Date(outdata$date)
	    names(outdata)[names(outdata) == 'as_of_date'] = 'date'    	
	}
	
    outdata
} 

load_vix <- function(as_of)
{
	stmt <- paste("select * from FIQModel.dbo.QM_DATA where PARAMETER_ID=49 and VALUE_DATE<='",format(as_of,'%d-%b-%Y'),"'",sep='')
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    vix <- sqlQuery(channel,stmt)
    odbcClose(channel)
    names(vix) <- casefold(names(vix),F)
    vix$as_of_date <- as.Date(vix$value_date)
    
    ix <- weekdays(vix$as_of_date) %in% c('Saturday','Sunday')
    vix <- vix[!ix,]
    
    vix <- sort.data.frame(vix,by=~as_of_date)
    
    vix$vix_1w <- movavg(vix$value,wgt=rep(1,5))
    vix$vix_6m <- movavg(vix$value,wgt=rep(1,126))
    vix$vix_5yr <- movavg(vix$value,wgt=rep(1,1250))
    
    vix$stmo_vix <- vix$vix_1w - vix$vix_6m
    vix$ltmo_vix <- vix$vix_1w - vix$vix_5yr
    
    vix$month_end_date <- month.end(vix$as_of_date)
    
    vix <- sort.data.frame(vix,by=~month_end_date - as_of_date)
    
    idx <- match(sort(unique(vix$month_end_date)),vix$month_end_date)    

    vix <- vix[idx,c('as_of_date','month_end_date','stmo_vix','ltmo_vix')]
}

load_tsy_yield_curve_tax <- function(as_of,daily = F,flds = NULL)
{
	cat('loading lehman fitted treasury yield curve...\n')
    if(!daily)
	{
	    stmt <- paste("
	        select *
	        FROM YIELD_CURVE_TIMESERIES
	        WHERE
	        YC_NAME = 'LgtParBond'
	        AND COUNTRY='US'
	        and ( (IS_END_OF_MONTH='Y' and AS_OF_DATE<='",format(as_of,'%d-%b-%Y'),"')
	        or AS_OF_DATE='",format(as_of,'%d-%b-%Y'),"')
	        ORDER BY AS_OF_DATE
	    ",sep='')
	    
	    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
	    outdata <- sqlQuery(channel,query=stmt)
	    odbcClose(channel)
	    
	    names(outdata)<-casefold(names(outdata),upper=F)
	    outdata$as_of_date <- as.Date(outdata$as_of_date)
	    outdata$month_end_date <- month.end(outdata$as_of_date)
	    
	    vars <- names(outdata)[grep('point',names(outdata))]
	    outdata <- outdata[,c('as_of_date','month_end_date',vars)]
	    

	}else #daily data
	{
		if(is.null(flds))
		{
			stmt <- paste("
	        select *
	        FROM YIELD_CURVE_TIMESERIES
	        WHERE
	        YC_NAME = 'LgtParBond'
	        AND COUNTRY='US'
	        and AS_OF_DATE<='",format(as_of,'%d-%b-%Y'),"' ",
	        "ORDER BY AS_OF_DATE
	    ",sep='')
    	}else
    	{
	    	stmt <- paste("
	        select AS_OF_DATE date, ",paste(flds,collapse = ','),
	        " FROM YIELD_CURVE_TIMESERIES
	        WHERE
	        YC_NAME = 'LgtParBond'
	        AND COUNTRY='US'
	        and AS_OF_DATE<='",format(as_of,'%d-%b-%Y'),"' ",
	        "ORDER BY AS_OF_DATE
	    	",sep='')
    	}
    	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
	    outdata <- sqlQuery(channel,query=stmt)
	    odbcClose(channel)
	    
	    names(outdata)<-casefold(names(outdata),upper=F)
	    names(outdata)[names(outdata) == 'as_of_date'] = 'date'
	    outdata$date <- as.Date(outdata$date)
	    
	}
	   	# remove tax rate for compartibility
    outdata   
}

#source('H:/SVN/Muni/v1.0/Src/MMDYieldCurve/aaa_spread_model_nc.R')

as_of = Sys.Date()
require(RODBC)
require(TTR)
db_info = get_db_info('PRD')

tsy_curve = load_tsy_yield_curve(as_of)
tsy_curve_tax = load_tsy_yield_curve_tax(as_of) # taxable curve
tsy_curve_tax = tsy_curve_tax[,c('as_of_date','point_120m')]
names(tsy_curve_tax) = c('as_of','tsy10y_tax')
muni_curve = load_MMD_yield_curve(as_of)
muni_curve_old = load_MMD(as_of)

t = rbind(muni_curve_old[muni_curve_old$as_of_date < min(muni_curve$as_of_date),],muni_curve)
t[t$as_of_date < min(muni_curve$as_of_date),43:dim(t)[2]] = NA
muni_curve = t

aaa_spread = calc_spread(tsy_curve,muni_curve)

supply_all = read.table(file = "H:\\Work\\muni\\AAA spread model\\Muni Supply.csv",header = T,sep = ",")
bbvstot = read.table(file = "H:\\Work\\muni\\AAA spread model\\BBVS.csv",header = T,sep = ",")
ig = read.table(file = "H:\\Work\\muni\\AAA spread model\\US IG.csv",header = T,sep = ",")
trvol = read.table(file = "H:\\Work\\muni\\AAA spread model\\TradeVol.csv",header = T,sep = ",")
mf_mp = read.table(file = "H:\\Work\\muni\\AAA spread model\\MF Missprice.csv",header = T,sep = ",")
#msrb = read.table(file = "H:\\Work\\muni\\AAA spread model\\Data.csv",header = T,sep = ",")

vix = load_vix(as_of)

fwd_per = 3
hl = dim(aaa_spread)[1]
# forward change for the specified horizon
reg_data = data.frame(as_of = aaa_spread$as_of_date[1:(hl-fwd_per)],
					  sprd_level_chg = diff(aaa_spread$sprd_level,lag = fwd_per),
					  sprd_level_1m_fwd_chg = diff(aaa_spread$sprd_level[1:(hl-fwd_per+1)],lag = 1),
					  sprd_level = aaa_spread$sprd_level[1:(hl-fwd_per)],
					  sprd_slope_chg = diff(aaa_spread$sprd_slope,lag = fwd_per),
					  sprd_slope = aaa_spread$sprd_slope[1:(hl-fwd_per)],
					  sprd_curv_chg = diff(aaa_spread$sprd_curv,lag = fwd_per),
					  sprd_curv = aaa_spread$sprd_curv[1:(hl-fwd_per)],
					  sprd_30y_chg = diff(aaa_spread$sprd_30y,lag = fwd_per),
					  sprd_30y = aaa_spread$sprd_30y[1:(hl-fwd_per)]
					  )
					  
reg_data = merge(reg_data,tsy_curve_tax)
t = muni_curve[,c('as_of_date','point_120m')]
names(t) = c('as_of','muni10y')
reg_data = merge(reg_data,t)					  
reg_data$tsy10y_ratio = reg_data$tsy10y_tax/reg_data$muni10y
reg_data$tsy10y_ratio_cen = reg_data$tsy10y_ratio  #-1#- mean(reg_data$tsy10y_ratio)
for(i in 12:dim(reg_data)[1])
	reg_data$tsy10y_ratio_cen[i] = reg_data$tsy10y_ratio[i] - mean(reg_data$tsy10y_ratio[1:i])

reg_data$tsy10y_sprd = reg_data$tsy10y_tax - reg_data$muni10y
for(i in 12:dim(reg_data)[1])
	reg_data$tsy10y_sprd[i] = reg_data$tsy10y_sprd[i] - mean(reg_data$tsy10y_sprd[1:i])
							  
# 1 month trailing change					  
reg_data$sprd_level_1m_chg[2:dim(reg_data)[1]] = diff(reg_data$sprd_level,lag = 1)
# 12 month linearly weighted momentum
reg_data$sprd_level_12m_mom_lw = WMA(reg_data$sprd_level_1m_chg, n = 12)
# 1 month slope trailing change					  
reg_data$sprd_slope_1m_chg[2:dim(reg_data)[1]] = diff(reg_data$sprd_slope,lag = 1)
# 12 month slope linearly weighted momentum
reg_data$sprd_slope_12m_mom_lw = WMA(reg_data$sprd_slope_1m_chg, n = 12)

# level deviation from long term average
for(i in 1:dim(reg_data)[1])
{
	reg_data$lt_mean_rev[i] = reg_data$sprd_level[i] - mean(reg_data$sprd_level[1:i])
}
# level deviation z-score (expanding window)
reg_data$aaa_zscore = NA
for(i in 3:dim(reg_data)[1])
{
	reg_data$aaa_zscore[i] = (reg_data$sprd_level[i] - mean(reg_data$sprd_level[1:i]))/sd(reg_data$sprd_level[1:i])
}

# level deviation from 2y average
reg_data$twoY_mean_rev = NA
for(i in 24:dim(reg_data)[1])
{
	reg_data$twoY_mean_rev[i] = reg_data$sprd_level[i] - mean(reg_data$sprd_level[(i-23):i])
}	
# level deviation from 5y average
reg_data$fiveY_mean_rev = NA
for(i in 60:dim(reg_data)[1])
{
	reg_data$fiveY_mean_rev[i] = reg_data$sprd_level[i] - mean(reg_data$sprd_level[(i-59):i])
}

# 30y deviation from 3y average, starts with expanding window
reg_data$sprd_30y_3y_mean_rev = NA
si = max(which(is.na(reg_data$sprd_30y)))+1
for(i in si:dim(reg_data)[1])
{
	reg_data$sprd_30y_3y_mean_rev[i] = reg_data$sprd_30y[i] - mean(reg_data$sprd_30y[(i-min(i-si,35)):i])
}

# slope deviation from term average (slope reversion)
lb = 6
reg_data$slope_rev = NA
for(i in lb:dim(reg_data)[1])
{
	reg_data$slope_rev[i] = reg_data$sprd_slope[i] - mean(reg_data$sprd_slope[(i-lb+1):i])
}
	
# treasury yield change
lb = 6
reg_data$tsy_mom = NA
for(i in (lb+1):dim(reg_data)[1])
{
	tsy_i = which(tsy_curve$as_of_date == reg_data$as_of[i]) 
	reg_data$tsy_mom[i] = tsy_curve$point_120m[tsy_i] - tsy_curve$point_120m[tsy_i - lb]
}

# supply
supply_lag = 1
reg_data$supply = NA
for(i in 1:dim(reg_data)[1])
{
	datadate = addMonth(reg_data$as_of[i],-supply_lag)
	inx = which(format.Date(as.Date(supply_all$Date),"%Y%m") == format.Date(datadate,"%Y%m"))
	if(length(inx) > 0)
		reg_data$supply[i] = supply_all$SPLYTOT[inx[length(inx)]]
}

#supply momentum
lb = 2
reg_data$supply_mom = NA
for(i in (1+lb):dim(reg_data)[1])
{
	reg_data$supply_mom[i] = reg_data$supply[i] - mean(reg_data$supply[(i-lb+1):i])
}
reg_data$supply_mom = reg_data$supply_mom - mean(reg_data$supply_mom,na.rm=T)

# visible supply
reg_data$vs = NA
for(i in 1:dim(reg_data)[1])
{
	inx = which(as.Date(bbvstot$Date) == as.Date(reg_data$as_of[i]))
	if(length(inx) > 0)
		reg_data$vs[i] = bbvstot$VSUP[inx]
}
# visible supply demeaned
# for(i in 1:dim(reg_data)[1])
# {
# 	reg_data$vs[i] = reg_data$vs[i] - mean(reg_data$vs[1:i])
# }

# visible supply momentum
lb = 2
reg_data$vs_mom = NA
for(i in (1+lb):dim(reg_data)[1])
{
	reg_data$vs_mom[i] = reg_data$vs[i] - mean(reg_data$vs[(i-lb+1):i])
}
#reg_data$supply_mom = reg_data$supply_mom - mean(reg_data$supply_mom,na.rm=T)



# slope deviation from long term average
for(i in 1:dim(reg_data)[1])
{
	reg_data$lt_slope_rev[i] = reg_data$sprd_slope[i] - mean(reg_data$sprd_slope[1:i])
}
# vix
reg_data = merge(reg_data,vix[,-1],by.x = 'as_of',by.y = 'month_end_date',all.x = T)

# curvature deviation from long term average
for(i in 1:dim(reg_data)[1])
{
	reg_data$lt_curv_rev[i] = reg_data$sprd_curv[i] - mean(reg_data$sprd_curv[1:i])
}

# curvature deviation from term average (curvature reversion)
lb = 60
reg_data$curv_rev = NA
for(i in lb:dim(reg_data)[1])
{
	reg_data$curv_rev[i] = reg_data$sprd_curv[i] - mean(reg_data$sprd_curv[(i-lb+1):i])
}

# ig spread z score (expanding window)
ig$ig_zscore = NA
ig$Date = month.end(as.Date(ig$Date))
for(i in 3:dim(ig)[1])
{
	ig$ig_zscore[i] = (ig$OASIG[i] - mean(ig$OASIG[1:i]))/sd(ig$OASIG[1:i])
}
reg_data = merge(reg_data,ig[,c('Date','ig_zscore')],by.x = 'as_of',by.y = 'Date',all.x = T)

# spread measure relative to IG
reg_data$igrel = reg_data$ig_zscore - reg_data$aaa_zscore

# trading volume data
trvol$Date = as.Date(trvol$Date)
reg_data = merge(reg_data,trvol,by.x = 'as_of',by.y = 'Date',all.x = T)

# Mutual Funds misprice data
mf_mp$Date = as.Date(mf_mp$Date)
reg_data = merge(reg_data,mf_mp,by.x = 'as_of',by.y = 'Date',all.x = T)

#msrb data
# trademonths = sort(unique(msrb$trade_month))
# tradedata = data.frame()
# for(m in trademonths)
# {
# 	as_of = month.end(as.Date(ISOdate(floor(m/100),m%%100,1)))
# 	trade_volume = sum(as.numeric(msrb$par_traded[msrb$trade_month == m & msrb$Maturity_Bucket == '5+ Year']),na.rm = T)
# 	avg_spread = mean(msrb$Spread[msrb$trade_month == m & msrb$Maturity_Bucket == '5+ Year'])
# 	
# 	tradedata = rbind(tradedata,data.frame(as_of = as_of, trade_volume = trade_volume, spread = avg_spread))
# }
# tradedata$spread = tradedata$spread - mean(tradedata$spread) # de-mean the S\B spreads
# reg_data = merge(reg_data,tradedata,by = 'as_of',all.x = T)

################## run out-of-sample regression #############################					  
st_from = 24

ind_var = c('lt_mean_rev')
ind_var = c('lt_mean_rev','tsy10y_ratio_cen')
#ind_var = c('lt_mean_rev','tsy10y_sprd')
#ind_var = c('lt_mean_rev','spread')
#ind_var = c('lt_mean_rev','vs')
#ind_var = c('sprd_level_12m_mom_lw')
#ind_var = c('twoY_mean_rev')
#ind_var = c('fiveY_mean_rev')
#ind_var = 'sprd_slope_12m_mom_lw'
#ind_var = 'tsy_mom'
#ind_var = 'supply'
#ind_var = 'supply_mom'
#ind_var = 'vs'
#ind_var = 'igrel'
#ind_var = 'TrVol'
#ind_var = 'misprice'
#ind_var = 'trade_volume'
#ind_var = 'spread'
#ind_var = 'tsy10y_ratio_cen'
#ind_var = 'tsy10y_sprd'

ind_var_slope = c('slope_rev')
#ind_var_slope = c('slope_rev','supply_mom')
#ind_var_slope = c('slope_rev','lt_slope_rev')
#ind_var_slope = c('lt_slope_rev','sprd_slope_12m_mom_lw')
#ind_var_slope = c('sprd_level_12m_mom_lw')
#ind_var_slope = c('twoY_mean_rev')
#ind_var_slope = 'stmo_vix'
#ind_var_slope = 'supply_mom'

ind_var_curv = c('curv_rev')
#ind_var_curv = c('lt_curv_rev')

ind_var_30y = c('sprd_30y_3y_mean_rev')

for(i in 1:length(ind_var))
{
	if(i == 1)	inx = !is.na(reg_data[,ind_var[i]])
	else inx = inx & !is.na(reg_data[,ind_var[i]])
}
		
reg_data_clean = reg_data[inx,]

reg_data_clean = reg_data_clean[reg_data_clean$as_of >= as.Date('2006-10-31'),]

for(i in 1:length(ind_var_slope))
{
	if(i == 1)	inx = !is.na(reg_data[,ind_var_slope[i]])
	else inx = inx & !is.na(reg_data[,ind_var_slope[i]])
}
		
reg_data_clean_slope = reg_data[inx,]

for(i in 1:length(ind_var_curv))
{
	if(i == 1)	inx = !is.na(reg_data[,ind_var_curv[i]])
	else inx = inx & !is.na(reg_data[,ind_var_curv[i]])
}
		
reg_data_clean_curv = reg_data[inx,]

reg_data_clean_30y = reg_data[(si+24):dim(reg_data)[1],] # start 2y after beginning of the time series

betas = c()
nms = c('as_of')
oos_fc = data.frame()
for(i in st_from:dim(reg_data_clean)[1])
{
 	 fit_level = lm(as.formula(paste("sprd_level_chg ~ ",paste(ind_var,collapse = "+")," - 1")),reg_data_clean[1:(i-fwd_per),])

 	#fit_level = lm(as.formula(paste("sprd_level_chg ~ ",paste(ind_var,collapse = "+"))),reg_data_clean[1:(i-fwd_per),])
 	#fit_level = lm(as.formula(paste("sprd_level_1m_fwd_chg ~ ",paste(ind_var,collapse = "+"))),reg_data_clean[1:(i-fwd_per),])
 	#fit_level = lm(as.formula(paste("sprd_level_1m_chg ~ ",paste(ind_var,collapse = "+"))),reg_data_clean[1:(i-fwd_per),])
 	#fit_level = glm(as.formula(paste("sprd_level_chg ~ ",paste(ind_var,collapse = "+"))),'gaussian',reg_data_clean[1:(i-fwd_per),])
 	#fit_level = glm(as.formula(paste("sprd_level_chg ~ ",paste(ind_var,collapse = "+")," - 1")),'gaussian',reg_data_clean[1:(i-fwd_per),])

 	if (i == st_from)
 	{
	 	betas = data.frame(as_of = as.Date(character()))
	 	
	 	for(j in 1:dim(summary(fit_level)$coefficients)[1])
	 	{
	 		nms = c(nms, c(row.names(summary(fit_level)$coefficients)[j],'t-stat'))
	 		betas = cbind(betas,data.frame(a1 = numeric(),a2 = numeric()))
 		}
 		names(betas) = nms
 	}
 	coeffs = data.frame(as_of = reg_data_clean$as_of[i])
 	for(j in 1:dim(summary(fit_level)$coefficients)[1])
 		coeffs = cbind(coeffs,data.frame(summary(fit_level)$coefficients[j,1],summary(fit_level)$coefficients[j,3]))
 	
 	names(coeffs) = nms	 
 	betas = rbind(betas,coeffs)
# 	print(reg_data_clean$as_of[i])
# 	print(summary(fit_level)$coefficients)
# 	print(summary(fit_level)$r.squared)
	names(betas) = nms
	betas$as_of = as.Date(betas$as_of,as.Date('1970-01-01'))
	
	# oos forecast
	ifc = i #+ fwd_per
	oos_fc = rbind(oos_fc,data.frame(as_of = reg_data_clean$as_of[ifc],act = reg_data_clean$sprd_level_chg[ifc], 
									fc = as.numeric(coeffs[ind_var]) %*% matrix(as.numeric(reg_data_clean[ifc,ind_var]))))
}

betas_slope = c()
nms = c('as_of')
oos_fc_slope = data.frame()
for(i in st_from:dim(reg_data_clean_slope)[1])
{
 	fit_slope = lm(as.formula(paste("sprd_slope_chg ~ ",paste(ind_var_slope,collapse = "+")," - 1")),reg_data_clean_slope[1:(i-fwd_per),])
 	#fit_slope = lm(as.formula(paste("sprd_slope_chg ~ ",paste(ind_var_slope,collapse = "+"))),reg_data_clean_slope[1:(i-fwd_per),])
 	#fit_slope = glm(as.formula(paste("sprd_slope_chg ~ ",paste(ind_var,collapse = "+"))),'gaussian',reg_data_clean_slope[1:(i-fwd_per),])
 	#fit_slope = glm(as.formula(paste("sprd_slope_chg ~ ",paste(ind_var,collapse = "+")," - 1")),'gaussian',reg_data_clean_slope[1:(i-fwd_per),])
 	

 	if (i == st_from)
 	{
	 	betas_slope = data.frame(as_of = as.Date(character()))
	 	
	 	for(j in 1:dim(summary(fit_slope)$coefficients)[1])
	 	{
	 		nms = c(nms, c(row.names(summary(fit_slope)$coefficients)[j],'t-stat'))
	 		betas_slope = cbind(betas_slope,data.frame(a1 = numeric(),a2 = numeric()))
 		}
 		names(betas_slope) = nms
 	}
 	coeffs = data.frame(as_of = reg_data_clean_slope$as_of[i])
 	for(j in 1:dim(summary(fit_slope)$coefficients)[1])
 		coeffs = cbind(coeffs,data.frame(summary(fit_slope)$coefficients[j,1],summary(fit_slope)$coefficients[j,3]))
 	
 	names(coeffs) = nms	 
 	betas_slope = rbind(betas_slope,coeffs)
# 	print(reg_data_clean_slope$as_of[i])
# 	print(summary(fit_slope)$coefficients)
# 	print(summary(fit_slope)$r.squared)
	names(betas_slope) = nms
	betas_slope$as_of = as.Date(betas_slope$as_of,as.Date('1970-01-01'))
	
	# oos forecast
	ifc = i #+ fwd_per
	oos_fc_slope = rbind(oos_fc_slope,data.frame(as_of = reg_data_clean_slope$as_of[ifc],act = reg_data_clean_slope$sprd_slope_chg[ifc], 
									fc = as.numeric(coeffs[ind_var_slope]) %*% matrix(as.numeric(reg_data_clean_slope[ifc,ind_var_slope]))))
}

betas_curv = c()
nms = c('as_of')
oos_fc_curv = data.frame()
for(i in st_from:dim(reg_data_clean_curv)[1])
{
 	fit_curv = lm(as.formula(paste("sprd_curv_chg ~ ",paste(ind_var_curv,collapse = "+")," - 1")),reg_data_clean_curv[1:(i-fwd_per),])
 	#fit_curv = lm(as.formula(paste("sprd_curv_chg ~ ",paste(ind_var_curv,collapse = "+"))),reg_data_clean_curv[1:(i-fwd_per),])
 	#fit_curv = glm(as.formula(paste("sprd_curv_chg ~ ",paste(ind_var,collapse = "+"))),'gaussian',reg_data_clean_curv[1:(i-fwd_per),])
 	#fit_curv = glm(as.formula(paste("sprd_curv_chg ~ ",paste(ind_var,collapse = "+")," - 1")),'gaussian',reg_data_clean_curv[1:(i-fwd_per),])
 	

 	if (i == st_from)
 	{
	 	betas_curv = data.frame(as_of = as.Date(character()))
	 	
	 	for(j in 1:dim(summary(fit_curv)$coefficients)[1])
	 	{
	 		nms = c(nms, c(row.names(summary(fit_curv)$coefficients)[j],'t-stat'))
	 		betas_curv = cbind(betas_curv,data.frame(a1 = numeric(),a2 = numeric()))
 		}
 		names(betas_curv) = nms
 	}
 	coeffs = data.frame(as_of = reg_data_clean_curv$as_of[i])
 	for(j in 1:dim(summary(fit_curv)$coefficients)[1])
 		coeffs = cbind(coeffs,data.frame(summary(fit_curv)$coefficients[j,1],summary(fit_curv)$coefficients[j,3]))
 	
 	names(coeffs) = nms	 
 	betas_curv = rbind(betas_curv,coeffs)
# 	print(reg_data_clean_curv$as_of[i])
# 	print(summary(fit_curv)$coefficients)
# 	print(summary(fit_curv)$r.squared)
	names(betas_curv) = nms
	betas_curv$as_of = as.Date(betas_curv$as_of,as.Date('1970-01-01'))
	
	# oos forecast
	ifc = i #+ fwd_per
	oos_fc_curv = rbind(oos_fc_curv,data.frame(as_of = reg_data_clean_curv$as_of[ifc],act = reg_data_clean_curv$sprd_curv_chg[ifc], 
									fc = as.numeric(coeffs[ind_var_curv]) %*% matrix(as.numeric(reg_data_clean_curv[ifc,ind_var_curv]))))
}

betas_30y = c()
nms = c('as_of')
oos_fc_30y = data.frame()
for(i in st_from:dim(reg_data_clean_30y)[1])
{
 	fit_30y = lm(as.formula(paste("sprd_30y_chg ~ ",paste(ind_var_30y,collapse = "+")," - 1")),reg_data_clean_30y[1:(i-fwd_per),])
 	#fit_30y = lm(as.formula(paste("sprd_30y_chg ~ ",paste(ind_var_30y,collapse = "+"))),reg_data_clean_30y[1:(i-fwd_per),])
 	#fit_30y = glm(as.formula(paste("sprd_30y_chg ~ ",paste(ind_var,collapse = "+"))),'gaussian',reg_data_clean_30y[1:(i-fwd_per),])
 	#fit_30y = glm(as.formula(paste("sprd_30y_chg ~ ",paste(ind_var,collapse = "+")," - 1")),'gaussian',reg_data_clean_30y[1:(i-fwd_per),])
 	

 	if (i == st_from)
 	{
	 	betas_30y = data.frame(as_of = as.Date(character()))
	 	
	 	for(j in 1:dim(summary(fit_30y)$coefficients)[1])
	 	{
	 		nms = c(nms, c(row.names(summary(fit_30y)$coefficients)[j],'t-stat'))
	 		betas_30y = cbind(betas_30y,data.frame(a1 = numeric(),a2 = numeric()))
 		}
 		names(betas_30y) = nms
 	}
 	coeffs = data.frame(as_of = reg_data_clean_30y$as_of[i])
 	for(j in 1:dim(summary(fit_30y)$coefficients)[1])
 		coeffs = cbind(coeffs,data.frame(summary(fit_30y)$coefficients[j,1],summary(fit_30y)$coefficients[j,3]))
 	
 	names(coeffs) = nms	 
 	betas_30y = rbind(betas_30y,coeffs)
# 	print(reg_data_clean_30y$as_of[i])
# 	print(summary(fit_30y)$coefficients)
# 	print(summary(fit_30y)$r.squared)
	names(betas_30y) = nms
	betas_30y$as_of = as.Date(betas_30y$as_of,as.Date('1970-01-01'))
	
	# oos forecast
	ifc = i #+ fwd_per
	oos_fc_30y = rbind(oos_fc_30y,data.frame(as_of = reg_data_clean_30y$as_of[ifc],act = reg_data_clean_30y$sprd_30y_chg[ifc], 
									fc = as.numeric(coeffs[ind_var_30y]) %*% matrix(as.numeric(reg_data_clean_30y[ifc,ind_var_30y]))))
}


#de-mean oos fc
# st = 30 
# oos_fc$fc_adj = oos_fc$fc; oos_fc_slope$fc_adj = oos_fc_slope$fc; oos_fc_curv$fc_adj = oos_fc_curv$fc; 
# for(i in st:dim(oos_fc)[1])
# 	oos_fc$fc_adj[i] = oos_fc$fc[i] - mean(oos_fc$fc[1:i])
#  for(i in st:dim(oos_fc_slope)[1])
#  	oos_fc_slope$fc_adj[i] = oos_fc_slope$fc[i] - mean(oos_fc_slope$fc[1:i])
#  for(i in st:dim(oos_fc_curv)[1])
#  	oos_fc_curv$fc_adj[i] = oos_fc_curv$fc[i] - mean(oos_fc_curv$fc[1:i])
# 
# oos_fc$fc = oos_fc$fc_adj; oos_fc_slope$fc = oos_fc_slope$fc_adj; oos_fc_curv$fc = oos_fc_curv$fc_adj; 
# 		
#print(betas)
start_from = as.Date('2001-01-01')
cat(paste('Level R-squared: ',format(summary(fit_level)$r.squared),'\n',sep=''))
fit = lm(act ~ fc -1,oos_fc[oos_fc$as_of > start_from,])
cat(paste('Level OOS forecast R-squared: ',format(summary(fit)$adj.r.squared),'\n',sep = ''))

cat(paste('Slope R-squared: ',format(summary(fit_slope)$r.squared),'\n',sep=''))
fit = lm(act ~ fc -1,oos_fc_slope)
cat(paste('Slope OOS forecast R-squared: ',format(summary(fit)$adj.r.squared),'\n',sep = ''))

cat(paste('Curvature R-squared: ',format(summary(fit_curv)$r.squared),'\n',sep=''))
fit = lm(act ~ fc -1,oos_fc_curv)
cat(paste('Curvature OOS forecast R-squared: ',format(summary(fit)$adj.r.squared),'\n',sep = ''))

cat(paste('30y spread R-squared: ',format(summary(fit_30y)$r.squared),'\n',sep=''))
fit = lm(act ~ fc -1,oos_fc_30y)
cat(paste('30y spread OOS forecast R-squared: ',format(summary(fit)$adj.r.squared),'\n',sep = ''))


#k_rates = c(8,20,40)
#k_rates = c(4,8,12,16,20,24,28,32,36,40,44,48,52,56,60,64,68,72,76,80)
k_rates = c(4,8,20,40,80,120)

tr_fc = load_tsy_fc(Sys.Date())
tr_term_fc = cal_term_from_pc(tr_fc)
tr_term_fc = data.frame(as_of = tr_term_fc$date,tr_term_fc$term_total[,k_rates])
for(i in 2:(1+length(k_rates)))
{
	names(tr_term_fc)[i] = paste(names(tsy_curve)[2+k_rates[i-1]],'_fc',sep = '')
}

# actual treasury fwd change
tsy_tmp = tsy_curve[,c(1,k_rates+2)]
tsy_act = c()
for(i in 1:length(k_rates))
{
	if( i == 1){
		tsy_act = data.frame(as_of = tsy_tmp$as_of_date[1:(dim(tsy_tmp)[1]-fwd_per)],diff(tsy_tmp[,i+1],lag = fwd_per))
		names(tsy_act)[2] = paste(names(tsy_tmp)[i+1],"_fwd",sep = '')
	}else
	{
		tsy_act = cbind(tsy_act,data.frame(a = diff(tsy_tmp[,i+1],lag = fwd_per)));
		names(tsy_act)[dim(tsy_act)[2]] = paste(names(tsy_tmp)[i+1],"_fwd",sep = '')
	}
}

tsy_perf = merge(tsy_act,tr_term_fc)


stdate = as.Date('2010-11-01')

tsy_perf = tsy_perf[tsy_perf$as_of >= stdate,]
# treasury performance statistics
restsy = data.frame()
iy = grep('fwd',names(tsy_perf))
ix = grep('fc',names(tsy_perf))
for(i in 1:length(iy))
{
	pres = lm(as.formula(paste(names(tsy_perf)[iy[i]]," ~ -1 + ",names(tsy_perf)[ix[i]],sep = '')),tsy_perf)
	restsy = rbind(restsy,data.frame(Tenor = names(tsy_perf)[iy[i]], R2 = summary(pres)$adj.r.squared))
}

# prepare spread forecast
dates = sort(na.exclude(as.Date(intersect(intersect(intersect(oos_fc$as_of,oos_fc_slope$as_of),oos_fc_curv$as_of),oos_fc_30y$as_of))))
mn_fc = data.frame()
for(i in 1:length(dates))
{
	mn_fc = rbind(mn_fc,data.frame(as_of = dates[i],level = oos_fc$fc[which(oos_fc$as_of == dates[i])],
				slope = oos_fc_slope$fc[which(oos_fc_slope$as_of == dates[i])],
				curv = oos_fc_curv$fc[which(oos_fc_curv$as_of == dates[i])],
				sprd_30y = oos_fc_30y$fc[which(oos_fc_30y$as_of == dates[i])]))
}

#mn_spread_term_fc = cal_term_from_pc(mn_fc)

mn_spread_term_fc = cal_term_from_pc_muni(mn_fc)

# combine actual and forecast spreads for selected key points

mn_spread_term_fc = data.frame(as_of = mn_spread_term_fc$date,mn_spread_term_fc$term_total[,k_rates])
for(i in 2:(1+length(k_rates)))
{
	names(mn_spread_term_fc)[i] = paste(names(muni_curve)[2+k_rates[i-1]],'_fc',sep = '')
}

dates <- as.Date(sort(intersect(tsy_curve$month_end_date,muni_curve$month_end_date)))
idx_tsy <- match(dates,tsy_curve$month_end_date)
idx_muni <- match(dates,muni_curve$month_end_date)

spread_perf = data.frame(as_of = as.Date(dates),muni_curve[idx_muni,k_rates + 2] - tsy_curve[idx_tsy,k_rates + 2])

nkr = dim(spread_perf)[2]
for(i in 2:nkr)
{
	t = data.frame(as_of = spread_perf$as_of[1:(dim(spread_perf)[1]-fwd_per)],data = diff(spread_perf[,i],lag = fwd_per))
	names(t)[2] = paste(names(spread_perf)[i],'_fwd',sep = '')
	spread_perf = merge(spread_perf,t,by = 'as_of',all.x = T)
}

spread_perf = merge(spread_perf,mn_spread_term_fc,by = 'as_of',all.y = T)

spread_perf = spread_perf[spread_perf$as_of >= stdate,]
# spread performance statistics
ressp = data.frame()
iy = grep('fwd',names(spread_perf))
ix = grep('fc',names(spread_perf))
for(i in 1:length(iy))
{
	pres = lm(as.formula(paste(names(spread_perf)[iy[i]]," ~ -1 + ",names(spread_perf)[ix[i]],sep = '')),spread_perf)
	ressp = rbind(ressp,data.frame(Tenor = names(spread_perf)[iy[i]], R2 = summary(pres)$adj.r.squared))
}



# curve act vs. forecast
curve_perf = muni_curve[,c(2,2+k_rates)]
names(curve_perf)[1] = 'as_of'
nkr = dim(curve_perf)[2]
for(i in 2:nkr)
{
	t = data.frame(as_of = curve_perf$as_of[1:(dim(curve_perf)[1]-fwd_per)],data = diff(curve_perf[,i],lag = fwd_per))
	names(t)[2] = paste(names(curve_perf)[i],'_fwd',sep = '')
	curve_perf = merge(curve_perf,t,by = 'as_of',all.x = T)
}
# sum up spread and curve term forecast

dates = as.Date(sort(na.exclude(as.Date(intersect(tr_term_fc$as_of,mn_spread_term_fc$as_of)))))
idx_tsy <- match(dates,tr_term_fc$as_of)
idx_muni <- match(dates,mn_spread_term_fc$as_of)
curve_fc = data.frame(as_of = dates,tr_term_fc[idx_tsy,2:(1+length(k_rates))] + mn_spread_term_fc[idx_muni,2:(1+length(k_rates))])
#curve_fc = data.frame(as_of = dates,mn_spread_term_fc[idx_muni,2:(1+length(k_rates))])
#curve_fc = data.frame(as_of = dates,tr_term_fc[idx_tsy,2:(1+length(k_rates))])


curve_perf = merge(curve_perf,curve_fc,by = 'as_of',all.y = T)

curve_perf = curve_perf[curve_perf$as_of >= stdate,]
# curve performance statistics
rescrv = data.frame()
iy = grep('fwd',names(curve_perf))
ix = grep('fc',names(curve_perf))
for(i in 1:length(iy))
{
	pres = lm(as.formula(paste(names(curve_perf)[iy[i]]," ~ -1 + ",names(curve_perf)[ix[i]],sep = '')),curve_perf)
	rescrv = rbind(rescrv,data.frame(Tenor = names(curve_perf)[iy[i]], R2 = summary(pres)$adj.r.squared))
}


# evaluate slope performance

muni_slope = data.frame(as_of = muni_curve$month_end_date, slope = muni_curve$point_120m - muni_curve$point_024m)
muni_slope$slope_fwd = NA
muni_slope$slope_fwd[1:(dim(muni_slope)[1]-fwd_per)] = muni_slope$slope[(fwd_per+1):dim(muni_slope)[1]] - muni_slope$slope[1:(dim(muni_slope)[1]-fwd_per)] # diff(muni_slope$slope,lag = fwd_per)

names(mn_fc)[names(mn_fc) == 'slope'] = 'slope_spread_fc' 
muni_slope = merge(muni_slope,mn_fc[,c(1,3)],by = 'as_of',all.y = T)
names(tr_fc)[names(tr_fc) == 'as_of_date'] = 'as_of'
muni_slope = merge(muni_slope,tr_fc[,c(1,3)],by = 'as_of',all.x = T)


y = unique(format(oos_fc$as_of,'%Y'))
yperf = data.frame()
for(i in 2:(length(y)-1))
{
	if(i == 2)
	{
		f = lm(act ~ -1 + fc,oos_fc[format(oos_fc$as_of,'%Y') == y[2] | format(oos_fc$as_of,'%Y') == y[1],])
	}else
	{
		f = lm(act ~ -1 + fc,oos_fc[format(oos_fc$as_of,'%Y') == y[i],])
	}
	yperf = rbind(yperf,data.frame(year = y[i],beta = summary(f)$coefficients[1],R2 = summary(f)$adj.r.squared))
}