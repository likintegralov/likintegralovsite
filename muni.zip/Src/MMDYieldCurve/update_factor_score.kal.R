#!\\nts0018\bond\ABFI_PROD\QuantApps\R-2.14.2\bin\Rscript

source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.kal.R',sep='') )

get_exposures <- function(sprd)
{
	# map for factor names
	var_map <- c(
	    'sprd_level_dev_lt', 'Spread Level / Long Term',
 	    'sprd_slope_dev_6m', 'Spread Slope / 6M',
 	    'sprd_curv_dev_5y',  'Spread Curvature / 5Y',
 	    'sprd_30y_dev_3y',   'Spread 30Y / 3Y')
 	# map for factor inputs (current values) names (first colunmn) 
 	input_map <- c(
	    'sprd_level', 'Spread Level / Long Term',
 	    'sprd_slope', 'Spread Slope / 6M',
 	    'sprd_curv',  'Spread Curvature / 5Y',
 	    'sprd_30y',   'Spread 30Y / 3Y')
#     stmt <- paste("
#     	select MODEL_NAME,FACTOR_NAME,FACTOR_ID FROM 
#         MODEL_DESCRIPTION a,MODEL_SPECIFICATION b
#         WHERE a.MODEL_NAME in('Muni Spread Level Model','Muni Spread Slope Model','Muni Spread Curvature Model')
#         AND b.MODEL_ID=a.MODEL_ID
#         AND a.VERSION='2.0'
# 	",sep='')
# 	
# 	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
#     outdata <- sqlQuery(channel,query=stmt)
#     odbcClose(channel)
    
	outdata = get_fact_map()
	# level model
    idx <- match(outdata$FACTOR_NAME[outdata$MODEL_NAME=='Muni Spread Level Model'],var_map)
    vars_level <- var_map[idx-1]		# get level model factors names
    idx <- match(outdata$FACTOR_NAME[outdata$MODEL_NAME=='Muni Spread Level Model'],input_map)
    input_level <- input_map[idx-1]		# get level model factors inputs names
    level_entry <- c()
    for(i in 1:length(vars_level)) # loop over factors of level model (currently just one factor)
    {
	    tmp <- data.frame(OBSERVATION_ID='Muni_level',AS_OF=sprd$as_of_date,
	    	FACTOR_ID = outdata$FACTOR_ID[outdata$MODEL_NAME=='Muni Spread Level Model'][i],
	    	FACTOR_EXPOSURE = sprd[,vars_level[i]],  # current value of i-th level model factor
	    	value = sprd[,input_level[i]])			# current value of input that is used to compute model factor. 
	    											# For the current single factor (level deviation from it's long term average), it is the current spread level
		level_entry <- rbind(level_entry,na.exclude(tmp))
    }
    
    # same logic is applied to slope, curvature and 30y model
    idx <- match(outdata$FACTOR_NAME[outdata$MODEL_NAME=='Muni Spread Slope Model'],var_map)
    vars_slope <- var_map[idx-1]
    idx <- match(outdata$FACTOR_NAME[outdata$MODEL_NAME=='Muni Spread Slope Model'],input_map)
    input_slope <- input_map[idx-1]
    slope_entry <- c()
    for(i in 1:length(vars_slope))
    {
	    tmp <- data.frame(OBSERVATION_ID='Muni_slope',AS_OF=sprd$as_of_date,
	    	FACTOR_ID = outdata$FACTOR_ID[outdata$MODEL_NAME=='Muni Spread Slope Model'][i],
	    	FACTOR_EXPOSURE = sprd[,vars_slope[i]],
	    	value = sprd[,input_slope[i]])
		slope_entry <- rbind(slope_entry,na.exclude(tmp))
    }
    
    idx <- match(outdata$FACTOR_NAME[outdata$MODEL_NAME=='Muni Spread Curvature Model'],var_map)
    vars_curv <- var_map[idx-1]
    idx <- match(outdata$FACTOR_NAME[outdata$MODEL_NAME=='Muni Spread Curvature Model'],input_map)
    input_curv <- input_map[idx-1]
    curv_entry <- c()
    for(i in 1:length(vars_curv))
    {
	    tmp <- data.frame(OBSERVATION_ID='Muni_curv',AS_OF=sprd$as_of_date,
	    	FACTOR_ID = outdata$FACTOR_ID[outdata$MODEL_NAME=='Muni Spread Curvature Model'][i],
	    	FACTOR_EXPOSURE = sprd[,vars_curv[i]],
	    	value = sprd[,input_curv[i]])
		curv_entry <- rbind(curv_entry,na.exclude(tmp))
    }
    
    idx <- match(outdata$FACTOR_NAME[outdata$MODEL_NAME=='Muni Spread 30Y Model'],var_map)
    vars_30y <- var_map[idx-1]
    idx <- match(outdata$FACTOR_NAME[outdata$MODEL_NAME=='Muni Spread 30Y Model'],input_map)
    input_30y <- input_map[idx-1]
    a30y_entry <- c()
    for(i in 1:length(vars_30y))
    {
	    tmp <- data.frame(OBSERVATION_ID='Muni_30y',AS_OF=sprd$as_of_date,
	    	FACTOR_ID = outdata$FACTOR_ID[outdata$MODEL_NAME=='Muni Spread 30Y Model'][i],
	    	FACTOR_EXPOSURE = sprd[,vars_30y[i]],
	    	value = sprd[,input_30y[i]])
		a30y_entry <- rbind(a30y_entry,na.exclude(tmp))
    }
    
    res <- rbind(level_entry,slope_entry,curv_entry, a30y_entry)
    
    res
}

get_exposures_old <- function(sprd)
{
	var_map <- c(
	    'mo_sprd_level', 'Spread Level / Short-Term',
	    'mo_sprd_slope', 'Spread Slope / Short-Term',
	    'mo_sprd_curv',  'Spread Curvature / Short-Term',
	    'ltmo_vix',      'Vix / Long-Term')
    
    stmt <- paste("
    	select MODEL_NAME,FACTOR_NAME,FACTOR_ID FROM 
        MODEL_DESCRIPTION a,MODEL_SPECIFICATION b
        WHERE a.MODEL_NAME in('Muni Spread Level Model','Muni Spread Slope Model','Muni Spread Curvature Model')
        AND b.MODEL_ID=a.MODEL_ID
        AND a.VERSION='1.0'
	",sep='')
	
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    outdata <- sqlQuery(channel,query=stmt)
    odbcClose(channel)
    
    idx <- match(outdata$FACTOR_NAME[outdata$MODEL_NAME=='Muni Spread Level Model'],var_map)
    vars_level <- var_map[idx-1]
    level_entry <- c()
    for(i in 1:length(vars_level))
    {
	    tmp <- data.frame(OBSERVATION_ID='Muni_level',AS_OF=sprd$as_of_date,
	    	FACTOR_ID = outdata$FACTOR_ID[outdata$MODEL_NAME=='Muni Spread Level Model'][i],
	    	FACTOR_EXPOSURE = sprd[,vars_level[i]])
		level_entry <- rbind(level_entry,na.exclude(tmp))
    }
    
    idx <- match(outdata$FACTOR_NAME[outdata$MODEL_NAME=='Muni Spread Slope Model'],var_map)
    vars_slope <- var_map[idx-1]
    slope_entry <- c()
    for(i in 1:length(vars_slope))
    {
	    tmp <- data.frame(OBSERVATION_ID='Muni_slope',AS_OF=sprd$as_of_date,
	    	FACTOR_ID = outdata$FACTOR_ID[outdata$MODEL_NAME=='Muni Spread Slope Model'][i],
	    	FACTOR_EXPOSURE = sprd[,vars_slope[i]])
		slope_entry <- rbind(slope_entry,na.exclude(tmp))
    }
    
    idx <- match(outdata$FACTOR_NAME[outdata$MODEL_NAME=='Muni Spread Curvature Model'],var_map)
    vars_curv <- var_map[idx-1]
    curv_entry <- c()
    for(i in 1:length(vars_curv))
    {
	    tmp <- data.frame(OBSERVATION_ID='Muni_curv',AS_OF=sprd$as_of_date,
	    	FACTOR_ID = outdata$FACTOR_ID[outdata$MODEL_NAME=='Muni Spread Curvature Model'][i],
	    	FACTOR_EXPOSURE = sprd[,vars_curv[i]])
		curv_entry <- rbind(curv_entry,na.exclude(tmp))
    }
    
    res <- rbind(level_entry,slope_entry,curv_entry)
    
    res
}


create_asof_map <- function(client_asof,server_asof)
{
    client_asof <- sort(unique(client_asof))
    server_asof <- sort(unique(server_asof))
    
    ret <- client_asof
    for(i in 1:length(client_asof))
    {
        ix <- server_asof<=client_asof[i]
        if(sum(ix)==0) stop('cannot find a match for ',client_asof[i],'\n')
        ret[i] <- max( server_asof[ix])
    }
    
    data.frame(client=client_asof,server=ret)
}

check_loadings <- function(db,exposures)
{
	ok = TRUE
	factor_loading <- load_mmd_factor_loading(db,max(exposures$AS_OF))
    
    map_asof <- create_asof_map(client_asof=exposures$AS_OF,server_asof=factor_loading$loading_asof)
    names(map_asof) <- c('AS_OF','loading_asof')
    exposures <- merge(exposures,map_asof)
	exposures <- merge(exposures,factor_loading,by=c('FACTOR_ID','loading_asof'),all.x=T)
	if(sum(is.na(exposures$FACTOR_LOADING)) > 0)
		ok = FALSE
	ok	
}
 
cal_factor_score <- function(db,exposures)
{
    factor_loading <- load_mmd_factor_loading(db,max(exposures$AS_OF))
    
    map_asof <- create_asof_map(client_asof=exposures$AS_OF,server_asof=factor_loading$loading_asof)
    names(map_asof) <- c('AS_OF','loading_asof')
    exposures <- merge(exposures,map_asof)
    
    exposures <- merge(exposures,factor_loading,by=c('FACTOR_ID','loading_asof'),all.x=T)
    
    #upper bound and lower bound
    exposures$FACTOR_EXPOSURE_used <- exposures$FACTOR_EXPOSURE
    ix <- !is.na(exposures$FACTOR_EXPOSURE) & exposures$FACTOR_EXPOSURE > exposures$FACTOR_UB
    exposures$FACTOR_EXPOSURE_used[ix] <- exposures$FACTOR_UB[ix]
    ix <- !is.na(exposures$FACTOR_EXPOSURE) & exposures$FACTOR_EXPOSURE < exposures$FACTOR_LB
    exposures$FACTOR_EXPOSURE_used[ix] <- exposures$FACTOR_LB[ix]
    
    #factor score calculation:
    # loading is saved to database as a normalized coefficient (multiplied by sd of the factor)
    # factor mean is 0 for all factors  
    # see update_factor_loading.kal.R, function map_results 
    exposures$FACTOR_SCORE <- exposures$FACTOR_LOADING*(exposures$FACTOR_EXPOSURE_used-exposures$FACTOR_MEAN)/exposures$FACTOR_STDEV
    
    exposures
}

populate_factor_scores <- function(scores)
{
	scores <- scores[,c('OBSERVATION_ID','AS_OF','FACTOR_ID','FACTOR_EXPOSURE','FACTOR_SCORE')]
	factor_ids <- sort(unique(scores$FACTOR_ID))
	if(is.null( opt$as_of ) )
	{
		cat('populating exposures from',format(min(scores$AS_OF)),'to',format(max(scores$AS_OF)),'\n')
		stmt <- paste("delete from MODEL_FACTOR_EXPOSURE where FACTOR_ID in (",paste(factor_ids,collapse=","),")",sep='')
		
		channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
	    outdata <- sqlQuery(channel,query=stmt )
	    odbcClose(channel)
	    
		export2db(data=scores,server_type='SQL',server=db_info$Database,db=db_info$InitDB,table='MODEL_FACTOR_EXPOSURE',user=db_info$User,psw=db_info$Password,na='')
	}else #only populate last month, if it is not already in
	{
		cat('populating exposures as of',format(max(scores$AS_OF)),'\n')
		stmt <- paste("delete from MODEL_FACTOR_EXPOSURE 
			where AS_OF='",format(max(scores$AS_OF),'%d-%b-%Y'),"' and
			FACTOR_ID in (",paste(factor_ids,collapse=","),")
			",sep='')
			
		channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
	    outdata <- sqlQuery(channel,query=stmt )
	    odbcClose(channel)
	    
		export2db(data=scores[scores$AS_OF==max(scores$AS_OF),],server_type='SQL',server=db_info$Database,db=db_info$InitDB,table='MODEL_FACTOR_EXPOSURE',user=db_info$User,psw=db_info$Password,na='')	
	}
	invisible()
}

# save inputs for factor computaion to the database
populate_factor_inputs <- function(ex)
{
	# each factor of in the model is computed as a current value of model variable (like spread level, slope, etc.) minus its averge over some time period (long term, 6m, etc.)
	# using current factor value and the current value of the model variable, we compute hitorical average. Thus we get both inputs for factor computation. 
	ex = ex[,c('AS_OF','FACTOR_ID','value','FACTOR_EXPOSURE')]
	ex[,'FACTOR_EXPOSURE'] = ex$value - ex$FACTOR_EXPOSURE		# compute historical average as difference between model varibale value and fator value 
	names(ex)[3:4] = c('CURRENT_VALUE','HIST_VALUE')
	
	factor_ids <- sort(unique(ex$FACTOR_ID))
	
	cat('populating inputs as of',format(max(ex$AS_OF)),'\n')
	stmt <- paste("delete from MUNI..FACTOR_INPUTS 
			where AS_OF='",format(max(ex$AS_OF),'%d-%b-%Y'),"' and
			FACTOR_ID in (",paste(factor_ids,collapse=","),")
			",sep='')
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
	    outdata <- sqlQuery(channel,query=stmt )
	    odbcClose(channel)
	export2db(data=ex[ex$AS_OF==max(ex$AS_OF),],server_type='SQL',server=db_info$Database,db='MUNI',table='FACTOR_INPUTS',user=db_info$User,psw=db_info$Password,na='')	
}

################################################################################
#source('H:/SVN/Muni/v1.0/Src/MMDYieldCurve/update_factor_score.kal.R')
#source('C:/SVN/Quant_Model-SQLServer/Muni/v1.0/Src/MMDYieldCurve/update_factor_score.kal.R')
setwd(paste(Sys.getenv('ABFI_DATA_REPOSITORY'),'\\Muni\\v1.0\\Input',sep='') )

library('getopt')
opt = getopt(matrix(
    c(
    'help', 'h', 0, "logical",
    'as_of','d', 2, "character",
    'db',	's', 2, "character"
    ),ncol=4,byrow=TRUE)
)

if ( !is.null(opt$help) ) {
  self = 'Rscript update_factor_loading.R'
  cat(paste("
    Usage: ",self,"  [--as_of date] [--all] [--help]  
        as_of : as_of date in yyyy-mm-dd format. if missing, update factor 
                scores for all dates. Optional      
        db    : Database server to run the script on (PRD/QA/DEV).
        help  : Show help.  Optional
    Example   : RScript update_factor_loading.R  --db QA --as_of 2012-02-15
  ",sep=""))
  q(status=1)
}

if ( is.null(opt$db) ) opt$db <- 'QA'
################################################################################

library(RODBC)
db_info <- get_db_info(db=opt$db)

# load curves and spread
load('MuniSprd.RData')
sprd <- sprd[sprd$month_end_date>='2005-04-30',]

opt$as_of = as.Date('2018-09-30')

# if as of date provided, verify that data exists for that date and discard all other dates (sprd will consist of 1 row)
if(!is.null(opt$as_of)) 
{
	#print(max(sprd$as_of_date))
	ix <- sprd$as_of_date==opt$as_of  # if as of date provided, check if the data available for the date
	if(sum(ix)==0) stop('no data available as of ',opt$as_of,'\nlast date with data is ',format(max(sprd$as_of_date)),'\n')
	sprd <- sprd[ix,]	
}

# compute current values of factors that are used to forecast spread change (level deviation from long term average and others)
exposures <- get_exposures(sprd)

# save inputs for current factors computation to the database
populate_factor_inputs(exposures)

if(!check_loadings(db_info,exposures))  # verify that there are calibrated loadings for all factors
{
	cat('loadings are not available as of',format(opt$as_of),'\n')
	q(status=0)
}
# multipy loadings and factor values to get forecast contribution (score) from each factor (for 1-factor models it is equal to total forecast)
scores <- cal_factor_score(db_info,exposures)

# save factor scores to the database
populate_factor_scores(scores)

cat(date(),'Done.\n')

q(status=0)

#source('H:/dev/Quant_Model-SQLServer/Muni/v1.0/Src/MMDYieldCurve/update_factor_score.R')
################################################################################
################################################################################



