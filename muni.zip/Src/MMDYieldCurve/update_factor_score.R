#!\\nts0018\bond\ABFI_PROD\QuantApps\R-2.14.2\bin\Rscript

source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.kal.R',sep='') )

get_exposures <- function(sprd)
{
	var_map <- c(
	    'sprd_level_dev_lt', 'Spread Level / Long Term',
 	    'sprd_slope_dev_6m', 'Spread Slope / 6M',
 	    'sprd_curv_dev_5y',  'Spread Curvature / 5Y',
 	    'sprd_30y_dev_3y',   'Spread 30Y / 3Y')
 	
#     stmt <- paste("
#     	select MODEL_NAME,FACTOR_NAME,FACTOR_ID FROM 
#         MODEL_DESCRIPTION a,MODEL_SPECIFICATION b
#         WHERE a.MODEL_NAME in('Muni Spread Level Model','Muni Spread Slope Model','Muni Spread Curvature Model')
#         AND b.MODEL_ID=a.MODEL_ID
#         AND a.VERSION='2.0'
# 	",sep='')
# 	
# 	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
#     outdata <- sqlQuery(channel,query=stmt)
#     odbcClose(channel)
    
	outdata = get_fact_map()
	
    idx <- match(outdata$FACTOR_NAME[outdata$MODEL_NAME=='Muni Spread Level Model'],var_map)
    vars_level <- var_map[idx-1]
    level_entry <- c()
    for(i in 1:length(vars_level))
    {
	    tmp <- data.frame(OBSERVATION_ID='Muni_level',AS_OF=sprd$as_of_date,
	    	FACTOR_ID = outdata$FACTOR_ID[outdata$MODEL_NAME=='Muni Spread Level Model'][i],
	    	FACTOR_EXPOSURE = sprd[,vars_level[i]])
		level_entry <- rbind(level_entry,na.exclude(tmp))
    }
    
    idx <- match(outdata$FACTOR_NAME[outdata$MODEL_NAME=='Muni Spread Slope Model'],var_map)
    vars_slope <- var_map[idx-1]
    slope_entry <- c()
    for(i in 1:length(vars_slope))
    {
	    tmp <- data.frame(OBSERVATION_ID='Muni_slope',AS_OF=sprd$as_of_date,
	    	FACTOR_ID = outdata$FACTOR_ID[outdata$MODEL_NAME=='Muni Spread Slope Model'][i],
	    	FACTOR_EXPOSURE = sprd[,vars_slope[i]])
		slope_entry <- rbind(slope_entry,na.exclude(tmp))
    }
    
    idx <- match(outdata$FACTOR_NAME[outdata$MODEL_NAME=='Muni Spread Curvature Model'],var_map)
    vars_curv <- var_map[idx-1]
    curv_entry <- c()
    for(i in 1:length(vars_curv))
    {
	    tmp <- data.frame(OBSERVATION_ID='Muni_curv',AS_OF=sprd$as_of_date,
	    	FACTOR_ID = outdata$FACTOR_ID[outdata$MODEL_NAME=='Muni Spread Curvature Model'][i],
	    	FACTOR_EXPOSURE = sprd[,vars_curv[i]])
		curv_entry <- rbind(curv_entry,na.exclude(tmp))
    }
    
    idx <- match(outdata$FACTOR_NAME[outdata$MODEL_NAME=='Muni Spread 30Y Model'],var_map)
    vars_30y <- var_map[idx-1]
    a30y_entry <- c()
    for(i in 1:length(vars_30y))
    {
	    tmp <- data.frame(OBSERVATION_ID='Muni_30y',AS_OF=sprd$as_of_date,
	    	FACTOR_ID = outdata$FACTOR_ID[outdata$MODEL_NAME=='Muni Spread 30Y Model'][i],
	    	FACTOR_EXPOSURE = sprd[,vars_30y[i]])
		a30y_entry <- rbind(a30y_entry,na.exclude(tmp))
    }
    
    res <- rbind(level_entry,slope_entry,curv_entry, a30y_entry)
    
    res
}

get_exposures_old <- function(sprd)
{
	var_map <- c(
	    'mo_sprd_level', 'Spread Level / Short-Term',
	    'mo_sprd_slope', 'Spread Slope / Short-Term',
	    'mo_sprd_curv',  'Spread Curvature / Short-Term',
	    'ltmo_vix',      'Vix / Long-Term')
    
    stmt <- paste("
    	select MODEL_NAME,FACTOR_NAME,FACTOR_ID FROM 
        MODEL_DESCRIPTION a,MODEL_SPECIFICATION b
        WHERE a.MODEL_NAME in('Muni Spread Level Model','Muni Spread Slope Model','Muni Spread Curvature Model')
        AND b.MODEL_ID=a.MODEL_ID
        AND a.VERSION='1.0'
	",sep='')
	
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    outdata <- sqlQuery(channel,query=stmt)
    odbcClose(channel)
    
    idx <- match(outdata$FACTOR_NAME[outdata$MODEL_NAME=='Muni Spread Level Model'],var_map)
    vars_level <- var_map[idx-1]
    level_entry <- c()
    for(i in 1:length(vars_level))
    {
	    tmp <- data.frame(OBSERVATION_ID='Muni_level',AS_OF=sprd$as_of_date,
	    	FACTOR_ID = outdata$FACTOR_ID[outdata$MODEL_NAME=='Muni Spread Level Model'][i],
	    	FACTOR_EXPOSURE = sprd[,vars_level[i]])
		level_entry <- rbind(level_entry,na.exclude(tmp))
    }
    
    idx <- match(outdata$FACTOR_NAME[outdata$MODEL_NAME=='Muni Spread Slope Model'],var_map)
    vars_slope <- var_map[idx-1]
    slope_entry <- c()
    for(i in 1:length(vars_slope))
    {
	    tmp <- data.frame(OBSERVATION_ID='Muni_slope',AS_OF=sprd$as_of_date,
	    	FACTOR_ID = outdata$FACTOR_ID[outdata$MODEL_NAME=='Muni Spread Slope Model'][i],
	    	FACTOR_EXPOSURE = sprd[,vars_slope[i]])
		slope_entry <- rbind(slope_entry,na.exclude(tmp))
    }
    
    idx <- match(outdata$FACTOR_NAME[outdata$MODEL_NAME=='Muni Spread Curvature Model'],var_map)
    vars_curv <- var_map[idx-1]
    curv_entry <- c()
    for(i in 1:length(vars_curv))
    {
	    tmp <- data.frame(OBSERVATION_ID='Muni_curv',AS_OF=sprd$as_of_date,
	    	FACTOR_ID = outdata$FACTOR_ID[outdata$MODEL_NAME=='Muni Spread Curvature Model'][i],
	    	FACTOR_EXPOSURE = sprd[,vars_curv[i]])
		curv_entry <- rbind(curv_entry,na.exclude(tmp))
    }
    
    res <- rbind(level_entry,slope_entry,curv_entry)
    
    res
}


load_factor_loading <- function(as_of)
{
	fmap = get_fact_map()
	
	q = paste("select * from FIQModel..MODEL_FACTOR_LOADING where FACTOR_ID in (",paste(fmap[,dim(fmap)[2]],collapse = ','),")
				 AND AS_OF <='",format(as_of,'%d-%b-%Y'),"'
        		",sep='')
        		
#     stmt <- paste("
#         select c.*
#         from MODEL_DESCRIPTION a,MODEL_SPECIFICATION b,MODEL_FACTOR_LOADING c
#         WHERE a.MODEL_NAME in 
#         ('Muni Spread Level Model','Muni Spread Slope Model','Muni Spread Curvature Model')
#         AND a.VERSION='2.0'
#         AND b.MODEL_ID=a.MODEL_ID
#         AND c.FACTOR_ID=b.FACTOR_ID
#         AND AS_OF <='",format(as_of,'%d-%b-%Y'),"'
#         ",sep='')
        
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    factor_loading <- sqlQuery(channel,query=q)
    odbcClose(channel)
    factor_loading$AS_OF <- as.Date(factor_loading$AS_OF)
    names(factor_loading)[2] <- 'loading_asof'
    factor_loading
}

create_asof_map <- function(client_asof,server_asof)
{
    client_asof <- sort(unique(client_asof))
    server_asof <- sort(unique(server_asof))
    
    ret <- client_asof
    for(i in 1:length(client_asof))
    {
        ix <- server_asof<=client_asof[i]
        if(sum(ix)==0) stop('cannot find a match for ',client_asof[i],'\n')
        ret[i] <- max( server_asof[ix])
    }
    
    data.frame(client=client_asof,server=ret)
}

cal_factor_score <- function(exposures)
{
    factor_loading <- load_factor_loading(max(exposures$AS_OF))
    
    map_asof <- create_asof_map(client_asof=exposures$AS_OF,server_asof=factor_loading$loading_asof)
    names(map_asof) <- c('AS_OF','loading_asof')
    exposures <- merge(exposures,map_asof)
    
    exposures <- merge(exposures,factor_loading,by=c('FACTOR_ID','loading_asof'),all.x=T)
    
    #upper bound and lower bound
    exposures$FACTOR_EXPOSURE_used <- exposures$FACTOR_EXPOSURE
    ix <- !is.na(exposures$FACTOR_EXPOSURE) & exposures$FACTOR_EXPOSURE > exposures$FACTOR_UB
    exposures$FACTOR_EXPOSURE_used[ix] <- exposures$FACTOR_UB[ix]
    ix <- !is.na(exposures$FACTOR_EXPOSURE) & exposures$FACTOR_EXPOSURE < exposures$FACTOR_LB
    exposures$FACTOR_EXPOSURE_used[ix] <- exposures$FACTOR_LB[ix]
    
    #factor score calculation
    exposures$FACTOR_SCORE <- exposures$FACTOR_LOADING*(exposures$FACTOR_EXPOSURE_used-exposures$FACTOR_MEAN)/exposures$FACTOR_STDEV
    
    exposures
}

populate_factor_scores <- function(scores)
{
	scores <- scores[,c('OBSERVATION_ID','AS_OF','FACTOR_ID','FACTOR_EXPOSURE','FACTOR_SCORE')]
	factor_ids <- sort(unique(scores$FACTOR_ID))
	if(is.null( opt$as_of ) )
	{
		cat('populating exposures from',format(min(scores$AS_OF)),'to',format(max(scores$AS_OF)),'\n')
		stmt <- paste("delete from MODEL_FACTOR_EXPOSURE where FACTOR_ID in (",paste(factor_ids,collapse=","),")",sep='')
		
		channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
	    outdata <- sqlQuery(channel,query=stmt )
	    odbcClose(channel)
	    
		export2db(data=scores,server_type='SQL',server=db_info$Database,db=db_info$InitDB,table='MODEL_FACTOR_EXPOSURE',user=db_info$User,psw=db_info$Password,na='')
	}else #only populate last month, if it is not already in
	{
		cat('populating exposures as of',format(max(scores$AS_OF)),'\n')
		stmt <- paste("delete from MODEL_FACTOR_EXPOSURE 
			where AS_OF='",format(max(scores$AS_OF),'%d-%b-%Y'),"' and
			FACTOR_ID in (",paste(factor_ids,collapse=","),")
			",sep='')
			
		channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
	    outdata <- sqlQuery(channel,query=stmt )
	    odbcClose(channel)
	    
		export2db(data=scores[scores$AS_OF==max(scores$AS_OF),],server_type='SQL',server=db_info$Database,db=db_info$InitDB,table='MODEL_FACTOR_EXPOSURE',user=db_info$User,psw=db_info$Password,na='')	
	}
	invisible()
}

################################################################################
#source('H:/SVN/Muni/v1.0/Src/MMDYieldCurve/update_factor_score.R')
setwd(paste(Sys.getenv('ABFI_DATA_REPOSITORY'),'\\Muni\\v1.0\\Input',sep='') )

library('getopt')
opt = getopt(matrix(
    c(
    'help', 'h', 0, "logical",
    'as_of','d', 2, "character",
    'db',	's', 2, "character"
    ),ncol=4,byrow=TRUE)
)

if ( !is.null(opt$help) ) {
  self = 'Rscript update_factor_loading.R'
  cat(paste("
    Usage: ",self,"  [--as_of date] [--all] [--help]  
        as_of : as_of date in yyyy-mm-dd format. if missing, update factor 
                scores for all dates. Optional      
        db    : Database server to run the script on (PRD/QA/DEV).
        help  : Show help.  Optional
    Example   : RScript update_factor_loading.R  --db QA --as_of 2012-02-15
  ",sep=""))
  q(status=1)
}

if ( is.null(opt$db) ) opt$db <- 'QA'
################################################################################

library(RODBC)
db_info <- get_db_info(db=opt$db)

load('MuniSprd.RData')
sprd <- sprd[sprd$month_end_date>='2005-04-30',]

#opt$as_of = as.Date('2017-04-30')

if(!is.null(opt$as_of)) 
{
	#print(max(sprd$as_of_date))
	ix <- sprd$as_of_date==opt$as_of
	if(sum(ix)==0) stop('no data available as of ',opt$as_of,'\nlast date with data is ',format(max(sprd$as_of_date)),'\n')
	sprd <- sprd[ix,]	
}

exposures <- get_exposures(sprd)

scores <- cal_factor_score(exposures)

populate_factor_scores(scores)

cat(date(),'Done.\n')

q(status=0)

#source('H:/dev/Quant_Model-SQLServer/Muni/v1.0/Src/MMDYieldCurve/update_factor_score.R')
################################################################################
################################################################################



