#!\\nts0018\bond\ABFI_PROD\QuantApps\R-2.14.2\bin\Rscript

source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.kal.R',sep='') )

# this function gets regression results and transforms to a database loadable dataframe
map_results <- function(coefs)
{
	var_map <- c(
	    'sprd_level_dev_lt', 'Spread Level / Long Term',
 	    'sprd_slope_dev_6m', 'Spread Slope / 6M',
 	    'sprd_curv_dev_5y',  'Spread Curvature / 5Y',
 	    'sprd_30y_dev_3y',   'Spread 30Y / 3Y')
 	
	# mapping between factor names and factor numric index, defined in muni_utiltiy
    outdata = get_fact_map()
    
    res <- c()
    #loop through regression results. i goes through number of dates
    for(i in 1:length(coefs))
    {
	    coef_level <- coefs[[i]]$fit_level$coefficients  # get factor regression coefficients ('loadings' or 'betas') for level (just one factor 'sprd_level_dev_lt' for the current 1-factor model)
	    idx <- match(names(coef_level),var_map)
	    idx <- match(var_map[idx+1],outdata$FACTOR_NAME[outdata$MODEL_NAME=='Muni Spread Level Model']) # index to get factor numeric ID from mapping (for 1-factor model it's always 1). Numeric ID is stored to database. 
	    level_sdev = apply(coefs[[i]]$fit_level$x,2,sd)													# compute factor standard deviation
	    level_entry <- data.frame(FACTOR_ID=outdata$FACTOR_ID[outdata$MODEL_NAME=='Muni Spread Level Model'][idx],  # create a dataframe to store the line to be written to the database
	    	AS_OF=as.Date(names(coefs)[i]),
	    	FACTOR_LOADING=coef_level*level_sdev,		# store standardized coefficients (impact of 1 sd movement in the factor)
	    	FACTOR_MEAN=0, # colMeans(coefs[[i]]$fit_level$x),
	    	FACTOR_STDEV=level_sdev,
	    	FACTOR_LB=coefs[[i]]$lb[,names(coef_level)],
	    	FACTOR_UB=coefs[[i]]$ub[,names(coef_level)])
	    
	    # same operations for slope, curvature and 30y point		
		coef_slope <- coefs[[i]]$fit_slope$coefficients
	    idx <- match(names(coef_slope),var_map)
	    idx <- match(var_map[idx+1],outdata$FACTOR_NAME[outdata$MODEL_NAME=='Muni Spread Slope Model'])
	    slope_sdev = apply(coefs[[i]]$fit_slope$x,2,sd)
	    slope_entry <- data.frame(FACTOR_ID=outdata$FACTOR_ID[outdata$MODEL_NAME=='Muni Spread Slope Model'][idx],
	    	AS_OF=as.Date(names(coefs)[i]),
	    	FACTOR_LOADING=coef_slope*slope_sdev,
	    	FACTOR_MEAN=0,	# do not de-mean, since not helpful on backtest
	    	FACTOR_STDEV=slope_sdev,
	    	FACTOR_LB=coefs[[i]]$lb[,names(coef_slope)],
	    	FACTOR_UB=coefs[[i]]$ub[,names(coef_slope)])	 
	    	
		coef_curv <- coefs[[i]]$fit_curv$coefficients
	    idx <- match(names(coef_curv),var_map)
	    idx <- match(var_map[idx+1],outdata$FACTOR_NAME[outdata$MODEL_NAME=='Muni Spread Curvature Model'])
	    curv_sdev = apply(coefs[[i]]$fit_curv$x,2,sd)
	    curv_entry <- data.frame(FACTOR_ID=outdata$FACTOR_ID[outdata$MODEL_NAME=='Muni Spread Curvature Model'][idx],
	    	AS_OF=as.Date(names(coefs)[i]),
	    	FACTOR_LOADING=coef_curv*curv_sdev,
	    	FACTOR_MEAN=0,
	    	FACTOR_STDEV=curv_sdev,
	    	FACTOR_LB=coefs[[i]]$lb[,names(coef_curv)],
	    	FACTOR_UB=coefs[[i]]$ub[,names(coef_curv)])
	    	
	    coef_30y <- coefs[[i]]$fit_30y$coefficients
	    idx <- match(names(coef_30y),var_map)
	    idx <- match(var_map[idx+1],outdata$FACTOR_NAME[outdata$MODEL_NAME=='Muni Spread 30Y Model'])
	    a30y_sdev = apply(coefs[[i]]$fit_30y$x,2,sd)
	    a30y_entry <- data.frame(FACTOR_ID=outdata$FACTOR_ID[outdata$MODEL_NAME=='Muni Spread 30Y Model'][idx],
	    	AS_OF=as.Date(names(coefs)[i]),
	    	FACTOR_LOADING=coef_30y*a30y_sdev,
	    	FACTOR_MEAN=0,
	    	FACTOR_STDEV=a30y_sdev,
	    	FACTOR_LB=coefs[[i]]$lb[,names(coef_30y)],
	    	FACTOR_UB=coefs[[i]]$ub[,names(coef_30y)])
	    		
		res <- rbind(res,level_entry,slope_entry,curv_entry,a30y_entry)
    }
    res
}
    	    
map_results_old <- function(coefs)
{
	var_map <- c(
	    'mo_sprd_level', 'Spread Level / Short-Term',
	    'mo_sprd_slope', 'Spread Slope / Short-Term',
	    'mo_sprd_curv',  'Spread Curvature / Short-Term',
	    'ltmo_vix',      'Vix / Long-Term')
    
    stmt <- paste("
    	select MODEL_NAME,FACTOR_NAME,FACTOR_ID FROM 
        MODEL_DESCRIPTION a,MODEL_SPECIFICATION b
        WHERE a.MODEL_NAME in('Muni Spread Level Model','Muni Spread Slope Model','Muni Spread Curvature Model')
        AND b.MODEL_ID=a.MODEL_ID
        AND a.VERSION='1.0'
	",sep='')
	
	channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    outdata <- sqlQuery(channel,query=stmt)
    odbcClose(channel)
    
    res <- c()
    for(i in 1:length(coefs))
    {
	    coef_level <- centered.coef(coefs[[i]]$fit_level)[-1]
	    idx <- match(names(coef_level),var_map)
	    idx <- match(var_map[idx+1],outdata$FACTOR_NAME[outdata$MODEL_NAME=='Muni Spread Level Model'])
	    level_entry <- data.frame(FACTOR_ID=outdata$FACTOR_ID[outdata$MODEL_NAME=='Muni Spread Level Model'][idx],
	    	AS_OF=as.Date(names(coefs)[i]),
	    	FACTOR_LOADING=coef_level,
	    	FACTOR_MEAN=coefs[[i]]$fit_level$xm,
	    	FACTOR_STDEV=coefs[[i]]$fit_level$scales,
	    	FACTOR_LB=coefs[[i]]$lb[,names(coef_level)],
	    	FACTOR_UB=coefs[[i]]$ub[,names(coef_level)])
	    	
		coef_slope <- centered.coef(coefs[[i]]$fit_slope)[-1]
	    idx <- match(names(coef_slope),var_map)
	    idx <- match(var_map[idx+1],outdata$FACTOR_NAME[outdata$MODEL_NAME=='Muni Spread Slope Model'])
	    slope_entry <- data.frame(FACTOR_ID=outdata$FACTOR_ID[outdata$MODEL_NAME=='Muni Spread Slope Model'][idx],
	    	AS_OF=as.Date(names(coefs)[i]),
	    	FACTOR_LOADING=coef_slope,
	    	FACTOR_MEAN=coefs[[i]]$fit_slope$xm,
	    	FACTOR_STDEV=coefs[[i]]$fit_slope$scales,
	    	FACTOR_LB=coefs[[i]]$lb[,names(coef_slope)],
	    	FACTOR_UB=coefs[[i]]$ub[,names(coef_slope)])	 
	    	
		coef_curv <- centered.coef(coefs[[i]]$fit_curv)[-1]
	    idx <- match(names(coef_curv),var_map)
	    idx <- match(var_map[idx+1],outdata$FACTOR_NAME[outdata$MODEL_NAME=='Muni Spread Curvature Model'])
	    curv_entry <- data.frame(FACTOR_ID=outdata$FACTOR_ID[outdata$MODEL_NAME=='Muni Spread Curvature Model'][idx],
	    	AS_OF=as.Date(names(coefs)[i]),
	    	FACTOR_LOADING=coef_curv,
	    	FACTOR_MEAN=coefs[[i]]$fit_curv$xm,
	    	FACTOR_STDEV=coefs[[i]]$fit_curv$scales,
	    	FACTOR_LB=coefs[[i]]$lb[,names(coef_curv)],
	    	FACTOR_UB=coefs[[i]]$ub[,names(coef_curv)])
	    	
		res <- rbind(res,level_entry,slope_entry,curv_entry)
    }
    res
}

populate_factor_loading <- function(res)
{
	factor_ids <- sort(unique(res$FACTOR_ID))
	# if as of date is not provided, save entire history
	if( is.null( opt$as_of ) )
	{
		cat('populating loadings from',format(min(res$AS_OF)),'to',format(max(res$AS_OF)),'\n')
		stmt <- paste("delete from MODEL_FACTOR_LOADING where FACTOR_ID in (",paste(factor_ids,collapse=","),")",sep='')
		
		channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
	    sqlQuery(channel,query=stmt )
	    odbcClose(channel)
	    
		export2db(data=res,server_type='SQL',server=db_info$Database,db=db_info$InitDB,table='MODEL_FACTOR_LOADING',user=db_info$User,psw=db_info$Password,na='')
	}else #if as of date provided, populate only last month, if it is not already in
	{
		cat('populating loadings as of',format(max(res$AS_OF)),'\n')		
		stmt <- paste("delete from MODEL_FACTOR_LOADING 
			where AS_OF='",format(max(res$AS_OF),'%d-%b-%Y'),"' and
			FACTOR_ID in (",paste(factor_ids,collapse=","),")
			",sep='')
			
		channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
	    sqlQuery(channel,query=stmt )
	    odbcClose(channel)
	    
		export2db(data=res[res$AS_OF==max(res$AS_OF),],server_type='SQL',server=db_info$Database,db=db_info$InitDB,table='MODEL_FACTOR_LOADING',user=db_info$User,psw=db_info$Password,na='')	
	}
	invisible()
}

################################################################################
################################################################################
library('getopt')
opt = getopt(matrix(
    c(
    'db',   's', 2, "character",
    'as_of','d', 2, "character",
    'help', 'h', 0, "logical"
    ),ncol=4,byrow=TRUE)
)

if ( !is.null(opt$help) ) {
  self = 'Rscript update_factor_loading.R'
  cat(paste("
    Usage: ",self,"  [--all] [--help]  
    	db   : Database server to run the script on (PRD/QA/DEV).
    	as_of: as_of date in yyyy-mm-dd format. if missing, update 
    	       factor loadings for all month-end dates. Optional
        help : Show help.  Optional
    Example  : RScript update_factor_loading.R  --db QA --as_of 2012-02-29
  ",sep=""))
  q(status=1)
}

if ( is.null(opt$db) ) opt$db <- 'PRD'

################################################################################
#source('H:/SVN/Muni/v1.0/Src/MMDYieldCurve/update_factor_loading.kal.R')
#source('C:/SVN/Quant_Model-SQLServer/Muni/v1.0/Src/MMDYieldCurve/update_factor_loading.kal.R')
setwd(paste(Sys.getenv('ABFI_DATA_REPOSITORY'),'\\Muni\\v1.0\\Input',sep='') )

library(RODBC)
db_info <- get_db_info(db=opt$db)

# load curves and spreads
load('MuniSprd.RData')

if(dim(sprd)[1] < 4)
{
	cat('spread history is too short\n') # spread history has to be long enough for at least one 3m forward change to be available
	q(status=0)
}
# add a field with 3m forward date for each line
sprd$fwd_date = as.Date('1970-01-01')
sprd$fwd_date[1:(dim(sprd)[1] - 3)] = sprd$as_of_date[4:dim(sprd)[1]]
#remove months with no data
ix <- rowSums(!is.na(sprd[,grep('_chg_fwd3m',names(sprd))]))==4
sprd <- sprd[ix,]

#always use month-end dates when update model factor loadings
dates <- sort(unique(sprd$fwd_date))
dates <- dates[dates>='2009-01-31']

#opt$as_of = as.Date('2018-09-30')

if(!is.null(opt$as_of)) 
{
	dates <- dates[dates==opt$as_of]
	if(length(dates)==0) {
		cat('no regression data available as of',format(opt$as_of),'\n')
		q(status=0)
	}
}

#x_vars <- c('mo_sprd_level','mo_sprd_slope','mo_sprd_curv','ltmo_vix')
x_vars <- c('sprd_level_dev_lt','sprd_slope_dev_6m','sprd_curv_dev_5y','sprd_30y_dev_3y')

#3-month forecasts
coefs <- list()
# if as_of date is provided then dates have only single date. Otherwise model is calibrated for all available dates.
for(i in 1:length(dates))
{
	ix <- sprd$fwd_date <= dates[i]
	reg_data <- na.exclude(sprd[ix,])
	
	if(dim(reg_data)[1] < 1)
	{
		cat("No regression data!\n")
		q(status = 0)
	}
#	for(xvar in x_vars) reg_data[,xvar] <- winsorise(reg_data[,xvar],lb=0.025,ub=0.975)
	
# linear regression of 3m forward changes of spread level, slope, curvature and 30y point on respective factors. See AAA spread model presentation.
	fit_level <- lm( sprd_level_chg_fwd3m ~ sprd_level_dev_lt - 1,data=reg_data,x = T)
	fit_slope <- lm( sprd_slope_chg_fwd3m ~ sprd_slope_dev_6m - 1, data=reg_data,x = T)
	fit_curv <- lm( sprd_curv_chg_fwd3m ~ sprd_curv_dev_5y - 1, data=reg_data,x = T)
	fit_30y = lm( sprd_30y_chg_fwd3m ~ sprd_30y_dev_3y - 1,data = reg_data,x = T)
	
	lb <- t(apply(reg_data[,x_vars],MARGIN=2,FUN=min,na.rm=T))
	ub <- t(apply(reg_data[,x_vars],MARGIN=2,FUN=max,na.rm=T))
	
	# put results in a list	
	coefs[[format(dates[i])]] <- list(fit_level=fit_level,fit_slope=fit_slope,fit_curv=fit_curv,fit_30y = fit_30y,lb=lb,ub=ub)
}
#convert results into database format
res <- map_results(coefs)
# save results to database
populate_factor_loading(res)
 
cat(date(),'Done.\n')

q(status=0)

#source('H:/dev/Quant_Model-SQLServer/Muni/v1.0/Src/MMDYieldCurve/update_factor_loading.R')
################################################################################
################################################################################



