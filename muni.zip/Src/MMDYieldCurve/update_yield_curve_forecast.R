#!\\nts0018\bond\ABFI_PROD\QuantApps\R-2.14.2\bin\Rscript
source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Muni\\v1.0\\Src\\ExcessReturn\\muni_utility.R',sep='') )
			
load_tsy_fc <- function(asof)
{
	# 3 month forecast
	stmt <- paste("select AS_OF_DATE, ",
        "POINT_120M/2 AS TSY_LEVEL_FC, ",
        "(POINT_120M - POINT_024M)/2 AS TSY_SLOPE_FC, ", 
        "(-2*POINT_024M + POINT_003M + POINT_120M)/2 AS TSY_CURVATURE_FC ",
        "FROM YIELD_CURVE_FORECAST_WIDE_VIEW ",
        "WHERE YC_NAME='Treasury' ",
        "and MODEL_ID = 17 ",
        "and FORECAST_HORIZON=6 ",
        "and CURRENCY='USD' ",
        "and AS_OF_DATE<='",format(asof,'%d-%b-%Y'),"'
        ",sep='')
        
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    tsy_fc <- sqlQuery(channel,query=stmt)
    odbcClose(channel)
    
    if(nrow(tsy_fc)==0) stop('no tsy forecst for ',asof,'\n',stmt)
    names(tsy_fc)<-casefold(names(tsy_fc),upper=F)
    tsy_fc$as_of_date <- as.Date(tsy_fc$as_of_date)
    #apply tax
 	tax = get_tax_rate(db_info)
	names(tax)[1] = 'as_of_date'
	tsy_fc = merge(tsy_fc,tax, by = 'as_of_date',all.x = T)
	    
	tsy_fc[,2:(dim(tsy_fc)[2] - 1)] = (1 - tsy_fc$tax/100)*tsy_fc[,2:(dim(tsy_fc)[2] - 1)]	
	   	# remove tax rate for compartibility
   	tsy_fc = tsy_fc[,-dim(tsy_fc)[2]]
    tsy_fc
}

sprd_factor_exposure <- function(asof)
{
	fmap = get_fact_map()
	
	q = paste(" select * from FIQModel..MODEL_FACTOR_EXPOSURE where FACTOR_ID in (",paste(fmap[,dim(fmap)[2]],collapse = ','),")
				and AS_OF<='",format(asof,'%d-%b-%Y'),"'
        		",sep='')
        		
#     stmt <- paste("
#         select c.*
#         from MODEL_DESCRIPTION a,MODEL_SPECIFICATION b,MODEL_FACTOR_EXPOSURE c
#         WHERE a.MODEL_NAME in 
#         ('Muni Spread Level Model','Muni Spread Slope Model','Muni Spread Curvature Model')
#         AND a.VERSION='2.0'
#         AND b.MODEL_ID=a.MODEL_ID
#         AND c.FACTOR_ID=b.FACTOR_ID
#         and AS_OF<='",format(asof,'%d-%b-%Y'),"'
#         ",sep='')
     
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    res <- sqlQuery(channel,query=q)
    odbcClose(channel)
    names(res) <- casefold(names(res),F)
    res$observation_id <- as.character(res$observation_id)
    res$as_of <- as.Date(res$as_of)
    
    res
}

load_muni_vol <- function(asof)
{
    cat('loading muni volatility curve...\n')
    stmt <- paste("
        select *
        from YIELD_CURVE_TIMESERIES
        where
        YC_NAME = 'MunAaahVol'
        and ( (IS_END_OF_MONTH='Y' and AS_OF_DATE<='",format(asof,'%d-%b-%Y'),"')
        or AS_OF_DATE='",format(asof,'%d-%b-%Y'),"')        
    ",sep='')
    
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    outdata <- sqlQuery(channel,query=stmt)
    odbcClose(channel)
    
    names(outdata) <- casefold(names(outdata),upper=F)
    outdata$as_of <- month.end(as.Date(outdata$as_of_date))
    
    names(outdata) <- gsub('point_','vol_',names(outdata))
    
    if(max(outdata$as_of) < asof)
    {
        ix <- outdata$as_of==max(outdata$as_of)
        d <- outdata[ix,]
        d$as_of <- asof
        outdata <- rbind(outdata,d)
    }
	if(max(outdata$as_of) > asof)
    {
        ix <- outdata$as_of==max(outdata$as_of)
        outdata$as_of[ix] <- asof        
    }

    outdata <- outdata[,c('as_of',names(outdata)[grep('vol_',names(outdata))])]
    names(outdata)[1] <- 'as_of_date'
    outdata
}

sprd_fc <- function(asof)
{
    sprd <- sprd_factor_exposure(asof)
    
    #aggregate up to get level and slope forecast
    agg <- aggregate(sprd[,'factor_score'],by=list(observation_id=sprd$observation_id,as_of_date=sprd$as_of), FUN = sum, na.rm=T)
    
    ix <- grep('level',agg$observation_id)
    res_level <- agg[ix,]
    names(res_level)[3] <- 'sprd_level_fc'
    
    ix <- grep('slope',agg$observation_id)    
    res_slope <- agg[ix,]
    names(res_slope)[3] <- 'sprd_slope_fc'
    
    ix <- grep('curv',agg$observation_id)
    res_curv <- agg[ix,]
    names(res_curv)[3] <- 'sprd_curvature_fc'
    
    ix <- grep('30y',agg$observation_id)
    res_30y <- agg[ix,]
    names(res_30y)[3] <- 'sprd_30y_fc'
    
    outdata <- merge(res_level[,c('as_of_date','sprd_level_fc')],res_slope[,c('as_of_date','sprd_slope_fc')])
    outdata <- merge(outdata,res_curv[,c('as_of_date','sprd_curvature_fc')])
    outdata <- merge(outdata,res_30y[,c('as_of_date','sprd_30y_fc')])
    
    #take last day of each month
    outdata$me <- month.end(outdata$as_of_date)
	outdata <- sort.data.frame(outdata,by=~me-as_of_date)
	idx <- match(sort(unique(outdata$me)),outdata$me)
	outdata <- outdata[idx,]
    
    outdata[,-match('me',names(outdata))]    
}

load_crv_loading <- function()
{
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    crv_loading <- sqlQuery(channel,query="select * from YIELD_CURVE_LOADING where YC_NAME='Treasury' and CURRENCY='ALL' and VERSION='2.1' order by MATURITY" )
    odbcClose(channel)
    names(crv_loading) <- casefold(names(crv_loading),F)
    crv_loading$term <- crv_loading$maturity*12
    crv_loading <- crv_loading[,c('term','level_loading','slope_loading','curvature_loading')]
    crv_loading
}

cal_roll_return <- function(ret_data,dur)
{    
    n <- length(vars_ac)
    yld_roll <- (ret_data[,vars_ac[1:(n-1)]] - ret_data[,vars_ac[2:n]])/0.25 # annualized 3m change in yields
 
    roll <- -(dur[,2:n]*2/3 + dur[,1:(n-1)]*1/3)*yld_roll[,1:(n-1)]
    #add first two columns
    roll <- cbind(point_003m=rep(0,nrow(ret_data)),roll)
       
}

cal_term_return <- function(ret_data,dur)
{
    crv <- load_crv_loading()
    
    vars_fc <- c('tsy_level_fc','tsy_slope_fc','tsy_curvature_fc','sprd_level_fc','sprd_slope_fc','sprd_curvature_fc')
    vars_loading <- c('level_loading','slope_loading','curvature_loading','level_loading','slope_loading','curvature_loading')
    
    term_fc <- c('term_tsy_level','term_tsy_slope','term_tsy_curvature','term_sprd_level','term_sprd_slope','term_sprd_curvature')
    
    n<-length(vars_ac)
    
    for(i in 1:length(vars_fc))
    {
        yld_fc <- as.matrix(ret_data[,vars_fc[i]]) %*% t(crv[,vars_loading[i]])
    #    assign(term_fc[i], -dur[,1:n] * yld_fc[,1:n])
        #annualized from 3m to 12m
    #    assign(term_fc[i],get(term_fc[i])/3*12)
        assign(term_fc[i],yld_fc/3*12)
    }
    
    
    # override forecast beyond 10y with linear interpolation between 10y and 30y model forecast
	term_sprd = term_sprd_level + term_sprd_slope + term_sprd_curvature
    ix = 40:120
    xout = seq(120,360,3)
    for(i in 1:dim(term_sprd)[1])
	    term_sprd[i,ix] = approx(c(120,360),c(term_sprd[i,40],ret_data[i,names(ret_data) == 'sprd_30y_fc']/3*12),xout)$y

    term_total = -dur[,1:n]*(term_tsy_level + term_tsy_slope + term_tsy_curvature + term_sprd)
       
    list(term_tsy_level=-dur[,1:n]*term_tsy_level,term_tsy_slope=-dur[,1:n]*term_tsy_slope,term_tsy_curvature=-dur[,1:n]*term_tsy_curvature,
    	 term_sprd_level=-dur[,1:n]*term_sprd_level,term_sprd_slope=-dur[,1:n]*term_sprd_slope,term_sprd_curvature=-dur[,1:n]*term_sprd_curvature,
    	 term_total=term_total,
    	 term_tsy = -dur[,1:n]*(term_tsy_level + term_tsy_slope + term_tsy_curvature),
    	 term_sprd = -dur[,1:n]*term_sprd)
}

cal_conv_return <- function(ret_data,cvx)
{
	vars_ac <- grep('point_',names(ret_data))
    vars_vol <- grep('vol',names(ret_data))
    n <- length(vars_vol)
    #use 0.9 multiplier
    conv <- 0.5*cvx[,3:n]*(ret_data[,vars_ac[3:n]] * ret_data[,vars_vol[3:n]])^2
    conv <- cbind(point_003m=rep(0,nrow(ret_data)),point_006m=rep(0,nrow(ret_data)),conv)
    conv[,c('point_003m','point_006m','point_009m','point_012m')] <- 0
    conv
}

populate_yield_curve_forecast <- function(res,db_info)
{
    res <- sort.data.frame(res,by=~as_of+maturity)
     
    model_id <- res$model_id[1]
    
    if(is.null(opt$as_of))
    {
	    cat('populating yield curve forecasts from',format(min(res$as_of)),'to',format(max(res$as_of)),'\n')
        stmt <- paste("delete from MODEL_FORECAST_YIELD_CURVE where MODEL_ID =",model_id,sep='')
    }else
    {
	    cat('populating yield curve forecasts as of',format(max(res$as_of)),'\n')
        res <- res[res$as_of==max(res$as_of),]
        stmt <- paste("delete from MODEL_FORECAST_YIELD_CURVE where MODEL_ID =",model_id," and AS_OF='",format(res$as_of[1],'%d-%b-%Y'),"'",sep='')
    }
    
    cat('deleting existing entries...\n')
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    sqlQuery(channel,query=stmt )
    odbcClose(channel)
    
    names(res) <- casefold(names(res),T)
    export2db(data=res,server_type='SQL',server=db_info$Database,db=db_info$InitDB,table='MODEL_FORECAST_YIELD_CURVE',user=db_info$User,psw=db_info$Password,na='')
    invisible()
}

################################################################################
################################################################################
#
library('getopt')
opt = getopt(matrix(
    c(
    'help', 'h', 0, "logical",
    'db',	's', 2, "character",
    'as_of','d', 2, "character"
    ),ncol=4,byrow=TRUE)
)

if ( !is.null(opt$help) ) {
  self = 'RScript update_yield_curve_forecast.R'
  cat(paste("
    Usage: ",self,"  [--as_of date] [--all] [--help]  
        db    : Database server to run the script on (PRD/QA/DEV).
        as_of : as_of date in yyyy-mm-dd format.
                if missing, update factor scores for all dates. Optional 
        help  : Show help.  Optional
    Example   : RScript update_yield_curve_forecast.R --db QA --as_of 2012-02-15
  ",sep=""))
  q(status=1)
}

if ( is.null(opt$db) ) opt$db <- 'QA'
##################################################################
##################################################################
#source('H:/SVN/Muni/v1.0/Src/MMDYieldCurve/update_yield_curve_forecast.R')
setwd(paste(Sys.getenv('ABFI_DATA_REPOSITORY'),'\\Muni\\v1.0\\Input',sep='') )

library(RODBC)
library(timeDate)
# Get database credentials
db_info <- get_db_info(db=opt$db)
opt$as_of = as.Date('2017-08-31')

# retrieve tsy_yield_curve muni_yield_curve loaded from YIELD_CURVE_TIMESERIES in load_data.R
load('MuniSprd.RData')

as_of <- max(sprd$as_of)
if(!is.null(opt$as_of)) as_of <- as.Date(opt$as_of)

muni_vol <- load_muni_vol(as_of)    

#determine if as_of is a business month end
d2end = as.numeric(month.end(as_of) - as_of)
month_end = T
if(d2end > 0)
for(i in 1:d2end)
	{if(isBizday(as.timeDate(as_of + i))) {month_end = F; break}}


tsy_fc = load_tsy_fc(as_of)
# check if treasury forecast is available intra-month
stale = as.numeric(as_of - max(tsy_fc$as_of_date))
if(stale > 0 & stale <31)
{
	#if not, use the last month end
	tsy_fc$as_of_date[tsy_fc$as_of_date == max(tsy_fc$as_of_date)] = as_of
}
	
muni_fc <- merge(sprd_fc(as_of),tsy_fc)

if( as_of > max(muni_fc$as_of_date) ) stop('data as of ',format(as_of),' not available')

intramonth = (format(as_of,'%m') == format(as_of + 1,'%m'))
if(intramonth) muni_yield_curve$month_end_date[muni_yield_curve$as_of_date == as_of] = as_of

muni_yield_curve = muni_yield_curve[,2:dim(muni_yield_curve)[2]]
names(muni_yield_curve)[1] = 'as_of_date'

ret_data <- merge(muni_fc,muni_yield_curve,all.x=T)
ret_data <- merge(ret_data,muni_vol,all.x=T)

vars_ac <- names(ret_data)[grep('point_',names(ret_data))]
vars_fc <- names(ret_data)[grep('_fc',names(ret_data))]
#change unit from percent(%) to unity
ret_data[,c(vars_fc,vars_ac)] <- ret_data[,c(vars_fc,vars_ac)]/100

vars_fc = vars_fc[-which(vars_fc == 'sprd_30y_fc')] # remove 30y point forecast

maturities <- matrix( seq(3,360,3)/12,nrow(ret_data),length(vars_ac),byrow=1)
    
dur <- par_bond_dur(ret_data[,vars_ac],ret_data[,vars_ac],maturities)
cvx <- par_bond_cvx(ret_data[,vars_ac],ret_data[,vars_ac],maturities)
roll <- cal_roll_return(ret_data,dur)
term <- cal_term_return(ret_data[,1:8],dur)

conv <- cal_conv_return(ret_data,cvx)
# converting semiannual compounding rates to annual
yld_fixed  <- (1+ret_data[,vars_ac]/2)^2-1

ret_fc <- yld_fixed + roll + term$term_total # + conv #remove convexity
 
res <- c()
#6m,2,5,10,20,30yr
for(i in c(0.5,2,5,10,20,30)*4)
{  
    d <- data.frame(yc_name='Muni',model_id=8,currency='USD',
    	maturity=i/4,as_of=ret_data$as_of_date,yield=ret_data[,vars_ac[i]],
    	duration=dur[,vars_ac[i]],forecast_horizon=3,
    	yield_change=-term$term_total[,vars_ac[i]]/dur[,vars_ac[i]]/4,
    	ret_total=ret_fc[,vars_ac[i]],ret_yield=yld_fixed[,vars_ac[i]],
    	ret_roll=roll[,vars_ac[i]],ret_convexity= 0, # conv[,vars_ac[i]],
    	ret_term=term$term_total[,vars_ac[i]],
    	ret_term_tsy_level=term$term_tsy_level[,vars_ac[i]],
    	ret_term_tsy_slope=term$term_tsy_slope[,vars_ac[i]],
    	ret_term_tsy_curvature=term$term_tsy_curvature[,vars_ac[i]],
    	ret_term_sprd_level=term$term_sprd_level[,vars_ac[i]],
    	ret_term_sprd_slope=term$term_sprd_slope[,vars_ac[i]],
    	ret_term_sprd_curvature=term$term_sprd_curvature[,vars_ac[i]])
    res <- rbind(res,d)
}

populate_yield_curve_forecast(res,db_info)

##################################################################
##################################################################
#save 3-month returns for muni bond excess return calculation
#actual 3-month returns
m <- nrow(ret_data)
n <- length(vars_ac)

#this is price return
ret_ac <- par_bond_price(ret_data[1:(m-3),vars_ac[2:n]],ret_data[4:m,vars_ac[1:(n-1)]],maturities[1:(m-3),2:n]-3/12) - 1 

#add first column
ret_ac <- cbind(point_003m=rep(0,nrow(ret_ac)),ret_ac)
#add carry return
carry_ac <- (yld_fixed[1:(m-3),vars_ac])/12*3

ret_ac <- ret_ac + carry_ac

#now save them
ret_ac <- as.data.frame(ret_ac)
ret_ac$as_of_date <- ret_data[1:(m-3),c('as_of_date')]
names(ret_ac) <- gsub('point','fwd3m_ac',names(ret_ac))
#if last day is intra-month, last 3m actual return should be NA
if(as_of < last.business.day (month.end(as_of)) ) ret_ac <- ret_ac[-nrow(ret_ac),]

ret_fc <- as.data.frame(ret_fc/12*3) #<-convert to 3-month
ret_fc$as_of_date <- ret_data[,c('as_of_date')]
names(ret_fc) <- gsub('point','fwd3m_fc',names(ret_fc))

yld_fixed = as.data.frame(yld_fixed/12*3) #<-convert to 3-month
yld_fixed$as_of_date <- ret_data[,c('as_of_date')]
names(yld_fixed) <- gsub('point','fwd3m_fc',names(yld_fixed))

roll = as.data.frame(roll/12*3) #<-convert to 3-month
roll$as_of_date <- ret_data[,c('as_of_date')]
names(roll) <- gsub('point','fwd3m_fc',names(roll))

term_fc = as.data.frame(term$term_total/12*3) #<-convert to 3-month
term_fc$as_of_date <- ret_data[,c('as_of_date')]
names(term_fc) <- gsub('point','fwd3m_fc',names(term_fc))

term_tsy_fc = as.data.frame(term$term_tsy/12*3) #<-convert to 3-month
term_tsy_fc$as_of_date <- ret_data[,c('as_of_date')]
names(term_tsy_fc) <- gsub('point','fwd3m_fc',names(term_tsy_fc))

term_sprd_fc = as.data.frame(term$term_sprd/12*3) #<-convert to 3-month
term_sprd_fc$as_of_date <- ret_data[,c('as_of_date')]
names(term_sprd_fc) <- gsub('point','fwd3m_fc',names(term_sprd_fc))

conv = as.data.frame(conv/12*3) #<-convert to 3-month
conv$as_of_date <- ret_data[,c('as_of_date')]
names(conv) <- gsub('point','fwd3m_fc',names(conv))

dur <- as.data.frame(dur)
dur$as_of_date <- ret_data[,c('as_of_date')]
names(dur) <- gsub('point','dur',names(dur))

ret_fc <- ret_fc[,c('as_of_date','fwd3m_fc_003m','fwd3m_fc_006m','fwd3m_fc_024m','fwd3m_fc_060m','fwd3m_fc_120m','fwd3m_fc_240m','fwd3m_fc_360m')]
ret_ac <- ret_ac[,c('as_of_date','fwd3m_ac_003m','fwd3m_ac_006m','fwd3m_ac_024m','fwd3m_ac_060m','fwd3m_ac_120m','fwd3m_ac_240m','fwd3m_ac_360m')]
conv <- conv[,c('as_of_date','fwd3m_fc_003m','fwd3m_fc_006m','fwd3m_fc_024m','fwd3m_fc_060m','fwd3m_fc_120m','fwd3m_fc_240m','fwd3m_fc_360m')]
yld_fixed <- yld_fixed[,c('as_of_date','fwd3m_fc_003m','fwd3m_fc_006m','fwd3m_fc_024m','fwd3m_fc_060m','fwd3m_fc_120m','fwd3m_fc_240m','fwd3m_fc_360m')]
roll <- roll[,c('as_of_date','fwd3m_fc_003m','fwd3m_fc_006m','fwd3m_fc_024m','fwd3m_fc_060m','fwd3m_fc_120m','fwd3m_fc_240m','fwd3m_fc_360m')]
term_fc <- term_fc[,c('as_of_date','fwd3m_fc_003m','fwd3m_fc_006m','fwd3m_fc_024m','fwd3m_fc_060m','fwd3m_fc_120m','fwd3m_fc_240m','fwd3m_fc_360m')]
term_tsy_fc <- term_tsy_fc[,c('as_of_date','fwd3m_fc_003m','fwd3m_fc_006m','fwd3m_fc_024m','fwd3m_fc_060m','fwd3m_fc_120m','fwd3m_fc_240m','fwd3m_fc_360m')]
term_sprd_fc <- term_sprd_fc[,c('as_of_date','fwd3m_fc_003m','fwd3m_fc_006m','fwd3m_fc_024m','fwd3m_fc_060m','fwd3m_fc_120m','fwd3m_fc_240m','fwd3m_fc_360m')]
dur <- dur[,c('as_of_date','dur_003m','dur_006m','dur_024m','dur_060m','dur_120m','dur_240m','dur_360m')]

save(ret_fc,ret_ac,dur,yld_fixed,roll,term_fc,conv,term_tsy_fc,term_sprd_fc,file='MuniParBondRet.RData')
##################################################################
##################################################################

cat(date(),'Done.\n')

q(status=0)

#source('C:/SVN/Quant_Model-SQLServer/Muni/v1.0/Src/MMDYieldCurve/update_yield_curve_forecast.R')

###############################################################################
###############################################################################