#!\\nts0018\bond\QuantApps\R-2.14.2\bin\Rscript

source(paste(Sys.getenv('ABFI_MODEL_HOME'),'\\Utility\\R_Splus\\utility.R',sep='') )

load_vix <- function(as_of)
{
	stmt <- paste("select * from FIQModel.dbo.QM_DATA where PARAMETER_ID=49 and VALUE_DATE<='",format(as_of,'%d-%b-%Y'),"'",sep='')
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    vix <- sqlQuery(channel,stmt)
    odbcClose(channel)
    names(vix) <- casefold(names(vix),F)
    vix$as_of_date <- as.Date(vix$value_date)
    
    ix <- weekdays(vix$as_of_date) %in% c('Saturday','Sunday')
    vix <- vix[!ix,]
    
    vix <- sort.data.frame(vix,by=~as_of_date)
    
    vix$vix_1w <- movavg(vix$value,wgt=rep(1,5))
    vix$vix_6m <- movavg(vix$value,wgt=rep(1,126))
    vix$vix_5yr <- movavg(vix$value,wgt=rep(1,1250))
    
    vix$stmo_vix <- vix$vix_1w - vix$vix_6m
    vix$ltmo_vix <- vix$vix_1w - vix$vix_5yr
    
    vix$month_end_date <- month.end(vix$as_of_date)
    
    vix <- sort.data.frame(vix,by=~month_end_date - as_of_date)
    
    idx <- match(sort(unique(vix$month_end_date)),vix$month_end_date)    

    vix <- vix[idx,c('as_of_date','month_end_date','stmo_vix','ltmo_vix')]
}

load_tsy_yield_curve <- function(as_of)
{
    cat('loading lehman fitted treasury yield curve...\n')
    stmt <- paste("
        select *
        FROM YIELD_CURVE_TIMESERIES
        WHERE
        YC_NAME = 'LgtParBond'
        AND COUNTRY='US'
        and ( (IS_END_OF_MONTH='Y' and AS_OF_DATE<='",format(as_of,'%d-%b-%Y'),"')
        or AS_OF_DATE='",format(as_of,'%d-%b-%Y'),"')
        ORDER BY AS_OF_DATE
    ",sep='')
    
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    outdata <- sqlQuery(channel,query=stmt)
    odbcClose(channel)
    
    names(outdata)<-casefold(names(outdata),upper=F)
    outdata$as_of_date <- as.Date(outdata$as_of_date)
    outdata$month_end_date <- month.end(outdata$as_of_date)
    
    vars <- names(outdata)[grep('point',names(outdata))]
    outdata <- outdata[,c('as_of_date','month_end_date',vars)]
    
    outdata   
        
}

load_MMD_yield_curve <- function(as_of)
{
    cat('loading MMD AAA yield curve...\n')
    stmt <- paste("
        select *
        from YIELD_CURVE_TIMESERIES
        where
        YC_NAME = 'MunAaaSpln'
        and ( (IS_END_OF_MONTH='Y' and AS_OF_DATE<='",format(as_of,'%d-%b-%Y'),"')
        or AS_OF_DATE='",format(as_of,'%d-%b-%Y'),"')
        ORDER BY AS_OF_DATE
    ",sep='')
    
    channel <- odbcDriverConnect(paste('DRIVER=SQL Server;SERVER=',db_info$Database,';DataBase=',db_info$InitDB,';uid=',db_info$User,';pwd=',db_info$Password,sep=''))
    outdata <- sqlQuery(channel,query=stmt )
    odbcClose(channel)
    
    names(outdata)<-casefold(names(outdata),upper=F)
    outdata$as_of_date <- as.Date(outdata$as_of_date)
    outdata$month_end_date <- month.end(outdata$as_of_date)
    
    vars <- names(outdata)[grep('point',names(outdata))]
    outdata <- outdata[,c('as_of_date','month_end_date',vars)]
    
    outdata
} 

merge_yields <- function(tsy,muni)
{    
    dates <- intersect(tsy$month_end_date,muni$month_end_date)
    idx_tsy <- match(dates,tsy$month_end_date)
    idx_muni <- match(dates,muni$month_end_date)
    
    muni_sprd <- muni[idx_muni,-(1:2)] - 0.65*tsy[idx_tsy,-(1:2)]
    sprd <- cbind(tsy[idx_tsy,c('as_of_date','month_end_date')],
		data.frame(sprd_level = muni_sprd$point_120m,
		sprd_slope = muni_sprd$point_120m - muni_sprd$point_024m,
		sprd_curv  = 2*muni_sprd$point_060m - muni_sprd$point_024m - muni_sprd$point_120m) )
	sprd
}

################################################################################
################################################################################
library('getopt')
opt = getopt(matrix(
    c(
    'db',   's', 2, "character",
    'as_of','d', 2, "character",
    'help', 'h', 0, "logical"
    ),ncol=4,byrow=TRUE)
)

if ( !is.null(opt$help) ) {
  self = 'Rscript load_data.R'
  cat(paste("
    Usage: ",self,"  [--as_of date] [--help]  
        db    : Database server to run the script on (PRD/QA/DEV).
        as_of : as_of date in yyyy-mm-dd format. default to last business date. 
                Optional      
        help  : Show help.  Optional
    Example   : RScript load_data.R --db QA --as_of 2012-02-15
  ",sep=""))
  q(status=1)
}

if ( is.null(opt$db) ) opt$db <- 'QA'
if ( is.null(opt$as_of) ) { require(tis); opt$as_of <- as.Date( previousBusinessDay(Sys.Date())) }
as_of <- as.Date(opt$as_of)
as_of = as.Date('2016-01-11')

################################################################################
#source('H:/SVN/Muni/v1.0/Src/MMDYieldCurve/load_data.R')

setwd(paste(Sys.getenv('ABFI_DATA_REPOSITORY'),'\\Muni\\v1.0\\Input',sep='') )

library(RODBC)
db_info <- get_db_info(db=opt$db)

cat('\nLoading data as of ',format(as_of),'...\n',sep='')

tsy_yield_curve <- load_tsy_yield_curve(as_of)

muni_yield_curve <- load_MMD_yield_curve(as_of)
 
sprd <- merge_yields(tsy_yield_curve,muni_yield_curve)

if( max(sprd$as_of_date) != as_of ) stop('data is not available as of ',format(as_of),'\n')

vars <- c('sprd_level','sprd_slope','sprd_curv')

sprd <- sort.data.frame(sprd,by=~-month_end_date)

sprd[,paste(vars,'_chg_fwd3m',sep='')] <- movdiff(sprd[,vars],lag=3,index=rep(1,nrow(sprd)),fill=NA) * (-1)
sprd[,paste(vars,'_chg_fwd1m',sep='')] <- movdiff(sprd[,vars],lag=1,index=rep(1,nrow(sprd)),fill=NA) * (-1)

sprd <- sort.data.frame(sprd,by=~month_end_date)

sprd[,paste('dif_',vars,sep='')] <- movdiff(sprd[,vars],lag=1,index=rep(1,nrow(sprd)),fill=NA)
sprd[,paste('mo_',vars,sep='')] <- movavg(sprd[,paste('dif_',vars,sep='')],wgt=1:12,index=rep(1,nrow(sprd)))

# level deviation from long term average
for(i in 1:dim(sprd)[1])
{
	sprd$sprd_level_dev_lt[i] = sprd$sprd_level[i] - mean(sprd$sprd_level[1:i])
}

# slope deviation from 6m average (slope reversion)
lb = 6
sprd$sprd_slope_dev_6m = NA
for(i in lb:dim(sprd)[1])
{
	sprd$sprd_slope_dev_6m[i] = sprd$sprd_slope[i] - mean(sprd$sprd_slope[(i-lb+1):i])
}

# curvature deviation from term average (curvature reversion)
lb = 60
sprd$sprd_curv_dev_5y = NA
for(i in lb:dim(sprd)[1])
{
	sprd$sprd_curv_dev_5y[i] = sprd$sprd_curv[i] - mean(sprd$sprd_curv[(i-lb+1):i])
}

#process intra-month calulation
pct_month <- min(1,as.numeric(format(as_of,'%d')) / as.numeric(format(last.business.day( month.end(as_of) ),'%d')) )

if(pct_month < 1)
{
    ix <- sprd$as_of==max(sprd$as_of)
    idx <- match(sprd$as_of[ix],sprd$as_of)
    
    sprd[idx-3,paste(vars,'_chg_fwd3m',sep='')] <- NA
    sprd[idx-1,paste(vars,'_chg_fwd1m',sep='')] <- NA
    
    
    wgt <- c(12,12:1-pct_month)
    sprd$mo_sprd_level[idx] <- sum(sprd$dif_sprd_level[idx:(idx-12)]*wgt)/sum(wgt)
    sprd$mo_sprd_slope[idx] <- sum(sprd$dif_sprd_slope[idx:(idx-12)]*wgt)/sum(wgt)
    sprd$mo_sprd_curv[idx] <- sum(sprd$dif_sprd_curv[idx:(idx-12)]*wgt)/sum(wgt)    
}

vix <- load_vix(as_of)
sprd <- merge(sprd,vix[,-1],all.x=T)


save(muni_yield_curve,tsy_yield_curve,sprd,file='MuniSprd.RData')

cat(date(),'Done.\n')

q(status=0)
#source('H:/dev/Quant_Model-SQLServer/Muni/v1.0/Src/MMDYieldCurve/load_data.R')
################################################################################
################################################################################



